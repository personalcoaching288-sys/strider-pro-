/* Protection de la saisie, sans rechargement ni modification des valeurs. */
(function () {
  "use strict";
  let last = null,
    selection = null,
    busy = false;
  function editable(el) {
    return !!(
      el &&
      el.isConnected &&
      !el.disabled &&
      !el.readOnly &&
      (el instanceof HTMLTextAreaElement ||
        (el instanceof HTMLInputElement &&
          ![
            "hidden",
            "file",
            "checkbox",
            "radio",
            "button",
            "submit",
            "reset",
            "color",
            "range",
          ].includes(el.type)))
    );
  }
  function active() {
    let el = document.activeElement;
    while (el && el.shadowRoot && el.shadowRoot.activeElement) el = el.shadowRoot.activeElement;
    return el;
  }
  function visible(el) {
    if (!editable(el) || !el.getClientRects().length) return false;
    const r = el.getBoundingClientRect(),
      x = Math.max(0, Math.min(innerWidth - 1, r.left + r.width / 2)),
      y = Math.max(0, Math.min(innerHeight - 1, r.top + r.height / 2));
    if (r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth) return false;
    let root = el.getRootNode(),
      host = el;
    while (root.host) {
      host = root.host;
      root = host.getRootNode();
    }
    const top = document.elementFromPoint(x, y);
    if (top !== host && !host.contains(top)) return false;
    const local = el.getRootNode();
    if (local.host && local.elementFromPoint) {
      const hit = local.elementFromPoint(x, y);
      if (hit !== el && !el.contains(hit)) return false;
    }
    return true;
  }
  function remember(el) {
    if (!editable(el)) return;
    last = el;
    try {
      selection = {
        start: el.selectionStart,
        end: el.selectionEnd,
        direction: el.selectionDirection,
      };
    } catch (e) {
      selection = null;
    }
  }
  async function recover() {
    if (busy) return;
    const el = editable(active()) ? active() : last;
    if (!visible(el)) return;
    const caret = el === last ? selection : null;
    busy = true;
    try {
      if (window.yhDisk?.restoreInputFocus) await window.yhDisk.restoreInputFocus();
      if (!visible(el)) return;
      el.focus({ preventScroll: true });
      if (caret && typeof caret.start === "number")
        try {
          el.setSelectionRange(caret.start, caret.end, caret.direction || "none");
        } catch (e) {}
      remember(el);
    } catch (e) {
      console.warn("Rétablissement du focus impossible");
    } finally {
      busy = false;
    }
  }
  ["focusin", "input", "keyup"].forEach((type) =>
    document.addEventListener(type, (e) => remember(e.composedPath()[0]), true),
  );
  document.addEventListener("selectionchange", () => remember(active()));
  // Un clic ordinaire doit utiliser le focus natif du champ, sans aller-retour Electron.
  // F6 et le rétablissement après un dialogue restent disponibles ci-dessous.
  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key === "F6" && !e.isComposing) {
        e.preventDefault();
        remember(active());
        recover();
      }
    },
    true,
  );
  if (window.yhDisk?.onRestoreInputFocus) window.yhDisk.onRestoreInputFocus(recover);
})();
