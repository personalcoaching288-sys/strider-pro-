(function () {
  "use strict";
  const PANEL_ID = "dashboardPanel";
  const pad = (n) => String(n).padStart(2, "0");
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const safe = (v) =>
    typeof escapeHtml === "function"
      ? escapeHtml(String(v || ""))
      : String(v || "").replace(
          /[&<>"']/g,
          (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
        );
  const fmtDate = (d, opts) => new Intl.DateTimeFormat("fr-FR", opts).format(d);
  function mondayOf(date) {
    const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const n = (d.getDay() + 6) % 7;
    d.setDate(d.getDate() - n);
    return d;
  }
  function sessionDate(s) {
    return String((s && s.date) || "").slice(0, 10);
  }
  function dashboardData() {
    let programs = [];
    try {
      programs = Array.isArray(programsIndex) ? programsIndex : [];
    } catch (e) {}
    let groups = [];
    try {
      groups = asStore && Array.isArray(asStore.groups) ? asStore.groups : [];
    } catch (e) {}
    let profiles = [];
    try {
      profiles = Array.isArray(athleteProfiles) ? athleteProfiles : [];
    } catch (e) {}
    return { programs, groups, profiles };
  }
  const compactNav = () => window.matchMedia("(max-width:1000px)").matches;
  function syncNavAccessibility() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) return;
    panel.querySelectorAll(".yh-nav-main").forEach((b) => {
      b.title = b.querySelector(".yh-nav-text")?.textContent || "Menu";
      b.setAttribute(
        "aria-expanded",
        String(b.closest(".yh-nav-group").classList.contains("open")),
      );
    });
    const toggle = panel.querySelector('[onclick="toggleDashboardSidebar()"]');
    if (toggle) {
      toggle.title = compactNav()
        ? "Ouvrir / fermer le menu latéral"
        : "Réduire / agrandir le menu latéral";
      toggle.setAttribute("aria-label", toggle.title);
      toggle.setAttribute(
        "aria-expanded",
        String(
          compactNav()
            ? panel.classList.contains("yh-nav-expanded")
            : !panel.classList.contains("yh-sidebar-collapsed"),
        ),
      );
    }
  }
  window.toggleDashboardSidebar = function () {
    const p = document.getElementById(PANEL_ID);
    if (!p) return;
    if (compactNav()) p.classList.toggle("yh-nav-expanded");
    else {
      p.classList.toggle("yh-sidebar-collapsed");
      try {
        localStorage.setItem(
          "yhcoach_dashboard_sidebar",
          p.classList.contains("yh-sidebar-collapsed") ? "1" : "0",
        );
      } catch (e) {}
    }
    syncNavAccessibility();
  };
  window.toggleDashboardNav = function (button) {
    const group = button && button.closest(".yh-nav-group"),
      p = document.getElementById(PANEL_ID);
    if (!group || !p) return;
    if (compactNav()) p.classList.add("yh-nav-expanded");
    else if (p.classList.contains("yh-sidebar-collapsed")) {
      p.classList.remove("yh-sidebar-collapsed");
      try {
        localStorage.setItem("yhcoach_dashboard_sidebar", "0");
      } catch (e) {}
    }
    p.querySelectorAll(".yh-nav-group").forEach((g) => {
      if (g !== group) g.classList.remove("open");
    });
    group.classList.toggle("open");
    syncNavAccessibility();
  };
  document.addEventListener("click", (e) => {
    const p = document.getElementById(PANEL_ID);
    if (!p || !p.classList.contains("yh-nav-expanded")) return;
    if (
      e.target.closest(".yh-subnav button") ||
      (!e.target.closest(".yh-sidebar") &&
        !e.target.closest('[onclick="toggleDashboardSidebar()"]'))
    ) {
      p.classList.remove("yh-nav-expanded");
      syncNavAccessibility();
    }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      document.getElementById(PANEL_ID)?.classList.remove("yh-nav-expanded");
      syncNavAccessibility();
    }
  });
  window.matchMedia("(max-width:1000px)").addEventListener("change", () => {
    document.getElementById(PANEL_ID)?.classList.remove("yh-nav-expanded");
    syncNavAccessibility();
  });
  document.addEventListener("DOMContentLoaded", syncNavAccessibility);
  window.dashboardGlobalSearch = function (event) {
    if (event.key !== "Enter") return;
    const q = String(event.target.value || "")
      .trim()
      .toLowerCase();
    if (!q) return;
    const { profiles, programs } = dashboardData();
    const p = profiles.find((x) =>
      [x.nom, x.prenom].filter(Boolean).join(" ").toLowerCase().includes(q),
    );
    if (p) {
      openAthleteProfiles();
      setTimeout(() => selectAthleteProfile(p.id), 0);
      return;
    }
    const prog = programs.find(
      (x) =>
        String(x.athlete || "")
          .toLowerCase()
          .includes(q) ||
        String(x.theme || "")
          .toLowerCase()
          .includes(q),
    );
    if (prog) {
      openProgram(prog.id);
      return;
    }
    showToast("Aucun athlète, programme ou séance trouvé");
  };
  window.dashboardWeekDetail = function (dayIso, count) {
    const d = new Date(dayIso + "T12:00:00");
    showToast(
      `${fmtDate(d, { weekday: "long", day: "numeric", month: "long" })} · ${count} activité${count > 1 ? "s" : ""}`,
    );
  };
  window.renderNewDashboard = function () {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) return;
    try {
      if (localStorage.getItem("yhcoach_dashboard_sidebar") === "1")
        panel.classList.add("yh-sidebar-collapsed");
    } catch (e) {}
    const { programs, groups, profiles } = dashboardData();
    const now = new Date();
    const todayIso = iso(now);
    const date = document.getElementById("yhDashboardDate");
    if (date)
      date.textContent = fmtDate(now, {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric",
      });
    const start = mondayOf(now),
      days = Array.from({ length: 7 }, (_, i) => {
        const d = new Date(start);
        d.setDate(start.getDate() + i);
        return d;
      });
    const activity = {};
    days.forEach((d) => (activity[iso(d)] = 0));
    programs.forEach((p) => {
      const k = String(p.date || "").slice(0, 10);
      if (k in activity) activity[k]++;
    });
    groups.forEach((g) =>
      (g.sessions || []).forEach((s) => {
        const k = sessionDate(s);
        if (k in activity) activity[k]++;
      }),
    );
    const counts = days.map((d) => activity[iso(d)] || 0),
      max = Math.max(1, ...counts),
      weekTotal = programs.filter((p) => String(p.date || "").slice(0, 10) in activity).length;
    const weekEl = document.getElementById("dashWeekCount");
    if (weekEl) weekEl.textContent = String(weekTotal);
    const weekSub = document.getElementById("dashWeekSub");
    if (weekSub)
      weekSub.textContent = weekTotal
        ? `${weekTotal} programme${weekTotal > 1 ? "s" : ""} planifié${weekTotal > 1 ? "s" : ""}`
        : "Aucun programme planifié";
    const bars = document.getElementById("dashWeekBars");
    if (bars)
      bars.innerHTML = days
        .map((d, i) => {
          const n = counts[i],
            h = 8 + Math.round((n / max) * 112),
            key = iso(d);
          return `<button class="yh-barcol ${key === todayIso ? "today" : ""}" onclick="dashboardWeekDetail('${key}',${n})" title="${safe(fmtDate(d, { weekday: "long" }))} : ${n} activité${n > 1 ? "s" : ""}"><span class="yh-bar-value">${n}</span><span class="yh-barfill" style="height:${h}px"></span><small>${["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"][i]}</small></button>`;
        })
        .join("");
    const upcoming = programs
      .filter((p) => String(p.date || "") > todayIso)
      .sort(
        (a, b) =>
          String(a.date || "").localeCompare(String(b.date || "")) ||
          (b.updatedAt || 0) - (a.updatedAt || 0),
      )
      .slice(0, 3);
    const up = document.getElementById("dashUpcomingList");
    if (up)
      up.innerHTML = upcoming.length
        ? upcoming
            .map((p, i) => {
              const d = new Date(String(p.date).slice(0, 10) + "T12:00:00");
              return `<button class="yh-event" onclick="openProgram('${p.id}')"><span class="yh-day">${pad(d.getDate())}<br>${fmtDate(d, { month: "short" }).replace(".", "").toUpperCase()}</span><span><b>${safe(p.theme || "Programme")} · ${safe(p.athlete || "Athlète")}</b><small>Séance ${p.sessionNum || 1}${p.poste ? " · " + safe(p.poste) : ""}</small></span><i class="yh-dot" style="background:${["#4ed19a", "#e8bd4d", "#68a9e8"][i % 3]}"></i></button>`;
            })
            .join("")
        : '<div class="yh-empty">Aucune échéance à venir.</div>';
    const recent = [];
    programs.forEach((p) =>
      recent.push({
        time: Number(p.updatedAt || p.createdAt || 0),
        type: "program",
        icon: "▣",
        title: `${p.theme || "Programme"} · ${p.athlete || "Athlète"}`,
        sub: "Programme enregistré",
        action: `openProgram('${p.id}')`,
      }),
    );
    profiles.forEach((p) => {
      const tests = (p.tests || []).slice();
      const t = tests[tests.length - 1];
      const time = Number(p.updatedAt || p.createdAt || (t && t.ts) || 0);
      recent.push({
        time,
        type: "profile",
        icon: "♙",
        title: `Profil de ${[p.prenom, p.nom].filter(Boolean).join(" ") || "l’athlète"}`,
        sub: t ? "Nouvelle mesure enregistrée" : "Profil enregistré",
        action: `openAthleteProfiles();setTimeout(()=>selectAthleteProfile('${p.id}'),0)`,
      });
    });
    recent.sort((a, b) => b.time - a.time);
    const rec = document.getElementById("dashRecentList");
    if (rec)
      rec.innerHTML = recent.length
        ? recent
            .slice(0, 3)
            .map((r) => {
              let when = "Activité récente";
              if (r.time) {
                const delta = Math.max(0, Date.now() - r.time);
                when =
                  delta < 3600000
                    ? "Il y a moins d’une heure"
                    : delta < 86400000
                      ? `Il y a ${Math.max(1, Math.round(delta / 3600000))} h`
                      : fmtDate(new Date(r.time), { day: "numeric", month: "short" });
              }
              return `<button class="yh-recent-row" onclick="${r.action}"><span class="yh-mini-icon">${r.icon}</span><span><b>${safe(r.title)}</b><small>${safe(r.sub)} · ${safe(when)}</small></span></button>`;
            })
            .join("")
        : '<div class="yh-empty">L’activité récente apparaîtra ici.</div>';
    const rate = typeof dashboardAttendanceRate === "function" ? dashboardAttendanceRate() : null;
    const rateSub = document.getElementById("dashAttendanceSub");
    if (rateSub)
      rateSub.textContent = rate == null ? "Aucune présence enregistrée" : "Présences enregistrées";
  };
  document.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
      try {
        renderNewDashboard();
      } catch (e) {}
    }, 80);
  });
})();
