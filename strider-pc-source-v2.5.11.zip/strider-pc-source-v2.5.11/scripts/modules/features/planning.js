"use strict";
(function () {
  const STATUS_LABELS = {
    draft: "Brouillon",
    planned: "Planifié",
    active: "En cours",
    completed: "Terminé",
    cancelled: "Annulé",
  };
  function n(v, f = null) {
    if (v === "" || v == null) return f;
    const x = Number(v);
    return Number.isFinite(x) ? x : f;
  }
  function computePlannedSessionDates(startISO, weeks, perWeek) {
    const out = [];
    weeks = Math.max(1, n(weeks, 1));
    perWeek = Math.min(7, Math.max(1, n(perWeek, 2)));
    if (!startISO) return out;
    const start = new Date(startISO + "T12:00:00");
    if (Number.isNaN(start.getTime())) return out;
    const step = Math.max(1, Math.floor(7 / perWeek));
    let num = 1;
    for (let w = 0; w < weeks; w++) {
      for (let s = 0; s < perWeek; s++) {
        const d = new Date(start);
        d.setDate(start.getDate() + w * 7 + s * step);
        out.push({
          week: w + 1,
          session: s + 1,
          sessionNum: num,
          index: num,
          date: d.toISOString().slice(0, 10),
          label: "Séance n°" + num,
        });
        num++;
      }
    }
    return out;
  }
  function formatDateFR(iso) {
    if (!iso) return "—";
    const p = String(iso).split("-");
    if (p.length !== 3) return iso;
    return p[2] + "/" + p[1] + "/" + p[0];
  }
  function weekdayFR(iso) {
    if (!iso) return "";
    const d = new Date(iso + "T12:00:00");
    if (Number.isNaN(d.getTime())) return "";
    return ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"][d.getDay()];
  }
  function collectPlannedSessionDatesFromUI() {
    const box = document.getElementById("plannedSessionDatesList");
    if (!box) return [];
    const rows = [...box.querySelectorAll("[data-planned-row]")];
    return rows
      .map((row) => {
        const num = n(row.querySelector("[data-session-num]") && row.querySelector("[data-session-num]").value, 1);
        const date = (row.querySelector("[data-session-date]") && row.querySelector("[data-session-date]").value) || "";
        return {
          sessionNum: num,
          index: num,
          date,
          label: "Séance n°" + num,
          week: Math.max(1, Math.ceil(num / Math.max(1, n(program && program.sessionsPerWeek, 2)))),
        };
      })
      .filter((x) => x.date);
  }
  function renderPlannedSessionDatesList(list) {
    const box = document.getElementById("plannedSessionDatesList");
    if (!box) return;
    const items = Array.isArray(list) ? list : [];
    if (!items.length) {
      box.innerHTML =
        '<span style="color:#94a3b8;font-size:0.85rem">Aucune séance — clique « Générer » ou « Ajouter une séance ».</span>';
      return;
    }
    box.innerHTML = items
      .map(function (x, i) {
        const num = x.sessionNum != null ? x.sessionNum : x.index != null ? x.index : i + 1;
        const date = x.date || "";
        const day = weekdayFR(date);
        return (
          '<div data-planned-row style="display:grid;grid-template-columns:90px 1fr auto;gap:8px;align-items:center;padding:8px 10px;border-radius:10px;background:rgba(183,154,88,0.12);border:1px solid rgba(183,154,88,0.35)">' +
          '<label style="font-size:0.75rem;color:#94a3b8">N°<br/><input data-session-num type="number" min="1" value="' +
          num +
          '" style="width:100%;margin-top:4px;padding:6px 8px;border-radius:8px;border:1px solid rgba(255,255,255,0.15);background:#0f1419;color:#f8fafc" onchange="window.onPlannedSessionFieldChange&&onPlannedSessionFieldChange()"/></label>' +
          '<label style="font-size:0.75rem;color:#94a3b8">Date' +
          (day ? ' <span style="color:#e8d0af">(' + day + ")</span>" : "") +
          '<br/><input data-session-date type="date" value="' +
          date +
          '" class="sp-date-cal" style="width:100%;margin-top:4px;padding:8px 10px;min-height:38px;border-radius:8px;border:1px solid rgba(232,208,175,0.35);background:#fff;color:#111;color-scheme:light;cursor:pointer" onchange="window.onPlannedSessionFieldChange&&onPlannedSessionFieldChange()" onclick="try{this.showPicker&&this.showPicker()}catch(e){}"/></label>' +
          '<button type="button" title="Supprimer" onclick="window.removePlannedSessionRow&&removePlannedSessionRow(this)" style="padding:8px 10px;border-radius:8px;border:1px solid rgba(248,113,113,0.4);background:rgba(248,113,113,0.12);color:#f87171;cursor:pointer">✕</button>' +
          "</div>"
        );
      })
      .join("");
  }
  window.onPlannedSessionFieldChange = function () {
    if (!program) return;
    program.plannedSessionDates = collectPlannedSessionDatesFromUI();
    applyNextPlannedSessionToProgramHeader();
    renderPlannedSessionDatesList(program.plannedSessionDates);
  };
  window.removePlannedSessionRow = function (btn) {
    const row = btn && btn.closest("[data-planned-row]");
    if (row) row.remove();
    if (!program) return;
    program.plannedSessionDates = collectPlannedSessionDatesFromUI();
    applyNextPlannedSessionToProgramHeader();
  };
  window.addPlannedSessionRow = function () {
    if (!program) return;
    const list = collectPlannedSessionDatesFromUI();
    const maxNum = list.reduce((m, x) => Math.max(m, n(x.sessionNum, 0)), 0);
    list.push({
      sessionNum: maxNum + 1,
      index: maxNum + 1,
      date: new Date().toISOString().slice(0, 10),
      label: "Séance n°" + (maxNum + 1),
    });
    program.plannedSessionDates = list;
    renderPlannedSessionDatesList(list);
    applyNextPlannedSessionToProgramHeader();
  };
  window.generatePlannedSessionDates = function () {
    const weeks = n(document.getElementById("inputCycleWeeks") && document.getElementById("inputCycleWeeks").value, 1);
    const perWeek = n(document.getElementById("inputSessionsPerWeek") && document.getElementById("inputSessionsPerWeek").value, 2);
    let start = document.getElementById("inputCycleStartDate") && document.getElementById("inputCycleStartDate").value;
    if (!start) {
      start = new Date().toISOString().slice(0, 10);
      const el = document.getElementById("inputCycleStartDate");
      if (el) el.value = start;
    }
    const list = computePlannedSessionDates(start, weeks, perWeek);
    if (program) program.plannedSessionDates = list;
    renderPlannedSessionDatesList(list);
    applyNextPlannedSessionToProgramHeader();
    return list;
  };
  function localPlanningDate(date = new Date()) {
    return [date.getFullYear(), String(date.getMonth() + 1).padStart(2, "0"), String(date.getDate()).padStart(2, "0")].join("-");
  }
  /** No expired session is presented as the next session. */
  function getNextPlannedSession(list, today = localPlanningDate(), strictlyAfter = false) {
    const items = (Array.isArray(list) ? list : [])
      .filter((x) => x && x.date)
      .slice()
      .sort((a, b) => String(a.date).localeCompare(String(b.date)));
    if (!items.length) return null;
    return items.find((x) => strictlyAfter ? x.date > today : x.date >= today) || null;
  }
  window.getProgramScheduledSessions = function (entry) {
    const full = typeof loadProgramFromStorage === "function" ? loadProgramFromStorage(entry.id) : null;
    const p = full || entry;
    if (/^(completed|cancelled)$/.test(p.status || "")) return [];
    const dates = Array.isArray(p.plannedSessionDates) && p.plannedSessionDates.length
      ? p.plannedSessionDates : [{ date: p.date, sessionNum: p.sessionNum }];
    if (p.completed && !p.status) return [];
    return dates.filter((s) => s && s.date && !s.done && !(p.completed && s.date === p.date && n(s.sessionNum ?? s.index, p.sessionNum || 1) === n(p.sessionNum, 1))).map((s) => ({
      ...entry, date: s.date, sessionNum: n(s.sessionNum ?? s.index, p.sessionNum || 1),
      time: s.time || p.time || "", kind: "program",
    }));
  };
  window.getUpcomingProgramSessions = function (entries, today = localPlanningDate()) {
    return (entries || []).flatMap((p) => {
      const next = getNextPlannedSession(window.getProgramScheduledSessions(p), today, true);
      return next ? [next] : [];
    }).sort((a, b) => a.date.localeCompare(b.date) || String(a.time).localeCompare(String(b.time)));
  };
  function syncPlannedProgramHeader() {
    if (!program || /^(completed|cancelled)$/.test(program.status || "") || (program.completed && !program.status)) return;
    const list = program.plannedSessionDates;
    if (!Array.isArray(list) || !list.length) return;
    if (program.completed) {
      const done = list.find((s) => s.date === program.date && n(s.sessionNum ?? s.index, 1) === n(program.sessionNum, 1));
      if (done) {
        done.done = true;
        done.doneAt = program.completedAt || program.date;
      }
    }
    const next = getNextPlannedSession(list.filter((s) => !s.done));
    if (next && (next.date !== program.date || n(next.sessionNum ?? next.index, 1) !== n(program.sessionNum, 1))) {
      program.completed = false;
      program.completedAt = null;
    }
    program.date = next ? next.date : "";
    if (next) program.sessionNum = n(next.sessionNum ?? next.index, program.sessionNum || 1);
  }
  function applyNextPlannedSessionToProgramHeader() {
    if (!program) return;
    syncPlannedProgramHeader();
    const sn = document.getElementById("inputSessionNum");
    const dt = document.getElementById("inputDate");
    if (sn) sn.value = program.sessionNum;
    if (dt) dt.value = program.date || "";
    if (typeof render === "function") {
      try {
        render();
      } catch (_) {}
    }
  }
  window.refreshPlannedSessionDates = function () {
    // Ne régénère plus tout seul : affiche la liste existante (éditable)
    if (!program) return [];
    if (!Array.isArray(program.plannedSessionDates) || !program.plannedSessionDates.length) {
      return window.generatePlannedSessionDates();
    }
    renderPlannedSessionDatesList(program.plannedSessionDates);
    applyNextPlannedSessionToProgramHeader();
    return program.plannedSessionDates;
  };
  function ensurePlanningDefaults() {
    if (!program) return;
    program.cycleName = program.cycleName || "Cycle principal";
    program.cycleWeeks = Math.max(1, n(program.cycleWeeks, 6));
    program.currentWeek = Math.min(program.cycleWeeks, Math.max(1, n(program.currentWeek, 1)));
    program.sessionsPerWeek = Math.min(7, Math.max(1, n(program.sessionsPerWeek, 2)));
    if (!program.cycleStartDate) program.cycleStartDate = new Date().toISOString().slice(0, 10);
    program.status = program.status || (program.completed ? "completed" : "draft");
    if (!Array.isArray(program.plannedSessionDates) || !program.plannedSessionDates.length) {
      program.plannedSessionDates = computePlannedSessionDates(
        program.cycleStartDate,
        program.cycleWeeks,
        program.sessionsPerWeek,
      );
    }
    program.feedback = program.feedback || {};
    (program.days || []).forEach((d) => {
      d.week = Math.max(1, n(d.week, 1));
      (d.exercises || []).forEach((e) => {
        if (e.actualSeries === undefined) e.actualSeries = null;
        if (e.actualReps === undefined) e.actualReps = null;
        if (e.actualChargeKg === undefined) e.actualChargeKg = null;
        if (e.actualRpe === undefined) e.actualRpe = null;
        if (e.actualNotes === undefined) e.actualNotes = "";
      });
    });
  }
  function progressionSuggestion(ex) {
    const rpe = n(ex.actualRpe, null),
      kg = n(ex.actualChargeKg, n(ex.chargeKg, null)),
      reps = n(ex.actualReps, null),
      target = n(ex.reps, null);
    if (rpe == null && kg == null) return "";
    if (rpe != null && rpe >= 9.5) return "Alléger de 5 à 10 % ou réduire le volume";
    if (rpe != null && rpe >= 8.5) return "Maintenir la charge et consolider la technique";
    if (rpe != null && rpe <= 7.5 && (reps == null || target == null || reps >= target))
      return kg != null
        ? `Prochaine charge suggérée : ${Math.round((kg + 2.5) * 2) / 2} kg`
        : `Augmenter progressivement de 2 à 5 %`;
    return "Maintenir puis réévaluer à la prochaine séance";
  }
  window.progressionSuggestion = progressionSuggestion;

  const baseRender = render;
  render = function () {
    syncPlannedProgramHeader();
    ensurePlanningDefaults();
    baseRender();
    const cb = document.getElementById("cycleBadge"),
      sb = document.getElementById("programStatusBadge");
    if (cb) cb.textContent = `${program.cycleName} · S${program.currentWeek}/${program.cycleWeeks}`;
    if (sb) {
      sb.textContent = STATUS_LABELS[program.status] || "Brouillon";
      sb.dataset.status = program.status;
    }
    const progress = document.getElementById("cycleProgressWrap");
    if (progress) {
      const pct = Math.round((program.currentWeek / program.cycleWeeks) * 100);
      progress.innerHTML = `<div><span>Progression du cycle</span><b>${pct}%</b></div><div class="cycle-progress"><span style="width:${pct}%"></span></div>`;
    }
    // Group existing day cards visually by week without changing old data format.
    const container = document.getElementById("daysContainer");
    if (container) {
      container.querySelectorAll(".planning-week-title").forEach((x) => x.remove());
      let last = null;
      const cards = [...container.querySelectorAll(":scope > .day-section")];
      cards.forEach((card, i) => {
        const d = program.days[i];
        const w = d ? Math.max(1, n(d.week, 1)) : 1;
        if (w !== last) {
          const h = document.createElement("div");
          h.className = "planning-week-title";
          h.innerHTML = `<span>SEMAINE ${w}</span><small>${escapeHtml(program.cycleName)}</small>`;
          container.insertBefore(h, card);
          last = w;
        }
      });
    }
    // Planned vs actual panels and automatic progression advice.
    const cards = [...document.querySelectorAll("#daysContainer .exercise-card")];
    let k = 0;
    (program.days || []).forEach((day) =>
      (day.exercises || []).forEach((ex) => {
        const card = cards[k++];
        if (!card) return;
        const old = card.querySelector(".actual-result-strip");
        if (old) old.remove();
        const has = [ex.actualSeries, ex.actualReps, ex.actualChargeKg, ex.actualRpe].some(
          (v) => v !== null && v !== undefined && v !== "",
        );
        if (!has) return;
        const sug = progressionSuggestion(ex);
        const box = document.createElement("div");
        box.className = "actual-result-strip";
        box.innerHTML = `<div><b>RÉALISÉ</b><span>${ex.actualSeries ?? "—"} séries · ${ex.actualReps ?? "—"} reps · ${ex.actualChargeKg ?? "—"} kg · RPE ${ex.actualRpe ?? "—"}</span></div>${sug ? `<em>↗ ${escapeHtml(sug)}</em>` : ""}${ex.actualNotes ? `<small>${escapeHtml(ex.actualNotes)}</small>` : ""}`;
        card.appendChild(box);
      }),
    );
  };

  const baseOpenProgramModal = openProgramModal;
  openProgramModal = function () {
    ensurePlanningDefaults();
    baseOpenProgramModal();
    const set = (id, v) => {
      const e = document.getElementById(id);
      if (e) e.value = v ?? "";
    };
    set("inputCycleName", program.cycleName);
    set("inputCycleWeeks", program.cycleWeeks);
    set("inputCurrentWeek", program.currentWeek);
    set("inputProgramStatus", program.status);
    set("inputCycleStartDate", program.cycleStartDate || new Date().toISOString().slice(0, 10));
    set("inputSessionsPerWeek", program.sessionsPerWeek || 2);
    if (typeof window.refreshPlannedSessionDates === "function") refreshPlannedSessionDates();
  };
  const baseSaveProgram = saveProgram;
  saveProgram = function () {
    ensurePlanningDefaults();
    const get = (id) => document.getElementById(id)?.value;
    program.cycleName = (get("inputCycleName") || "Cycle principal").trim();
    program.cycleWeeks = Math.max(1, n(get("inputCycleWeeks"), 6));
    program.currentWeek = Math.min(program.cycleWeeks, Math.max(1, n(get("inputCurrentWeek"), 1)));
    program.status = get("inputProgramStatus") || "draft";
    program.cycleStartDate = get("inputCycleStartDate") || new Date().toISOString().slice(0, 10);
    program.sessionsPerWeek = Math.min(7, Math.max(1, n(get("inputSessionsPerWeek"), 2)));
    if (!Array.isArray(program.plannedSessionDates) || !program.plannedSessionDates.length) {
      program.plannedSessionDates = computePlannedSessionDates(
        program.cycleStartDate,
        program.cycleWeeks,
        program.sessionsPerWeek,
      );
    }
    applyNextPlannedSessionToProgramHeader();
    baseSaveProgram();
  };

  const baseAddDay = addDay;
  addDay = function () {
    baseAddDay();
    const e = document.getElementById("inputDayWeek");
    if (e) e.value = program.currentWeek || 1;
  };
  const baseEditDay = editDay;
  editDay = function (id) {
    baseEditDay(id);
    const d = (program.days || []).find((x) => x.id === id),
      e = document.getElementById("inputDayWeek");
    if (e) e.value = d?.week || program.currentWeek || 1;
  };
  const baseSaveDay = saveDay;
  saveDay = function () {
    const week = Math.max(
      1,
      n(document.getElementById("inputDayWeek")?.value, program.currentWeek || 1),
    );
    const id = editingDayId,
      before = (program.days || []).length;
    baseSaveDay();
    const d = id ? (program.days || []).find((x) => x.id === id) : (program.days || [])[before];
    if (d) {
      d.week = week;
      save();
      render();
    }
  };

  const baseOpenExerciseModal = openExerciseModal;
  openExerciseModal = function (dayId, exId = null) {
    baseOpenExerciseModal(dayId, exId);
    const day = (program.days || []).find((d) => d.id === dayId),
      ex = day?.exercises?.find((e) => e.id === exId);
    const set = (id, v) => {
      const e = document.getElementById(id);
      if (e) e.value = v ?? "";
    };
    set("inputActualSeries", ex?.actualSeries);
    set("inputActualReps", ex?.actualReps);
    set("inputActualChargeKg", ex?.actualChargeKg);
    set("inputActualRpe", ex?.actualRpe);
    set("inputActualNotes", ex?.actualNotes);
  };
  const baseSaveExercise = saveExercise;
  saveExercise = async function () {
    const dayId = currentDayId,
      exId = currentExId;
    const result = {
      actualSeries: n(document.getElementById("inputActualSeries")?.value, null),
      actualReps: n(document.getElementById("inputActualReps")?.value, null),
      actualChargeKg: n(document.getElementById("inputActualChargeKg")?.value, null),
      actualRpe: n(document.getElementById("inputActualRpe")?.value, null),
      actualNotes: (document.getElementById("inputActualNotes")?.value || "").trim(),
    };
    const day = (program.days || []).find((d) => d.id === dayId),
      before = day?.exercises?.length || 0;
    await baseSaveExercise();
    const target = exId ? day?.exercises?.find((e) => e.id === exId) : day?.exercises?.[before];
    if (target) {
      Object.assign(target, result);
      program.updatedAt = Date.now();
      saveProgramToStorage(program);
      render();
    }
  };

  const baseToggleSessionDone = toggleSessionDone;
  toggleSessionDone = function () {
    baseToggleSessionDone();
    program.status = program.completed ? "completed" : "active";
    save();
    render();
  };
  window.openSessionFeedback = function () {
    ensurePlanningDefaults();
    const f = program.feedback || {};
    const set = (id, v) => {
      const e = document.getElementById(id);
      if (e) e.value = v ?? "";
    };
    set("feedbackFatigue", f.fatigue);
    set("feedbackPain", f.pain);
    set("feedbackQuality", f.quality);
    set(
      "feedbackStatus",
      program.status === "completed"
        ? "completed"
        : program.status === "cancelled"
          ? "cancelled"
          : "active",
    );
    set("feedbackComment", f.comment);
    const summary = document.getElementById("feedbackSummary");
    if (summary) {
      const adv = [];
      if (n(f.pain, 0) >= 5) adv.push("Douleur élevée : adapter la prochaine séance.");
      if (n(f.fatigue, 0) >= 8) adv.push("Fatigue élevée : prévoir récupération ou décharge.");
      if (!adv.length) adv.push("Renseigne le bilan pour obtenir une recommandation.");
      summary.innerHTML = adv.map((x) => `<p>${escapeHtml(x)}</p>`).join("");
    }
    openModal("sessionFeedbackModal");
  };
  window.saveSessionFeedback = function () {
    ensurePlanningDefaults();
    const g = (id) => document.getElementById(id)?.value;
    program.feedback = {
      fatigue: n(g("feedbackFatigue"), null),
      pain: n(g("feedbackPain"), null),
      quality: n(g("feedbackQuality"), null),
      comment: (g("feedbackComment") || "").trim(),
      savedAt: new Date().toISOString(),
    };
    program.status = g("feedbackStatus") || "active";
    program.completed = program.status === "completed";
    program.completedAt = program.completed ? new Date().toISOString().slice(0, 10) : null;
    program.updatedAt = Date.now();
    saveProgramToStorage(program);
    render();
    closeModal("sessionFeedbackModal");
    showToast("Bilan de séance enregistré");
  };

  ensurePlanningDefaults();
  if (document.getElementById("editorScreen")?.classList.contains("active")) render();
})();
