# Version 2.4.22 — Barre compacte et fiche individuelle

- Liste des profils : Nom puis Prénom uniquement, sans groupe ni numéro de maillot. Le filtre et le compteur ATHLÈTES sont conservés.
- Nouveau, Partage et ⋯ rapprochés. Suppression dans ⋯ avec confirmation. Les boutons ne se déplacent pas pendant la sauvegarde.
- Enregistrement… puis Enregistré pendant deux secondes, en dessous ; aucun voyant permanent. Un échec ne disparaît pas comme une réussite.
- Partage : section visible pour la fiche complète de l’athlète affiché en PDF, HTML lecture seule et JSON compatible avec l’import. Photo, logo du club, champs, mensurations, courbe sélectionnée et historique sont inclus. Les exports du groupe et listes personnalisées sont conservés.
- Ouverture des profils stabilisée : préparation avant affichage, sans remplissage différé ; grands panneaux sans inclinaison au démarrage. Photos et identité préservées.

Sauvegarder les données et conserver l’ancienne version avant remplacement. Projet Electron avec BAT, pas un installateur Windows déjà compilé. Les tests navigateur et des ponts simulés ne remplacent pas la vérification sur Windows.
