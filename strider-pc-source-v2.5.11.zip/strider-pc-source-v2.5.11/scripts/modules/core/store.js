/**
 * YhCoachPro — stockage unifié (SSD Electron ou localStorage)
 * Charger CE fichier en premier (avant les autres modules).
 */
(function (global) {
  "use strict";

  /** Clés connues — référence pour maintenance */
  var YH_STORE_KEYS = {
    profilesIndex: "yhcoachpro_athlete_profiles_index",
    profileItemPrefix: "yhcoachpro_athlete_profile_",
    profilesLegacy: "yhcoachpro_athlete_profiles",
    programsIndex: "yhcoachpro_programs_index",
    programPrefix: "prog_",
    attendance: "yhcoachpro_assiduite_v2",
    attendanceLegacy: "yhcoachpro_assiduite_v1",
    license: "yhcoachpro_license_v2",
    exerciseLibrary: "yhcoachpro_exercise_library",
    theme: "yhcoachpro_theme",
    compact: "yhcoachpro_compact",
    dashboardMode: "yhcoach_dashboard_mode",
    seedFlag: "yhcoachpro_exercises_seeded_v1",
  };

  function diskEnabled() {
    return !!(global.yhDisk && global.yhDisk.enabled);
  }

  function storeGet(key) {
    try {
      if (diskEnabled() && global.yhDisk && global.yhDisk.read) {
        var v = global.yhDisk.read(key);
        if (v != null && v !== "") return v;
      }
    } catch (e) {}
    try {
      return global.localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function storeSet(key, val) {
    var diskOk = false;
    var lsOk = false;
    try {
      if (diskEnabled() && global.yhDisk && global.yhDisk.write) {
        diskOk = !!global.yhDisk.write(key, val);
        if (!diskOk) console.error("yhDisk.write failed", key);
      }
    } catch (e) {
      console.error("disk write", e);
    }
    try {
      global.localStorage.setItem(key, val);
      lsOk = true;
    } catch (e) {
      if (e && (e.name === "QuotaExceededError" || e.code === 22)) {
        if (diskOk) return true;
        throw e;
      }
      console.error("localStorage write", e);
    }
    if (diskEnabled()) return diskOk || lsOk;
    return lsOk;
  }

  function storeRemove(key) {
    try {
      if (diskEnabled() && global.yhDisk && global.yhDisk.remove) {
        return !!global.yhDisk.remove(key);
      }
      global.localStorage.removeItem(key);
      return true;
    } catch (e) {
      return false;
    }
  }

  function storeGetJSON(key, fallback) {
    try {
      var raw = storeGet(key);
      if (raw == null || raw === "") return fallback;
      return JSON.parse(raw);
    } catch (e) {
      return fallback;
    }
  }

  function storeSetJSON(key, obj) {
    return storeSet(key, JSON.stringify(obj));
  }

  // API globale (compatible avec le code existant)
  global.YH_STORE_KEYS = YH_STORE_KEYS;
  global.storeGet = storeGet;
  global.storeSet = storeSet;
  global.storeRemove = storeRemove;
  global.storeGetJSON = storeGetJSON;
  global.storeSetJSON = storeSetJSON;
  global.YHStore = {
    keys: YH_STORE_KEYS,
    get: storeGet,
    set: storeSet,
    remove: storeRemove,
    getJSON: storeGetJSON,
    setJSON: storeSetJSON,
    diskEnabled: diskEnabled,
  };
})(typeof window !== "undefined" ? window : this);
