# Version 2.4.21 — Compteur explicite et voyant de sauvegarde

- La petite case orange indique « 32 ATHLÈTES » pour un groupe de 32 profils, sans comparaison au nombre total. Singulier : « 1 ATHLÈTE » ; groupe vide : « 0 ATHLÈTES ».
- Le groupe sélectionné reste mémorisé comme dans la version 2.4.20.
- Le libellé Enregistrement/Sauvegarde automatique est remplacé par un voyant rond discret de 12 pixels, sans bouton, texte visible, ni animation.
- Vert : le profil a été enregistré avec succès.
- Orange : modification en attente ou enregistrement en cours. Un profil vierge non enregistré, un nom/prénom manquant ou un échec de stockage ne sont jamais signalés comme enregistrés en vert.
- Une infobulle précise l’état au survol ; le voyant possède aussi un libellé accessible.
- La sauvegarde automatique reste active. Les pointages, données, groupes, fonds et logos sont conservés.

Sauvegarder les données avant remplacement et conserver l’ancienne version.
Projet Electron avec BAT, pas un installateur Windows compilé.
