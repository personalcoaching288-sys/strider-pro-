/** Helpers UI (toasts, modales, utilitaires) */
// ========== UI HELPERS ==========
function openModal(id) {
  document.getElementById(id).classList.add("show");
}
function closeModal(id) {
  document.getElementById(id).classList.remove("show");
}

function showToast(msg) {
  try {
    const t = document.getElementById("toast");
    if (!t) {
      console.log("[toast]", msg);
      return;
    }
    t.textContent = msg;
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), 2800);
  } catch (e) {
    console.log("[toast]", msg);
  }
}

function updateHexes() {
  ["Border", "Series", "Reps", "Charge", "Recup", "Card"].forEach((k) => {
    const el = document.getElementById("col" + k);
    const hex = document.getElementById("hex" + k);
    if (el && hex) hex.textContent = el.value;
  });
  ["Series", "Reps", "Charge", "Recup"].forEach((k) => {
    const el = document.getElementById("compCol" + k);
    const hex = document.getElementById("hexComp" + k);
    if (el && hex) hex.textContent = el.value;
  });
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function updateCardColorVisibility() {
  const group = document.getElementById("cardColorGroup");
  const checked = document.getElementById("colorWhole")?.checked;
  if (group) group.style.display = checked ? "" : "none";
}

// Color pickers live update
// Color pickers live update
document.querySelectorAll('input[type="color"]').forEach((input) => {
  input.addEventListener("input", () => {
    if (input.id === "inputDayColor") {
      document.getElementById("dayColorHex").textContent = input.value;
    } else if (input.id.startsWith("hCol")) {
      const hexId = "hHex" + input.id.replace("hCol", "");
      const hexEl = document.getElementById(hexId);
      if (hexEl) hexEl.textContent = input.value;
    } else {
      updateHexes();
    }
  });
});

// Toggle card color visibility
document.getElementById("colorWhole")?.addEventListener("change", updateCardColorVisibility);

// Close modal on overlay click
document.querySelectorAll(".modal-overlay").forEach((ov) => {
  ov.addEventListener("click", (e) => {
    if (e.target === ov) ov.classList.remove("show");
  });
});
