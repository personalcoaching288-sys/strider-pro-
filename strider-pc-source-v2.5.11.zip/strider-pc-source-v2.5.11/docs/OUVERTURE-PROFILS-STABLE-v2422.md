# Correctif préparé — ouverture stable des profils

Préparation des champs, tests et indicateurs avant la révélation de la page. Suppression du remplissage différé de 50 ms. Désactivation du rendu différé content-visibility sur la fiche et ses images ; réservation de l’espace de la barre de défilement. Pas d’inclinaison 3D sur les deux grands panneaux de formulaire ; le relief au survol des petites sections reste conservé. Fond et logo inchangés.

Correctif local en attente d’intégration à la version avec la barre compacte validée. Aucun ZIP livré pour ce seul correctif. Vérification navigateur, pas encore une reproduction sur le PC Windows de l’utilisateur.
