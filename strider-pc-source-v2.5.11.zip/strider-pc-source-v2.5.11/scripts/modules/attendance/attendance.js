"use strict";

// ========== ASSIDUITE (multi-groupes) ==========
const AS_KEY = "yhcoachpro_assiduite_v2";
let asStore = { groups: [], currentGroupId: null };
let asOpenSessionId = null;
let asClockTimer = null;

function asDefaultGroup(title) {
  return {
    id: uid(),
    title: title || "Nouveau groupe",
    logo: null,
    players: [],
    sessions: [],
  };
}

function asLoad() {
  try {
    const raw = typeof storeGet === "function" ? storeGet(AS_KEY) : localStorage.getItem(AS_KEY);
    if (!raw) {
      // migration v1
      const oldRaw =
        typeof storeGet === "function"
          ? storeGet("yhcoachpro_assiduite_v1")
          : localStorage.getItem("yhcoachpro_assiduite_v1");
      if (oldRaw) {
        const old = JSON.parse(oldRaw);
        const g = asDefaultGroup("Groupe 1");
        g.players = Array.isArray(old.players) ? old.players : [];
        g.sessions = Array.isArray(old.sessions) ? old.sessions : [];
        asStore = { groups: [g], currentGroupId: g.id };
        asSave();
        return;
      }
      const g = asDefaultGroup("NCB / Groupe 1");
      asStore = { groups: [g], currentGroupId: g.id };
      return;
    }
    const d = JSON.parse(raw);
    if (d && Array.isArray(d.groups)) {
      asStore = d;
    } else if (d && (d.players || d.sessions)) {
      const g = asDefaultGroup("Groupe 1");
      g.players = d.players || [];
      g.sessions = d.sessions || [];
      asStore = { groups: [g], currentGroupId: g.id };
    } else {
      const g = asDefaultGroup("Groupe 1");
      asStore = { groups: [g], currentGroupId: g.id };
    }
    if (!asStore.groups.length) {
      const g = asDefaultGroup("Groupe 1");
      asStore.groups = [g];
      asStore.currentGroupId = g.id;
    }
    if (!asStore.currentGroupId || !asStore.groups.find((x) => x.id === asStore.currentGroupId)) {
      asStore.currentGroupId = asStore.groups[0].id;
    }
  } catch (e) {
    const g = asDefaultGroup("Groupe 1");
    asStore = { groups: [g], currentGroupId: g.id };
  }
}
function asSave() {
  const str = JSON.stringify(asStore);
  try {
    if (typeof storeSet === "function") storeSet(AS_KEY, str);
    else localStorage.setItem(AS_KEY, str);
  } catch (e) {
    console.warn(e);
  }
}
function asGroup() {
  return asStore.groups.find((g) => g.id === asStore.currentGroupId) || asStore.groups[0];
}
// Présentation uniquement : ne jamais changer les identifiants, les présences,
// ni le nom historique utilisé pour retrouver les programmes du tableau de bord.
function asRefreshProfileNames() {
  try {
    if (typeof loadAthleteProfiles === "function") loadAthleteProfiles();
  } catch (e) {
    console.warn(e);
  }
}
function asPlayersForDisplay(group) {
  const profiles =
    typeof athleteProfiles !== "undefined" && Array.isArray(athleteProfiles) ? athleteProfiles : [];
  const byId = new Map(profiles.map((p) => [p.id, p]));
  const normal = (value) =>
    String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLocaleLowerCase("fr-FR")
      .replace(/\s+/g, " ")
      .trim();
  const byName = new Map();
  profiles.forEach((p) => {
    const names = new Set(
      [[p.prenom, p.nom].filter(Boolean).join(" "), [p.nom, p.prenom].filter(Boolean).join(" ")]
        .map(normal)
        .filter(Boolean),
    );
    names.forEach((key) => {
      const matches = byName.get(key) || [];
      matches.push(p);
      byName.set(key, matches);
    });
  });
  const players = (group?.players || []).map((player) => {
    const matches = byName.get(normal(player.name)) || [];
    // Sans lien, utiliser uniquement une correspondance certaine : les noms
    // composés et homonymes ne doivent pas être devinés ni inversés au hasard.
    const profile =
      byId.get(player.profileId) || (!player.profileId && matches.length === 1 ? matches[0] : null);
    const nom = String(profile?.nom ?? player.nom ?? "").trim();
    const prenom = String(profile?.prenom ?? player.prenom ?? "").trim();
    const name = [nom, prenom].filter(Boolean).join(" ") || String(player.name || "").trim();
    return { ...player, name, nom, prenom };
  });
  const opts = { sensitivity: "base", numeric: true };
  return players.sort(
    (a, b) =>
      (a.nom || a.name).localeCompare(b.nom || b.name, "fr", opts) ||
      a.prenom.localeCompare(b.prenom, "fr", opts),
  );
}

function asPad(n) {
  return String(n).padStart(2, "0");
}
function asDateKey(d = new Date()) {
  return d.getFullYear() + "-" + asPad(d.getMonth() + 1) + "-" + asPad(d.getDate());
}
function asMonthKey(d = new Date()) {
  return d.getFullYear() + "-" + asPad(d.getMonth() + 1);
}
function asFormatDate(k) {
  try {
    return new Date(k + "T12:00:00").toLocaleDateString("fr-FR", {
      weekday: "long",
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  } catch (e) {
    return k;
  }
}
function asEsc(s) {
  return String(s || "").replace(
    /[&<>"']/g,
    (c) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      })[c],
  );
}

function asFillGroupSelect() {
  const sel = document.getElementById("asGroupSelect");
  if (!sel) return;
  sel.innerHTML = asStore.groups
    .map((g) => `<option value="${g.id}">${asEsc(g.title || "Groupe")}</option>`)
    .join("");
  sel.value = asStore.currentGroupId;
}
function asUpdateHeader() {
  const g = asGroup();
  if (!g) return;
  const titleIn = document.getElementById("asGroupTitleInput");
  if (titleIn) titleIn.value = g.title || "";
  const main = document.getElementById("asMainTitle");
  if (main) main.textContent = g.title || "Assiduité";
  const sub = document.getElementById("asMainSub");
  if (sub) sub.textContent = "Effectif : " + (g.players || []).length + " athlète(s)";
  const box = document.getElementById("asGroupLogoBox");
  if (box) {
    // Visual fallback only: do not assign the default image to the stored club.
    const logo = typeof g.logo === "string" ? g.logo.trim() : "";
    const fallback = typeof getAppPlaceholderDataUrl === "function"
      ? getAppPlaceholderDataUrl()
      : "./assets/branding/default-photo.png";
    const img = document.createElement("img");
    img.alt = logo ? "Logo du club" : "Logo Strider Pro par défaut";
    img.style.cssText = "width:100%;height:100%;object-fit:contain;background:transparent";
    if (!logo) {
      img.classList.add("strider-image-default");
      img.style.objectFit = "cover";
    }
    img.src = logo || fallback;
    box.replaceChildren(img);
    window.StriderImageFallback?.scan(box);
  }
}
function asSwitchGroup(id) {
  asStore.currentGroupId = id;
  asOpenSessionId = null;
  asSave();
  asRenderAll();
}
function asNewGroup() {
  try {
    if (!asStore || !Array.isArray(asStore.groups)) {
      asLoad();
    }
    const n = (asStore.groups || []).length + 1;
    const g = asDefaultGroup("Nouveau groupe " + n);
    asStore.groups.push(g);
    asStore.currentGroupId = g.id;
    asOpenSessionId = null;
    asSave();
    asRenderAll();
    // Focus titre pour renommer (prompt Electron souvent bloque)
    setTimeout(() => {
      const el = document.getElementById("asGroupTitleInput");
      if (el) {
        el.value = g.title;
        el.focus();
        el.select();
      }
    }, 50);
    showToast("Groupe créé — tape le titre puis Entrée");
  } catch (e) {
    console.error(e);
    showToast("Erreur création groupe");
  }
}
function asRenameGroup() {
  const g = asGroup();
  if (!g) return;
  const el = document.getElementById("asGroupTitleInput");
  if (el) {
    el.focus();
    el.select();
    showToast("Modifie le titre puis clique ailleurs ou Entrée");
  }
}
function asSaveGroupTitle() {
  const g = asGroup();
  if (!g) return;
  const el = document.getElementById("asGroupTitleInput");
  if (!el) return;
  const t = el.value.trim();
  if (!t) return;
  g.title = t;
  asSave();
  asUpdateHeader();
  asFillGroupSelect();
}
function asDeleteGroup() {
  if (asStore.groups.length <= 1) {
    showToast("Garde au moins un groupe");
    return;
  }
  const g = asGroup();
  if (!g || !confirm("Supprimer le groupe « " + (g.title || "") + " » et toutes ses données ?"))
    return;
  asStore.groups = asStore.groups.filter((x) => x.id !== g.id);
  asStore.currentGroupId = asStore.groups[0].id;
  asSave();
  asRenderAll();
}
function asOnLogoFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const g = asGroup();
    if (!g) return;
    // compress lightly via canvas if image
    const img = new Image();
    img.onload = () => {
      try {
        const c = document.createElement("canvas");
        const max = 256;
        let w = img.width,
          h = img.height;
        if (w > max || h > max) {
          const r = Math.min(max / w, max / h);
          w = Math.round(w * r);
          h = Math.round(h * r);
        }
        c.width = w;
        c.height = h;
        c.getContext("2d").drawImage(img, 0, 0, w, h);
        g.logo = c.toDataURL("image/png");
      } catch (e) {
        g.logo = reader.result;
      }
      asSave();
      asUpdateHeader();
      showToast("Logo enregistré");
    };
    img.onerror = () => {
      g.logo = reader.result;
      asSave();
      asUpdateHeader();
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
  input.value = "";
}

function showAssiduite() {
  asLoad();
  document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
  const el = document.getElementById("assiduiteScreen");
  if (el) el.classList.add("active");
  asRenderAll();
  if (asClockTimer) clearInterval(asClockTimer);
  asUpdateClock();
  asClockTimer = setInterval(asUpdateClock, 1000);
}

var asViewDate = null;
function asViewKey() { return asViewDate || asDateKey(); }
function asSetViewDate(k) {
  const today = asDateKey();
  asViewDate = k && /^\d{4}-\d{2}-\d{2}$/.test(k) && k !== today ? k : null;
  const g = asGroup();
  const first = ((g && g.sessions) || []).filter((x) => x.date === asViewKey()).sort((a, b) => (a.time || "").localeCompare(b.time || ""))[0];
  asOpenSessionId = asViewDate && first ? first.id : null;
  asUpdateClock();
  asRenderToday();
}
function asOpenDayPicker(event) {
  const i = document.getElementById("asViewDateInput");
  if (!i) return;
  // Un toucher direct ouvre le calendrier natif : ne pas le relancer ni
  // écraser une sélection en cours quand le clic remonte vers la date.
  if (event && event.target === i) return;
  i.value = asViewKey();
  try { if (i.showPicker) { i.showPicker(); return; } } catch (e) {}
  i.focus(); i.click();
}
function asShiftViewDate(n) {
  const d = new Date(asViewKey() + "T12:00:00");
  d.setDate(d.getDate() + n);
  asSetViewDate(asDateKey(d));
}
function asUpdateClock() {
  const d = new Date();
  const clock = document.getElementById("asClock");
  const td = document.getElementById("asTodayDate");
  if (clock) {
    clock.innerHTML =
      d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) +
      "<div class='as-sub'>" +
      asFormatDate(asDateKey(d)) +
      "</div>";
  }
  if (td) td.textContent = asFormatDate(asViewKey());
  const inp = document.getElementById("asViewDateInput");
  if (inp && document.activeElement !== inp && inp.value !== asViewKey()) inp.value = asViewKey();
  const bt = document.getElementById("asBackToday");
  if (bt) bt.style.display = asViewDate ? "" : "none";
}

function asShowPanel(id) {
  document.querySelectorAll("#assiduiteScreen .as-tab").forEach((t) => {
    t.classList.toggle("active", t.getAttribute("data-as") === id);
  });
  document.querySelectorAll("#assiduiteScreen .as-panel").forEach((p) => {
    p.classList.toggle("active", p.id === id);
  });
  if (id === "asMonthly") asRenderMonthly();
  if (id === "asStats") asRenderStats();
  if (id === "asReport") asRenderReportPreview();
  if (id === "asRpe" && typeof asRenderRpe === "function") asRenderRpe();
}

function asMonths() {
  const g = asGroup();
  const x = new Set([asMonthKey()]);
  (g.sessions || []).forEach((s) => {
    if (s.date) x.add(s.date.slice(0, 7));
  });
  return [...x].sort().reverse();
}
function asFillMonths() {
  ["asMonthSelect", "asStatsMonth", "asMonthlyMonth", "asReportMonth"].forEach((id) => {
    const e = document.getElementById(id);
    if (!e) return;
    const old = e.value;
    const arr = asMonths();
    e.innerHTML = arr
      .map((m) => {
        const label = new Date(m + "-01T12:00:00").toLocaleDateString("fr-FR", {
          month: "long",
          year: "numeric",
        });
        return `<option value="${m}">${label}</option>`;
      })
      .join("");
    e.value = arr.includes(old) ? old : asMonthKey();
  });
}

function asAddPlayer() {
  const g = asGroup();
  if (!g) return;
  const i = document.getElementById("asPlayerInput");
  const name = ((i && i.value) || "").trim();
  if (!name) return;
  if ((g.players || []).some((p) => p.name.toLowerCase() === name.toLowerCase())) {
    showToast("Cet athlète existe déjà dans ce groupe");
    return;
  }
  g.players = g.players || [];
  g.players.push({ id: uid(), name });
  if (i) i.value = "";
  asSave();
  asRenderAll();
  showToast("Athlète ajouté");
}
function asRemovePlayer(id) {
  const g = asGroup();
  if (!g || !confirm("Supprimer cet athlète de ce groupe ?")) return;
  g.players = (g.players || []).filter((p) => p.id !== id);
  asSave();
  asRenderAll();
}
function asNewSession() {
  const g = asGroup();
  if (!g) return;
  if (!(g.players || []).length) {
    showToast("Ajoute d'abord des athlètes à ce groupe");
    asShowPanel("asPlayers");
    return;
  }
  const n = new Date();
  const s = {
    id: uid(),
    date: asViewKey(),
    time: n.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
    attendance: {},
  };
  g.players.forEach((p) => {
    s.attendance[p.id] = null;
  });
  g.sessions = g.sessions || [];
  g.sessions.push(s);
  asOpenSessionId = s.id;
  asSave();
  asRenderAll();
  showToast("Séance créée");
}
function asSetAttendance(sid, pid, val) {
  const g = asGroup();
  if (!g) return;
  const s = (g.sessions || []).find((x) => String(x.id) === String(sid));
  if (!s) return;
  s.attendance = s.attendance || {};
  if (![true,false,"late",null].includes(val)) return;
  if (!(g.players || []).some((p) => String(p.id) === String(pid))) return;
  s.attendance[pid] = val;
  asOpenSessionId = s.id;
  asSave();
  asRenderAll();
}
function asDeleteSession(id) {
  const g = asGroup();
  if (!g || !confirm("Supprimer cette séance ?")) return;
  g.sessions = (g.sessions || []).filter((s) => s.id !== id);
  if (asOpenSessionId === id) asOpenSessionId = null;
  asSave();
  asRenderAll();
}
function asToggleSession(id) {
  const session = (asGroup()?.sessions || []).find((x) => String(x.id) === String(id));
  if (!session) return;
  asOpenSessionId = String(asOpenSessionId) === String(session.id) ? null : session.id;
  asRenderToday();
}
function asCount(s,g){let p=0,a=0,r=0,n=0;for(const player of g.players||[]){const v=(s.attendance||{})[player.id];if(v===true)p++;else if(v===false)a++;else if(v==='late')r++;else n++;}return {p,a,r,n};}

function asRenderToday() {
  const g = asGroup();
  if (!g) return;
  const ss = (g.sessions || [])
    .filter((s) => s.date === asViewKey())
    .sort((a, b) => (a.time || "").localeCompare(b.time || ""));
  const area = document.getElementById("asSessionArea");
  if (!area) return;
  if (!ss.length) {
    area.innerHTML = `<div class="as-empty">${asViewDate ? "Aucune séance ce jour-là pour ce groupe. Cliquez sur « + Enregistrer une séance » pour en ajouter une." : "Aucune séance aujourd'hui pour ce groupe."}</div>`;
    return;
  }
  area.innerHTML = ss
    .map((s, i) => {
      const c = asCount(s, g);
      const open = asOpenSessionId === s.id;
      const roster = asPlayersForDisplay(g)
        .map((p) => {
          const v = (s.attendance || {})[p.id];
          return `<div class="as-player-row">
            <span style="font-weight:650;color:#f1f5f9">${asEsc(p.name)}</span>
            <div style="display:flex;gap:7px">
              <button type="button" class="as-att present ${v === true ? "active" : ""}" data-as-status="present" data-as-session="${asEsc(s.id)}" data-as-player="${asEsc(p.id)}" title="Présent" aria-label="Présent" aria-pressed="${v === true}">✓</button>
              <button type="button" class="as-att late ${v === "late" ? "active" : ""}" data-as-status="late" data-as-session="${asEsc(s.id)}" data-as-player="${asEsc(p.id)}" title="Retard" aria-label="Retard" aria-pressed="${v === "late"}">◷</button>
              <button type="button" class="as-att absent ${v === false ? "active" : ""}" data-as-status="absent" data-as-session="${asEsc(s.id)}" data-as-player="${asEsc(p.id)}" title="Absent" aria-label="Absent" aria-pressed="${v === false}">✕</button>
            </div>
          </div>`;
        })
        .join("");
      return `<div style="border-top:${i ? "1px solid rgba(255,255,255,0.1)" : "0"};padding-top:${i ? "14px" : "0"};margin-top:${i ? "14px" : "0"}">
          <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;cursor:pointer" data-as-toggle="${asEsc(s.id)}">
            <div>
              <div style="font-weight:700;color:#f8fafc">Séance ${i + 1} · ${asEsc(s.time)}</div>
              <div class="as-sub">${c.p} à l’heure · ${c.r} en retard · ${c.a} absent(s)${c.n ? " · " + c.n + " non renseigné" : ""}</div>
            </div>
            <div style="display:flex;gap:7px">
              <button type="button" class="as-btn as-secondary" data-as-toggle="${asEsc(s.id)}">${open ? "Masquer" : "Athlètes"}</button>
              <button type="button" class="as-btn as-danger" title="Supprimer cet entraînement" onclick="event.stopPropagation();asDeleteSession('${s.id}')"><i class="fas fa-trash"></i> Supprimer</button>
            </div>
          </div>
          <div style="display:${open ? "grid" : "none"};gap:8px;margin-top:10px">
            ${roster || '<div class="as-empty">Aucun athlète</div>'}
          </div>
        </div>`;
    })
    .join("");
}

function asRenderPlayers() {
  const g = asGroup();
  const el = document.getElementById("asPlayerList");
  if (!el || !g) return;
  if (!(g.players || []).length) {
    el.innerHTML = `<div class="as-empty">Aucun athlète dans ce groupe.</div>`;
    return;
  }
  el.innerHTML = asPlayersForDisplay(g)
    .map(
      (p) =>
        `<div class="as-player-row"><span style="color:#f1f5f9">${asEsc(p.name)}</span>
        <button type="button" class="as-btn as-danger" onclick="asRemovePlayer('${p.id}')">Supprimer</button></div>`,
    )
    .join("");
}

function asColorClass(p) {
  if (p < 30) return "as-green";
  if (p <= 40) return "as-yellow";
  if (p <= 50) return "as-orange";
  return "as-red";
}

function asManualSave() {
  asSave();
  showToast("Assiduité enregistrée");
}

function asPlayerMonthStats(g, p, ss) {
  let a=0,pr=0,late=0,onTime=0,marked=0;const details=[];
  for(const session of ss){const v=(session.attendance||{})[p.id];let status='na';if(v===false){a++;marked++;status='absent'}else if(v===true){pr++;onTime++;marked++;status='present'}else if(v==='late'){pr++;late++;marked++;status='late'}details.push({date:session.date,time:session.time,status})}
  const pct=marked?Math.round(a/marked*100):0,latePct=marked?Math.round(late/marked*100):0,participationPercent=marked?Math.round(pr/marked*100):0;
  return {a,pr,late,onTime,marked,pct,latePct,participationPercent,details};
}

function asRenderStats() {
  const g = asGroup();
  if (!g) return;
  const m = document.getElementById("asStatsMonth")?.value || asMonthKey();
  const q = ((document.getElementById("asStatsSearch") || {}).value || "").trim().toLowerCase();
  const ss = (g.sessions || []).filter((s) => (s.date || "").startsWith(m));
  const el = document.getElementById("asStatsList");
  const ind = document.getElementById("asStatsIndividual");
  if (!el) return;

  const players = asPlayersForDisplay(g).filter(
    (p) =>
      !q ||
      p.name.toLowerCase().includes(q) ||
      [p.prenom, p.nom].filter(Boolean).join(" ").toLowerCase().includes(q),
  );

  if (ind) {
    if (q && players.length === 1) {
      const p = players[0];
      const st = asPlayerMonthStats(g, p, ss);
      const label = new Date(m + "-01T12:00:00").toLocaleDateString("fr-FR", {
        month: "long",
        year: "numeric",
      });
      ind.innerHTML = `<div style="border:2px solid rgba(232,208,175,0.45);border-radius:14px;padding:14px;background:rgba(232,208,175,0.06)">
            <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
              <strong style="font-size:1.15rem;color:#e8d0af">${asEsc(p.name)}</strong>
              <span class="as-percent ${asColorClass(st.pct)}">${st.pct}% absence</span><span class="as-percent as-late-percent">${st.latePct}% retard</span>
            </div>
            <div class="as-sub" style="margin:8px 0">Fiche individuelle — ${label} · ${asEsc(g.title || "")}</div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0">
              <div class="as-kpi"><strong>${st.pr}</strong><span>Présences</span></div>
              <div class="as-kpi"><strong>${st.late}</strong><span>Retards · ${st.latePct}%</span></div>
               <div class="as-kpi"><strong>${st.a}</strong><span>Absences</span></div>
              <div class="as-kpi"><strong>${st.marked}/${ss.length}</strong><span>Séances notées</span></div>
            </div>
            <div class="as-progress"><div class="as-fill" style="width:${st.pct}%"></div></div>
            <div style="margin-top:12px;max-height:220px;overflow:auto">
              ${
                st.details.length
                  ? st.details
                      .map((d) => {
                        const lab =
                          d.status === "present"
                            ? "✓ Présent"
                            : d.status === "late" ? "◷ Retard" : d.status === "absent"
                              ? "✕ Absent"
                              : "— Non renseigné";
                        const col =
                          d.status === "present"
                            ? "#86efac"
                            : d.status === "late" ? "#ffb463" : d.status === "absent"
                              ? "#fca5a5"
                              : "#94a3b8";
                        return `<div class="as-player-row"><span class="as-sub">${asEsc(d.date)} · ${asEsc(d.time || "")}</span><span style="color:${col};font-weight:700">${lab}</span></div>`;
                      })
                      .join("")
                  : '<div class="as-empty">Aucune séance ce mois</div>'
              }
            </div>
          </div>`;
    } else if (q && players.length === 0) {
      ind.innerHTML = `<div class="as-empty">Aucun athlète trouvé pour « ${asEsc(q)} »</div>`;
    } else if (q && players.length > 1) {
      ind.innerHTML = `<div class="as-sub">${players.length} résultats — affine la recherche pour la fiche individuelle.</div>`;
    } else {
      ind.innerHTML = "";
    }
  }

  if (!(g.players || []).length) {
    el.innerHTML = `<div class="as-empty">Aucun athlète.</div>`;
    return;
  }
  if (!players.length) {
    el.innerHTML = q ? "" : `<div class="as-empty">Aucun athlète.</div>`;
    return;
  }
  el.innerHTML = players
    .map((p) => {
      const st = asPlayerMonthStats(g, p, ss);
      return `<div style="border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:11px;margin-bottom:8px;cursor:pointer"
          onclick="document.getElementById('asStatsSearch').value=${asEsc(JSON.stringify(p.name))};asRenderStats()">
          <div style="display:flex;justify-content:space-between;gap:10px">
            <strong style="color:#f8fafc">${asEsc(p.name)}</strong><button class="as-btn as-secondary as-single-player-share" type="button" onclick="event.stopPropagation();asOpenPlayerStatsShare(${asEsc(JSON.stringify(p.id))})">Partage</button>
            <span class="as-percent ${asColorClass(st.pct)}">${st.pct}% absence</span><span class="as-percent as-late-percent">${st.latePct}% retard</span>
          </div>
          <div class="as-sub">${st.a} absence(s) · ${st.late} retard(s) (${st.latePct}%) · ${st.pr} participation(s) (${st.participationPercent}%) · ${st.marked}/${ss.length} séances renseignées</div>
          <div class="as-progress"><div class="as-fill" style="width:${st.pct}%"></div></div>
        </div>`;
    })
    .join("");
}

function asRenderMonthSummary() {
  const g = asGroup();
  if (!g) return;
  const m = document.getElementById("asMonthSelect")?.value || asMonthKey();
  const ss = (g.sessions || []).filter((s) => (s.date || "").startsWith(m));
  let a = 0;
  ss.forEach((s) =>
    Object.values(s.attendance || {}).forEach((v) => {
      if (v === false) a++;
    }),
  );
  const ts = document.getElementById("asTotalSessions");
  const ta = document.getElementById("asTotalAbsences");
  if (ts) ts.textContent = ss.length;
  if (ta) ta.textContent = a;
}

function asMonthlyPercentageCell(stats, kind, format) {
  const absence = kind === 'absence', value = absence ? stats.pct : stats.latePct;
  if (!stats.marked) return '<td class="as-month-percent-cell as-unmarked" title="Aucune séance renseignée">—</td>';
  const cssClass = absence ? asColorClass(value) : 'as-late-percent';
  if (format === 'screen') return '<td class="as-month-percent-cell"><span class="as-percent '+cssClass+'" title="'+(absence?'Pourcentage d’absence':'Pourcentage de retard')+' sur les séances renseignées">'+value+'%</span></td>';
  const palette = { 'as-green': ['#166534','#dcfce7'], 'as-yellow': ['#92400e','#fef3c7'], 'as-orange': ['#9a3412','#ffedd5'], 'as-red': ['#7f1d1d','#fecaca'], 'as-late-percent': ['#9a5b1c','#fff0d6'] };
  const colors = palette[cssClass];
  return '<td class="as-month-percent-cell '+cssClass+'" style="background-color:'+colors[0]+';color:'+colors[1]+';font-weight:700;text-align:center;">'+value+'%</td>';
}

function asMonthlyGrid(g,month,format='screen'){
 const [year,mo]=month.split('-').map(Number),days=new Date(year,mo,0).getDate(),ss=(g.sessions||[]).filter(s=>(s.date||'').startsWith(month));
 let out='<table><thead><tr><th>Athlète</th>';for(let d=1;d<=days;d++)out+='<th>'+d+'</th>';out+='<th>Abs.</th><th>% absence</th><th>Ret.</th><th>% retard</th><th>% participation</th></tr></thead><tbody>';
 for(const p of asPlayersForDisplay(g)){const st=asPlayerMonthStats(g,p,ss);out+='<tr><td>'+asEsc(p.name)+'</td>';for(let d=1;d<=days;d++){const vals=ss.filter(s=>s.date===month+'-'+asPad(d)).map(s=>(s.attendance||{})[p.id]);out+='<td>'+ (vals.length?vals.map(v=>format==='excel'?(v===true?'Présent':v==='late'?'Retard':v===false?'Absent':'Non renseigné'):(v===true?'P':v==='late'?'R':v===false?'A':'—')).join(' / '):'—')+'</td>'}out+='<td>'+st.a+'</td>'+asMonthlyPercentageCell(st,'absence',format)+'<td>'+st.late+'</td>'+asMonthlyPercentageCell(st,'late',format)+'<td>'+(st.marked?st.participationPercent+'%':'—')+'</td></tr>'}return out+'</tbody></table>';
}
function asRenderMonthly(){const g=asGroup(),box=document.getElementById('asMonthlyTable');if(!g||!box)return;const month=document.getElementById('asMonthlyMonth')?.value||asMonthKey(),ss=(g.sessions||[]).filter(s=>(s.date||'').startsWith(month));box.innerHTML=asMonthlyGrid(g,month)+'<p class="as-sub">P = présent à l’heure · R = retard · A = absent · — = non renseigné. Les retards comptent comme participation.</p><div class="as-month-sessions"><h3>Entraînements du mois</h3>'+ss.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).map((s,i)=>'<div class="as-month-session-row"><span><b>Entraînement '+(i+1)+'</b> · '+asEsc(s.date)+' '+asEsc(s.time||'')+'</span><button class="as-btn as-danger" onclick="asDeleteSession('+asEsc(JSON.stringify(s.id))+')">Supprimer</button></div>').join('')+'</div>';}

function asExportMonthlyExcel() {
  asRefreshProfileNames();
  const g = asGroup();
  if (!g) {
    if (typeof showToast === "function") showToast("Aucun groupe sélectionné");
    return;
  }
  const month =
    document.getElementById("asReportMonth")?.value ||
    document.getElementById("asMonthlyMonth")?.value ||
    asMonthKey();
  const [year, mo] = month.split("-").map(Number);
  const days = new Date(year, mo, 0).getDate();
  const ss = (g.sessions || []).filter((s) => (s.date || "").startsWith(month));
  const players = asPlayersForDisplay(g);

  // CSV séparé par ; (Excel FR) + BOM UTF-8 — s'ouvre correctement dans Excel
  const esc = (v) => {
    const s = String(v == null ? "" : v);
    if (/[;"\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  };
  const headers = ["Athlète"];
  for (let d = 1; d <= days; d++) headers.push(String(d));
  headers.push("Absences", "% absence", "Retards", "% retard", "% participation");
  const lines = [headers.map(esc).join(";")];

  for (const p of players) {
    const st = asPlayerMonthStats(g, p, ss);
    const row = [p.name || ""];
    for (let d = 1; d <= days; d++) {
      const dayKey = month + "-" + asPad(d);
      const vals = ss
        .filter((s) => s.date === dayKey)
        .map((s) => (s.attendance || {})[p.id]);
      if (!vals.length) {
        row.push("—");
      } else {
        row.push(
          vals
            .map((v) =>
              v === true
                ? "Présent"
                : v === "late"
                  ? "Retard"
                  : v === false
                    ? "Absent"
                    : "Non renseigné",
            )
            .join(" / "),
        );
      }
    }
    row.push(
      st.a,
      st.marked ? st.pct + "%" : "—",
      st.late,
      st.marked ? st.latePct + "%" : "—",
      st.marked ? st.participationPercent + "%" : "—",
    );
    lines.push(row.map(esc).join(";"));
  }

  lines.push("");
  lines.push(esc("Groupe") + ";" + esc(g.title || ""));
  lines.push(esc("Mois") + ";" + esc(month));
  lines.push(
    esc("Note") +
      ";" +
      esc("Retard = participation. Pourcentages calculés uniquement sur les séances renseignées."),
  );

  const csv = "\ufeff" + lines.join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const safe =
    typeof yhSafeFileName === "function"
      ? yhSafeFileName(g.title || "groupe")
      : String(g.title || "groupe").replace(/[^a-z0-9_-]+/gi, "_");
  window.yhSaveFile("Assiduite_" + safe + "_" + month + ".csv", blob);
  if (typeof showToast === "function")
    showToast("Rapport mensuel exporté (Excel / CSV)");
}

function asToggleShareMenu(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  const menu = document.getElementById("attendanceShareMenu");
  if (menu) menu.classList.toggle("show");
}
function asCloseShareMenu() {
  const menu = document.getElementById("attendanceShareMenu");
  if (menu) menu.classList.remove("show");
}
document.addEventListener("click", (e) => {
  if (!e.target.closest(".attendance-share-wrap")) asCloseShareMenu();
});

function asSessionRpeStats(session) {
  const map = (session && session.rpe) || {};
  const values = {};
  const nums = [];
  Object.keys(map).forEach((pid) => {
    const n = Number(map[pid]);
    if (Number.isFinite(n) && n >= 1 && n <= 10) {
      values[pid] = n;
      nums.push(n);
    }
  });
  if (!nums.length) return { average: null, count: 0, values };
  const average = Math.round((nums.reduce((a, b) => a + b, 0) / nums.length) * 10) / 10;
  return { average, count: nums.length, values };
}

function asPlayerRpeAggregate(playerId, sessions) {
  const vals = [];
  (sessions || []).forEach((s) => {
    const map = s.rpe || {};
    let v = map[playerId];
    if (v == null) v = map[String(playerId)];
    const n = Number(v);
    if (Number.isFinite(n) && n >= 1 && n <= 10) vals.push(n);
  });
  if (!vals.length) return { average: null, count: 0, values: vals };
  return {
    average: Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 10) / 10,
    count: vals.length,
    values: vals,
  };
}

function asBuildAttendanceJsonPayload(g, options) {
  options = options || {};
  const month = options.month || null;
  const sessionsAll = Array.isArray(g.sessions) ? g.sessions : [];
  const sessions = month
    ? sessionsAll.filter((s) => (s.date || "").startsWith(month))
    : sessionsAll.slice();
  const players = asPlayersForDisplay(g);
  const sessionRows = sessions.map((session) => {
    const rpe = asSessionRpeStats(session);
    return {
      id: session.id,
      date: session.date,
      time: session.time || "",
      attendance: session.attendance || {},
      rpe: session.rpe || {},
      rpeCollectif: rpe.average,
      rpeCount: rpe.count,
    };
  });
  const collectiveVals = sessionRows
    .map((s) => s.rpeCollectif)
    .filter((v) => v != null && Number.isFinite(Number(v)));
  const rpeCollectifGlobal = collectiveVals.length
    ? Math.round(
        (collectiveVals.reduce((a, b) => a + Number(b), 0) / collectiveVals.length) * 10,
      ) / 10
    : null;
  const playerRows = players.map((p) => {
    const st = asPlayerMonthStats(g, p, sessions);
    const rpeInd = asPlayerRpeAggregate(p.id, sessions);
    return {
      id: p.id,
      name: p.name,
      nom: p.nom || "",
      prenom: p.prenom || "",
      present: st.pr,
      onTime: st.onTime,
      late: st.late,
      absent: st.a,
      marked: st.marked,
      absencePercent: st.pct,
      latePercent: st.latePct,
      participationPercent: st.participationPercent,
      rpeIndividuel: rpeInd.average,
      rpeSeances: rpeInd.count,
    };
  });
  return {
    yhcoachproAttendanceReport: true,
    version: 2,
    exportedAt: new Date().toISOString(),
    scope: month ? "month" : "group",
    month: month || null,
    group: {
      id: g.id,
      title: g.title,
      logo: g.logo || null,
      players: (g.players || []).map((p) => ({
        id: p.id,
        name: p.name,
        nom: p.nom || "",
        prenom: p.prenom || "",
      })),
    },
    players: playerRows,
    sessions: sessionRows,
    rpe: {
      collectifGlobal: rpeCollectifGlobal,
      parSeance: sessionRows.map((s) => ({
        id: s.id,
        date: s.date,
        time: s.time,
        moyenne: s.rpeCollectif,
        effectif: s.rpeCount,
      })),
      individuel: playerRows.map((p) => ({
        id: p.id,
        name: p.name,
        moyenne: p.rpeIndividuel,
        seances: p.rpeSeances,
      })),
    },
  };
}

function asDownloadJson(filename, payload) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json;charset=utf-8",
  });
  window.yhSaveFile(filename, blob);
}

function asExportMonthlyJSON() {
  asRefreshProfileNames();
  const g = asGroup();
  if (!g) {
    showToast("Aucun groupe d'assiduité");
    return;
  }
  const month =
    document.getElementById("asReportMonth")?.value ||
    document.getElementById("asMonthlyMonth")?.value ||
    asMonthKey();
  const payload = asBuildAttendanceJsonPayload(g, { month });
  const safe = String(g.title || "groupe").replace(/[^a-z0-9_-]+/gi, "_");
  asDownloadJson("Assiduite_" + safe + "_" + month + ".json", payload);
  showToast("JSON mensuel exporté (assiduité + RPE)");
}

/** Export JSON du groupe entier (toutes les séances) + RPE individuel & collectif */
function asExportGroupJSON() {
  asRefreshProfileNames();
  const g = asGroup();
  if (!g) {
    showToast("Aucun groupe d'assiduité");
    return;
  }
  const payload = asBuildAttendanceJsonPayload(g, {});
  const safe = String(g.title || "groupe").replace(/[^a-z0-9_-]+/gi, "_");
  asDownloadJson("Assiduite_Groupe_" + safe + ".json", payload);
  showToast(
    "JSON groupe exporté — " +
      (payload.sessions || []).length +
      " séances, RPE inclus",
  );
}

function asImportAttendanceJSON(file) {
  if (!file) return;
  if (!/\.json$/i.test(file.name || "")) {
    showToast("Choisissez un fichier JSON d'assiduité");
    return;
  }
  const reader = new FileReader();
  reader.onload = function () {
    try {
      const text = String(reader.result || "").replace(/^\uFEFF/, "");
      const payload = JSON.parse(text);
      if (!payload || payload.yhcoachproAttendanceReport !== true) {
        throw new Error("Fichier non reconnu (rapport d'assiduité Strider Pro attendu)");
      }
      if (payload.version !== 1 && payload.version !== 2) {
        throw new Error("Version de fichier non prise en charge");
      }
      asLoad();
      const srcGroup = payload.group || {};
      const title = String(srcGroup.title || "Groupe importé").trim() || "Groupe importé";
      const norm = (v) =>
        String(v || "")
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .toLocaleLowerCase("fr-FR")
          .replace(/\s+/g, " ")
          .trim();

      let target = asStore.groups.find((g) => norm(g.title) === norm(title));
      let created = false;
      if (!target) {
        target = asDefaultGroup(title);
        if (srcGroup.logo) target.logo = srcGroup.logo;
        asStore.groups.push(target);
        created = true;
      }
      asStore.currentGroupId = target.id;

      // Joueurs du groupe
      const incomingPlayers =
        Array.isArray(srcGroup.players) && srcGroup.players.length
          ? srcGroup.players
          : Array.isArray(payload.players)
            ? payload.players
            : [];
      if (!Array.isArray(target.players)) target.players = [];
      const playerIds = new Set(target.players.map((p) => String(p.id)));
      incomingPlayers.forEach((p) => {
        if (!p) return;
        const id = p.id != null ? String(p.id) : uid();
        if (playerIds.has(String(id))) {
          const existing = target.players.find((x) => String(x.id) === String(id));
          if (existing) {
            if (p.name) existing.name = p.name;
            if (p.nom) existing.nom = p.nom;
            if (p.prenom) existing.prenom = p.prenom;
          }
          return;
        }
        target.players.push({
          id: id,
          name: p.name || [p.prenom, p.nom].filter(Boolean).join(" ") || "Joueur",
          nom: p.nom || "",
          prenom: p.prenom || "",
        });
        playerIds.add(String(id));
      });

      // Séances : fusion par date+heure, sinon ajout
      if (!Array.isArray(target.sessions)) target.sessions = [];
      const sessions = Array.isArray(payload.sessions) ? payload.sessions : [];
      let added = 0;
      let updated = 0;
      sessions.forEach((s) => {
        if (!s || !s.date) return;
        const key = String(s.date) + "|" + String(s.time || "");
        let dest = target.sessions.find(
          (x) => String(x.date) + "|" + String(x.time || "") === key,
        );
        if (!dest) {
          dest = {
            id: s.id || uid(),
            date: s.date,
            time: s.time || "",
            attendance: {},
            rpe: {},
          };
          target.sessions.push(dest);
          added++;
        } else {
          updated++;
        }
        dest.attendance = Object.assign({}, dest.attendance || {}, s.attendance || {});
        dest.rpe = Object.assign({}, dest.rpe || {}, s.rpe || {});
      });

      asSave();
      try {
        if (typeof asFillGroups === "function") asFillGroups();
        else if (typeof asRenderGroups === "function") asRenderGroups();
      } catch (e) {}
      try {
        asRender();
      } catch (e) {}
      try {
        if (typeof asRenderMonthly === "function") asRenderMonthly();
      } catch (e) {}
      showToast(
        (created ? "Groupe créé · " : "Groupe mis à jour · ") +
          added +
          " séance(s) ajoutée(s), " +
          updated +
          " fusionnée(s) · RPE inclus",
      );
    } catch (e) {
      console.error(e);
      showToast("Import impossible : " + (e.message || e));
    }
  };
  reader.onerror = function () {
    showToast("Lecture du fichier impossible");
  };
  reader.readAsText(file);
}

window.asExportGroupJSON = asExportGroupJSON;
window.asImportAttendanceJSON = asImportAttendanceJSON;
window.asOnAttendanceImportFile = function (input) {
  const f = input && input.files && input.files[0];
  if (f) asImportAttendanceJSON(f);
  if (input) input.value = "";
};


function asRenderReportPreview() {
  asFillMonths();
  const g = asGroup();
  const box = document.getElementById("asReportPreview");
  if (!box || !g) return;
  const m = document.getElementById("asReportMonth")?.value || asMonthKey();
  const label = new Date(m + "-01T12:00:00").toLocaleDateString("fr-FR", {
    month: "long",
    year: "numeric",
  });
  box.innerHTML = `<div class="as-sub">Rapport prêt pour <strong style="color:#e8d0af">${asEsc(g.title)}</strong> — ${label}. Choisis Partage → PDF pour enregistrer le rapport.</div>`;
}

// Le rapport s'exporte par la fenêtre d'impression isolée de l'application,
// jamais par window.open (bloqué volontairement pour la sécurité).
function asBuildMonthlyReport(){asRefreshProfileNames();const current=asGroup();if(!current)throw Error('Choisissez un groupe.');const g=JSON.parse(JSON.stringify(current)),month=document.getElementById('asReportMonth')?.value||document.getElementById('asMonthlyMonth')?.value||asMonthKey();if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))throw Error('Mois invalide');const ss=(g.sessions||[]).filter(s=>(s.date||'').startsWith(month));const rows=asPlayersForDisplay(g).map(p=>{const st=asPlayerMonthStats(g,p,ss);return '<tr><td>'+asEsc(p.name)+'</td><td>'+st.onTime+'</td><td>'+st.late+'</td><td>'+st.a+'</td><td>'+st.marked+'</td><td>'+st.pct+'%</td><td>'+st.latePct+'%</td><td>'+st.participationPercent+'%</td></tr>'}).join('');const logo=g.logo?yhEmbeddedMedia(g.logo):getAppLogoDataUrl();if(g.logo&&!/^data:image\//.test(logo||''))throw Error('Logo du club non disponible');const html='<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\';img-src data:;style-src \'unsafe-inline\';"><title>Rapport d’assiduité</title><style>@page{size:A4 landscape;margin:10mm}*{box-sizing:border-box}body{font:11px Arial;color:#182433;background:white;margin:0}header{display:flex;gap:15px;align-items:center;border-bottom:1px solid #b99b5d;padding-bottom:14px}header img{width:55px;height:55px;object-fit:contain}h1{font-size:21px}h2{font-size:15px;color:#715c32;margin:20px 0 10px}table{width:100%;border-collapse:collapse;table-layout:fixed}td,th{border:1px solid #ddd;padding:5px 3px;text-align:center;overflow-wrap:anywhere}td:first-child,th:first-child{text-align:left;width:22%}th{background:#eee9da}thead{display:table-header-group}tr{break-inside:avoid}.monthly{font-size:7px}.monthly td,.monthly th{padding:4px 1px}.monthly td:first-child,.monthly th:first-child{width:14%}p,footer{color:#687383}footer{font-size:9px}h2{break-after:avoid}</style></head><body><header><img src="'+asEsc(logo||'')+'" alt="Logo"><div><h1>'+asEsc(g.title)+'</h1><p>Rapport mensuel — '+asEsc(month)+' · '+ss.length+' séance(s)</p></div></header><h2>Statistiques du mois</h2><table><thead><tr><th>Athlète</th><th>À l’heure</th><th>Retards</th><th>Absences</th><th>Séances notées</th><th>% absence</th><th>% retard</th><th>% participation</th></tr></thead><tbody>'+rows+'</tbody></table><h2>Tableau mensuel</h2><div class="monthly">'+asMonthlyGrid(g,month,'report')+'</div><p>P = présent à l’heure · R = retard · A = absent · — = non renseigné. Les retards comptent comme participation. Pourcentages calculés uniquement sur les séances renseignées.</p><footer>Strider Pro · Rapport du groupe sélectionné</footer></body></html>';return {html,month,groupId:g.id,filename:'StriderPro_Assiduite_'+yhSafeFileName(g.title)+'_'+month+'.pdf'};}

let _asReportExportBusy = false;
async function asExportMonthlyPDF(mode = "pdf") {
  if (_asReportExportBusy) return;
  _asReportExportBusy = true;
  const button = document.querySelector(
    '#attendanceShareMenu button[onclick*="asExportMonthlyPDF"]',
  );
  if (button) button.disabled = true;
  try {
    const report = asBuildMonthlyReport();
    if (!window.yhDisk?.exportProfileList)
      throw Error(
        "L’enregistrement PDF direct est disponible dans l’application de bureau. Dans le navigateur, partage le HTML puis imprime-le en PDF.",
      );
    showToast(mode === "print" ? "Préparation de l’impression…" : "Préparation du rapport PDF…");
    const result = await window.yhDisk.exportProfileList(report.filename, report.html, true, mode);
    if (result?.ok)
      showToast(mode === "print" ? "Rapport envoyé à l’impression." : "Rapport PDF enregistré.");
    else if (!result?.canceled) throw Error(result?.error || "L’enregistrement n’a pas abouti.");
  } catch (e) {
    console.error("attendance-report-export", e);
    showToast("Rapport PDF : " + e.message);
  } finally {
    _asReportExportBusy = false;
    if (button) button.disabled = false;
  }
}
function asPrintReport() {
  return asExportMonthlyPDF("print");
}

function asRenderAll() {
  asRefreshProfileNames();
  asFillGroupSelect();
  asUpdateHeader();
  asFillMonths();
  asRenderToday();
  asRenderPlayers();
  asRenderMonthSummary();
  asRenderStats();
  asRenderMonthly();
  asRenderReportPreview();
}

// One click handler for all attendance statuses, also for imported numeric IDs.
document.addEventListener("click", function(event) {
  const button = event.target.closest && event.target.closest("#assiduiteScreen button[data-as-status]");
  if (!button) {
    const toggle = event.target.closest && event.target.closest("#assiduiteScreen [data-as-toggle]");
    if (toggle) {
      event.preventDefault();
      event.stopPropagation();
      asToggleSession(toggle.dataset.asToggle);
    }
    return;
  }
  const value = {present:true,late:"late",absent:false}[button.dataset.asStatus];
  if (value === undefined) return;
  event.preventDefault();
  event.stopPropagation();
  asSetAttendance(button.dataset.asSession, button.dataset.asPlayer, value);
});
