@echo off
setlocal
title Strider Pro - Creation de l'installateur
cd /d "%~dp0"

echo ==============================================
echo   STRIDER PRO - Creation de l'installateur
echo ==============================================
echo.
echo Ne fermez pas cette fenetre. La premiere fois,
echo cela peut prendre 10 a 20 minutes.
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERREUR] Node.js n'est pas installe.
  echo Installez-le depuis https://nodejs.org ^(bouton LTS^),
  echo cochez "Add to PATH", redemarrez le PC, puis relancez ce fichier.
  echo.
  start "" "https://nodejs.org"
  pause
  exit /b 1
)

for /f "delims=" %%v in ('node -v') do echo Node.js trouve : %%v
echo.

set CSC_IDENTITY_AUTO_DISCOVERY=false

echo [1/4] Nettoyage de l'ancien dossier dist...
if exist "dist" rmdir /s /q "dist"

echo [2/4] Telechargement des elements necessaires...
call npm install --no-audit --no-fund
if errorlevel 1 goto :erreur

echo.
echo [3/4] Verification des fichiers...
call npm run verify
if errorlevel 1 goto :erreur

echo.
echo [4/4] Fabrication de l'installateur et de la version portable...
call npm run dist
if errorlevel 1 goto :erreur

echo.
echo ==============================================
echo   TERMINE !
echo ==============================================
echo Dans le dossier dist :
echo  - "Strider Pro Setup 2.5.10.exe"  : l'installateur
echo  - "StriderPro-Portable.exe"      : sans installation
echo.
start "" explorer "%~dp0dist"
pause
exit /b 0

:erreur
echo.
echo [ERREUR] La creation a echoue. Lisez le message ci-dessus.
echo Verifiez la connexion Internet et l'antivirus, puis relancez.
pause
exit /b 1
