/** Programme (save, load index, nouveau, ouvrir) */
// ========== PROGRAM ==========
function openProgramModal() {
  if (!guardEdit()) return;
  document.getElementById("inputAthlete").value = program.athlete || "";
  document.getElementById("inputPoste").value = program.poste || "";
  document.getElementById("inputTheme").value = program.theme || "";
  if (document.getElementById("inputObjective"))
    document.getElementById("inputObjective").value = program.objective || "";
  document.getElementById("inputSessionNum").value = program.sessionNum || 1;
  document.getElementById("inputDate").value = program.date || "";
  document.getElementById("inputChargePct").value =
    program.chargePct !== null && program.chargePct !== undefined ? program.chargePct : "";
  document.getElementById("inputTitleFont").value =
    program.titleFont || "'Segoe UI', system-ui, sans-serif";
  document.getElementById("inputTitleSize").value = program.titleSize || 24;

  if (!program.headerColors) {
    program.headerColors = {
      cardBg: "#000000",
      name: "#ffffff",
      theme: "#6366f1",
      themeText: "#ffffff",
      date: "#374151",
      dateBg: "#e5e7eb",
      charge: "#ffffff",
      chargeBg: "#6366f1",
      border: "#e5e7eb",
      session: "#ffffff",
      sessionBg: "#1f2937",
    };
  }
  const hc = program.headerColors;
  const setColor = (id, hexId, val) => {
    const el = document.getElementById(id);
    const hex = document.getElementById(hexId);
    if (el) el.value = val || el.value;
    if (hex) hex.textContent = val || el.value;
  };
  setColor("hColPageBg", "hHexPageBg", program.pageBg || "#f4f6f9");
  setColor("hColCardBg", "hHexCardBg", hc.cardBg);
  setColor("hColBorder", "hHexBorder", hc.border);
  setColor("hColName", "hHexName", hc.name);
  setColor("hColTheme", "hHexTheme", hc.theme || program.themeColor);
  setColor("hColThemeText", "hHexThemeText", hc.themeText || "#ffffff");
  setColor("hColDate", "hHexDate", hc.date);
  setColor("hColDateBg", "hHexDateBg", hc.dateBg);
  setColor("hColCharge", "hHexCharge", hc.charge);
  setColor("hColChargeBg", "hHexChargeBg", hc.chargeBg);
  setColor("hColSession", "hHexSession", hc.session || "#ffffff");
  setColor("hColSessionBg", "hHexSessionBg", hc.sessionBg || "#1f2937");

  athleteImageData = program.athletePhoto || null;
  if (program.athletePhoto) {
    document.getElementById("athleteImgPreview").innerHTML =
      `<img class="img-preview" src="${program.athletePhoto}" />`;
  } else {
    const logo = getAppPlaceholderDataUrl();
    document.getElementById("athleteImgPreview").innerHTML = logo
      ? `<img class="img-preview" src="${logo}" alt="Strider Pro" />`
      : `<div class="img-preview-placeholder"><i class="fas fa-user"></i></div>`;
  }

  clubLogoData = program.clubLogo || null;
  if (program.clubLogo) {
    document.getElementById("clubLogoPreview").innerHTML =
      `<img class="img-preview" src="${program.clubLogo}" />`;
  } else {
    const logo = getAppPlaceholderDataUrl();
    document.getElementById("clubLogoPreview").innerHTML = logo
      ? `<img class="img-preview" src="${logo}" alt="Strider Pro" />`
      : `<div class="img-preview-placeholder"><i class="fas fa-shield-alt"></i></div>`;
  }
  openModal("programModal");
}

async function previewAthleteImage(input) {
  const file = input.files[0];
  if (!file) return;
  try {
    // preserveAlpha=true → PNG transparent, pas de fond noir
    athleteImageData = await compressImageFile(file, 200, 0.55, true);
    document.getElementById("athleteImgPreview").innerHTML =
      `<img class="img-preview" src="${athleteImageData}" />`;
  } catch (e) {
    showToast("Impossible de lire l'image");
    input.value = "";
  }
}

function removeAthleteImage() {
  athleteImageData = null;
  {
    const logo = getAppPlaceholderDataUrl();
    document.getElementById("athleteImgPreview").innerHTML = logo
      ? `<img class="img-preview" src="${logo}" alt="Strider Pro" />`
      : `<div class="img-preview-placeholder"><i class="fas fa-user"></i></div>`;
  }
  document.getElementById("inputAthleteImage").value = "";
}

async function previewClubLogo(input) {
  const file = input.files[0];
  if (!file) return;
  try {
    // preserveAlpha=true → PNG transparent, pas de fond noir
    clubLogoData = await compressImageFile(file, 140, 0.55, true);
    document.getElementById("clubLogoPreview").innerHTML =
      `<img class="img-preview" src="${clubLogoData}" />`;
  } catch (e) {
    showToast("Impossible de lire l'image");
    input.value = "";
  }
}

function removeClubLogo() {
  clubLogoData = null;
  {
    const logo = getAppPlaceholderDataUrl();
    document.getElementById("clubLogoPreview").innerHTML = logo
      ? `<img class="img-preview" src="${logo}" alt="Strider Pro" />`
      : `<div class="img-preview-placeholder"><i class="fas fa-shield-alt"></i></div>`;
  }
  const el = document.getElementById("inputClubLogo");
  if (el) el.value = "";
}

function saveProgram() {
  if (!guardEdit()) return;
  program.athlete = document.getElementById("inputAthlete").value.trim() || "Nouvel athlète";
  program.poste = document.getElementById("inputPoste").value.trim();
  program.theme = document.getElementById("inputTheme").value.trim() || "force";
  program.objective = (document.getElementById("inputObjective")?.value || "").trim();
  program.sessionNum = +document.getElementById("inputSessionNum").value || 1;
  program.date = document.getElementById("inputDate").value;
  program.athletePhoto = athleteImageData;
  program.clubLogo = clubLogoData;
  program.titleFont = document.getElementById("inputTitleFont").value;
  program.titleSize = +document.getElementById("inputTitleSize").value || 24;

  const chargeVal = document.getElementById("inputChargePct").value;
  program.chargePct = chargeVal === "" || chargeVal === null ? null : +chargeVal;

  program.pageBg = document.getElementById("hColPageBg").value || "#f4f6f9";
  program.headerColors = {
    cardBg: document.getElementById("hColCardBg").value,
    border: document.getElementById("hColBorder").value,
    name: document.getElementById("hColName").value,
    theme: document.getElementById("hColTheme").value,
    themeText: document.getElementById("hColThemeText").value,
    date: document.getElementById("hColDate").value,
    dateBg: document.getElementById("hColDateBg").value,
    charge: document.getElementById("hColCharge").value,
    chargeBg: document.getElementById("hColChargeBg").value,
    session: document.getElementById("hColSession").value,
    sessionBg: document.getElementById("hColSessionBg").value,
  };
  program.themeColor = program.headerColors.theme;

  if (!program.id) program.id = uid();
  if (!program.createdAt) program.createdAt = Date.now();
  program.updatedAt = Date.now();
  const ok = saveProgramToStorage(program);
  render();
  closeModal("programModal");
  showToast(ok ? "Programme enregistré !" : "Échec enregistrement");
  if (ok) {
    programDirty = false;
    try {
      renderProgramList();
    } catch (e) {}
  }
}

// exports.js chargé séparément.
