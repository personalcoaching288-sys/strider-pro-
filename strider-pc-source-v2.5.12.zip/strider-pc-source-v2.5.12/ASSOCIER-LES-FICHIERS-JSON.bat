@echo off
setlocal
title Strider Pro - Ouvrir les fichiers JSON

rem Ce fichier doit rester dans le meme dossier que StriderPro-PC-v2.5.12-Portable.exe
set "EXE=%~dp0StriderPro-PC-v2.5.12-Portable.exe"
if not exist "%EXE%" (
  echo Le logiciel StriderPro-PC-v2.5.12-Portable.exe est introuvable.
  echo Placez ce fichier dans le meme dossier que le logiciel, puis recommencez.
  pause
  exit /b 1
)

echo Association des fichiers JSON avec Strider Pro...
reg export "HKCU\Software\Classes\.json" "%~dp0association-json-avant-strider.reg" /y >nul 2>&1
reg add "HKCU\Software\Classes\.json" /ve /t REG_SZ /d "StriderPro.json" /f >nul
if errorlevel 1 goto erreur
reg add "HKCU\Software\Classes\StriderPro.json" /ve /t REG_SZ /d "Fichier Strider Pro" /f >nul
reg add "HKCU\Software\Classes\StriderPro.json\DefaultIcon" /ve /t REG_SZ /d "\"%EXE%\",0" /f >nul
reg add "HKCU\Software\Classes\StriderPro.json\shell\open\command" /ve /t REG_SZ /d "\"%EXE%\" \"%%1\"" /f >nul
if errorlevel 1 goto erreur

echo.
echo TERMINE : double-cliquez maintenant sur un fichier JSON exporte par Strider.
echo Ne deplacez pas le logiciel sans relancer cette association.
echo.
pause
exit /b 0

:erreur
echo.
echo L'association n'a pas pu etre enregistree.
echo Faites un clic droit sur un JSON, puis "Ouvrir avec" et choisissez Strider Pro.
pause
exit /b 1
