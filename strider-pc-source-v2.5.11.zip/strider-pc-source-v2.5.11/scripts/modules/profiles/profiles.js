"use strict";

// ========== PROFILS ATHLETES ==========
let athleteProfiles = [];
let currentProfileId = null;
let profilePhotoData = null;
let profileClubLogoData = null;
const PROFILE_GROUP_FILTER_STORE_KEY = "yhcoachpro_profiles_group_filter";
let profileGroupFilterId = String(storeGet(PROFILE_GROUP_FILTER_STORE_KEY) || "");

function profileSetGroupFilter(id) {
  profileGroupFilterId = String(id || "");
  const filter = document.getElementById("profileGroupFilter");
  if (filter) filter.value = profileGroupFilterId;
  try {
    storeSet(PROFILE_GROUP_FILTER_STORE_KEY, profileGroupFilterId);
  } catch (e) {
    console.warn(e);
  }
}

function hideOneRmPercents() {
  const p = document.getElementById("oneRmPercentPanel");
  if (p) p.style.display = "none";
}
function showOneRmPercents(inputEl) {
  const panel = document.getElementById("oneRmPercentPanel");
  const list = document.getElementById("oneRmPercentList");
  const title = document.getElementById("oneRmPercentTitle");
  if (!panel || !list || !inputEl) return;
  const raw = parseFloat(String(inputEl.value || "").replace(",", "."));
  const label =
    inputEl.previousElementSibling && inputEl.previousElementSibling.tagName === "LABEL"
      ? inputEl.previousElementSibling.textContent
      : inputEl.id || "1RM";
  // si l'input est dans un div, label is sibling of input's parent structure: label is previous sibling of input
  let lab = label;
  try {
    const wrap = inputEl.parentElement;
    const l = wrap && wrap.querySelector("label");
    if (l) lab = l.textContent.trim();
  } catch (e) {}
  if (!raw || isNaN(raw) || raw <= 0) {
    title.textContent = lab + " — entre une charge 1RM";
    list.innerHTML =
      '<div class="pct-item" style="grid-column:1/-1">Saisis d\'abord le 1RM (kg)</div>';
    panel.style.display = "block";
    return;
  }
  title.textContent = lab + " · 1RM = " + raw + " kg";
  const pcts = [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95];
  list.innerHTML = pcts
    .map((p) => {
      const kg = Math.round((raw * p) / 10) / 10; // 1 decimal
      return '<div class="pct-item"><strong>' + p + "%</strong>" + kg + " kg</div>";
    })
    .join("");
  panel.style.display = "block";
}

const PROFILE_FIELDS = [
  "nom",
  "prenom",
  "naissance",
  "tel",
  "maillot",
  "taille_maillot",
  "numero_licence",
  "code_couleur",
  "poste",
  "saison",
  "blood_group",
  "club",
  "taille",
  "poids",
  "env1",
  "env2",
  "saut_elan",
  "saut_sans",
  "saut_attaque",
  "saut_attaque_sans",
  "saut_bloc",
  "saut_bloc_sans",
  "env_h",
  "vma",
  "vitesse_9m",
  "vitesse_18m",
  "vitesse_3x6",
  "vitesse_93639",
  "test_sapin",
  "souplesse",
  "medball_1_assis",
  "medball_1_debout",
  "medball_2_assis",
  "medball_2_debout",
  "tech_service",
  "tech_reception",
  "tech_attaque",
  "tech_bloc",
  "tech_passe",
  "tech_defense",
  "1rm_dc",
  "1rm_tirage",
  "1rm_pullover",
  "1rm_squat",
  "1rm_sdt",
  "m_cou",
  "m_poitrine",
  "m_abdo",
  "m_biceps_g",
  "m_cuisse_g",
  "m_mollet_g",
  "m_epaule",
  "m_tour",
  "m_hanche",
  "m_biceps_d",
  "m_cuisse_d",
  "m_mollet_d",
  "blessures_actuelles",
  "blessures_anciennes",
  "notes",
];

// Un fichier par profil sur l'application de bureau : une nouvelle fiche
// ne peut pas écraser les précédentes et le stockage évolue sans gros JSON.
const PROFILE_LEGACY_STORE_KEY = "yhcoachpro_athlete_profiles";
const PROFILE_INDEX_STORE_KEY = "yhcoachpro_athlete_profiles_index";
const PROFILE_ITEM_STORE_PREFIX = "yhcoachpro_athlete_profile_";

function normalizeAthleteProfile(p) {
  if (!p || typeof p !== "object") return null;
  const ids = Array.isArray(p.groupIds) ? p.groupIds.filter(Boolean) : p.groupId ? [p.groupId] : [];
  return { ...p, groupIds: Array.from(new Set(ids)), groupId: ids[0] || "" };
}

function compareAthleteProfiles(a, b) {
  const opts = { sensitivity: "base", numeric: true };
  const byLastName = String(a?.nom || "")
    .trim()
    .localeCompare(String(b?.nom || "").trim(), "fr", opts);
  if (byLastName) return byLastName;
  return String(a?.prenom || "")
    .trim()
    .localeCompare(String(b?.prenom || "").trim(), "fr", opts);
}

function updateWaistHipRatio() {
  const waist = parseFloat(document.getElementById("pf_m_tour")?.value);
  const hip = parseFloat(document.getElementById("pf_m_hanche")?.value);
  const numEl = document.getElementById("pf_whr_num") || document.getElementById("pf_whr_value");
  const labEl = document.getElementById("pf_whr_label");
  const box = document.getElementById("pf_whr_value");
  if (!numEl) return;
  if (!waist || !hip || waist <= 0 || hip <= 0) {
    if (numEl.id === "pf_whr_num") numEl.textContent = "—";
    else numEl.textContent = "—";
    if (labEl) {
      labEl.textContent = "";
      labEl.style.color = "#94a3b8";
    }
    if (box) {
      box.style.borderColor = "rgba(255,255,255,0.12)";
      box.style.color = "#e8d0af";
    }
    return;
  }
  const r = waist / hip;
  const v = (Math.round(r * 100) / 100).toFixed(2);
  if (numEl.id === "pf_whr_num") numEl.textContent = v;
  else numEl.textContent = v;
  let label = "",
    color = "#22c55e";
  if (r < 0.85) {
    label = "Excellent";
    color = "#22c55e";
  } else if (r < 0.9) {
    label = "Bon";
    color = "#84cc16";
  } else if (r < 0.95) {
    label = "Moyen";
    color = "#eab308";
  } else if (r < 1.0) {
    label = "Élevé";
    color = "#f97316";
  } else {
    label = "Risque";
    color = "#ef4444";
  }
  if (labEl) {
    labEl.textContent = label;
    labEl.style.color = color;
  }
  if (numEl) numEl.style.color = color;
  if (box) box.style.borderColor = color;
}

function updateProfileIMC() {
  const tEl = document.getElementById("pf_taille");
  const pEl = document.getElementById("pf_poids");
  const disp = document.getElementById("pf_imc_display");
  if (!disp) return;
  const cm = parseFloat(tEl && tEl.value);
  const kg = parseFloat(pEl && pEl.value);
  if (!cm || !kg || cm <= 0 || kg <= 0) {
    disp.value = "";
    disp.placeholder = "—";
    disp.style.setProperty("color", "#f8fafc", "important");
    disp.style.setProperty("border-color", "rgba(255,255,255,0.12)", "important");
    return;
  }
  const m = cm / 100;
  const imc = kg / (m * m);
  const v = Math.round(imc * 10) / 10;
  let cat = "",
    col = "#e8d0af";
  if (imc < 18.5) {
    cat = "Maigreur";
    col = "#38bdf8";
  } else if (imc < 25) {
    cat = "Normal";
    col = "#4ade80";
  } else if (imc < 30) {
    cat = "Surpoids";
    col = "#fbbf24";
  } else {
    cat = "Obésité";
    col = "#f87171";
  }
  disp.value = v + " · " + cat;
  disp.style.setProperty("color", col, "important");
  disp.style.setProperty("border-color", col, "important");
}

function loadAthleteProfiles() {
  try {
    if (typeof USE_DISK !== "undefined" && USE_DISK) {
      const indexRaw = storeGet(PROFILE_INDEX_STORE_KEY);
      // Index présent (même vide []) = source de vérité : ne pas ressusciter l’ancien stockage
      if (indexRaw != null && String(indexRaw).trim() !== "") {
        let ids = [];
        try {
          ids = JSON.parse(indexRaw);
        } catch (e) {
          ids = [];
        }
        if (Array.isArray(ids)) {
          athleteProfiles = ids
            .map((id) => {
              try {
                return normalizeAthleteProfile(
                  JSON.parse(storeGet(PROFILE_ITEM_STORE_PREFIX + id) || "null"),
                );
              } catch (e) {
                return null;
              }
            })
            .filter(Boolean);
          return;
        }
      }
    }
    const raw = JSON.parse(storeGet(PROFILE_LEGACY_STORE_KEY) || "[]");
    athleteProfiles = (Array.isArray(raw) ? raw : []).map(normalizeAthleteProfile).filter(Boolean);
    // Migration unique vers le disque, puis on neutralise le legacy pour éviter les "fantômes"
    if (typeof USE_DISK !== "undefined" && USE_DISK) {
      saveAthleteProfilesStore();
    }
  } catch (e) {
    athleteProfiles = [];
  }
}
function saveAthleteProfilesStore(changedProfileId) {
  try {
    if (typeof USE_DISK !== "undefined" && USE_DISK) {
      let previousIds = [];
      try {
        previousIds = JSON.parse(storeGet(PROFILE_INDEX_STORE_KEY) || "[]");
      } catch (e) {}
      const ids = [];
      for (const profile of athleteProfiles) {
        if (!profile || !profile.id) continue;
        // Une modification de formulaire ne réécrit que la fiche concernée.
        // Les imports, migrations et suppressions continuent de sauvegarder l’ensemble.
        if (!changedProfileId || profile.id === changedProfileId) {
          if (!storeSet(PROFILE_ITEM_STORE_PREFIX + profile.id, JSON.stringify(profile))) return false;
        }
        ids.push(profile.id);
      }
      // Un index vide présent reste la source de vérité; ne pas recréer des profils supprimés.
      if (JSON.stringify(previousIds) !== JSON.stringify(ids) || storeGet(PROFILE_INDEX_STORE_KEY) == null) {
        if (!storeSet(PROFILE_INDEX_STORE_KEY, JSON.stringify(ids))) return false;
      }
      (Array.isArray(previousIds) ? previousIds : [])
        .filter((id) => !ids.includes(id))
        .forEach((id) => {
          try {
            storeRemove(PROFILE_ITEM_STORE_PREFIX + id);
          } catch (e) {}
        });
      // Synchroniser / vider le legacy pour qu’il ne ressuscite plus les profils supprimés
      try {
        storeSet(PROFILE_LEGACY_STORE_KEY, "[]");
      } catch (e) {}
      return true;
    }
    return !!storeSet(PROFILE_LEGACY_STORE_KEY, JSON.stringify(athleteProfiles));
  } catch (e) {
    showToast("Stockage plein — allège ou supprime des données");
    return false;
  }
}

function openAthleteProfiles() {
  flushProfileAutosave();
  unlockCoachMode();
  try {
    document.getElementById("licenseLock")?.classList.remove("show");
  } catch (e) {}
  try {
    document.body.classList.remove("athlete-mode");
  } catch (e) {}
  // Remplir et calculer la fiche avant de retirer le tableau de bord.
  loadAthleteProfiles();
  refreshProfileGroupControls();
  refreshProfileSelect();
  const visibleProfiles = profileVisibleProfiles();
  if (visibleProfiles.length) selectAthleteProfile(visibleProfiles[0].id);
  else newAthleteProfile();
  document.querySelectorAll(".screen.active").forEach((el) => {
    if (el.id !== "profileScreen") el.classList.remove("active");
  });
  const sc = document.getElementById("profileScreen");
  if (sc) {
    sc.classList.add("active");
    sc.style.display = "block";
    sc.style.pointerEvents = "auto";
  }
  // Le canvas nécessite la largeur réelle, sans retarder le reste du formulaire.
  if (typeof drawProfileEvolutionChart === "function") drawProfileEvolutionChart();
}

function closeAthleteProfiles() {
  flushProfileAutosave();
  closeProfileMoreMenu();
  const sc = document.getElementById("profileScreen");
  if (sc) {
    sc.classList.remove("active");
    sc.style.display = "none";
  }
  document.getElementById("homeScreen")?.classList.add("active");
}

function profileGroupIds(p) {
  if (!p) return [];
  if (Array.isArray(p.groupIds)) return Array.from(new Set(p.groupIds.filter(Boolean)));
  return p.groupId ? [p.groupId] : [];
}

function profileGroupKindLabel(kind) {
  return (
    {
      club: "Club",
      equipe: "Équipe",
      categorie: "Catégorie",
      selection: "Sélection",
      autre: "Groupe",
    }[kind] || "Groupe"
  );
}

function profileGroupLabel(g) {
  return profileGroupKindLabel(g && g.kind) + " · " + ((g && g.title) || "Sans titre");
}

function profileGroupsList() {
  try {
    asLoad();
  } catch (e) {}
  return typeof asStore !== "undefined" && Array.isArray(asStore.groups) ? asStore.groups : [];
}

function profileVisibleProfiles() {
  if (!profileGroupFilterId) return athleteProfiles.slice();
  return athleteProfiles.filter((p) => profileGroupIds(p).includes(profileGroupFilterId));
}

function refreshProfileSelect() {
  const sel = document.getElementById("profileAthleteSelect");
  if (!sel) return;
  const cur = currentProfileId;
  const groups = profileGroupsList();
  const byId = new Map(groups.map((g) => [g.id, g]));
  const visible = profileVisibleProfiles().slice().sort(compareAthleteProfiles);
  sel.innerHTML =
    '<option value="">— Choisir un athlète —</option>' +
    visible
      .map((p) => {
        // Affichage NOM puis prénom pour rendre le classement par nom évident.
        const label =
          [String(p.nom || "").toLocaleUpperCase("fr-FR"), p.prenom].filter(Boolean).join(" ") ||
          "Sans nom";
        return `<option value="${p.id}">${escapeHtml(label)}</option>`;
      })
      .join("");
  if (cur && visible.some((p) => p.id === cur)) sel.value = cur;
  const count = document.getElementById("profileVisibleCount");
  if (count) {
    count.textContent = visible.length + (visible.length === 1 ? " ATHLÈTE" : " ATHLÈTES");
    count.setAttribute(
      "aria-label",
      visible.length +
        " profil" +
        (visible.length > 1 ? "s" : "") +
        (profileGroupFilterId ? " dans le groupe sélectionné" : " au total"),
    );
  }
}

function refreshProfileGroupControls() {
  try { if (typeof asLoad === "function") asLoad(); } catch (e) {}
  const groups = profileGroupsList();
  const filter = document.getElementById("profileGroupFilter");
  if (filter) {
    const old = profileGroupFilterId;
    filter.innerHTML =
      '<option value="">Tous les groupes</option>' +
      groups
        .map((g) => {
          const count = athleteProfiles.filter((p) => profileGroupIds(p).includes(g.id)).length;
          return `<option value="${g.id}">${escapeHtml(profileGroupLabel(g))} (${count})</option>`;
        })
        .join("");
    if (groups.some((g) => g.id === old)) filter.value = old;
    else {
      profileSetGroupFilter("");
    }
  }
  const current = athleteProfiles.find((p) => p.id === currentProfileId);
  refreshProfileGroupSelect(current ? profileGroupIds(current) : []);
}

function refreshProfileGroupSelect(selectedIds) {
  const box = document.getElementById("profileGroupMembership");
  if (!box) return;
  const selected = new Set(
    Array.isArray(selectedIds) ? selectedIds : selectedIds ? [selectedIds] : [],
  );
  const groups = profileGroupsList();
  box.innerHTML = groups.length
    ? groups
        .map(
          (g) =>
            `<label class="profile-group-check"><input type="checkbox" value="${g.id}" ${selected.has(g.id) ? "checked" : ""} onchange="profileUpdateGroupSummary()"><span><b>${escapeHtml(g.title || "Groupe")}</b><small>${escapeHtml(profileGroupKindLabel(g.kind))}</small></span></label>`,
        )
        .join("")
    : '<div class="profile-groups-empty">Aucun groupe. Crée ton premier club, équipe ou catégorie.</div>';
  profileUpdateGroupSummary();
}

function profileSelectedGroupIdsFromForm() {
  return Array.from(
    document.querySelectorAll('#profileGroupMembership input[type="checkbox"]:checked'),
  )
    .map((el) => el.value)
    .filter(Boolean);
}

function profileUpdateGroupSummary() {
  const ids = profileSelectedGroupIdsFromForm();
  const groups = profileGroupsList();
  const summary = document.getElementById("profileGroupSummary");
  if (!summary) return;
  summary.textContent = ids.length
    ? ids
        .map((id) => groups.find((g) => g.id === id))
        .filter(Boolean)
        .map(profileGroupLabel)
        .join(" • ")
    : "Cet athlète n’est encore affecté à aucun groupe.";
}

function profileShowAll() {
  flushProfileAutosave();
  loadAthleteProfiles();
  profileSetGroupFilter("");
  refreshProfileSelect();
  // Ne pas remplacer le formulaire actuellement en cours d'édition.
}

function profileOnGroupFilterChange() {
  const requested = document.getElementById("profileGroupFilter")?.value || "";
  flushProfileAutosave();
  loadAthleteProfiles();
  const exists = !requested || profileGroupsList().some((g) => g.id === requested);
  profileSetGroupFilter(exists ? requested : "");
  refreshProfileSelect();
  const visible = profileVisibleProfiles();
  if (visible.length && !visible.some((p) => p.id === currentProfileId))
    selectAthleteProfile(visible[0].id);
  else if (!visible.length) newAthleteProfile();
}

function profileCreateGroup() {
  const nameEl = document.getElementById("profileNewGroupName");
  const kindEl = document.getElementById("profileNewGroupKind");
  const title = (nameEl?.value || "").trim();
  if (!title) {
    showToast("Indique le nom du club, de l’équipe ou de la catégorie");
    nameEl?.focus();
    return;
  }
  try {
    asLoad();
    const g = asDefaultGroup(title);
    g.kind = kindEl?.value || "equipe";
    asStore.groups.push(g);
    asStore.currentGroupId = g.id;
    asSave();
    if (nameEl) nameEl.value = "";
    refreshProfileGroupControls();
    const check = document.querySelector(`#profileGroupMembership input[value="${g.id}"]`);
    if (check) check.checked = true;
    profileUpdateGroupSummary();
    showToast(profileGroupKindLabel(g.kind) + " créé(e) : " + title);
  } catch (e) {
    console.error(e);
    showToast("Erreur lors de la création du groupe");
  }
}

function profileOpenGroupManager() {
  flushProfileAutosave();
  const selectedGroupId = profileGroupFilterId;
  closeAthleteProfiles();
  asLoad();
  if (selectedGroupId && asStore.groups.some((g) => g.id === selectedGroupId)) {
    asStore.currentGroupId = selectedGroupId;
    asSave();
  }
  if (typeof showAssiduite === "function") {
    showAssiduite();
    setTimeout(() => asShowPanel("asPlayers"), 0);
  }
}

function syncProfileToAttendanceGroups(p) {
  if (!p) return;
  try {
    asLoad();
    const ids = new Set(profileGroupIds(p));
    const name = dashProfileName(p);
    (asStore.groups || []).forEach((g) => {
      g.players = Array.isArray(g.players) ? g.players : [];
      const linked = g.players.find((x) => x.profileId === p.id);
      if (!ids.has(g.id)) {
        g.players = g.players.filter((x) => x.profileId !== p.id);
        return;
      }
      const sameName = g.players.find((x) => dashNormalizeName(x.name) === dashNormalizeName(name));
      const target = linked || sameName;
      if (target) {
        target.name = name;
        target.profileId = p.id;
      } else if (name) g.players.push({ id: uid(), profileId: p.id, name });
    });
    asSave();
  } catch (e) {
    console.warn(e);
  }
}

function emptyProfile() {
  return {
    id: uid(),
    photo: null,
    nom: "",
    prenom: "",
    naissance: "",
    tel: "",
    maillot: "",
    taille_maillot: "",
    numero_licence: "",
    code_couleur: "",
    poste: "",
    saison: "",
    blood_group: "",
    club: "",
    clubLogo: null,
    taille: "",
    poids: "",
    env1: "",
    env2: "",
    blessures_actuelles: "",
    blessures_anciennes: "",
    saut_elan: "",
    saut_sans: "",
    saut_attaque: "",
    saut_attaque_sans: "",
    saut_bloc: "",
    saut_bloc_sans: "",
    env_h: "",
    vma: "",
    vitesse_9m: "",
    vitesse_18m: "",
    vitesse_3x6: "",
    vitesse_93639: "",
    test_sapin: "",
    souplesse: "",
    medball_1_assis: "",
    medball_1_debout: "",
    medball_2_assis: "",
    medball_2_debout: "",
    tech_service: "",
    tech_reception: "",
    tech_attaque: "",
    tech_bloc: "",
    tech_passe: "",
    tech_defense: "",
    "1rm_dc": "",
    "1rm_tirage": "",
    "1rm_pullover": "",
    "1rm_squat": "",
    "1rm_sdt": "",
    m_cou: "",
    m_poitrine: "",
    m_abdo: "",
    m_biceps_g: "",
    m_cuisse_g: "",
    m_mollet_g: "",
    m_epaule: "",
    m_tour: "",
    m_hanche: "",
    m_biceps_d: "",
    m_cuisse_d: "",
    m_mollet_d: "",
    notes: "",
    groupId: "",
    groupIds: [],
    tests: [],
    updatedAt: Date.now(),
  };
}


/** Date de naissance : listes Jour / Mois / Année */
const PROFILE_MONTHS_FR = [
  "", "janvier", "février", "mars", "avril", "mai", "juin",
  "juillet", "août", "septembre", "octobre", "novembre", "décembre",
];
function profileInitNaissanceSelects() {
  const j = document.getElementById("pf_naissance_j");
  const m = document.getElementById("pf_naissance_m");
  const a = document.getElementById("pf_naissance_a");
  if (!j || !m || !a) return;
  if (j.options.length <= 1) {
    for (let d = 1; d <= 31; d++) {
      const o = document.createElement("option");
      o.value = String(d).padStart(2, "0");
      o.textContent = String(d);
      j.appendChild(o);
    }
  }
  if (m.options.length <= 1) {
    for (let i = 1; i <= 12; i++) {
      const o = document.createElement("option");
      o.value = String(i).padStart(2, "0");
      o.textContent = PROFILE_MONTHS_FR[i];
      m.appendChild(o);
    }
  }
  if (a.options.length <= 1) {
    const yNow = new Date().getFullYear();
    for (let y = yNow; y >= 1940; y--) {
      const o = document.createElement("option");
      o.value = String(y);
      o.textContent = String(y);
      a.appendChild(o);
    }
  }
  const sync = () => {
    const hidden = document.getElementById("pf_naissance");
    if (!hidden) return;
    if (j.value && m.value && a.value) {
      hidden.value = a.value + "-" + m.value + "-" + j.value;
    } else {
      hidden.value = "";
    }
    try {
      if (typeof scheduleProfileAutosave === "function") scheduleProfileAutosave();
    } catch (e) {}
  };
  if (!j.dataset.ymdBound) {
    j.addEventListener("change", sync);
    m.addEventListener("change", sync);
    a.addEventListener("change", sync);
    j.dataset.ymdBound = "1";
  }
}
function profileSetNaissanceUI(iso) {
  profileInitNaissanceSelects();
  const j = document.getElementById("pf_naissance_j");
  const m = document.getElementById("pf_naissance_m");
  const a = document.getElementById("pf_naissance_a");
  const hidden = document.getElementById("pf_naissance");
  if (!j || !m || !a) return;
  const s = String(iso || "").trim();
  if (hidden) hidden.value = s;
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    const [yy, mm, dd] = s.split("-");
    a.value = yy;
    m.value = mm;
    j.value = dd;
  } else {
    a.value = "";
    m.value = "";
    j.value = "";
  }
}

function fillProfileForm(p) {
  p = p || emptyProfile();
  currentProfileId = p.id;
  setProfileAutosaveStatus("idle");
  profilePhotoData = p.photo || null;
  profileClubLogoData = p.clubLogo || null;
  const box = document.getElementById("profilePhotoBox");
  if (box) {
    if (p.photo) {
      box.innerHTML = `<img loading="lazy" decoding="async" src="${p.photo}" alt="" /><input type="file" accept="image/*" onchange="onProfilePhoto(this)" />`;
    } else {
      const logo = getAppPlaceholderDataUrl();
      box.innerHTML = logo
        ? `<img loading="lazy" decoding="async" src="${logo}" alt="Strider Pro" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" /><input type="file" accept="image/*" onchange="onProfilePhoto(this)" />`
        : `<i class="fas fa-user" style="font-size:2.5rem;color:#94a3b8"></i><input type="file" accept="image/*" onchange="onProfilePhoto(this)" />`;
    }
  }
  const clubBox = document.getElementById("profileClubLogoBox");
  if (clubBox) {
    if (p.clubLogo) {
      clubBox.innerHTML = `<img loading="lazy" decoding="async" src="${p.clubLogo}" alt="Club" /><input type="file" accept="image/*" onchange="onProfileClubLogo(this)" />`;
    } else {
      const logo = getAppPlaceholderDataUrl();
      clubBox.innerHTML = logo
        ? `<img loading="lazy" decoding="async" src="${logo}" alt="Strider Pro" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" /><input type="file" accept="image/*" onchange="onProfileClubLogo(this)" />`
        : `<i class="fas fa-shield-alt" style="color:#94a3b8;font-size:1.5rem"></i><input type="file" accept="image/*" onchange="onProfileClubLogo(this)" />`;
    }
  }
  PROFILE_FIELDS.forEach((f) => {
    const el = document.getElementById("pf_" + f);
    if (el) el.value = p[f] != null ? p[f] : "";
  });
  profileInitNaissanceSelects();
  profileSetNaissanceUI(p && p.naissance);
  if (typeof syncProfileColorUI === "function") syncProfileColorUI();
  const sel = document.getElementById("profileAthleteSelect");
  if (sel) sel.value = p.id || "";
  refreshProfileGroupSelect(profileGroupIds(p));
  const td = document.getElementById("pf_test_date");
  if (td && !td.value) td.value = new Date().toISOString().slice(0, 10);
  if (typeof renderProfileTestsList === "function") renderProfileTestsList();
  if (typeof updateProfileIMC === "function") updateProfileIMC();
  if (typeof updateWaistHipRatio === "function") updateWaistHipRatio();
  if (
    document.getElementById("profileScreen")?.classList.contains("active") &&
    typeof drawProfileEvolutionChart === "function"
  )
    drawProfileEvolutionChart();
  window.SPProfileLayout?.sync();
}

function readProfileForm() {
  const p = emptyProfile();
  p.id = currentProfileId || uid();
  p.photo = profilePhotoData;
  p.clubLogo = profileClubLogoData;
  PROFILE_FIELDS.forEach((f) => {
    const el = document.getElementById("pf_" + f);
    p[f] = el ? el.value : "";
  });
  p.groupIds = profileSelectedGroupIdsFromForm();
  p.groupId = p.groupIds[0] || "";
  p.updatedAt = Date.now();
  return p;
}

function selectAthleteProfile(id) {
  if (!id) return;
  flushProfileAutosave();
  loadAthleteProfiles();
  const p = athleteProfiles.find((x) => x.id === id);
  if (p) {
    // Une ouverture directe (recherche, import, activité récente) ne modifie
    // pas le groupe choisi dans « Afficher ». La fiche peut rester hors filtre.
    refreshProfileSelect();
    fillProfileForm(p);
  } else showToast("Athlète introuvable");
}

function newAthleteProfile() {
  flushProfileAutosave();
  const p = emptyProfile();
  // Une création dans un groupe appartient à ce groupe dès le formulaire vierge.
  // L'autosauvegarde ne doit pas élargir le filtre à tous les profils.
  if (profileGroupFilterId && profileGroupsList().some((g) => g.id === profileGroupFilterId)) {
    p.groupIds = [profileGroupFilterId];
    p.groupId = profileGroupFilterId;
  }
  while (athleteProfiles.some((x) => x.id === p.id)) p.id = uid();
  currentProfileId = p.id;
  fillProfileForm(p);
  const sel = document.getElementById("profileAthleteSelect");
  if (sel) sel.value = "";
  showToast("Nouvelle fiche athlète");
}

// Rafraîchir la fiche éditée, pas toutes les photos et historiques à chaque pause de saisie.
function loadAthleteProfileForEditSave(profileId) {
  if (typeof USE_DISK === "undefined" || !USE_DISK) {loadAthleteProfiles();return;}
  try {
    const rawIndex = storeGet(PROFILE_INDEX_STORE_KEY);
    if (rawIndex == null || String(rawIndex).trim() === "") {loadAthleteProfiles();return;}
    const ids = JSON.parse(rawIndex);
    const knownIds = athleteProfiles.filter(p=>p&&p.id).map(p=>p.id);
    if (!Array.isArray(ids) || JSON.stringify(ids)!==JSON.stringify(knownIds)) {loadAthleteProfiles();return;}
    const idx=athleteProfiles.findIndex(p=>p.id===profileId);
    if(idx>=0){
      const latest=normalizeAthleteProfile(JSON.parse(storeGet(PROFILE_ITEM_STORE_PREFIX+profileId)||"null"));
      if(!latest){loadAthleteProfiles();return;}
      athleteProfiles[idx]=latest;
    }
  } catch(e) {loadAthleteProfiles();}
}

function saveAthleteProfile(silent) {
  const p = readProfileForm();
  if (!(p.nom || "").trim() && !(p.prenom || "").trim()) {
    if (!silent) showToast("Indique au moins un nom ou prénom");
    setProfileAutosaveStatus("pending");
    return;
  }
  loadAthleteProfileForEditSave(p.id);
  const idx = athleteProfiles.findIndex((x) => x.id === p.id);
  const previous = idx >= 0 ? athleteProfiles[idx] : null;
  // Preserve extension metadata without re-reading unrelated athletes.
  if (previous) for (const key of Object.keys(previous)) {
    if (!Object.prototype.hasOwnProperty.call(p, key)) p[key] = previous[key];
  }
  // IMPORTANT : conserver tout l'historique. Avant cette correction,
  // Enregistrer la fiche recréait tests:[] et effaçait les anciens points.
  p.tests = previous && Array.isArray(previous.tests) ? previous.tests.slice() : [];
  const tracked = [
    "poids",
    "taille",
    "env1",
    "env2",
    "saut_elan",
    "saut_sans",
    "saut_attaque",
    "saut_attaque_sans",
    "saut_bloc",
    "saut_bloc_sans",
    "env_h",
    "vma",
    "vitesse_9m",
    "vitesse_18m",
    "vitesse_3x6",
    "vitesse_93639",
    "test_sapin",
    "souplesse",
    "medball_1_assis",
    "medball_1_debout",
    "medball_2_assis",
    "medball_2_debout",
    "tech_service",
    "tech_reception",
    "tech_attaque",
    "tech_bloc",
    "tech_passe",
    "tech_defense",
    "1rm_dc",
    "1rm_tirage",
    "1rm_pullover",
    "1rm_squat",
    "1rm_sdt",
    "m_cou",
    "m_poitrine",
    "m_abdo",
    "m_biceps_g",
    "m_cuisse_g",
    "m_mollet_g",
    "m_epaule",
    "m_tour",
    "m_hanche",
    "m_biceps_d",
    "m_cuisse_d",
    "m_mollet_d",
  ];
  const hasNumeric = tracked.some(
    (k) => p[k] !== "" && p[k] != null && !isNaN(parseFloat(String(p[k]).replace(",", "."))),
  );
  const last = p.tests.length ? p.tests[p.tests.length - 1] : null;
  const baseDay =
    document.getElementById("pf_test_date")?.value || new Date().toISOString().slice(0, 10);
  const changed =
    !last ||
    String(last.date || "").slice(0, 10) !== baseDay ||
    tracked.some(
      (k) => String(last[k] == null ? "" : last[k]) !== String(p[k] == null ? "" : p[k]),
    );
  if (hasNumeric && changed) {
    p.tests.push(buildProfileSnapshot(p, profilePointLabel(baseDay)));
    if (p.tests.length > 60) p.tests = p.tests.slice(-60);
  }
  if (idx >= 0) athleteProfiles[idx] = p;
  else athleteProfiles.push(p);
  currentProfileId = p.id;
  if (saveAthleteProfilesStore(p.id)) {
    // Le filtre reste le choix du coach, même si une affiliation est retirée.
    // Le formulaire reste éditable ; seules les fiches du groupe sont listées.
    syncProfileToAttendanceGroups(p);
    refreshProfileGroupControls();
    refreshProfileSelect();
    const sel = document.getElementById("profileAthleteSelect");
    if (sel) sel.value = p.id;
    renderProfileTestsList();
    drawProfileEvolutionChart();
    if (!silent) showToast("Fiche athlète enregistrée");
    setProfileAutosaveStatus("saved");
  } else {
    setProfileAutosaveStatus("error");
  }
}

let _profileAutosaveTimer = null;
let _profileAutosaveReady = false;
let _profileIsComposing = false;
let _profileSaveMessageTimer = null;
function setProfileAutosaveStatus(state) {
  const el = document.getElementById("profileAutosaveStatus");
  if (!el) return;
  clearTimeout(_profileSaveMessageTimer);
  const labels = {
    saving: "Enregistrement…",
    saved: "Enregistré",
    pending: "Nom ou prénom requis",
    error: "Non enregistré — vérifie le stockage",
    idle: "",
  };
  el.dataset.state = state;
  el.textContent = labels[state] || "";
  el.classList.toggle("visible", Boolean(el.textContent));
  el.title = el.textContent;
  el.setAttribute("aria-label", el.textContent);
  if (state === "saved")
    _profileSaveMessageTimer = setTimeout(() => {
      el.textContent = "";
      el.classList.remove("visible");
      el.title = "";
      el.setAttribute("aria-label", "");
    }, 2000);
}
function scheduleProfileAutosave() {
  clearTimeout(_profileAutosaveTimer);
  _profileAutosaveTimer = null;
  if (!_profileAutosaveReady || !currentProfileId || _profileIsComposing) return;
  const nom = document.getElementById("pf_nom")?.value.trim() || "";
  const prenom = document.getElementById("pf_prenom")?.value.trim() || "";
  if (!nom && !prenom) {
    setProfileAutosaveStatus("pending");
    return;
  }
  const editingId = currentProfileId;
  setProfileAutosaveStatus("saving");
  _profileAutosaveTimer = setTimeout(function () {
    _profileAutosaveTimer = null;
    if (currentProfileId !== editingId || _profileIsComposing) return;
    try {
      saveAthleteProfile(true);
    } catch (e) {
      setProfileAutosaveStatus("error");
      console.warn(e);
    }
  }, 850);
}
function flushProfileAutosave() {
  if (!_profileAutosaveTimer) return;
  clearTimeout(_profileAutosaveTimer);
  _profileAutosaveTimer = null;
  try {
    saveAthleteProfile(true);
  } catch (e) {
    setProfileAutosaveStatus("error");
    console.warn(e);
  }
}
function initProfileAutosave() {
  const screen = document.getElementById("profileScreen");
  if (!screen || screen.dataset.autosaveReady) return;
  screen.dataset.autosaveReady = "1";
  screen.addEventListener("compositionstart", function () {
    _profileIsComposing = true;
    clearTimeout(_profileAutosaveTimer);
    _profileAutosaveTimer = null;
  });
  screen.addEventListener("compositionend", function () {
    _profileIsComposing = false;
    scheduleProfileAutosave();
  });
  screen.addEventListener("input", function (e) {
    if (e.target && (e.target.id || "").startsWith("pf_")) scheduleProfileAutosave();
  });
  screen.addEventListener("change", function (e) {
    if (
      e.target &&
      ((e.target.id || "").startsWith("pf_") || e.target.closest?.("#profileGroupMembership"))
    )
      scheduleProfileAutosave();
  });
  window.addEventListener("beforeunload", flushProfileAutosave);
  _profileAutosaveReady = true;
  setProfileAutosaveStatus("idle");
}
setTimeout(initProfileAutosave, 0);

function deleteAthleteProfile() {
  if (!currentProfileId) return;
  if (!confirm("Supprimer cette fiche athlète ?")) return;
  clearTimeout(_profileAutosaveTimer);
  _profileAutosaveTimer = null;
  loadAthleteProfiles();
  const removedId = currentProfileId;
  athleteProfiles = athleteProfiles.filter((x) => x.id !== removedId);
  if (!saveAthleteProfilesStore()) {
    showToast("Suppression non enregistrée");
    return;
  }
  try {
    if (typeof storeRemove === "function") storeRemove(PROFILE_ITEM_STORE_PREFIX + removedId);
  } catch (e) {}
  currentProfileId = null;
  refreshProfileSelect();
  const visible = profileVisibleProfiles().slice().sort(compareAthleteProfiles);
  if (visible.length) selectAthleteProfile(visible[0].id);
  else newAthleteProfile();
  showToast("Fiche supprimée");
}

async function onProfilePhoto(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  try {
    const data = await compressImageFile(file, 220, 0.55, true);
    profilePhotoData = data;
    const box = document.getElementById("profilePhotoBox");
    if (box && data) {
      box.innerHTML = `<img loading="lazy" decoding="async" src="${data}" alt="" /><input type="file" accept="image/*" onchange="onProfilePhoto(this)" />`;
      scheduleProfileAutosave();
    }
  } catch (e) {
    showToast("Erreur photo");
  }
}

async function onProfileClubLogo(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  try {
    const data = await compressImageFile(file, 160, 0.55, true);
    profileClubLogoData = data;
    const box = document.getElementById("profileClubLogoBox");
    if (box && data) {
      box.innerHTML = `<img loading="lazy" decoding="async" src="${data}" alt="Club" /><input type="file" accept="image/*" onchange="onProfileClubLogo(this)" />`;
      scheduleProfileAutosave();
    }
  } catch (e) {
    showToast("Erreur logo club");
  }
}

function getCurrentProfileObj() {
  if (!currentProfileId) return null;
  loadAthleteProfileForEditSave(currentProfileId);
  return athleteProfiles.find((x) => x.id === currentProfileId) || null;
}

function buildProfileSnapshot(p, dateLabel) {
  return {
    id: uid(),
    date: dateLabel,
    ts: Date.now(),
    poids: p.poids,
    taille: p.taille,
    env1: p.env1,
    env2: p.env2,
    saut_elan: p.saut_elan,
    saut_sans: p.saut_sans,
    saut_attaque: p.saut_attaque,
    saut_attaque_sans: p.saut_attaque_sans,
    saut_bloc: p.saut_bloc,
    saut_bloc_sans: p.saut_bloc_sans,
    env_h: p.env_h,
    vma: p.vma,
    vitesse_9m: p.vitesse_9m,
    vitesse_18m: p.vitesse_18m,
    vitesse_3x6: p.vitesse_3x6,
    vitesse_93639: p.vitesse_93639,
    test_sapin: p.test_sapin,
    souplesse: p.souplesse,
    medball_1_assis: p.medball_1_assis,
    medball_1_debout: p.medball_1_debout,
    medball_2_assis: p.medball_2_assis,
    medball_2_debout: p.medball_2_debout,
    tech_service: p.tech_service,
    tech_reception: p.tech_reception,
    tech_attaque: p.tech_attaque,
    tech_bloc: p.tech_bloc,
    tech_passe: p.tech_passe,
    tech_defense: p.tech_defense,
    "1rm_dc": p["1rm_dc"],
    "1rm_tirage": p["1rm_tirage"],
    "1rm_pullover": p["1rm_pullover"],
    "1rm_squat": p["1rm_squat"],
    "1rm_sdt": p["1rm_sdt"],
    m_cou: p.m_cou,
    m_poitrine: p.m_poitrine,
    m_abdo: p.m_abdo,
    m_biceps_g: p.m_biceps_g,
    m_cuisse_g: p.m_cuisse_g,
    m_mollet_g: p.m_mollet_g,
    m_epaule: p.m_epaule,
    m_tour: p.m_tour,
    m_hanche: p.m_hanche,
    m_biceps_d: p.m_biceps_d,
    m_cuisse_d: p.m_cuisse_d,
    m_mollet_d: p.m_mollet_d,
  };
}
function profilePointLabel(baseDay) {
  const now = new Date();
  const day = baseDay || now.toISOString().slice(0, 10);
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  // plusieurs points le même jour possibles grâce à l'heure
  return day + " " + hh + ":" + mm + ":" + ss;
}
let _pfPointTimer = null;
function scheduleProfilePointFromForm() {
  clearTimeout(_pfPointTimer);
  _pfPointTimer = setTimeout(function () {
    try {
      addProfileChartPoint(true);
    } catch (e) {}
  }, 500);
}
function addProfileChartPoint(silent) {
  // Ne pas enregistrer si l'utilisateur est encore en train de taper le poids/taille
  try {
    const ae = document.activeElement;
    if (ae && (ae.id === "pf_poids" || ae.id === "pf_taille")) {
      if (silent) return;
    }
  } catch (e) {}
  const p = readProfileForm();
  if (!(p.nom || "").trim() && !(p.prenom || "").trim()) {
    if (!silent) showToast("Indique un nom avant d'enregistrer un point");
    try {
      drawProfileEvolutionChart();
    } catch (e) {}
    return;
  }
  // Ignorer poids absurde pendant saisie partielle (ex: "9" au lieu de "93")
  if (p.poids !== "" && p.poids != null) {
    const kg = parseFloat(String(p.poids).replace(",", "."));
    if (!isNaN(kg) && kg > 0 && kg < 25) {
      // possible enfant, on accepte seulement si explicit (pas silent partiel)
      // pour adulte volley: si dernier poids connu > 40 et nouveau < 25, ignorer
      try {
        loadAthleteProfiles();
        const cur = athleteProfiles.find((x) => x.id === p.id);
        const prev = cur && cur.poids != null && cur.poids !== "" ? parseFloat(cur.poids) : null;
        if (prev != null && prev >= 40 && kg < 25 && silent) {
          try {
            drawProfileEvolutionChart();
          } catch (e) {}
          return;
        }
      } catch (e) {}
    }
  }
  // besoin d'au moins une valeur numérique
  const hasVal = [
    "poids",
    "taille",
    "vma",
    "saut_elan",
    "1rm_dc",
    "1rm_squat",
    "m_poitrine",
    "m_tour",
  ].some(function (k) {
    return p[k] !== "" && p[k] != null && !isNaN(parseFloat(p[k]));
  });
  if (!hasVal) {
    try {
      drawProfileEvolutionChart();
    } catch (e) {}
    return;
  }
  loadAthleteProfiles();
  let idx = athleteProfiles.findIndex((x) => x.id === p.id);
  if (idx < 0) {
    p.tests = [];
    athleteProfiles.push(p);
    idx = athleteProfiles.length - 1;
  } else {
    p.tests = athleteProfiles[idx].tests || [];
    p.photo = athleteProfiles[idx].photo || p.photo;
    p.clubLogo = athleteProfiles[idx].clubLogo || p.clubLogo;
  }
  currentProfileId = p.id;
  const dateEl = document.getElementById("pf_test_date");
  const baseDay = (dateEl && dateEl.value) || new Date().toISOString().slice(0, 10);
  const last = p.tests.length ? p.tests[p.tests.length - 1] : null;
  // si dernière valeur poids identique à l'instant T, ne pas doubler
  if (
    last &&
    String(last.poids || "") === String(p.poids || "") &&
    String(last.taille || "") === String(p.taille || "") &&
    Date.now() - (last.ts || 0) < 2000
  ) {
    try {
      drawProfileEvolutionChart();
    } catch (e) {}
    return;
  }
  const label = profilePointLabel(baseDay);
  p.tests.push(buildProfileSnapshot(p, label));
  p.tests.sort(function (a, b) {
    return String(a.date || "").localeCompare(String(b.date || "")) || (a.ts || 0) - (b.ts || 0);
  });
  if (p.tests.length > 60) p.tests = p.tests.slice(-60);
  athleteProfiles[idx] = p;
  if (saveAthleteProfilesStore()) {
    try {
      renderProfileTestsList();
    } catch (e) {}
    try {
      drawProfileEvolutionChart();
    } catch (e) {}
    if (!silent) showToast("Point enregistré · " + label);
  }
}
function saveProfileTest() {
  addProfileChartPoint(false);
}

function renderProfileTestsList() {
  const box = document.getElementById("profileTestsList");
  if (!box) return;
  const p = getCurrentProfileObj();
  const tests = p && p.tests ? p.tests.slice().reverse() : [];
  if (!tests.length) {
    box.innerHTML =
      '<p style="color:#94a3b8;font-size:0.88rem;margin-top:8px">Aucun test enregistré pour cet athlète.</p>';
    return;
  }
  box.innerHTML =
    '<div style="font-size:0.8rem;color:#94a3b8;margin:8px 0 4px">Historique des tests</div>' +
    tests
      .map((t) => {
        const bits = [];
        if (t.poids) bits.push("Poids " + t.poids + "kg");
        if (t.vma) bits.push("VMA " + t.vma);
        if (t.saut_elan) bits.push("Saut " + t.saut_elan + "cm");
        if (t["1rm_dc"]) bits.push("DC " + t["1rm_dc"] + "kg");
        return `<div class="profile-test-item">
            <span><strong>${escapeHtml(t.date || "")}</strong> · ${escapeHtml(bits.join(" · ") || "valeurs saisies")}</span>
            <button type="button" title="Supprimer" onclick="deleteProfileTest('${t.id}')"><i class="fas fa-trash"></i></button>
          </div>`;
      })
      .join("");
}

function deleteProfileTest(testId) {
  loadAthleteProfiles();
  const idx = athleteProfiles.findIndex((x) => x.id === currentProfileId);
  if (idx < 0) return;
  if (!confirm("Supprimer ce test ?")) return;
  athleteProfiles[idx].tests = (athleteProfiles[idx].tests || []).filter((t) => t.id !== testId);
  saveAthleteProfilesStore();
  renderProfileTestsList();
  drawProfileEvolutionChart();
  showToast("Test supprimé");
}

function drawProfileEvolutionChart() {
  const canvas = document.getElementById("profileEvolutionCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const dpr = window.devicePixelRatio || 1;
  const parent = canvas.parentElement;
  let w = canvas.clientWidth || (parent && (parent.clientWidth || parent.offsetWidth)) || 0;
  if (w < 40) w = 640;
  const h = 280;
  canvas.width = Math.floor(w * dpr);
  canvas.height = Math.floor(h * dpr);
  canvas.style.width = "100%";
  canvas.style.height = h + "px";
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const metric = document.getElementById("pf_graph_metric")?.value || "poids";
  const summary = document.getElementById("profileEvolutionSummary");
  const p = getCurrentProfileObj();
  let tests =
    p && p.tests
      ? p.tests.filter((t) => {
          const raw = t[metric];
          return raw !== "" && raw != null && !isNaN(parseFloat(String(raw).replace(",", ".")));
        })
      : [];
  tests = tests.slice().sort(function (a, b) {
    return String(a.date || "").localeCompare(String(b.date || "")) || (a.ts || 0) - (b.ts || 0);
  });

  const labels = {
    poids: "Poids (kg)",
    taille: "Taille (cm)",
    env1: "Envergure 1 main",
    env2: "Envergure 2 mains",
    env_h: "Envergure horizontale",
    saut_elan: "Saut élan",
    saut_sans: "Saut sans élan",
    saut_attaque: "Saut d’attaque avec élan",
    saut_attaque_sans: "Saut d’attaque sans élan",
    saut_bloc: "Saut de bloc avec élan",
    saut_bloc_sans: "Saut de bloc sans élan",
    env_h: "Envergure horizontale",
    vma: "VMA",
    vitesse_9m: "Vitesse 9m",
    vitesse_18m: "Vitesse 18m",
    vitesse_3x6: "Vitesse 3×6 m",
    vitesse_93639: "Vitesse 9-3-6-3-9",
    test_sapin: "Test Sapin",
    souplesse: "Souplesse",
    medball_1_assis: "Med-ball 1kg assis",
    medball_1_debout: "Med-ball 1kg debout",
    medball_2_assis: "Med-ball 2kg assis",
    medball_2_debout: "Med-ball 2kg debout",
    tech_service: "Service",
    tech_reception: "Réception",
    tech_attaque: "Attaque",
    tech_bloc: "Bloc",
    tech_passe: "Passe d’attaque",
    tech_defense: "Défense basse",
    "1rm_dc": "1RM DC",
    "1rm_tirage": "1RM Tirage",
    "1rm_pullover": "1RM Pull-over",
    "1rm_squat": "1RM Squat",
    "1rm_sdt": "1RM SDT",
    m_cou: "Cou",
    m_poitrine: "Poitrine",
    m_abdo: "Abdo",
    m_biceps_g: "Biceps G",
    m_cuisse_g: "Cuisse G",
    m_mollet_g: "Mollet G",
    m_epaule: "Épaule",
    m_tour: "Tour de taille",
    m_hanche: "Hanche",
    m_biceps_d: "Biceps D",
    m_cuisse_d: "Cuisse D",
    m_mollet_d: "Mollet D",
  };

  // fond
  const grd = ctx.createLinearGradient(0, 0, 0, h);
  grd.addColorStop(0, "rgba(15,12,20,0.9)");
  grd.addColorStop(1, "rgba(10,8,14,0.95)");
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, w, h);

  if (tests.length < 1) {
    if (summary)
      summary.innerHTML =
        '<div class="profile-trend-card neutral"><small>Historique</small><strong>Aucune mesure</strong><span>Enregistre une première valeur.</span></div>';
    ctx.fillStyle = "#94a3b8";
    ctx.font = "14px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("Aucun point — change le poids ou clique Sauver test", w / 2, h / 2);
    return;
  }

  const values = tests.map((t) => parseFloat(String(t[metric]).replace(",", ".")));
  let minV = Math.min.apply(null, values);
  let maxV = Math.max.apply(null, values);
  // Échelle réaliste : un écart de 1 kg (93 vs 94) doit être bien visible
  if (!isFinite(minV) || !isFinite(maxV)) {
    if (summary) summary.innerHTML = "";
    ctx.fillStyle = "#94a3b8";
    ctx.font = "14px system-ui";
    ctx.textAlign = "center";
    ctx.fillText("Données invalides", w / 2, h / 2);
    return;
  }
  if (minV === maxV) {
    minV -= 1;
    maxV += 1;
  }
  // amplitude mini pour bien séparer les points proches
  let range = maxV - minV;
  if (range < 2) {
    const mid = (minV + maxV) / 2;
    minV = mid - 1.25;
    maxV = mid + 1.25;
    range = maxV - minV;
  }
  const pad = Math.max(range * 0.12, 0.25);
  const yMin = minV - pad;
  const yMax = maxV + pad;
  const left = 48,
    right = w - 16,
    top = 32,
    bottom = h - 44;
  const plotW = Math.max(right - left, 10);
  const plotH = Math.max(bottom - top, 10);

  // grille
  ctx.strokeStyle = "rgba(255,255,255,0.07)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = top + (plotH * i) / 4;
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(right, y);
    ctx.stroke();
    const val = yMax - ((yMax - yMin) * i) / 4;
    ctx.fillStyle = "#94a3b8";
    ctx.font = "11px system-ui";
    ctx.textAlign = "right";
    ctx.fillText(val.toFixed(1), left - 6, y + 4);
  }

  const spanY = yMax - yMin || 1;
  const pts = tests.map(function (t, i) {
    const x = left + (tests.length === 1 ? plotW / 2 : (plotW * i) / (tests.length - 1));
    // 93 plus bas que 94 : y augmente vers le bas en canvas
    const ratio = (values[i] - yMin) / spanY; // 0 en bas d'échelle, 1 en haut
    const y = top + plotH * (1 - ratio);
    return { x: x, y: y, v: values[i], date: t.date || "" };
  });

  // aire sous la courbe
  ctx.beginPath();
  pts.forEach(function (pt, i) {
    if (i === 0) ctx.moveTo(pt.x, pt.y);
    else ctx.lineTo(pt.x, pt.y);
  });
  ctx.lineTo(pts[pts.length - 1].x, bottom);
  ctx.lineTo(pts[0].x, bottom);
  ctx.closePath();
  ctx.fillStyle = "rgba(56,189,248,0.14)";
  ctx.fill();

  // ligne
  ctx.strokeStyle = "#38bdf8";
  ctx.lineWidth = 2.5;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.beginPath();
  pts.forEach(function (pt, i) {
    if (i === 0) ctx.moveTo(pt.x, pt.y);
    else ctx.lineTo(pt.x, pt.y);
  });
  ctx.stroke();

  // points
  pts.forEach(function (pt) {
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
    ctx.fillStyle = "#e8d0af";
    ctx.fill();
    ctx.strokeStyle = "#0a0a12";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = "#f8fafc";
    ctx.font = "bold 11px system-ui";
    ctx.textAlign = "center";
    ctx.fillText(String(pt.v), pt.x, pt.y - 12);
    ctx.fillStyle = "#94a3b8";
    ctx.font = "9px system-ui";
    // afficher date+heure condensée
    const lab = String(pt.date);
    const short = lab.length > 10 ? lab.slice(5, 16) : lab.slice(5);
    ctx.fillText(short, pt.x, bottom + 16);
  });

  ctx.fillStyle = "#e8d0af";
  ctx.font = "bold 13px system-ui";
  ctx.textAlign = "left";
  ctx.fillText((labels[metric] || metric) + " · " + tests.length + " point(s)", left, 18);

  // Rectangles de lecture rapide : départ, valeur actuelle et tendance.
  if (summary) {
    const first = values[0],
      current = values[values.length - 1];
    const delta = current - first;
    const percent = first !== 0 ? (delta / Math.abs(first)) * 100 : 0;
    const unit =
      metric === "poids"
        ? " kg"
        : [
              "taille",
              "saut_elan",
              "saut_sans",
              "m_cou",
              "m_poitrine",
              "m_abdo",
              "m_biceps_g",
              "m_cuisse_g",
              "m_mollet_g",
              "m_epaule",
              "m_tour",
              "m_hanche",
              "m_biceps_d",
              "m_cuisse_d",
              "m_mollet_d",
            ].includes(metric)
          ? " cm"
          : "";
    const lowerIsBetter = ["vitesse_9m", "vitesse_18m"].includes(metric);
    const neutralMetric = metric === "poids" || metric === "taille" || metric.startsWith("m_");
    let trendLabel = "Stable",
      trendClass = "neutral",
      symbol = "→";
    if (Math.abs(delta) > 0.0001) {
      symbol = delta > 0 ? "↑" : "↓";
      if (neutralMetric) {
        trendLabel = delta > 0 ? "Hausse" : "Baisse";
        trendClass = delta > 0 ? "up" : "down";
      } else {
        const progress = lowerIsBetter ? delta < 0 : delta > 0;
        trendLabel = progress ? "Progression" : "Régression";
        trendClass = progress ? "progress" : "regress";
      }
    }
    const signed = (delta > 0 ? "+" : "") + Math.round(delta * 100) / 100;
    const signedPct = (percent > 0 ? "+" : "") + Math.round(percent * 10) / 10 + "%";
    summary.innerHTML = `
          <div class="profile-trend-card"><small>Départ</small><strong>${first}${unit}</strong><span>${escapeHtml(String(tests[0].date || "").slice(0, 10))}</span></div>
          <div class="profile-trend-card"><small>Actuel</small><strong>${current}${unit}</strong><span>${escapeHtml(String(tests[tests.length - 1].date || "").slice(0, 10))}</span></div>
          <div class="profile-trend-card ${trendClass}"><small>Évolution</small><strong>${signed}${unit}</strong><span>${signedPct} depuis le départ</span></div>
          <div class="profile-trend-card ${trendClass}"><small>Tendance</small><strong>${symbol} ${trendLabel}</strong><span>${tests.length} mesure${tests.length > 1 ? "s" : ""}</span></div>`;
  }
}

async function exportProfilePDF() {
  const card = document.getElementById("profileCard");
  if (!card) return;
  // sauver d'abord
  try {
    saveAthleteProfile();
  } catch (e) {}
  showToast("Génération du PDF...");
  if (window.yhDisk && typeof window.yhDisk.exportPdf === "function") {
    const nom =
      (document.getElementById("pf_prenom")?.value || "") +
      "_" +
      (document.getElementById("pf_nom")?.value || "athlete");
    document.body.classList.add("pdf-profile-export");
    try {
      await new Promise((r) => setTimeout(r, 120));
      const result = await window.yhDisk.exportPdf("Fiche_" + nom.replace(/\s+/g, "_") + ".pdf", {
        landscape: false,
      });
      if (result && result.ok) showToast("PDF enregistré");
      else if (!(result && result.canceled))
        showToast("Erreur PDF : " + ((result && result.error) || "inconnue"));
    } catch (e) {
      console.error(e);
      showToast("Erreur lors de la génération du PDF");
    } finally {
      document.body.classList.remove("pdf-profile-export");
    }
    return;
  }
  try {
    await ensureExportTools({ image: true, pdf: true });
    const canvas = await html2canvas(card, {
      scale: 2,
      useCORS: true,
      backgroundColor: "#0f0c14",
      logging: false,
    });
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 10;
    const imgW = pageW - margin * 2;
    const imgH = (canvas.height * imgW) / canvas.width;
    let y = margin;
    const data = canvas.toDataURL("image/jpeg", 0.92);
    if (imgH <= pageH - margin * 2) {
      doc.addImage(data, "JPEG", margin, y, imgW, imgH);
    } else {
      // multi-page crop
      let remaining = imgH;
      let srcY = 0;
      const pageImgH = pageH - margin * 2;
      while (remaining > 0) {
        const sliceH = Math.min(pageImgH, remaining);
        const sliceCanvas = document.createElement("canvas");
        const ratio = canvas.width / imgW;
        sliceCanvas.width = canvas.width;
        sliceCanvas.height = Math.floor(sliceH * ratio);
        const sctx = sliceCanvas.getContext("2d");
        sctx.drawImage(
          canvas,
          0,
          Math.floor(srcY * ratio),
          canvas.width,
          sliceCanvas.height,
          0,
          0,
          canvas.width,
          sliceCanvas.height,
        );
        if (srcY > 0) doc.addPage();
        doc.addImage(
          sliceCanvas.toDataURL("image/jpeg", 0.92),
          "JPEG",
          margin,
          margin,
          imgW,
          sliceH,
        );
        remaining -= sliceH;
        srcY += sliceH;
      }
    }
    const nom =
      (document.getElementById("pf_prenom")?.value || "") +
      "_" +
      (document.getElementById("pf_nom")?.value || "athlete");
    doc.save("Fiche_" + nom.replace(/\s+/g, "_") + ".pdf");
    showToast("PDF téléchargé");
  } catch (e) {
    console.error(e);
    showToast("Erreur PDF — vérifie la connexion (librairies)");
  }
}

// Options de profil : suppression protégée, menu fermé hors clic ou Échap.
function closeProfileMoreMenu() {
  const menu = document.getElementById("profileMoreMenu");
  if (menu) menu.hidden = true;
  document.getElementById("profileMoreButton")?.setAttribute("aria-expanded", "false");
}
document.getElementById("profileMoreButton")?.addEventListener("click", () => {
  const menu = document.getElementById("profileMoreMenu");
  if (!menu) return;
  menu.hidden = !menu.hidden;
  document.getElementById("profileMoreButton").setAttribute("aria-expanded", String(!menu.hidden));
});
document.getElementById("profileDeleteButton")?.addEventListener("click", () => {
  closeProfileMoreMenu();
  deleteAthleteProfile();
});
document.addEventListener("click", (e) => {
  if (!e.target.closest(".profile-more-wrap")) closeProfileMoreMenu();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeProfileMoreMenu();
});

try { document.addEventListener("DOMContentLoaded", function(){ profileInitNaissanceSelects(); }); } catch(e) {}


/** Sous-volets Tests : Physique / Technique / 1RM */
function selectProfileTestSubtab(tab) {
  const allowed = ["physique", "technique", "1rm"];
  if (!allowed.includes(tab)) tab = "physique";
  document.querySelectorAll("[data-test-subtab]").forEach((btn) => {
    const on = btn.getAttribute("data-test-subtab") === tab;
    btn.classList.toggle("active", on);
    btn.setAttribute("aria-selected", String(on));
  });
  document.querySelectorAll("[data-test-pane]").forEach((pane) => {
    pane.hidden = pane.getAttribute("data-test-pane") !== tab;
  });
  if (tab !== "1rm" && typeof hideOneRmPercents === "function") hideOneRmPercents();
}
window.selectProfileTestSubtab = selectProfileTestSubtab;
