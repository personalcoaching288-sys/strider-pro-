/** Thème / dark mode */
// ========== DARK MODE ==========
function toggleDarkMode(force) {
  const on =
    force === true || force === false ? force : !document.body.classList.contains("dark-mode");
  document.body.classList.toggle("dark-mode", on);
  try {
    localStorage.setItem("yhcoachpro_dark", on ? "1" : "0");
  } catch (e) {}
}
function initDarkMode() {
  let pref = null;
  try {
    pref = localStorage.getItem("yhcoachpro_dark");
  } catch (e) {}
  if (pref === "1") toggleDarkMode(true);
  else if (pref === "0") toggleDarkMode(false);
  else if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches)
    toggleDarkMode(true);
}
