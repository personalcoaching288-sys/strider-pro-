# Version 2.4.13 — Retrait des anciens thèmes visuels

Tous les fonds photographiques actuellement affichés restent identiques à la 2.4.12 : tableau de bord, menu latéral, fiches de séance, assiduité, profils, programmes et bibliothèque. Aucun fichier photo n’est supprimé ou remplacé.

Retrait du fond dégradé historique du corps de l’application, remplacé par une couleur noire unie de secours derrière les photos. Suppression de la section Thèmes (Doré, Bleu, Rouge, Noir) des paramètres, de ses fonctions et de ses anciens styles CSS. Le réglage Mode sombre est conservé ; les anciennes préférences de couleur deviennent inactives sans toucher aux données ni aux sauvegardes.

Les accents dorés, panneaux translucides, couleurs personnalisées des programmes et thèmes d’entraînement (force, hypertrophie, etc.) sont conservés. Les exports utilisent leur fond sombre fixe habituel ; le PDF des fiches reste en A4 clair. Import des fiches, sauvegarde et licence restent inchangés.

Sauvegarder avant mise à jour et conserver la version précédente. Archive du projet source avec scripts de lancement, pas un installateur compilé. Tests navigateur ; installation Windows à vérifier sur votre ordinateur.
