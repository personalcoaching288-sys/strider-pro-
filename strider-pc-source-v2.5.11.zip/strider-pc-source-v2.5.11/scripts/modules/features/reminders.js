/** Rappels séances du jour */
// ========== REMINDERS ==========
function checkTodayReminders() {
  const today = new Date().toISOString().slice(0, 10);
  const due = programsIndex.filter((p) => p.date === today);
  const banner = document.getElementById("reminderBanner");
  const text = document.getElementById("reminderText");
  if (!banner) return;
  if (due.length) {
    const names = due.map((p) => p.athlete || "Athlète").join(", ");
    if (text)
      text.textContent =
        due.length === 1
          ? `Séance prévue aujourd'hui : ${names}`
          : `${due.length} séances prévues aujourd'hui : ${names}`;
    banner.classList.add("show");
    if ("Notification" in window && Notification.permission === "granted") {
      try {
        new Notification("Strider Pro", { body: text.textContent, icon: "./icon-192.png" });
      } catch (e) {}
    }
  } else {
    banner.classList.remove("show");
  }
}
function requestNotificationPermission() {
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
  }
}
