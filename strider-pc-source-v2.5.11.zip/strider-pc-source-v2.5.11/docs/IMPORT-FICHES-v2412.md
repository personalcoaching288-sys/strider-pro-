# Version 2.4.12 — Import de fiches et fonds définitifs

Fiche de séance : photo de la salle de volley. Assiduité : photo de la joueuse en bleu. Ce sont les fonds de la maquette B choisie. Photos conservées à leur résolution d’origine et en WebP sans perte, marges hautes retirées ; cela augmente la taille du projet. Le tableau de bord, le menu latéral, le logo et les panneaux translucides sont conservés. PDF et impression restent en A4 clair.

## Importer une fiche
Cliquer Importer fichier en haut de la page Fiches de séance, puis choisir le fichier JSON obtenu par Partage > JSON — sauvegarde. La fiche entière, son club, ses consignes et tous les schémas sont importés puis enregistrés. Retrouver la fiche dans Mes fiches. L’import crée de nouveaux identifiants et conserve les fiches existantes ; les titres identiques reçoivent le suffixe Importée.

Formats acceptés : export de fiche YhCoachPro formatVersion 1, fiche complète JSON brute, tableau JSON de fiches complètes (jusqu’à 100 par fichier, fichier de 10 Mo maximum). PDF, images, HTML et sauvegardes globales de l’application ne sont pas convertis en fiches modifiables. Les fichiers invalides sont refusés sans insertion partielle. Les champs importés sont contrôlés, et les éléments du schéma limités aux types connus de l’éditeur.

Avant mise à jour : faire une sauvegarde complète, garder la version précédente et décompresser dans un nouveau dossier. Démarrer avec DEMARRER-DEVELOPPEMENT.bat. L’archive contient le projet source, pas un installateur compilé. Tests navigateur et stockage simulé ; vérifier l’installation et l’imprimante sur votre ordinateur Windows.
