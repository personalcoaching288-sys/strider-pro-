# Version 2.4.19 — Groupe conservé et assiduité Nom puis Prénom

- Une nouvelle fiche créée dans un groupe a ce groupe précoché dès le départ.
- L’enregistrement automatique conserve le filtre sélectionné. Il ne repasse plus à tous les profils.
- Le coach peut toujours modifier les affiliations. Une fiche retirée du groupe reste dans le formulaire en cours, mais n’apparaît plus dans la liste filtrée ; aucune affiliation n’est forcée à la sauvegarde.
- La suppression d’un profil choisit le prochain profil dans le même groupe, sans élargir le filtre.
- À l’ouverture de la page Profils, tous les profils restent disponibles, comme dans la version précédente.
- Assiduité : Nom puis Prénom, ordre alphabétique par nom puis prénom dans l’appel, l’effectif, les statistiques, le tableau mensuel et les rapports PDF/impression, HTML, Excel et JSON.
- Les identifiants d’assiduité et les pointages existants sont conservés. Le nom historique stocké n’est pas réécrit, pour préserver les associations avec les programmes.
- Les fiches liées permettent le bon affichage des noms composés. Les anciens noms libres sans fiche correspondante restent tels qu’ils ont été saisis, sans inversion hasardeuse. Pour les nouvelles entrées libres, saisir Nom puis Prénom.
- Aucun changement de logo, de fond, de licence ou de format de sauvegarde. Les exports JSON de profils complets et les listes personnalisées restent disponibles.

Avant remplacement : réaliser une sauvegarde complète et conserver l’ancienne version.
Projet Electron avec fichiers BAT ; ce ZIP n’est pas un installateur Windows compilé.
