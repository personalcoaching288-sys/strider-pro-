/* Import local XLSX/DOCX/CSV : aucune transmission et aucune écriture avant confirmation. */
(function () {
  "use strict";
  const MAX_FILE = 12 * 1024 * 1024,
    MAX_XML = 8 * 1024 * 1024,
    MAX_TOTAL = 32 * 1024 * 1024;
  const MAX_ROWS = 10000,
    MAX_COLS = 150;
  const $ = (id) => document.getElementById(id);
  const esc = (v) =>
    String(v ?? "").replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
    );
  const norm = (s) =>
    String(s ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "");
  const labels = {
    nom: "Nom",
    prenom: "Prénom",
    naissance: "Date de naissance",
    tel: "Téléphone",
    maillot: "N° de maillot",
    taille_maillot: "Taille de maillot",
    numero_licence: "N° de licence",
    poste: "Poste",
    saison: "Saison",
    blood_group: "Groupe sanguin",
    club: "Club",
    taille: "Taille (cm)",
    poids: "Poids (kg)",
    env1: "Envergure 1 main",
    env2: "Envergure 2 mains",
    notes: "Observations",
    code_couleur: "Repère couleur",
  };
  const aliases = {
    __nom_prenom: ["nometprenom", "nomprenom", "nometprenoms", "nomsprenoms", "nomcomplet", "fullname", "athlete", "eleves", "eleve"],
    __prenom_nom: ["prenometnom", "prenomnom"],
    nom: ["nom", "noms", "nomdefamille", "surname", "lastname"],
    prenom: ["prenom", "prenoms", "firstname"],
    naissance: [
      "naissance",
      "datedenaissance",
      "datenaissance",
      "birthday",
      "birthdate",
      "dob",
      "datenaiss",
    ],
    tel: ["tel", "telephone", "telephonee", "mobile", "portable", "phone"],
    maillot: ["maillot", "numeromaillot", "numerodemaillot", "nmaillot", "ndemaillot", "dossard"],
    taille_maillot: ["taillemaillot", "tailledemaillot"],
    numero_licence: ["numerolicence", "numerodelicence", "nlicence", "ndelicence", "licence"],
    poste: ["poste", "postedejeu", "position"],
    saison: ["saison", "saisonsportive"],
    blood_group: ["groupesanguin", "groupsanguin", "groupsonguin", "groupesonguin", "bloodgroup"],
    club: ["club", "nomduclub"],
    taille: ["taille", "taillecm", "height", "heightcm"],
    poids: ["poids", "poidskg", "weight"],
    env1: ["envergure1main", "envergure1", "env1"],
    env2: ["envergure2mains", "envergure2", "env2"],
    notes: ["notes", "observations", "observation", "commentaires"],
    code_couleur: ["codecouleur", "reperecouleur", "couleur"],
  };
  const label = (k) => labels[k] || k.replace(/_/g, " ");
  const nodes = (root, tag) =>
    Array.from(root.getElementsByTagName("*")).filter((n) => n.localName === tag);
  const child = (root, tag) => Array.from(root.children || []).filter((n) => n.localName === tag);
  function xml(text) {
    if (/<!DOCTYPE|<!ENTITY/i.test(text)) throw Error("XML avec entités interdit.");
    const d = new DOMParser().parseFromString(text, "application/xml");
    if (nodes(d, "parsererror").length) throw Error("Document XML invalide.");
    return d;
  }
  async function zipEntries(file) {
    const data = new Uint8Array(await file.arrayBuffer()),
      v = new DataView(data.buffer);
    let end = -1;
    for (let i = data.length - 22; i >= Math.max(0, data.length - 65557); i--)
      if (
        v.getUint32(i, true) === 0x06054b50 &&
        i + 22 + v.getUint16(i + 20, true) === data.length
      ) {
        end = i;
        break;
      }
    if (end < 0) throw Error("Fichier Office invalide ou endommagé.");
    if (v.getUint16(end + 4, true) || v.getUint16(end + 6, true))
      throw Error("Archive multi-volume non prise en charge.");
    const count = v.getUint16(end + 10, true),
      size = v.getUint32(end + 12, true);
    let pos = v.getUint32(end + 16, true),
      total = 0;
    if (count > 3000 || pos + size > end) throw Error("Archive Office trop volumineuse.");
    const entries = new Map();
    for (let i = 0; i < count; i++) {
      if (pos + 46 > data.length || v.getUint32(pos, true) !== 0x02014b50)
        throw Error("Archive Office invalide.");
      const flags = v.getUint16(pos + 8, true),
        method = v.getUint16(pos + 10, true),
        compressed = v.getUint32(pos + 20, true),
        unpacked = v.getUint32(pos + 24, true),
        len = v.getUint16(pos + 28, true),
        extra = v.getUint16(pos + 30, true),
        comment = v.getUint16(pos + 32, true),
        offset = v.getUint32(pos + 42, true);
      if (
        pos + 46 + len + extra + comment > data.length ||
        flags & 1 ||
        unpacked === 0xffffffff ||
        offset === 0xffffffff
      )
        throw Error("Fichier chiffré ou archive non prise en charge.");
      const name = new TextDecoder().decode(data.subarray(pos + 46, pos + 46 + len));
      total += unpacked;
      if (
        total > MAX_TOTAL ||
        unpacked > MAX_XML ||
        /[\u0000\\]/.test(name) ||
        name.split("/").includes("..")
      )
        throw Error("Archive trop volumineuse ou chemin invalide.");
      entries.set(name, { method, compressed, unpacked, offset });
      pos += 46 + len + extra + comment;
    }
    let inflated = 0;
    return async (name) => {
      const e = entries.get(name);
      if (!e) return null;
      const o = e.offset;
      if (o + 30 > data.length || v.getUint32(o, true) !== 0x04034b50)
        throw Error("Entrée ZIP invalide.");
      const start = o + 30 + v.getUint16(o + 26, true) + v.getUint16(o + 28, true);
      if (start + e.compressed > data.length) throw Error("Fichier tronqué.");
      const packed = data.subarray(start, start + e.compressed);
      let out;
      if (e.method === 0) out = packed;
      else if (e.method === 8) {
        const reader = new Blob([packed])
            .stream()
            .pipeThrough(new DecompressionStream("deflate-raw"))
            .getReader(),
          chunks = [];
        let n = 0;
        try {
          while (true) {
            const step = await reader.read();
            if (step.done) break;
            n += step.value.byteLength;
            if (n > MAX_XML || inflated + n > MAX_TOTAL)
              throw Error("Contenu décompressé trop volumineux.");
            chunks.push(step.value);
          }
        } catch (error) {
          await reader.cancel().catch(() => {});
          throw error;
        }
        out = new Uint8Array(n);
        let a = 0;
        for (const c of chunks) {
          out.set(c, a);
          a += c.length;
        }
      } else throw Error("Compression Office non prise en charge.");
      if (out.length !== e.unpacked) throw Error("Taille d’archive incohérente.");
      inflated += out.length;
      return new TextDecoder().decode(out);
    };
  }
  function bounds(rows) {
    if (rows.length > MAX_ROWS + 1 || rows.some((r) => r.length > MAX_COLS))
      throw Error("Limite d’import : 10 000 lignes et 150 colonnes par fichier.");
    return rows;
  }
  async function parseXlsx(file) {
    const get = await zipEntries(file),
      wb = xml((await get("xl/workbook.xml")) || ""),
      rels = xml((await get("xl/_rels/workbook.xml.rels")) || ""),
      stringsText = await get("xl/sharedStrings.xml"),
      stylesText = await get("xl/styles.xml");
    const strings = stringsText
        ? nodes(xml(stringsText), "si").map((si) =>
            nodes(si, "t")
              .map((n) => n.textContent)
              .join(""),
          )
        : [],
      styles = stylesText ? xml(stylesText) : null,
      formats = {};
    if (styles)
      for (const n of nodes(styles, "numFmt"))
        formats[n.getAttribute("numFmtId")] = n.getAttribute("formatCode");
    const xfs = styles ? child(nodes(styles, "cellXfs")[0] || {}, "xf") : [];
    const date1904 = nodes(wb, "workbookPr")[0]?.getAttribute("date1904");
    const tables = [];
    for (const sheet of nodes(wb, "sheet")) {
      const id =
        sheet.getAttribute("r:id") ||
        Array.from(sheet.attributes).find((a) => a.localName === "id")?.value;
      const rel = nodes(rels, "Relationship").find((n) => n.getAttribute("Id") === id);
      if (!rel || rel.getAttribute("TargetMode") === "External") continue;
      let path = rel.getAttribute("Target") || "";
      path = path.startsWith("/") ? path.slice(1) : "xl/" + path;
      if (!/^xl\/worksheets\/[^/]+\.xml$/.test(path)) continue;
      const raw = await get(path);
      if (!raw) continue;
      const doc = xml(raw);
      let rows = [],
        rowNumbers = [];
      for (const tr of nodes(doc, "row")) {
        const row = [];
        for (const c of child(tr, "c")) {
          const ref = (c.getAttribute("r") || "").match(/^([A-Z]+)[0-9]+$/);
          let col = ref
            ? Array.from(ref[1]).reduce((a, l) => a * 26 + l.charCodeAt(0) - 64, 0) - 1
            : row.length;
          if (col >= MAX_COLS) throw Error("Trop de colonnes dans la feuille.");
          const type = c.getAttribute("t"),
            value = nodes(c, "v")[0]?.textContent || "";
          let text =
            type === "s"
              ? strings[Number(value)] || ""
              : type === "inlineStr"
                ? nodes(c, "t")
                    .map((t) => t.textContent)
                    .join("")
                : value;
          if (type === "e") text = "";
          const fmt = formats[xfs[Number(c.getAttribute("s") || 0)]?.getAttribute("numFmtId")];
          if ((!type || type === "n") && fmt && /^0+$/.test(fmt) && /^\d+$/.test(text))
            text = text.padStart(Math.min(fmt.length, 64), "0");
          row[col] = text;
        }
        if (row.some((v) => String(v || "").trim())) {
          const width = Math.max(row.length, 1);
          rows.push(Array.from({ length: width }, (_, i) => row[i] || ""));
          rowNumbers.push(Number(tr.getAttribute("r")) || rows.length);
        }
        if (rows.length > MAX_ROWS + 1) throw Error("Trop de lignes dans la feuille.");
      }
      if (rows.length) {
        const maxW = Math.max(...rows.map((r) => r.length), 1);
        rows = rows.map((r) => Array.from({ length: maxW }, (_, i) => r[i] || ""));
      }
      tables.push({
        title: sheet.getAttribute("name") || "Feuille",
        rows: bounds(rows),
        rowNumbers,
        date1904: date1904 === "1" || date1904 === "true",
        source: "xlsx",
      });
    }
    if (!tables.length) throw Error("Aucune feuille lisible dans ce fichier XLSX.");
    return tables;
  }
  async function parseDocx(file) {
    const get = await zipEntries(file),
      text = await get("word/document.xml");
    if (!text) throw Error("Document Word DOCX invalide.");
    const doc = xml(text),
      tables = [];
    for (const tbl of nodes(doc, "tbl")) {
      if (nodes(tbl, "tbl").length) continue;
      const rows = child(tbl, "tr")
        .map((tr) =>
          child(tr, "tc").flatMap((tc) => {
            const paragraphs = nodes(tc, "p").map((p) =>
              nodes(p, "t")
                .map((t) => t.textContent)
                .join(""),
            );
            const span = Number(nodes(tc, "gridSpan")[0]?.getAttribute("w:val") || 1);
            if (span > MAX_COLS) throw Error("Tableau Word trop large.");
            return [paragraphs.join("\n"), ...Array(Math.max(0, span - 1)).fill("")];
          }),
        )
        .filter((r) => r.some((v) => v.trim()));
      if (rows.length)
        tables.push({
          title: "Tableau " + (tables.length + 1),
          rows: bounds(rows),
          source: "docx",
        });
    }
    if (!tables.length)
      throw Error(
        "La liste Word doit être dans un tableau : une personne par ligne, une information par colonne.",
      );
    return tables;
  }
  function parseCsv(text) {
    text = text.replace(/^\uFEFF/, "");
    const first = text.split(/\r?\n/)[0],
      sep = [";", ",", "\t"].sort((a, b) => first.split(b).length - first.split(a).length)[0];
    const rows = [];
    let row = [],
      cell = "",
      quoted = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (c === '"') {
        if (quoted && text[i + 1] === '"') {
          cell += '"';
          i++;
        } else quoted = !quoted;
      } else if (!quoted && (c === sep || c === "\n" || c === "\r")) {
        row.push(cell);
        cell = "";
        if (c !== sep) {
          if (c === "\r" && text[i + 1] === "\n") i++;
          if (row.some((v) => v.trim())) rows.push(row);
          row = [];
          if (rows.length > MAX_ROWS + 1) throw Error("Trop de lignes dans le CSV.");
        }
      } else cell += c;
    }
    if (quoted) throw Error("Guillemets non fermés dans le CSV.");
    row.push(cell);
    if (row.some((v) => v.trim())) rows.push(row);
    return [{ title: "Liste CSV", rows: bounds(rows), source: "csv" }];
  }
  async function parseFile(file) {
    if (!file || !file.size || file.size > MAX_FILE)
      throw Error("Choisis un fichier non vide de moins de 12 Mo.");
    const ext = file.name.split(".").pop().toLowerCase();
    if (ext === "xlsx") return parseXlsx(file);
    if (ext === "docx") return parseDocx(file);
    if (ext === "csv") return parseCsv(await file.text());
    throw Error(
      "Formats acceptés : .xlsx, .docx et .csv. Pour .xls ou .doc, enregistre une copie au format récent.",
    );
  }
  function birthDate(value, table) {
    const v = String(value == null ? "" : value).trim();
    if (!v) return "";
    let y, m, d;
    // 1) Série Excel (nombre de jours depuis 1899/1904)
    if (/^\d+(?:\.\d+)?$/.test(v) && Number(v) > 20000 && Number(v) < 80000) {
      const serial = Math.floor(Number(v));
      const base = table && table.date1904 ? Date.UTC(1904, 0, 1) : Date.UTC(1899, 11, 30);
      const date = new Date(base + serial * 86400000);
      y = date.getUTCFullYear();
      m = date.getUTCMonth() + 1;
      d = date.getUTCDate();
    } else {
      let a = v.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T\s].*)?$/);
      if (a) {
        y = +a[1];
        m = +a[2];
        d = +a[3];
      } else {
        // JJ/MM/AAAA , JJ-MM-AAAA , JJ.MM.AAAA , JJ/MMAAAA (ex. 16/092016)
        a =
          v.match(/^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})$/) ||
          v.match(/^(\d{1,2})[/.\-](\d{2})(\d{4})$/) ||
          v.match(/^(\d{2})(\d{2})(\d{4})$/);
        if (!a) throw Error("Date attendue : JJ/MM/AAAA");
        d = +a[1];
        m = +a[2];
        y = +a[3];
      }
    }
    const date = new Date(Date.UTC(y, m - 1, d));
    if (
      y < 1900 ||
      y > 2100 ||
      date.getUTCFullYear() !== y ||
      date.getUTCMonth() + 1 !== m ||
      date.getUTCDate() !== d
    )
      throw Error("Date de naissance invalide");
    return [y, String(m).padStart(2, "0"), String(d).padStart(2, "0")].join("-");
  }
  let state = { tables: [], table: 0, filename: "", busy: false };
  function table() {
    return state.tables[state.table];
  }
  function headerKey(value) {
    const n = norm(value);
    return (
      Object.keys(aliases).find((k) => aliases[k].includes(n)) ||
      PROFILE_FIELDS.find((k) => norm(k) === n) ||
      ""
    );
  }
  function detectHeader(t) {
    let best = 0,
      score = -1;
    t.rows.slice(0, 40).forEach((row, i) => {
      const keys = row.map(headerKey).filter(Boolean);
      let n = new Set(keys).size;
      // Bonus si colonnes nom/prénom + naissance/tel reconnues
      if (keys.some((k) => k === "__nom_prenom" || k === "nom" || k === "prenom")) n += 2;
      if (keys.includes("naissance")) n += 1;
      if (keys.includes("tel")) n += 1;
      if (n > score) {
        score = n;
        best = i;
      }
    });
    return best;
  }
  function prepareHeader() {
    const t = table();
    if (!t) return;
    t.headerIndex = detectHeader(t);
    $("ptiHeaderRow").innerHTML = t.rows
      .slice(0, 40)
      .map(
        (row, i) =>
          '<option value="' +
          i +
          '">Ligne ' +
          (t.rowNumbers?.[i] || i + 1) +
          " — " +
          esc(row.filter(Boolean).join(" · ").slice(0, 90)) +
          "</option>",
      )
      .join("");
    $("ptiHeaderRow").value = String(t.headerIndex);
  }
  function splitCombined(value, reverse) {
    const words = String(value || "")
      .trim()
      .replace(/\s+/g, " ")
      .split(" ")
      .filter(Boolean);
    if (!words.length) return { nom: "", prenom: "" };
    if (reverse) return { nom: words.slice(-1).join(" "), prenom: words.slice(0, -1).join(" ") };
    // Préfixes composés (AIT YEHIA, BEN …)
    const prefixes = ["ait", "ben", "el", "de", "le", "la", "abu", "ibn"];
    if (words.length === 1) return { nom: words[0], prenom: "" };
    if (words.length === 2) return { nom: words[0], prenom: words[1] };
    const count = prefixes.includes(norm(words[0])) ? 2 : 1;
    return { nom: words.slice(0, count).join(" "), prenom: words.slice(count).join(" ") };
  }
  function mappings() {
    return Array.from($("ptiMapping").querySelectorAll("select")).map((s) => s.value);
  }
  /** Mapping final : selects UI + auto-détection depuis la ligne de titres (fiable pour Excel). */
  function resolvedMap() {
    const t = table();
    if (!t) return [];
    const ui = mappings();
    const headerIdx = $("ptiHeader").checked ? Number($("ptiHeaderRow").value) || 0 : -1;
    const headers = headerIdx >= 0 ? t.rows[headerIdx] || [] : [];
    const width = Math.max(ui.length, headers.length, ...t.rows.map((r) => r.length), 1);
    const map = Array.from({ length: width }, (_, i) => ui[i] || "");
    // Compléter les colonnes non mappées via les titres Excel
    for (let i = 0; i < width; i++) {
      if (map[i]) continue;
      const auto = headerKey(headers[i] || "");
      if (auto) map[i] = auto;
    }
    // Éviter doublons de clés (garder la 1re colonne)
    const seen = new Set();
    return map.map((k) => {
      if (!k) return "";
      if (seen.has(k)) return "";
      seen.add(k);
      return k;
    });
  }
  function plan() {
    const t = table();
    if (!t) return [];
    const map = resolvedMap(),
      active = map.filter(Boolean);
    if (
      !active.some(
        (k) => k === "nom" || k === "prenom" || k === "__nom_prenom" || k === "__prenom_nom",
      )
    )
      throw Error("Associe au moins une colonne au Nom ou au Prénom.");
    if (active.some((k) => k.startsWith("__")) && active.some((k) => k === "nom" || k === "prenom"))
      throw Error("Choisis soit les colonnes Nom/Prénom séparées, soit la colonne combinée.");
    const seen = athleteProfiles.map((p) => ({
      name: norm(p.nom) + "|" + norm(p.prenom),
      birth: p.naissance || "",
    }));
    const records = [];
    const offset = $("ptiHeader").checked ? (Number($("ptiHeaderRow").value) || 0) + 1 : 0;
    t.rows.slice(offset).forEach((cells, i) => {
      const values = {};
      const row = Array.from({ length: map.length }, (_, n) => String(cells[n] ?? "").trim());
      map.forEach((key, n) => {
        if (!key) return;
        if (key === "__nom_prenom" || key === "__prenom_nom")
          Object.assign(values, splitCombined(row[n], key === "__prenom_nom"));
        else values[key] = row[n];
      });
      if (values.nom && !values.prenom && /\s/.test(values.nom)) {
        Object.assign(values, splitCombined(values.nom, false));
      }
      // Téléphone : garder tel que texte (zéros en tête)
      if (values.tel) values.tel = String(values.tel).replace(/\.0$/, "").trim();
      if (!Object.values(values).some(Boolean)) return;
      let error = "";
      let warning = "";
      if (!values.nom && !values.prenom) error = "Nom et prénom vides";
      // Date : ne pas faire échouer toute la ligne si format douteux
      if (values.naissance) {
        try {
          values.naissance = birthDate(values.naissance, t);
        } catch (e) {
          warning = e.message;
          values.naissance = ""; // n'importe pas une date invalide, mais garde le profil
        }
      }
      if (values.code_couleur) {
        values.code_couleur = norm(values.code_couleur);
        if (!PROFILE_COLOR_OPTIONS[values.code_couleur])
          error = "Couleur attendue : vert, orange ou rouge";
      }
      for (const key of [
        "taille",
        "poids",
        "env1",
        "env2",
        "vma",
        "saut_elan",
        "saut_sans",
        "vitesse_9m",
        "vitesse_18m",
        "1rm_dc",
        "1rm_tirage",
        "1rm_pullover",
        "1rm_squat",
        "1rm_sdt",
      ])
        if (values[key]) {
          const n = values[key].replace(",", ".");
          if (!/^\d+(?:\.\d+)?$/.test(n)) error = "Valeur numérique invalide : " + label(key);
          else values[key] = n;
        }
      const name = norm(values.nom) + "|" + norm(values.prenom),
        birth = values.naissance || "",
        duplicate = seen.some((p) => p.name === name && (!birth || !p.birth || birth === p.birth));
      if (!error) seen.push({ name, birth });
      records.push({ values, error, duplicate, row: t.rowNumbers?.[offset + i] || offset + i + 1 });
    });
    return records;
  }
  function redraw() {
    try {
      const records = plan(),
        skip = $("ptiSkip").checked,
        good = records.filter((r) => !r.error && (!skip || !r.duplicate));
      $("ptiCount").textContent =
        good.length +
        " profils à créer · " +
        records.filter((r) => r.duplicate && !r.error).length +
        " doublons possibles · " +
        records.filter((r) => r.error).length +
        " lignes invalides (non importées).";
      $("ptiConfirm").disabled = !good.length || state.busy;
      $("ptiPreview").innerHTML =
        "<table><thead><tr><th>Ligne</th><th>Nom</th><th>Prénom</th><th>Naissance</th><th>Tél</th><th>Taille</th><th>Poids</th><th>Gr. sang.</th><th>Vérification</th></tr></thead><tbody>" +
        records
          .slice(0, 200)
          .map(
            (r) =>
              "<tr><td>" +
              r.row +
              "</td><td>" +
              esc(r.values.nom) +
              "</td><td>" +
              esc(r.values.prenom) +
              "</td><td>" +
              esc(r.values.naissance) +
              "</td><td>" +
              esc(r.values.tel) +
              "</td><td>" +
              esc(r.values.taille) +
              "</td><td>" +
              esc(r.values.poids) +
              "</td><td>" +
              esc(r.values.blood_group) +
              "</td><td>" +
              esc(
                r.error ||
                  (r.duplicate
                    ? skip
                      ? "Doublon — ignoré"
                      : "Doublon — nouvelle fiche"
                    : "Nouvelle fiche"),
              ) +
              "</td></tr>",
          )
          .join("") +
        "</tbody></table>" +
        (records.length > 200
          ? "<p>Aperçu des 200 premières lignes; le compteur inclut la liste entière.</p>"
          : "");
      $("ptiError").textContent = "";
    } catch (e) {
      $("ptiError").textContent = e.message;
      $("ptiConfirm").disabled = true;
    }
  }
  function buildMapping() {
    const t = table();
    if (!t) return;
    const count = Math.max(...t.rows.map((r) => r.length), 0),
      headers = $("ptiHeader").checked ? t.rows[Number($("ptiHeaderRow").value) || 0] : [];
    $("ptiMapping").innerHTML = Array.from({ length: count }, (_, i) => {
      const h = headers[i] || "Colonne " + (i + 1),
        key = headerKey(h);
      return (
        "<label>" +
        esc(h) +
        '<select data-col="' +
        i +
        '"><option value="">Ne pas importer</option>' +
        ["__nom_prenom", "__prenom_nom", ...PROFILE_FIELDS]
          .map(
            (k) =>
              '<option value="' +
              esc(k) +
              '" ' +
              (k === key ? "selected" : "") +
              ">" +
              esc(
                k === "__nom_prenom"
                  ? "Nom + prénom dans une cellule (nom en premier)"
                  : k === "__prenom_nom"
                    ? "Prénom + nom dans une cellule"
                    : label(k),
              ) +
              "</option>",
          )
          .join("") +
        "</select></label>"
      );
    }).join("");
    $("ptiHeaderRow").disabled = !$("ptiHeader").checked;
    $("ptiNameHelp").textContent = mappings().some((k) => k.startsWith("__"))
      ? "Séparation automatique du nom/prénom : vérifie l’aperçu, particulièrement les noms composés. Les titres au-dessus de la ligne choisie ne seront pas importés."
      : "Les titres situés au-dessus de la ligne choisie ne seront pas importés.";
    redraw();
  }
  function refreshGroups() {
    const selected = profileGroupFilterId;
    $("ptiGroup").innerHTML =
      '<option value="">Sans groupe</option>' +
      profileGroupsList()
        .map((g) => '<option value="' + esc(g.id) + '">' + esc(profileGroupLabel(g)) + "</option>")
        .join("");
    $("ptiGroup").value = profileGroupsList().some((g) => g.id === selected) ? selected : "";
  }
  async function chooseFile(file) {
    if (state.busy) return;
    state.busy = true;
    $("ptiConfirm").disabled = true;
    state.tables = [];
    $("ptiPreview").textContent = "Lecture locale du fichier…";
    $("ptiMapping").textContent = "";
    $("ptiError").textContent = "";
    try {
      state.tables = await parseFile(file);
      state.table = 0;
      state.filename = file.name;
      $("ptiSource").textContent = file.name;
      $("ptiSheet").innerHTML = state.tables
        .map((t, i) => '<option value="' + i + '">' + esc(t.title) + "</option>")
        .join("");
      if (!table().rows.length) throw Error("Ce tableau ne contient aucune ligne.");
    } catch (e) {
      $("ptiError").textContent = e.message;
      $("ptiPreview").textContent = "Aucun profil créé.";
      state.tables = [];
    } finally {
      state.busy = false;
      if (state.tables.length) {
        prepareHeader();
        buildMapping();
      }
    }
  }
  async function commit() {
    if (state.busy || !guardEdit()) return;
    flushProfileAutosave();
    loadAthleteProfiles();
    const groupId = $("ptiGroup").value;
    if (groupId && !profileGroupsList().some((g) => g.id === groupId))
      throw Error("Choisis un groupe existant.");
    const records = plan().filter((r) => !r.error && (!$("ptiSkip").checked || !r.duplicate));
    if (!records.length) return;
    state.busy = true;
    $("ptiConfirm").disabled = true;
    const previous = athleteProfiles.slice();
    try {
      const added = records.map((r) => {
        const p = emptyProfile();
        const v = r.values || {};
        // Champs texte / mesures explicitement recopiés
        for (const f of PROFILE_FIELDS) {
          if (v[f] != null && String(v[f]).trim() !== "") p[f] = String(v[f]).trim();
        }
        if (v.nom) p.nom = String(v.nom).trim();
        if (v.prenom) p.prenom = String(v.prenom).trim();
        if (v.naissance) p.naissance = String(v.naissance).trim();
        if (v.tel) p.tel = String(v.tel).trim();
        if (v.taille) p.taille = String(v.taille).trim();
        if (v.poids) p.poids = String(v.poids).trim();
        if (v.blood_group) {
          let bg = String(v.blood_group).trim().toUpperCase().replace(/\s+/g, "");
          bg = bg.replace("A-", "A−").replace("B-", "B−").replace("AB-", "AB−").replace("O-", "O−");
          // garder + ASCII
          p.blood_group = bg;
        }
        if (v.code_couleur) p.code_couleur = String(v.code_couleur).trim();
        // sécurité : recopier explicitement date & tél
        if (v.naissance) p.naissance = String(v.naissance).trim();
        if (v.tel) p.tel = String(v.tel).trim();
        p.groupIds = groupId ? [groupId] : [];
        p.groupId = groupId || "";
        p.updatedAt = Date.now();
        return p;
      });
      athleteProfiles = previous.concat(added);
      if (!saveAthleteProfilesStore())
        throw Error("Enregistrement impossible : aucun import confirmé.");
      loadAthleteProfiles();
      refreshProfileSelect();
      fillProfileForm(athleteProfiles.find((p) => p.id === added[0].id) || added[0]);
      $("ptiModal").classList.remove("show");
      if ($("pslModal")) $("pslModal").classList.remove("show");
      window.dispatchEvent(new CustomEvent("yh-profile-import-complete"));
      showToast(added.length + " profils importés. Les profils existants ont été conservés.");
    } catch (e) {
      athleteProfiles = previous;
      saveAthleteProfilesStore();
      $("ptiError").textContent = e.message;
    } finally {
      state.busy = false;
      $("ptiConfirm").disabled = false;
    }
  }
  function ensure() {
    if ($("ptiModal")) return;
    const modal = document.createElement("div");
    modal.id = "ptiModal";
    modal.className = "modal-overlay";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-label", "Importer une liste de profils");
    modal.innerHTML =
      '<div class="modal pti-modal"><div class="modal-header"><h2>Importer une liste Excel / Word</h2><button id="ptiClose" class="modal-close" type="button" aria-label="Fermer">×</button></div><div class="modal-body"><p>Une ligne = un profil. Lecture locale, sans envoi sur Internet. Vérifie les colonnes avant de confirmer.</p><label>Fichier <input id="ptiFile" type="file" accept=".xlsx,.docx,.csv"/></label><small>Excel .xlsx · Word .docx avec un tableau · CSV. Aucun profil existant ne sera remplacé.</small><p id="ptiSource"></p><div class="pti-options"><label>Feuille / tableau<select id="ptiSheet"></select></label><label>Groupe des nouveaux profils<select id="ptiGroup"></select></label></div><label class="pti-check"><input id="ptiHeader" type="checkbox" checked/> Le tableau contient une ligne de titres</label><label>Ligne des titres (détection automatique)<select id="ptiHeaderRow"></select></label><p id="ptiNameHelp"></p><div id="ptiMapping" class="pti-mapping"></div><label class="pti-check"><input id="ptiSkip" type="checkbox" checked/> Ignorer les doublons possibles (nom, prénom et naissance)</label><p id="ptiCount" role="status"></p><p id="ptiError" role="alert"></p><div id="ptiPreview"></div></div><div class="modal-footer"><button id="ptiCancel" class="btn-cancel" type="button">Annuler</button><button id="ptiConfirm" class="btn-save" type="button" disabled>Créer les profils</button></div></div>';
    document.body.appendChild(modal);
    $("ptiFile").onchange = () => chooseFile($("ptiFile").files[0]);
    $("ptiSheet").onchange = () => {
      state.table = +$("ptiSheet").value;
      prepareHeader();
      buildMapping();
    };
    $("ptiHeader").onchange = buildMapping;
    $("ptiHeaderRow").onchange = buildMapping;
    $("ptiSkip").onchange = redraw;
    $("ptiMapping").onchange = redraw;
    $("ptiConfirm").onclick = () => commit().catch((e) => ($("ptiError").textContent = e.message));
    const close = () => {
      if (!state.busy) modal.classList.remove("show");
    };
    $("ptiClose").onclick = close;
    $("ptiCancel").onclick = close;
    modal.addEventListener("click", (e) => {
      if (e.target === modal) close();
    });
  }
  window.openProfileTableImport = function () {
    if (!guardEdit()) return;
    flushProfileAutosave();
    loadAthleteProfiles();
    ensure();
    refreshGroups();
    $("ptiModal").classList.add("show");
    if (state.tables.length) redraw();
  };
  // Surface de diagnostic locale sans contournement des permissions d’écriture.
  window.YHProfileTableImport = Object.freeze({ parseFile, birthDate });
})();
