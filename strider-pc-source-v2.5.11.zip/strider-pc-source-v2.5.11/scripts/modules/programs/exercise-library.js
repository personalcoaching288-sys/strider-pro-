/** Bibliothèque d'exercices intégrée */
// ========== BIBLIOTHEQUE INTEGREE ==========
const YH_SEED_FLAG = "yhcoachpro_lib_seeded_v12_volley";
const YH_BUILTIN_EXERCISES =
  typeof window !== "undefined" && window.YH_BUILTIN_EXERCISES ? window.YH_BUILTIN_EXERCISES : [];

function ensureBuiltinExerciseLibrary(force) {
  try {
    if (!YH_BUILTIN_EXERCISES || !YH_BUILTIN_EXERCISES.length) {
      if (force) showToast("Fichier builtin-exercises.js manquant");
      return;
    }
    const seeded =
      typeof storeGet === "function" ? storeGet(YH_SEED_FLAG) : localStorage.getItem(YH_SEED_FLAG);
    if (seeded === "1" && !force) return;
    let list = [];
    try {
      list = loadExerciseLibrary() || [];
    } catch (e) {
      list = [];
    }
    const byName = {};
    list.forEach((x, i) => {
      byName[(x.name || "").toLowerCase()] = i;
    });
    YH_BUILTIN_EXERCISES.forEach((ex) => {
      const key = (ex.name || "").toLowerCase();
      if (key in byName) {
        const item = list[byName[key]];
        if (ex.image) item.image = ex.image;
        if (item.series == null) item.series = ex.series;
        if (item.reps == null) item.reps = ex.reps;
        if (item.charge == null) item.charge = ex.charge;
        if (!item.recup) item.recup = ex.recup;
      } else {
        list.push({
          id: typeof uid === "function" ? uid() : String(Date.now()),
          name: ex.name,
          image: ex.image || null,
          series: ex.series,
          reps: ex.reps,
          charge: ex.charge,
          recup: ex.recup,
          rpe: ex.rpe,
          notes: "",
        });
      }
    });
    saveExerciseLibrary(list);
    if (typeof storeSet === "function") storeSet(YH_SEED_FLAG, "1");
    else localStorage.setItem(YH_SEED_FLAG, "1");
    if (force)
      showToast("Bibliothèque : " + YH_BUILTIN_EXERCISES.length + " exercices avec images");
  } catch (e) {
    console.warn(e);
  }
}

// licenses.js chargé séparément.
