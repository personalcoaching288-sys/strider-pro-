# Version 2.4.14 — Sécurisation de la saisie

Le blocage intermittent signalé sur Windows n’a pas été reproduit sur ce poste de test. Cette version corrige des fragilités vérifiables de l’autosauvegarde et ajoute une récupération du focus ; elle doit être validée sur votre ordinateur, sans garantie que la cause Windows soit éliminée.

Dans les profils, vider le nom et le prénom annule l’ancienne sauvegarde programmée au lieu de la laisser partir pendant la correction. Le statut devient « En attente d’un nom ou prénom ». Aucune fiche sans nom n’est sauvegardée. La composition clavier est respectée. Une sauvegarde en attente est terminée avant de changer ou créer un profil, et annulée avant suppression confirmée pour éviter une sauvegarde sur la mauvaise fiche.

Dans les profils et les fiches de séance (y compris les champs du terrain), le clic dans un champ éditable demande à Electron de reprendre le clavier. Aucun champ verrouillé n’est déverrouillé et aucun texte n’est remplacé. Pas de vérification permanente ni rechargement automatique. Le menu natif Édition rétablit les commandes usuelles du clavier.

Si la saisie bloque encore, cliquer dans le champ puis appuyer sur F6 (ou Édition → Rétablir la saisie). Le dernier champ visible et non masqué par une fenêtre peut reprendre le focus, sans vider ses données ni recharger l’application. La fenêtre n’est pas ramenée au premier plan si une autre application est active.

Fonds, logos, licence, programmes, import JSON et PDF A4 conservés. Sauvegarder avant mise à jour, conserver la 2.4.13 et tester dans un dossier séparé avec DEMARRER-DEVELOPPEMENT.bat. Archive du projet source, pas installateur compilé.
