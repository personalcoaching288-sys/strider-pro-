/** Historique des charges (kg) */
// ========== LOAD HISTORY (kg) ==========
function loadHistoryStore() {
  try {
    return JSON.parse(localStorage.getItem("yhcoachpro_load_history") || "{}");
  } catch (e) {
    return {};
  }
}
function saveHistoryStore(store) {
  try {
    localStorage.setItem("yhcoachpro_load_history", JSON.stringify(store));
  } catch (e) {}
}
function recordLoadHistory(prog) {
  if (!prog || !prog.athlete) return;
  const store = loadHistoryStore();
  const athlete = prog.athlete;
  if (!store[athlete]) store[athlete] = {};
  const date = prog.date || new Date().toISOString().slice(0, 10);
  (prog.days || []).forEach((day) => {
    (day.exercises || []).forEach((ex) => {
      const push = (name, kg) => {
        if (!name || kg === null || kg === undefined || kg === "") return;
        if (!store[athlete][name]) store[athlete][name] = [];
        store[athlete][name].push({ date, kg: +kg, session: prog.sessionNum || 1 });
        // keep last 30
        if (store[athlete][name].length > 12)
          store[athlete][name] = store[athlete][name].slice(-12);
      };
      push(ex.name, ex.chargeKg);
      if (ex.compName) push(ex.compName, ex.compChargeKg);
    });
  });
  saveHistoryStore(store);
}
function fillHistoryAthleteSelect(selected) {
  const sel = document.getElementById("historyAthleteSelect");
  if (!sel) return;
  const store = loadHistoryStore();
  const names = Object.keys(store || {})
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b, "fr", { sensitivity: "base" }));
  // aussi athlètes des programmes enregistrés
  try {
    loadProgramsIndex();
    (programsIndex || []).forEach((p) => {
      const n = (p.athlete || "").trim();
      if (n && !names.includes(n)) names.push(n);
    });
    names.sort((a, b) => a.localeCompare(b, "fr", { sensitivity: "base" }));
  } catch (e) {}
  const cur = selected != null ? selected : sel.value;
  sel.innerHTML =
    '<option value="">— Choisir un athlète —</option>' +
    names
      .map((n) => `<option value="${String(n).replace(/"/g, "&quot;")}">${escapeHtml(n)}</option>`)
      .join("");
  if (cur && names.includes(cur)) sel.value = cur;
  else if (names.length === 1) sel.value = names[0];
  const hidden = document.getElementById("historyAthleteFilter");
  if (hidden) hidden.value = sel.value || "";
}
function openHistoryModal(athleteName) {
  fillHistoryAthleteSelect(athleteName || "");
  const sel = document.getElementById("historyAthleteSelect");
  if (sel && athleteName) {
    // tenter de sélectionner même si casse différente
    const opt = Array.from(sel.options).find(
      (o) => o.value.toLowerCase() === String(athleteName).toLowerCase(),
    );
    if (opt) sel.value = opt.value;
  }
  const hidden = document.getElementById("historyAthleteFilter");
  if (hidden && sel) hidden.value = sel.value || "";
  renderHistoryList();
  openModal("historyModal");
}
function buildKgChartSvg(entries, large) {
  if (!entries || entries.length < 1)
    return "<p style='color:#6b7280;font-size:0.85rem'>Pas de données</p>";
  const data = entries.slice(-16);
  const kgs = data.map((e) => +e.kg || 0);
  const min = Math.min(...kgs);
  const max = Math.max(...kgs);
  const span = Math.max(max - min, 1);
  const W = large ? 320 : 280;
  const H = large ? 140 : 80;
  const pad = 12;
  const n = data.length;
  const pts = data.map((e, i) => {
    const x = pad + (n === 1 ? W / 2 : (i / (n - 1)) * (W - pad * 2));
    const y = H - pad - ((e.kg - min) / span) * (H - pad * 2);
    return { x, y, kg: e.kg, date: e.date || "", session: e.session };
  });
  const line = pts
    .map((p, i) => (i === 0 ? "M" : "L") + p.x.toFixed(1) + "," + p.y.toFixed(1))
    .join(" ");
  const area =
    line + ` L${pts[pts.length - 1].x.toFixed(1)},${H - pad} L${pts[0].x.toFixed(1)},${H - pad} Z`;
  const dots = pts
    .map(
      (p) =>
        `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${large ? 4 : 3}" fill="#6366f1" stroke="#fff" stroke-width="1.5"><title>${p.date}: ${p.kg} kg</title></circle>`,
    )
    .join("");
  const labels = pts
    .map((p, i) => {
      if (!large) return "";
      if (n > 8 && i !== 0 && i !== n - 1 && i % 2 === 1) return "";
      return `<text x="${p.x.toFixed(1)}" y="${H - 2}" text-anchor="middle" font-size="9" fill="#94a3b8">${p.session ? "S" + p.session : (p.date || "").slice(5)}</text>`;
    })
    .join("");
  return `<div class="history-chart"><svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="xMidYMid meet"><path d="${area}" fill="rgba(99,102,241,0.15)" stroke="none"/><path d="${line}" fill="none" stroke="#6366f1" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>${dots}${labels}</svg><div class="chart-labels"><span>${data[0].date || ""}</span><span>${min} → ${max} kg</span><span>${data[data.length - 1].date || ""}</span></div></div>`;
}

let historySelectedKey = null;

function renderHistoryList() {
  const store = loadHistoryStore();
  const sel = document.getElementById("historyAthleteSelect");
  const athleteSel = (sel && sel.value ? sel.value : "").trim();
  const hidden = document.getElementById("historyAthleteFilter");
  if (hidden) hidden.value = athleteSel;
  const list = document.getElementById("historyList");
  const panel = document.getElementById("historyGraphPanel");
  if (!list) return;

  if (!athleteSel) {
    list.innerHTML =
      '<div class="empty-state"><p>Choisis un athlète dans la liste pour voir son suivi de charges.</p></div>';
    if (panel) panel.classList.remove("show");
    return;
  }

  // Exercices de CET athlète uniquement
  const athleteKey =
    Object.keys(store).find((a) => a.toLowerCase() === athleteSel.toLowerCase()) || athleteSel;
  const exMap = store[athleteKey] || {};
  const rows = Object.keys(exMap).map((exName) => ({
    athlete: athleteKey,
    exName,
    entries: exMap[exName] || [],
  }));
  rows.sort((a, b) => a.exName.localeCompare(b.exName, "fr", { sensitivity: "base" }));

  if (!rows.length) {
    list.innerHTML =
      '<div class="empty-state"><p>Aucun historique de charge pour <strong>' +
      escapeHtml(athleteSel) +
      "</strong>.<br>Enregistre des programmes avec des kg.</p></div>";
    if (panel) panel.classList.remove("show");
    return;
  }

  list.innerHTML = rows
    .map((r) => {
      const entries = r.entries;
      const last = entries[entries.length - 1];
      const first = entries[0];
      const diff = (last?.kg || 0) - (first?.kg || 0);
      const diffStr = diff > 0 ? `+${diff} kg` : diff < 0 ? `${diff} kg` : "0 kg";
      const key = encodeURIComponent(r.athlete + "||" + r.exName);
      return `<button type="button" class="history-ex-btn" onclick="showHistoryGraph('${key}')">
          <span><strong>${escapeHtml(r.exName)}</strong><br><span class="meta">${entries.length} séance(s)</span></span>
          <span class="meta" style="color:#0d9488;font-weight:700">${diffStr}</span>
        </button>`;
    })
    .join("");

  if (panel) panel.classList.remove("show");
  historySelectedKey = null;
}

function showHistoryGraph(keyEnc) {
  const key = decodeURIComponent(keyEnc);
  const [athlete, exName] = key.split("||");
  const store = loadHistoryStore();
  const entries = store[athlete] && store[athlete][exName] ? store[athlete][exName] : [];
  const panel = document.getElementById("historyGraphPanel");
  const title = document.getElementById("historyGraphTitle");
  const sub = document.getElementById("historyGraphSub");
  const svg = document.getElementById("historyGraphSvg");
  if (!panel) return;
  historySelectedKey = key;
  if (title) title.textContent = exName || "Exercice";
  if (sub) {
    const last = entries[entries.length - 1];
    const first = entries[0];
    const diff = entries.length ? (last.kg || 0) - (first.kg || 0) : 0;
    sub.textContent = `${athlete} · ${entries.length} point(s) · progression ${diff > 0 ? "+" : ""}${diff} kg`;
  }
  if (svg) svg.innerHTML = buildKgChartSvg(entries, true);
  panel.classList.add("show");
  panel.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

// sharing.js chargé séparément.
