"use strict";

// ========== LICENCES SIGNÉES ED25519 ==========
const YH_LIC_STORE_KEY = "yhcoachpro_license_v2";
let yhLicenseState = { active: false, checking: true };

function yhLoadLicenseRecord() {
  try {
    const raw =
      typeof storeGet === "function"
        ? storeGet(YH_LIC_STORE_KEY)
        : localStorage.getItem(YH_LIC_STORE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (_) {
    return null;
  }
}
function yhSaveLicenseRecord(rec) {
  const raw = JSON.stringify(rec);
  if (typeof storeSet === "function") storeSet(YH_LIC_STORE_KEY, raw);
  else localStorage.setItem(YH_LIC_STORE_KEY, raw);
}
function yhSetLock(locked, message) {
  const lock = document.getElementById("licenseLock");
  if (lock) {
    lock.classList.toggle("show", !!locked);
    lock.classList.toggle("force-show", !!locked);
  }
  document.body.classList.toggle("license-locked", !!locked);
  const msg = document.getElementById("licenseLockMsg");
  if (msg && message) msg.textContent = message;
}
async function yhRefreshDeviceId() {
  const el = document.getElementById("licenseDeviceId");
  try {
    const id = await window.yhDisk.getLicenseDeviceId();
    if (el) el.textContent = id || "indisponible";
    return id;
  } catch (_) {
    if (el) el.textContent = "indisponible";
    return null;
  }
}
async function yhVerify(key) {
  if (!window.yhDisk || typeof window.yhDisk.verifyLicense !== "function") {
    return { ok: false, reason: "La vérification sécurisée nécessite l’application Windows." };
  }
  return window.yhDisk.verifyLicense(String(key || "").trim());
}
async function applyLicenseLockUI() {
  yhLicenseState = { active: false, checking: true };
  yhSetLock(true, "Vérification de la licence sécurisée…");
  await yhRefreshDeviceId();
  const rec = yhLoadLicenseRecord();
  if (!rec || !rec.key) {
    yhLicenseState = { active: false, reason: "none" };
    yhSetLock(
      true,
      "Cette installation nécessite une licence signée. Communique le code appareil ci-dessous pour recevoir ta licence.",
    );
    return yhLicenseState;
  }
  const result = await yhVerify(rec.key);
  if (rec.blocked || (result && result.blocked)) {
    yhLicenseState = { active: false, blocked: true, reason: (result && (result.blockReason || result.reason)) || rec.reason || "Abonnement bloqué" };
    yhSetLock(true, "Abonnement bloqué par l'administrateur. Contacte ton fournisseur pour le réactiver.");
    return yhLicenseState;
  }
  if (!result || !result.ok) {
    yhLicenseState = { active: false, reason: (result && result.reason) || "invalid" };
    yhSetLock(true, (result && result.reason) || "Licence invalide ou expirée.");
    return yhLicenseState;
  }
  yhLicenseState = { active: true, ...result };
  yhSetLock(false);
  const badge =
    document.getElementById("licenseStatusBadge") ||
    (() => {
      const logo = document.querySelector(".topbar .logo");
      if (!logo) return null;
      const node = document.createElement("span");
      node.id = "licenseStatusBadge";
      node.style.cssText = "margin-left:8px;font-size:.7rem;color:#e8d0af";
      logo.appendChild(node);
      return node;
    })();
  if (badge) badge.textContent = `Licence → ${result.expiresLabel || result.expiresAt || "active"}`;
  return yhLicenseState;
}
async function activateLicenseFromInput() {
  const input = document.getElementById("licenseInput");
  const key = input ? input.value.trim() : "";
  if (!key) {
    showToast("Entre une licence signée");
    return;
  }
  yhSetLock(true, "Vérification cryptographique…");
  const result = await yhVerify(key);
  if (result && result.blocked) {
    // Enregistre le blocage : l'app reste verrouillée jusqu'à une nouvelle licence active
    yhSaveLicenseRecord({
      key,
      blocked: true,
      activatedAt: new Date().toISOString(),
      reason: result.blockReason || result.reason || "Abonnement bloqué",
    });
    yhLicenseState = {
      active: false,
      blocked: true,
      reason: result.blockReason || result.reason || "Abonnement bloqué",
    };
    yhSetLock(
      true,
      "Abonnement bloqué par l'administrateur. Contacte ton fournisseur pour le réactiver.",
    );
    if (input) input.value = "";
    showToast("Abonnement bloqué — accès coupé");
    return;
  }
  if (!result || !result.ok) {
    yhLicenseState = { active: false, reason: (result && result.reason) || "invalid" };
    yhSetLock(true, (result && result.reason) || "Licence invalide");
    showToast((result && result.reason) || "Licence invalide");
    return;
  }
  yhSaveLicenseRecord({ key, activatedAt: new Date().toISOString(), blocked: false });
  if (input) input.value = "";
  await applyLicenseLockUI();
  showToast("Licence signée activée");
}
function openLicensePanel() {
  yhSetLock(
    true,
    yhLicenseState.active
      ? "Licence active. Tu peux saisir une nouvelle licence pour la remplacer."
      : null,
  );
  yhRefreshDeviceId();
}
function importLicenseFile(fileInput) {
  const file = fileInput && fileInput.files && fileInput.files[0];
  if (!file) return;
  if (file.size > 16384) {
    showToast("Fichier de licence trop volumineux");
    fileInput.value = "";
    return;
  }
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const key = String(reader.result || "")
        .replace(/\s+/g, "")
        .trim();
      if (!key.startsWith("YH2.")) throw new Error("Format de licence invalide");
      const input = document.getElementById("licenseInput");
      if (input) input.value = key;
      await activateLicenseFromInput();
    } catch (err) {
      showToast(err && err.message ? err.message : "Fichier de licence invalide");
    } finally {
      fileInput.value = "";
    }
  };
  reader.onerror = () => {
    showToast("Impossible de lire le fichier de licence");
    fileInput.value = "";
  };
  reader.readAsText(file);
}
async function copyLicenseDeviceId() {
  const id = await yhRefreshDeviceId();
  if (!id) return;
  try {
    await navigator.clipboard.writeText(id);
    showToast("Code appareil copié");
  } catch (_) {
    showToast("Code appareil : " + id);
  }
}
window.YHLicense = { isActive: () => !!yhLicenseState.active, refresh: applyLicenseLockUI };

// ========== COLLAGE FIABLE DU CODE D'ACTIVATION ==========
function yhNormalizeLicenseText(value) {
  const text = String(value || "").trim();
  const match = text.match(/YH2\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
  return match ? match[0] : text.replace(/\s+/g, "");
}
async function pasteLicenseFromClipboard() {
  const input = document.getElementById("licenseInput");
  if (!input) return;
  try {
    let text = "";
    if (window.yhDisk && typeof window.yhDisk.readClipboardText === "function") {
      text = await window.yhDisk.readClipboardText();
    } else if (navigator.clipboard && typeof navigator.clipboard.readText === "function") {
      text = await navigator.clipboard.readText();
    }
    const key = yhNormalizeLicenseText(text);
    if (!key || !key.startsWith("YH2.")) {
      showToast("Le presse-papiers ne contient pas de licence YH2");
      input.focus();
      return;
    }
    input.value = key;
    input.focus();
    showToast("Code de licence collé");
  } catch (_) {
    showToast("Utilise Ctrl+V dans la zone de licence");
    input.focus();
  }
}
function yhPrepareLicensePaste() {
  const input = document.getElementById("licenseInput");
  if (!input || input.dataset.pasteReady === "1") return;
  input.dataset.pasteReady = "1";
  input.addEventListener("paste", () => {
    setTimeout(() => {
      input.value = yhNormalizeLicenseText(input.value);
    }, 0);
  });
  input.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    pasteLicenseFromClipboard();
  });
}
if (document.readyState === "loading")
  document.addEventListener("DOMContentLoaded", yhPrepareLicensePaste);
else yhPrepareLicensePaste();
