"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { striderExternalFileTarget } = require("../modules/sharing/external-file-open.js");

test("un programme JSON ouvert par double-clic va à l'import des programmes", () => {
  const json = JSON.stringify({ days: [], athlete: "Nadia" });
  assert.equal(striderExternalFileTarget("StriderPro_Nadia.json", json), "importFileInput");
});

test("des profils JSON ouverts par double-clic vont à l'import des profils", () => {
  const json = JSON.stringify({ yhcoachproProfiles: true, profiles: [{ nom: "Benali", prenom: "Nadia" }] });
  assert.equal(striderExternalFileTarget("StriderPro_profils.json", json), "importProfilesInput");
});

test("une assiduité JSON ouverte par double-clic va à l'import de l'assiduité", () => {
  const json = JSON.stringify({ yhcoachproAttendanceReport: true });
  assert.equal(striderExternalFileTarget("assiduite.json", json), "asAttendanceImportInput");
});

test("une sauvegarde complète ouverte par double-clic demande la restauration prévue", () => {
  const json = JSON.stringify({ yhcoachproFullBackup: true, programs: [], profiles: [] });
  assert.equal(striderExternalFileTarget("sauvegarde.json", json), "fullBackupInput");
});

test("un JSON étranger à Strider ne déclenche aucun import", () => {
  assert.equal(striderExternalFileTarget("notes.json", '{"hello":"world"}'), null);
  assert.equal(striderExternalFileTarget("invalide.json", "{"), null);
});
