/* Strider Pro — traduction FR / EN / AR à l'affichage (le français reste la langue source). */
(function () {
  var KEY = "strider_lang";
  var DICT = window.STRIDER_I18N_DICT || {};
  var lang = "fr";
  try { lang = localStorage.getItem(KEY) || "fr"; } catch (e) {}
  if (["fr", "en", "ar"].indexOf(lang) < 0) lang = "fr";
  var LOCALE = { fr: "fr-FR", en: "en-GB", ar: "ar" };
  var keys = Object.keys(DICT).sort(function (a, b) { return b.length - a.length; });
  var orig = new WeakMap(); // textNode -> texte français d'origine
  var attrOrig = new WeakMap(); // element -> {attr: français}
  var ATTRS = ["placeholder", "title", "aria-label", "alt"];
  var SKIP = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, NOSCRIPT: 1, OPTION: 0 };
  var cache = {};
  var observedRoots = new WeakSet();
  // These sheet nodes display coach-authored values, not interface labels.
  var SHEET_CONTENT = '#title, .phase-name, #courtLabel, #objective, #objects, #sessionGroupMembership, #assignList, #deleteManyList';

  function tr(s) {
    if (lang === "fr" || !s) return s;
    var c = cache[s]; if (c !== undefined) return c;
    var m = s.match(/^(\s*)([\s\S]*?)(\s*)$/), core = m[2], out = core;
    var hit = DICT[core] || DICT[core.replace(/\s+/g, " ")];
    if (hit) out = hit[lang] || core;
    else if (/[A-Za-zÀ-ÿ]{2}/.test(core) && core.length < 400) out = partial(core);
    var r = m[1] + out + m[3];
    cache[s] = r; return r;
  }
  function partial(s) {
    var res = "", i = 0, changed = false;
    while (i < s.length) {
      var found = null;
      if (i === 0 || /[^A-Za-zÀ-ÿ]/.test(s[i - 1])) {
        for (var k = 0; k < keys.length; k++) {
          var key = keys[k];
          if (key.length >= 3 && s.substr(i, key.length) === key && !/[A-Za-zÀ-ÿ]/.test(s[i + key.length] || " ")) { found = key; break; }
        }
      }
      if (found) { res += DICT[found][lang]; i += found.length; changed = true; }
      else { res += s[i]; i++; }
    }
    return changed ? res : s;
  }
  window.strT = tr;

  function skipEl(el) {
    for (var e = el; e; e = e.parentElement) {
      if (SKIP[e.tagName] || e.isContentEditable || (e.hasAttribute && e.hasAttribute("data-no-i18n"))) return true;
      var root = e.getRootNode && e.getRootNode();
      if (root && root.host && root.host.id === "sessionSheetHost") {
        if (e.matches(SHEET_CONTENT)) return true;
        if (e.tagName === "OPTION" && e.parentElement.id !== "field_status" && e.value) return true;
      }
    }
    return false;
  }
  function doText(n) {
    var cur = n.nodeValue;
    if (!/[A-Za-zÀ-ÿ]/.test(cur)) return;
    var o = orig.get(n);
    // si le texte a été changé par l'app, le nouveau texte devient la source
    if (o === undefined || (cur !== o.fr && cur !== o.out)) o = { fr: cur };
    var out = tr(o.fr); o.out = out; orig.set(n, o);
    if (cur !== out) n.nodeValue = out;
  }
  function doAttrs(el) {
    // Translate option labels without changing their persisted French value.
    if (el.tagName === "OPTION" && !el.hasAttribute("value")) el.setAttribute("value", el.value);
    var store = attrOrig.get(el) || {};
    for (var i = 0; i < ATTRS.length; i++) {
      var a = ATTRS[i]; if (!el.hasAttribute(a)) continue;
      var cur = el.getAttribute(a), o = store[a];
      if (!o || (cur !== o.fr && cur !== o.out)) o = { fr: cur };
      var out = tr(o.fr); o.out = out; store[a] = o;
      if (cur !== out) el.setAttribute(a, out);
    }
    if (el.tagName === "INPUT" && (el.type === "button" || el.type === "submit")) {
      var ov = store.value; var cv = el.value;
      if (!ov || (cv !== ov.fr && cv !== ov.out)) ov = { fr: cv };
      ov.out = tr(ov.fr); store.value = ov; if (cv !== ov.out) el.value = ov.out;
    }
    attrOrig.set(el, store);
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { if (!skipEl(root.parentElement)) doText(root); return; }
    if (root.nodeType !== 1 && root.nodeType !== 11) return;
    if (root.nodeType === 1) {
      if (skipEl(root)) return;
      doAttrs(root);
      if (root.shadowRoot) observeRoot(root.shadowRoot);
    }
    var w = document.createTreeWalker(root, 5, null), n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 1) { if (skipEl(n)) continue; doAttrs(n); if (n.shadowRoot) observeRoot(n.shadowRoot); }
      else if (!skipEl(n.parentElement)) doText(n);
    }
  }
  var busy = false;
  var mo = new MutationObserver(function (list) {
    if (busy) return; busy = true;
    try {
      for (var i = 0; i < list.length; i++) {
        var m = list[i];
        if (m.type === "childList") m.addedNodes.forEach(walk);
        else if (m.type === "characterData") walk(m.target);
        else if (m.type === "attributes") walk(m.target);
      }
    } finally { mo.takeRecords(); busy = false; }
  });
  function observeRoot(root) {
    if (lang === "fr" || observedRoots.has(root)) return;
    observedRoots.add(root);
    mo.observe(root, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS.concat(["value"]) });
    walk(root);
  }
  // MutationObserver on body cannot see inside a shadow root (session sheet).
  var attachShadow = Element.prototype.attachShadow;
  Element.prototype.attachShadow = function (options) {
    var root = attachShadow.call(this, options);
    if (options.mode === "open") observeRoot(root);
    return root;
  };

  // Dates et heures dans la langue choisie
  ["toLocaleDateString", "toLocaleTimeString", "toLocaleString"].forEach(function (fn) {
    var o = Date.prototype[fn];
    Date.prototype[fn] = function (loc, opt) {
      if (lang !== "fr" && (loc === "fr-FR" || loc === "fr" || loc === undefined)) loc = LOCALE[lang];
      return o.call(this, loc, opt);
    };
  });
  // Intl (graphiques, échéances, nombres) dans la langue choisie
  ["DateTimeFormat", "NumberFormat"].forEach(function (name) {
    var O = Intl[name];
    if (!O) return;
    function W(loc, opt) {
      if (lang !== "fr" && (loc === "fr-FR" || loc === "fr" || loc === undefined)) loc = LOCALE[lang];
      return new O(loc, opt);
    }
    W.prototype = O.prototype;
    W.supportedLocalesOf = O.supportedLocalesOf;
    Intl[name] = W;
  });
  ["alert", "confirm", "prompt"].forEach(function (fn) {
    var o = window[fn];
    if (typeof o !== "function") return;
    window[fn] = function (msg) { var a = [].slice.call(arguments); if (typeof msg === "string") a[0] = msg.split("\n").map(tr).join("\n"); return o.apply(window, a); };
  });

  function applyDir() {
    var h = document.documentElement;
    h.lang = lang; h.dir = lang === "ar" ? "rtl" : "ltr";
    h.classList.toggle("strider-rtl", lang === "ar");
  }
  window.strSetLang = function (l) {
    try { localStorage.setItem(KEY, l); } catch (e) {}
    location.reload();
  };
  function markLang() {
    document.querySelectorAll("[data-str-lang-select]").forEach(function (x) { x.value = lang; });
    document.querySelectorAll(".strider-lang-row [data-lang]").forEach(function (b) {
      var on = b.getAttribute("data-lang") === lang;
      b.style.borderColor = on ? "var(--accent, #d4a64a)" : "";
      b.style.color = on ? "var(--accent, #d4a64a)" : "";
      b.style.flex = "1";
    });
  }
  applyDir();
  function start() {
    markLang();
    if (lang !== "fr") {
      observeRoot(document.body);
    }
  }
  if (document.body) start(); else document.addEventListener("DOMContentLoaded", start);
})();
