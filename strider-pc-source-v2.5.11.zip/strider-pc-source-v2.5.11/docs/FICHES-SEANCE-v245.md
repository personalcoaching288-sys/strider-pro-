# YhCoachPro 2.4.5 — Fiches de séance

Présentation issue de la première maquette validée : contour doré fin uniforme, cartes translucides contrastées, effet de relief au survol. Terrain 2D saumon sur fond bleu-vert avec lignes blanches et filet central.

## Personnalisation
Nom, équipe, date, effectif, lieu, coach, statut et objectif général. Pour chaque partie : titre, sous-titre, durée, consignes, objectif et matériel. Ajout, suppression et changement d’ordre des parties. Durée totale et nombre de parties calculés automatiquement. Nom/numéro des joueurs modifiable après sélection.

## Schémas
Joueurs, adversaires, ballons, cônes, cerceaux, flèches bleues de déplacement et orange de trajectoire. Déplacement libre, rotation, suppression et annulation. Flèches à pointe pleine, longueur et courbure réglables. Agrandissement du terrain et fermeture avec Échap. Chaque partie conserve son propre schéma.

## Enregistrement et duplication
Enregistrer conserve la fiche dans Mes fiches. Dupliquer enregistre la source, crée une copie profonde indépendante avec un nouvel identifiant et le suffixe — Copie, puis l’enregistre dans la même bibliothèque. Les anciennes fiches sont ouvertes avec conservation de leurs textes et éléments ; leurs horaires servent à calculer les durées. La bibliothèque existante et sa clé de stockage ne changent pas.

Les modifications non enregistrées déclenchent un avertissement avant nouvelle fiche, changement de fiche, retour à l’accueil ou fermeture.

## Mise à jour
Faire une sauvegarde complète avant de remplacer une version. Conserver le même profil de données Electron. Tester l’ouverture des anciennes fiches et une sauvegarde/restauration sur votre ordinateur Windows. L’archive est le projet source avec ses scripts de lancement/construction, pas un installateur Windows déjà compilé. Les tests réalisés ici sont des tests navigateur, pas une exécution installée sous Windows.
