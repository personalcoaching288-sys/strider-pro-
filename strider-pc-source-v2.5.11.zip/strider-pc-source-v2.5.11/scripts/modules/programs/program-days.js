/** Jours de programme (ajout, édition, suppression) */
// ========== DAYS ==========
function addDay() {
  if (!guardEdit()) return;
  editingDayId = null;
  document.getElementById("inputDayName").value = "";
  document.getElementById("inputDayColor").value = "#4f46e5";
  document.getElementById("dayColorHex").textContent = "#4f46e5";
  openModal("dayModal");
}

function editDay(id) {
  if (!guardEdit()) return;
  const day = program.days.find((d) => d.id === id);
  if (!day) return;
  editingDayId = id;
  document.getElementById("inputDayName").value = day.name;
  document.getElementById("inputDayColor").value = day.color || "#4f46e5";
  document.getElementById("dayColorHex").textContent = day.color || "#4f46e5";
  openModal("dayModal");
}

function saveDay() {
  if (!guardEdit()) return;
  const name = document.getElementById("inputDayName").value.trim().toUpperCase();
  const color = document.getElementById("inputDayColor").value;
  if (!name) {
    showToast("Nom du jour obligatoire");
    return;
  }

  if (editingDayId) {
    const day = program.days.find((d) => d.id === editingDayId);
    if (day) {
      day.name = name;
      day.color = color;
    }
  } else {
    program.days.push({
      id: uid(),
      name,
      color,
      open: true,
      exercises: [],
    });
  }
  save();
  render();
  closeModal("dayModal");
  showToast("Jour enregistré");
}

function deleteDay(id) {
  if (!guardEdit()) return;
  if (!confirm("Supprimer ce jour et tous ses exercices ?")) return;
  program.days = program.days.filter((d) => d.id !== id);
  save();
  render();
  showToast("Jour supprimé");
}

function toggleDay(id) {
  const day = program.days.find((d) => d.id === id);
  if (day) {
    // Boolean strict : true = ouvert, false = fermé
    const currentlyOpen = day.open !== false;
    day.open = !currentlyOpen;
    save();
    render();
  }
}
