/** Chargement à la demande html2canvas / jspdf */
// ========== CHARGEMENT À LA DEMANDE ==========
const optionalAssetLoads = new Map();

function loadOptionalScript(src, isReady, label) {
  if (isReady()) return Promise.resolve();
  if (optionalAssetLoads.has(src)) return optionalAssetLoads.get(src);
  const promise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = src;
    script.async = true;
    script.onload = () => (isReady() ? resolve() : reject(new Error(label + " non disponible")));
    script.onerror = () => reject(new Error("Impossible de charger " + label));
    document.head.appendChild(script);
  }).catch((err) => {
    optionalAssetLoads.delete(src);
    throw err;
  });
  optionalAssetLoads.set(src, promise);
  return promise;
}

async function ensureExportTools(options = {}) {
  if (options.image) {
    await loadOptionalScript(
      "./node_modules/html2canvas/dist/html2canvas.min.js",
      () => typeof window.html2canvas === "function",
      "l'outil image",
    );
  }
  if (options.pdf) {
    await loadOptionalScript(
      "./node_modules/jspdf/dist/jspdf.umd.min.js",
      () => !!(window.jspdf && window.jspdf.jsPDF),
      "l'outil PDF",
    );
  }
}
