// Après la fabrication : met l'icône Strider et les informations du fichier
// dans "Strider Pro.exe" (remplace rcedit, qui demande Windows ou Wine).
const fs = require("fs");
const path = require("path");
const ResEdit = require("resedit");

exports.default = async function (context) {
  if (context.electronPlatformName !== "win32") return;
  const exe = path.join(context.appOutDir, context.packager.appInfo.productFilename + ".exe");
  const data = fs.readFileSync(exe);
  const pe = ResEdit.NtExecutable.from(data, { ignoreCert: true });
  const res = ResEdit.NtExecutableResource.from(pe);
  const ico = ResEdit.Data.IconFile.from(fs.readFileSync(path.join(__dirname, "icon.ico")));
  const groups = ResEdit.Resource.IconGroupEntry.fromEntries(res.entries);
  const groupId = groups.length ? groups[0].id : 1;
  const lang = groups.length ? groups[0].lang : 1033;
  ResEdit.Resource.IconGroupEntry.replaceIconsForResource(res.entries, groupId, lang, ico.icons.map((i) => i.data));
  const version = context.packager.appInfo.version;
  const vi = ResEdit.Resource.VersionInfo.fromEntries(res.entries)[0];
  if (vi) {
    const [a, b, c] = version.split(".").map(Number);
    vi.setFileVersion(a, b, c, 0, 1033);
    vi.setProductVersion(a, b, c, 0, 1033);
    vi.setStringValues({ lang: 1033, codepage: 1200 }, {
      FileDescription: "Strider Pro — Coaching & Performance",
      ProductName: "Strider Pro",
      CompanyName: "Yassine Hakmi",
      LegalCopyright: "Copyright © 2026 Yassine Hakmi",
      InternalName: "Strider Pro",
      OriginalFilename: "Strider Pro.exe",
      FileVersion: version,
      ProductVersion: version,
    });
    vi.outputToResourceEntries(res.entries);
  }
  res.outputResource(pe);
  fs.writeFileSync(exe, Buffer.from(pe.generate()));
  console.log("  • icône Strider appliquée", exe);
};
