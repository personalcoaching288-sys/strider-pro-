/* Statistics for one selected player only; never alter group/profile storage. */
(function () {
  "use strict";
  let snapshot = null,
    busy = false;
  const esc = (x) =>
    String(x ?? "").replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
    );
  function capture(id) {
    const g = asGroup(),
      month = document.getElementById("asStatsMonth")?.value || asMonthKey();
    if (!g) throw Error("Choisis un groupe.");
    const p = asPlayersForDisplay(g).find((x) => x.id === id);
    if (!p) throw Error("Ce joueur ne fait pas partie du groupe choisi.");
    const sessions = (g.sessions || [])
      .filter((s) => (s.date || "").startsWith(month))
      .slice()
      .sort((a, b) => (a.date + " " + (a.time || "")).localeCompare(b.date + " " + (b.time || "")));
    const stats = asPlayerMonthStats(g, p, sessions);
    return JSON.parse(
      JSON.stringify({
        kind: "striderAttendancePlayerStats",
        version: 1,
        month,
        group: { id: g.id, title: g.title || "" },
        player: { id: p.id, name: p.name },
        totalSessions: sessions.length,
        presences: stats.pr,
        onTime: stats.onTime,
        late: stats.late,
        latePercent: stats.marked ? stats.latePct : null,
        participationPercent: stats.marked ? stats.participationPercent : null,
        absences: stats.a,
        unmarked: sessions.length - stats.marked,
        marked: stats.marked,
        absencePercent: stats.marked ? stats.pct : null,
        details: stats.details,
      }),
    );
  }
  function html(d) {
    const month = new Date(d.month + "-01T12:00:00").toLocaleDateString("fr-FR", {
      month: "long",
      year: "numeric",
    });
    const bg =
      typeof yhShareBackgroundDataUrl === "function" ? yhShareBackgroundDataUrl() : "";
    const details = (d.details || [])
      .map((row) => {
        const st =
          row.status === "present"
            ? '<span class="ok">Présent</span>'
            : row.status === "late"
              ? '<span class="mid">Retard</span>'
              : row.status === "absent"
                ? '<span class="hi">Absent</span>'
                : "—";
        return (
          "<tr><td>" +
          esc(row.date || "") +
          "</td><td>" +
          esc(row.time || "") +
          "</td><td>" +
          st +
          "</td></tr>"
        );
      })
      .join("");
    const part =
      d.participationPercent != null ? d.participationPercent + " %" : "—";
    const abs = d.absencePercent != null ? d.absencePercent + " %" : "—";
    const lateP = d.latePercent != null ? d.latePercent + " %" : "—";
    return (
      '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
      "<title>" +
      esc(d.player.name) +
      " — Assiduité</title><style>" +
      "*{box-sizing:border-box}" +
      (bg
        ? 'body{background:#030507 url("' +
          bg +
          '") center/cover fixed no-repeat}body::before{content:"";position:fixed;inset:0;background:linear-gradient(105deg,rgba(3,5,7,.52),rgba(3,5,7,.28));pointer-events:none;z-index:0}main{position:relative;z-index:1}'
        : "body{background:#09090f}") +
      'body{margin:0;color:#f8fafc;font:15px/1.5 "Segoe UI",system-ui,sans-serif;min-height:100vh}' +
      "main{width:min(720px,calc(100% - 28px));margin:24px auto 48px}" +
      ".card{margin-bottom:14px;padding:18px 20px;border-radius:16px;background:rgba(6,9,15,.78);border:1px solid rgba(185,155,93,.32);box-shadow:0 12px 36px rgba(0,0,0,.25)}" +
      ".brand{color:#e8d0af;font-weight:800;letter-spacing:.08em;text-transform:uppercase;font-size:.72rem}" +
      "h1{margin:6px 0 4px;font-size:1.45rem}h2{margin:0 0 12px;color:#e8d0af;font-size:1rem}" +
      ".sub{color:#94a3b8;margin:0;font-size:.88rem}" +
      ".kpis{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:14px}" +
      ".kpi{background:rgba(0,0,0,.28);border:1px solid rgba(185,155,93,.2);border-radius:12px;padding:12px;text-align:center}" +
      ".kpi small{display:block;color:#94a3b8;font-size:.7rem;text-transform:uppercase;margin-bottom:4px}" +
      ".kpi b{font-size:1.25rem;color:#e8d0af;font-weight:800}" +
      ".ok{color:#4ade80;font-weight:700}.mid{color:#fbbf24;font-weight:700}.hi{color:#f87171;font-weight:700}" +
      "table{width:100%;border-collapse:collapse;font-size:.88rem}th,td{padding:9px 6px;border-bottom:1px solid rgba(255,255,255,.08);text-align:left}" +
      "th{color:#94a3b8;font-size:.72rem;text-transform:uppercase}" +
      "footer{text-align:center;color:#64748b;font-size:.75rem;margin-top:18px}" +
      "</style></head><body><main>" +
      '<div class="card"><div class="brand">Strider Pro</div><h1>' +
      esc(d.player.name) +
      '</h1><p class="sub">Assiduité individuelle · ' +
      esc(d.group.title || "") +
      " · " +
      esc(month) +
      '</p><div class="kpis">' +
      '<div class="kpi"><small>Participation</small><b>' +
      part +
      "</b></div>" +
      '<div class="kpi"><small>Absences</small><b class="hi">' +
      String(d.absences) +
      " (" +
      abs +
      ")</b></div>" +
      '<div class="kpi"><small>Présents / retards</small><b class="ok">' +
      String(d.onTime) +
      " · " +
      String(d.late) +
      "</b></div>" +
      '<div class="kpi"><small>Séances</small><b>' +
      String(d.marked) +
      " / " +
      String(d.totalSessions) +
      "</b></div>" +
      "</div></div>" +
      '<div class="card"><h2>Détail des séances</h2><table><thead><tr><th>Date</th><th>Heure</th><th>Statut</th></tr></thead><tbody>' +
      (details || "<tr><td colspan=3>Aucune séance</td></tr>") +
      "</tbody></table></div>" +
      "<footer>Strider Pro · Statistiques individuelles · Lecture seule</footer>" +
      "</main></body></html>"
    );
  }

  function modal() {
    let el = document.getElementById("asPlayerShareDialog");
    if (el) return el;
    el = document.createElement("dialog");
    el.id = "asPlayerShareDialog";
    el.innerHTML =
      '<div class="as-player-share-head"><h3>Partager les statistiques du joueur</h3><button type="button" id="asPlayerShareClose" aria-label="Fermer">×</button></div><p id="asPlayerShareSummary"></p><div class="as-player-share-actions"><button type="button" data-player-share="pdf">PDF</button><button type="button" data-player-share="html">HTML</button><button type="button" data-player-share="json">JSON</button></div><p id="asPlayerShareStatus" role="status"></p>';
    document.body.appendChild(el);
    el.querySelector("#asPlayerShareClose").onclick = () => {
      if (!busy) el.close();
    };
    el.addEventListener("cancel", (e) => {
      if (busy) e.preventDefault();
    });
    el.querySelectorAll("[data-player-share]").forEach(
      (btn) => (btn.onclick = () => exportOne(btn.dataset.playerShare)),
    );
    return el;
  }
  window.asOpenPlayerStatsShare = function (id) {
    try {
      if (busy) return;
      snapshot = capture(id);
      const el = modal();
      document.getElementById("asPlayerShareSummary").textContent =
        snapshot.player.name + " · " + snapshot.group.title + " · " + snapshot.month;
      document.getElementById("asPlayerShareStatus").textContent =
        "Seules les statistiques de ce joueur seront partagées.";
      if (!el.open) el.showModal();
    } catch (e) {
      showToast(e.message);
    }
  };
  async function exportOne(mode) {
    if (busy || !snapshot) return;
    busy = true;
    const el = modal(),
      status = document.getElementById("asPlayerShareStatus"),
      d = JSON.parse(JSON.stringify(snapshot));
    el.querySelectorAll("button").forEach((b) => (b.disabled = true));
    status.textContent = "Préparation…";
    try {
      const name =
        "StriderPro_Assiduite_" + yhSafeFileName(d.player.name, "Joueur") + "_" + d.month;
      if (mode === "pdf") {
        if (!window.yhDisk?.exportProfileList)
          throw Error("Le PDF est disponible dans l’application de bureau.");
        const res = await window.yhDisk.exportProfileList(name + ".pdf", html(d), false, "pdf");
        if (res?.canceled) {
          status.textContent = "Enregistrement annulé.";
          return;
        }
        if (!res?.ok) throw Error(res?.error || "Le PDF n’a pas pu être enregistré.");
      } else if (window.yhDisk?.exportFile) {
        const res = await window.yhDisk.exportFile(
          name + "." + mode,
          mode === "json" ? JSON.stringify(d, null, 2) : html(d),
        );
        if (res?.canceled) {
          status.textContent = "Enregistrement annulé.";
          return;
        }
        if (!res?.ok) throw Error(res?.error || "Le fichier n’a pas pu être enregistré.");
      } else {
        const blob = new Blob([mode === "json" ? JSON.stringify(d, null, 2) : html(d)], {
            type: mode === "json" ? "application/json" : "text/html;charset=utf-8",
          }),
          url = URL.createObjectURL(blob),
          a = document.createElement("a");
        a.href = url;
        a.download = name + "." + mode;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
      status.textContent = "Statistiques individuelles exportées.";
    } catch (e) {
      status.textContent = e.message;
      showToast(e.message);
    } finally {
      busy = false;
      el.querySelectorAll("button").forEach((b) => (b.disabled = false));
    }
  }
  window.StriderPlayerStatsShare = { capture, html };
})();
