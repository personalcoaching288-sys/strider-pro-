"use strict";
const PROFILE_COLOR_OPTIONS = Object.freeze({
  vert: { label: "Vert", color: "#719d82" },
  orange: { label: "Orange", color: "#bf9669" },
  rouge: { label: "Rouge", color: "#b77b7e" },
});
function syncProfileColorUI() {
  const field = document.getElementById("pf_code_couleur");
  if (!field) return;
  document
    .querySelectorAll("[data-profile-color]")
    .forEach((b) => b.setAttribute("aria-checked", String(b.dataset.profileColor === field.value)));
}
function setProfileColor(value) {
  if (value !== "" && !PROFILE_COLOR_OPTIONS[value]) return;
  const field = document.getElementById("pf_code_couleur");
  if (!field) return;
  field.value = value;
  syncProfileColorUI();
  field.dispatchEvent(new Event("change", { bubbles: true }));
}
function profileColorDot(value) {
  const item = PROFILE_COLOR_OPTIONS[value];
  if (!item) return "";
  return (
    '<span class="profile-color-dot-export" title="Repère ' +
    item.label +
    '" aria-label="Repère ' +
    item.label +
    '" style="display:inline-block;width:5px;height:5px;border-radius:50%;background:' +
    item.color +
    ";border:1px solid " +
    item.color +
    ';margin-right:6px;vertical-align:middle;print-color-adjust:exact;-webkit-print-color-adjust:exact"></span>'
  );
}
