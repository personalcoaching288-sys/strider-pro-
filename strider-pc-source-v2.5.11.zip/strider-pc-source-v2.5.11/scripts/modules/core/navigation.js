/** Navigation écrans (home, editor, dashboard links) */
// ========== NAVIGATION ==========

let homeCarouselIndex = 0;
let homeCarouselTimer = null;

function renderHomeCarousel() {
  const el = document.getElementById("homeCarousel");
  const dots = document.getElementById("homeCarouselDots");
  if (!el || typeof SPORT_TEMPLATES === "undefined") return;
  const keys = Object.keys(SPORT_TEMPLATES);
  if (!keys.length) return;
  el.innerHTML = keys
    .map((key, i) => {
      const t = SPORT_TEMPLATES[key];
      const icon = t.icon || "fa-dumbbell";
      return `<div class="home-slide${i === homeCarouselIndex ? " active" : ""}" data-i="${i}">
          <h3><i class="fas ${icon}"></i> ${t.label}</h3>
          <p>${t.desc}</p>
          <div class="slide-actions">
            <button type="button" class="btn-use" onclick="openTemplateModal(); setTimeout(()=>openSportSessions('${key}'), 50)"><i class="fas fa-bolt"></i> Voir séances</button>
            <button type="button" class="btn-next" onclick="nextHomeSlide()"><i class="fas fa-arrow-right"></i> Suivant</button>
          </div>
        </div>`;
    })
    .join("");
  if (dots) {
    dots.innerHTML = keys
      .map(
        (_, i) =>
          `<button type="button" class="${i === homeCarouselIndex ? "active" : ""}" onclick="goHomeSlide(${i})"></button>`,
      )
      .join("");
  }
}
function goHomeSlide(i) {
  const keys = Object.keys(SPORT_TEMPLATES || {});
  if (!keys.length) return;
  homeCarouselIndex = ((i % keys.length) + keys.length) % keys.length;
  renderHomeCarousel();
  restartHomeCarouselTimer();
}
function nextHomeSlide() {
  goHomeSlide(homeCarouselIndex + 1);
}
function restartHomeCarouselTimer() {
  if (homeCarouselTimer) clearInterval(homeCarouselTimer);
  homeCarouselTimer = setInterval(() => {
    if (document.getElementById("homeScreen")?.classList.contains("active")) {
      nextHomeSlide();
    }
  }, 5000);
}

function dashboardLocalDate(date = new Date()) {
  return [date.getFullYear(), String(date.getMonth() + 1).padStart(2, "0"), String(date.getDate()).padStart(2, "0")].join("-");
}

function dashboardSessionsForDate(date = dashboardLocalDate()) {
  const rows = (programsIndex || [])
    .flatMap((p) => typeof window.getProgramScheduledSessions === "function" ? window.getProgramScheduledSessions(p) : [p])
    .filter((p) => p && p.date === date)
    .map((p) => ({ ...p, kind: "program" }));
  try {
    const sheets = typeof window.getSavedSessionSheets === "function" ? window.getSavedSessionSheets() : [];
    const seen = new Set();
    sheets.forEach((s) => {
      if (!s || !s.id || seen.has(s.id) || s.date !== date || /^(Annulée?|Cancelled)$/i.test(s.status || "")) return;
      seen.add(s.id);
      rows.push({ ...s, kind: "sheet", time: s.hour || "", theme: s.title, athlete: s.groupTitle || s.team || s.club || "", sport: s.sport || "volley" });
    });
  } catch (e) {
    console.warn("Bibliothèque de séances indisponible", e);
  }
  return rows.sort((a, b) => String(a.time || "99:99").localeCompare(String(b.time || "99:99")));
}

function dashboardOpenSession(kind, id) {
  if (kind === "sheet") return window.showSessionSheet(id);
  return openProgram(id);
}

function dashboardSessionAction(p) {
  return `data-session-kind="${p.kind}" data-session-id="${escapeHtml(p.id)}" onclick="dashboardOpenSession(this.dataset.sessionKind,this.dataset.sessionId)"`;
}

function renderHomeToday() {
  const box = document.getElementById("homeTodayList");
  if (!box) return;
  const due = dashboardSessionsForDate();
  if (!due.length) {
    box.innerHTML = '<div class="home-today-empty">Aucune seance programmee pour aujourd hui</div>';
    return;
  }
  box.innerHTML = due
    .map((p) => {
      let img = "";
      try {
        const full = p.kind === "program" ? loadProgramFromStorage(p.id) : null;
        if (full && full.athletePhoto) {
          img = `<img src="${full.athletePhoto}" alt="" />`;
        } else {
          img = `<div class="ph"><i class="fas fa-user"></i></div>`;
        }
      } catch (e) {
        img = `<div class="ph"><i class="fas fa-user"></i></div>`;
      }
      const theme = escapeHtml(p.theme || "");
      const poste = p.poste ? " · " + escapeHtml(p.poste) : "";
      return `<button type="button" class="home-today-card" ${dashboardSessionAction(p)}>
          ${img}
          <div>
            <strong>${escapeHtml(p.athlete || "Athlète")}</strong>
            <span>${theme}${poste} · Séance n°${p.sessionNum || 1}</span>
          </div>
        </button>`;
    })
    .join("");
}

function openTodaySession() {
  const due = dashboardSessionsForDate();
  if (!due.length) {
    showToast("Aucune séance prévue aujourd'hui");
    return;
  }
  if (due.length === 1) {
    dashboardOpenSession(due[0].kind, due[0].id);
    return;
  }
  // Plusieurs : ouvrir le panneau programmes filtré / le premier + toast
  showToast(due.length + " séances aujourd'hui — ouverture de la première");
  dashboardOpenSession(due[0].kind, due[0].id);
}

const YH_APP_LOGO = YHEmbeddedAssets["795f28b36d4ab4e2"];
function getAppWordmarkDataUrl() {
  return YHEmbeddedAssets["0499de30d9ddda4a"];
}
function getAppLogoDataUrl() {
  return YH_APP_LOGO;
}
function logoPlaceholderImg(cssClass, style) {
  const src = getAppLogoDataUrl();
  if (!src) return null;
  const st =
    style || "width:100%;height:100%;object-fit:cover;border-radius:inherit;background:#000";
  const cls = cssClass ? ' class="' + cssClass + '"' : "";
  return "<img" + cls + ' src="' + src + '" alt="Strider Pro" style="' + st + '" />';
}

function dashNormalizeName(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}
function dashProfileName(p) {
  return [p && p.prenom, p && p.nom].filter(Boolean).join(" ").trim();
}
function dashProfileLabel(p) {
  return [String((p && p.nom) || "").toLocaleUpperCase("fr-FR"), p && p.prenom]
    .filter(Boolean)
    .join(" ")
    .trim();
}
function dashUniqueNames(values) {
  const seen = new Set();
  return values
    .filter(Boolean)
    .map((x) => String(x).trim())
    .filter((name) => {
      const key = dashNormalizeName(name);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => a.localeCompare(b, "fr"));
}
function dashSelectedGroup() {
  const id = document.getElementById("dashGroupSelect")?.value || "";
  return id ? (asStore.groups || []).find((g) => g.id === id) || null : null;
}
function dashNamesForGroup(group) {
  if (!group) {
    const attendance = (asStore.groups || []).flatMap((g) => (g.players || []).map((p) => p.name));
    const profiles = (athleteProfiles || []).map(dashProfileName);
    const programmed = (programsIndex || []).map((p) => p.athlete);
    return dashUniqueNames(attendance.concat(profiles, programmed));
  }
  return dashUniqueNames((group.players || []).map((p) => p.name));
}
function dashFillAthleteControls() {
  const group = dashSelectedGroup();
  const names = dashNamesForGroup(group);
  const progSel = document.getElementById("dashAthleteProgramSelect");
  if (progSel) {
    const old = progSel.value;
    progSel.innerHTML =
      '<option value="">— Sélectionner un athlète —</option>' +
      names.map((n) => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join("");
    if (names.includes(old)) progSel.value = old;
  }
  const allowed = new Set(names.map(dashNormalizeName));
  const profiles = (athleteProfiles || []).filter(
    (p) => !group || allowed.has(dashNormalizeName(dashProfileName(p))),
  );
  const profileSel = document.getElementById("dashProfileSelect");
  profiles.sort((a, b) =>
    typeof compareAthleteProfiles === "function"
      ? compareAthleteProfiles(a, b)
      : String(a.nom || "").localeCompare(String(b.nom || ""), "fr", {
          sensitivity: "base",
          numeric: true,
        }),
  );
  if (profileSel)
    profileSel.innerHTML =
      '<option value="">— Sélectionner une fiche —</option>' +
      profiles
        .map(
          (p) =>
            `<option value="${p.id}">${escapeHtml(dashProfileLabel(p) || "Sans nom")}</option>`,
        )
        .join("");
  const datalist = document.getElementById("dashProfileOptions");
  if (datalist)
    datalist.innerHTML = profiles
      .map((p) => `<option value="${escapeHtml(dashProfileLabel(p))}"></option>`)
      .join("");
  return names;
}
function dashCopyProfileName() {
  const id = document.getElementById("dashProfileSelect")?.value;
  const p = (athleteProfiles || []).find((x) => x.id === id);
  const input = document.getElementById("dashProfileSearch");
  if (p && input) input.value = dashProfileName(p);
}
function dashOnGroupChange() {
  const group = dashSelectedGroup();
  const names = dashFillAthleteControls();
  const summary = document.getElementById("dashGroupSummary");
  if (summary)
    summary.textContent = group
      ? `${group.title || "Groupe"} · ${names.length} athlète(s)`
      : `${(asStore.groups || []).length} groupe(s) · tous les athlètes`;
  const chips = document.getElementById("dashGroupPlayers");
  if (chips)
    chips.innerHTML = names.length
      ? names
          .slice(0, 12)
          .map((n) => `<span>${escapeHtml(n)}</span>`)
          .join("") + (names.length > 12 ? `<span>+${names.length - 12}</span>` : "")
      : "<span>Aucun athlète</span>";
  const details = document.getElementById("dashGroupDetails");
  if (details)
    details.innerHTML = group
      ? `<div class="dash-v18-group-name"><b>${escapeHtml(group.title || "Groupe")}</b><span>${(group.players || []).length} athlète(s) · ${(group.sessions || []).length} séance(s) d’assiduité</span></div>`
      : `<div class="dash-v18-group-name"><b>Tous les groupes</b><span>${(asStore.groups || []).reduce((n, g) => n + (g.players || []).length, 0)} inscriptions au total</span></div>`;
  const result = document.getElementById("dashAthleteProgramsResult");
  if (result) result.innerHTML = '<div class="dash-empty">Choisis un athlète.</div>';
}
function showDashboardAthletePrograms() {
  const name = document.getElementById("dashAthleteProgramSelect")?.value || "";
  const result = document.getElementById("dashAthleteProgramsResult");
  if (!result) return;
  if (!name) {
    result.innerHTML = '<div class="dash-empty">Choisis un athlète.</div>';
    return;
  }
  const key = dashNormalizeName(name);
  const matches = (programsIndex || [])
    .filter((p) => dashNormalizeName(p.athlete) === key)
    .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  result.innerHTML = matches.length
    ? matches
        .map(
          (p) =>
            `<button class="dash-v18-program" onclick="openProgram('${p.id}')"><div><b>${escapeHtml(p.theme || "Programme")}</b><small>Séance ${p.sessionNum || 1} · ${escapeHtml(p.date || "Sans date")}</small></div><span>Ouvrir →</span></button>`,
        )
        .join("")
    : '<div class="dash-empty">Aucun programme dédié à cet athlète.</div>';
}
function openDashboardAthleteProfile() {
  loadAthleteProfiles();
  const selectedId = document.getElementById("dashProfileSelect")?.value || "";
  const typed = document.getElementById("dashProfileSearch")?.value || "";
  let p = selectedId ? athleteProfiles.find((x) => x.id === selectedId) : null;
  const key = dashNormalizeName(typed);
  if (!p && key)
    p =
      athleteProfiles.find((x) => dashNormalizeName(dashProfileName(x)) === key) ||
      athleteProfiles.find((x) => dashNormalizeName(dashProfileName(x)).includes(key));
  if (!p) {
    showToast("Fiche athlète introuvable");
    return;
  }
  const id = p.id;
  openAthleteProfiles();
  setTimeout(() => selectAthleteProfile(id), 0);
}
function openDashboardGroupManager() {
  const g = dashSelectedGroup();
  asLoad();
  if (g && (asStore.groups || []).some((x) => x.id === g.id)) asStore.currentGroupId = g.id;
  showAssiduite();
  setTimeout(() => asShowPanel("asPlayers"), 0);
}
function dashPopulateTemplates() {
  const sel = document.getElementById("dashTemplateSport");
  if (!sel || typeof SPORT_TEMPLATES === "undefined") return;
  const old = sel.value;
  sel.innerHTML =
    '<option value="">— Choisir un sport —</option>' +
    Object.keys(SPORT_TEMPLATES)
      .map((k) => `<option value="${k}">${escapeHtml(SPORT_TEMPLATES[k].label || k)}</option>`)
      .join("");
  if (SPORT_TEMPLATES[old]) sel.value = old;
  dashChangeTemplateSport();
}
function dashChangeTemplateSport() {
  const sportKey = document.getElementById("dashTemplateSport")?.value || "";
  const theme = document.getElementById("dashTemplateTheme");
  if (!theme) return;
  const sport = SPORT_TEMPLATES && SPORT_TEMPLATES[sportKey];
  theme.innerHTML =
    '<option value="">— Choisir un thème —</option>' +
    (sport
      ? Object.keys(sport.sessions || {})
          .map((k) => `<option value="${k}">${escapeHtml(sport.sessions[k].label || k)}</option>`)
          .join("")
      : "");
}
function dashUseTemplate() {
  const sport = document.getElementById("dashTemplateSport")?.value || "";
  const theme = document.getElementById("dashTemplateTheme")?.value || "";
  if (!sport) {
    showToast("Choisis d’abord un sport");
    return;
  }
  if (!theme) {
    openTemplateModal();
    setTimeout(() => openSportSessions(sport), 50);
    return;
  }
  const athlete = document.getElementById("dashAthleteProgramSelect")?.value || "";
  applySportTemplate(sport, theme);
  if (athlete && program) {
    program.athlete = athlete;
    render();
  }
}
function renderDashboardHome() {
  try {
    loadProgramsIndex();
  } catch (e) {}
  try {
    loadAthleteProfiles();
  } catch (e) {
    athleteProfiles = [];
  }
  try {
    asLoad();
  } catch (e) {
    asStore = { groups: [], currentGroupId: null };
  }
  const today = dashboardLocalDate();
  const allNames = dashNamesForGroup(null);
  const setText = (id, v) => {
    const el = document.getElementById(id);
    if (el) el.textContent = String(v);
  };
  setText("dashGroups", (asStore.groups || []).length);
  setText("dashAthletes", allNames.length);
  setText("dashPrograms", (programsIndex || []).length);
  setText("dashSessions", dashboardSessionsForDate(today).length);
  const dateEl = document.getElementById("dashDate");
  if (dateEl)
    dateEl.textContent =
      new Intl.DateTimeFormat("fr-FR", { weekday: "long", day: "numeric", month: "long" }).format(
        new Date(),
      ) + " · groupes, programmes et fiches";
  const groupSel = document.getElementById("dashGroupSelect");
  if (groupSel) {
    const old = groupSel.value;
    groupSel.innerHTML =
      '<option value="">Tous les groupes</option>' +
      (asStore.groups || [])
        .map(
          (g) =>
            `<option value="${g.id}">${escapeHtml(g.title || "Groupe")} (${(g.players || []).length})</option>`,
        )
        .join("");
    if ((asStore.groups || []).some((g) => g.id === old)) groupSel.value = old;
  }
  dashOnGroupChange();
  dashPopulateTemplates();
  renderSimpleDashboard();
  applyDashboardMode();
}

function dashboardAttendanceRate() {
  let present = 0,
    marked = 0;
  (asStore.groups || []).forEach((g) =>
    (g.sessions || []).forEach((s) =>
      Object.values(s.attendance || {}).forEach((v) => {
        if (v === true || v === "late") {
          present++;
          marked++;
        } else if (v === false) marked++;
      }),
    ),
  );
  return marked ? Math.round((present / marked) * 100) : null;
}
function dashboardLatestProgress(p) {
  const tests = (p.tests || [])
    .slice()
    .sort(
      (a, b) =>
        String(a.date || "").localeCompare(String(b.date || "")) || (a.ts || 0) - (b.ts || 0),
    );
  if (tests.length < 2) return null;
  const metrics = [
    ["poids", "Poids", "kg", false],
    ["vma", "VMA", "", true],
    ["saut_elan", "Saut avec élan", "cm", true],
    ["1rm_dc", "Développé couché", "kg", true],
    ["1rm_squat", "1/2 Squat", "kg", true],
  ];
  for (const [key, label, unit, higher] of metrics) {
    const vals = tests.filter(
      (t) =>
        t[key] !== "" && t[key] != null && !isNaN(parseFloat(String(t[key]).replace(",", "."))),
    );
    if (vals.length < 2) continue;
    const a = parseFloat(String(vals[vals.length - 2][key]).replace(",", ".")),
      b = parseFloat(String(vals[vals.length - 1][key]).replace(",", "."));
    if (a === b) continue;
    return { label, unit, delta: b - a, good: higher ? b > a : null };
  }
  return null;
}

function dashboardLatestRpe() {
  try {
    if (typeof asLoad === "function") asLoad();
  } catch (_) {}
  if (typeof asStore === "undefined" || !asStore || !(asStore.groups || []).length) {
    return { avg: null, label: "Aucune donnée RPE" };
  }
  let best = null;
  (asStore.groups || []).forEach((g) => {
    (g.sessions || []).forEach((s) => {
      if (!s || !s.date) return;
      const att = s.attendance || {};
      const rpeMap = s.rpe || {};
      const presentIds = Object.keys(att).filter(
        (id) => att[id] === true || att[id] === "late" || att[id] === "present",
      );
      if (!presentIds.length) return;
      const vals = presentIds
        .map((id) => Number(rpeMap[id] != null ? rpeMap[id] : rpeMap[String(id)]))
        .filter((v) => Number.isFinite(v) && v >= 1 && v <= 10);
      if (!vals.length) return;
      const avg = Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 10) / 10;
      const stamp = String(s.date) + (s.time || "");
      if (!best || stamp > best.stamp) {
        let level = "Modérée";
        if (avg <= 6) level = "Légère";
        else if (avg >= 8.5) level = "Élevée";
        best = { avg, level, stamp, date: s.date };
      }
    });
  });
  if (!best) return { avg: null, label: "Saisir le RPE →" };
  return {
    avg: best.avg,
    label: best.level + " · " + (best.date || ""),
  };
}

function renderSimpleDashboard() {
  const today = dashboardLocalDate(),
    due = dashboardSessionsForDate(today);
  const set = (id, v) => {
    const e = document.getElementById(id);
    if (e) e.textContent = String(v);
  };
  set("dashSimpleAthletes", (athleteProfiles || []).length);
  set("dashSimplePrograms", (programsIndex || []).length);
  set("dashSimpleSessionsCount", due.length);
  set(
    "dashSimpleSessionsSub",
    due.length ? `${due.length} prévue${due.length > 1 ? "s" : ""}` : "Aucune prévue",
  );
  const rate = dashboardAttendanceRate();
  set("dashSimpleAttendance", rate == null ? "—" : rate + "%");
  const rpeInfo = dashboardLatestRpe();
  set("dashSimpleRpe", rpeInfo.avg == null ? "—" : String(rpeInfo.avg).replace(".", ","));
  const rpeSub = document.getElementById("dashRpeSub");
  if (rpeSub) rpeSub.textContent = rpeInfo.label || "Ouvrir le suivi RPE";
  const sel = document.getElementById("dashSimpleAthleteSelect");
  if (sel) {
    const old = sel.value;
    const rows = (athleteProfiles || [])
      .slice()
      .sort((a, b) =>
        typeof compareAthleteProfiles === "function" ? compareAthleteProfiles(a, b) : 0,
      );
    sel.innerHTML =
      '<option value="">— Sélectionner un athlète —</option>' +
      rows
        .map(
          (p) =>
            `<option value="${p.id}">${escapeHtml(dashProfileLabel(p) || "Sans nom")}</option>`,
        )
        .join("");
    if (rows.some((p) => p.id === old)) sel.value = old;
  }
  const sessions = document.getElementById("dashSimpleSessions");
  if (sessions)
    sessions.innerHTML = due.length
      ? due
          .map(
            (p) =>
              `<button class="dash-simple-session" ${dashboardSessionAction(p)}><time>${escapeHtml(p.time || "—")}</time><span><b>${escapeHtml(p.theme || (p.kind === "sheet" ? "Fiche de séance" : "Séance de musculation"))}</b><small>${escapeHtml(p.athlete || (p.kind === "sheet" ? p.sport : "Athlète"))}${p.kind === "program" ? " · Séance n°" + escapeHtml(p.sessionNum || 1) : ""}</small></span><em>${escapeHtml(p.kind === "sheet" ? p.status || "Prévue" : "À faire")}</em></button>`,
          )
          .join("")
      : '<div class="dash-simple-empty">Aucune séance programmée aujourd’hui.</div>';
  const progress = (athleteProfiles || [])
    .map((p) => ({ p, r: dashboardLatestProgress(p) }))
    .filter((x) => x.r)
    .slice(0, 4);
  const prog = document.getElementById("dashSimpleProgress");
  if (prog)
    prog.innerHTML = progress.length
      ? progress
          .map(({ p, r }) => {
            const sign = r.delta > 0 ? "+" : "";
            const cls = r.good === false ? "bad" : r.good === true ? "good" : "neutral";
            return `<button class="dash-simple-progress" onclick="openAthleteProfiles();setTimeout(()=>selectAthleteProfile('${p.id}'),0)"><span><b>${escapeHtml(dashProfileLabel(p))}</b><small>${escapeHtml(r.label)}</small></span><em class="${cls}">${r.delta > 0 ? "↑" : "↓"} ${sign}${Math.round(r.delta * 10) / 10} ${r.unit}</em></button>`;
          })
          .join("")
      : '<div class="dash-simple-empty">Les progressions apparaîtront après deux mesures.</div>';
  const stale = (athleteProfiles || []).filter((p) => {
    const t = (p.tests || []).slice(-1)[0];
    if (!t || !t.date) return false;
    const d = new Date(String(t.date).slice(0, 10) + "T12:00:00");
    return isFinite(d) && Date.now() - d.getTime() > 30 * 86400000;
  }).length;
  const incomplete = (athleteProfiles || []).filter(
    (p) => !(p.nom || "").trim() || !(p.prenom || "").trim(),
  ).length;
  const weekEnd = new Date();
  weekEnd.setDate(weekEnd.getDate() + 7);
  const upcomingPrograms = typeof window.getUpcomingProgramSessions === "function"
    ? window.getUpcomingProgramSessions(programsIndex || [], today) : programsIndex || [];
  const week = upcomingPrograms.filter((p) => p.date > today && p.date <= dashboardLocalDate(weekEnd)).length;
  const alerts = [];
  if (stale)
    alerts.push([
      "danger",
      `${stale} test${stale > 1 ? "s" : ""} à renouveler`,
      "Données physiques de plus de 30 jours",
    ]);
  if (incomplete)
    alerts.push([
      "warn",
      `${incomplete} profil${incomplete > 1 ? "s" : ""} incomplet${incomplete > 1 ? "s" : ""}`,
      "Nom ou prénom manquant",
    ]);
  if (week)
    alerts.push([
      "warn",
      `${week} séance${week > 1 ? "s" : ""} cette semaine`,
      "Programmes planifiés dans les 7 jours",
    ]);
  const ab = document.getElementById("dashSimpleAlerts");
  if (ab)
    ab.innerHTML = alerts.length
      ? alerts
          .map(
            (a) =>
              `<div class="dash-simple-alert"><i class="${a[0]}"></i><span><b>${a[1]}</b><small>${a[2]}</small></span></div>`,
          )
          .join("")
      : '<div class="dash-simple-empty">Aucune alerte importante.</div>';
  set("dashSimpleAlertCount", alerts.length + " alerte" + (alerts.length > 1 ? "s" : ""));
  try {
    if (typeof renderNewDashboard === "function") renderNewDashboard();
  } catch (e) {}
}
function openSimpleDashboardAthlete() {
  const id = document.getElementById("dashSimpleAthleteSelect")?.value;
  if (!id) {
    showToast("Choisis un athlète");
    return;
  }
  openAthleteProfiles();
  setTimeout(() => selectAthleteProfile(id), 0);
}
function applyDashboardMode() {
  const simple = document.getElementById("dashSimpleView"),
    full = document.getElementById("dashFullView"),
    btn = document.getElementById("dashModeButton");
  if (simple) simple.hidden = false;
  if (full) full.hidden = true;
  if (btn) btn.hidden = true;
}
function toggleDashboardMode() {
  let mode = "simple";
  try {
    mode = localStorage.getItem("yhcoach_dashboard_mode") || "simple";
    localStorage.setItem("yhcoach_dashboard_mode", mode === "full" ? "simple" : "full");
  } catch (e) {}
  applyDashboardMode();
}

function applyDashboardVisibility(visible) {
  const classic = document.getElementById("classicHomeContent");
  const panel = document.getElementById("dashboardPanel");
  const button = document.getElementById("dashboardToggleBtn");
  if (!classic || !panel || !button) return;
  const show = Boolean(visible);
  classic.hidden = show;
  panel.hidden = !show;
  button.innerHTML = show
    ? '<span class="dashboard-toggle-symbol">−</span><span class="top-action-label">Réduire</span>'
    : '<span class="dashboard-toggle-symbol">▦</span><span class="top-action-label">Restaurer le tableau</span>';
  button.setAttribute(
    "aria-label",
    show ? "Réduire le tableau de bord" : "Restaurer le tableau de bord",
  );
  button.title = show ? "Réduire le tableau de bord" : "Restaurer le tableau de bord";
  button.setAttribute("aria-pressed", show ? "true" : "false");
  document.getElementById("homeScreen")?.classList.toggle("dashboard-view", show);
  if (show) {
    closeHomeMenus();
    try {
      renderDashboardHome();
    } catch (e) {}
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
}

function toggleDashboardPanel() {
  const home = document.getElementById("homeScreen");
  if (!home || !home.classList.contains("active")) {
    showHome();
    return;
  }
  const panel = document.getElementById("dashboardPanel");
  applyDashboardVisibility(panel ? panel.hidden : true);
}

function openHomeMenuFromDashboard() {
  showHome();
  applyDashboardVisibility(false);
  toggleHomeMenu();
}

function openHomeProgramsFromDashboard() {
  showHome();
  applyDashboardVisibility(false);
  toggleHomePrograms();
}

function dashboardCardKey(event, action) {
  if (event.key !== "Enter" && event.key !== " ") return;
  event.preventDefault();
  if (typeof action === "function") action();
}

function showHome() {
  try {
    if (asClockTimer) clearInterval(asClockTimer);
  } catch (e) {}
  // Fermer TOUS les ecrans (sinon Assiduite / profil restent visibles)
  try {
    document.querySelectorAll(".screen").forEach((s) => {
      s.classList.remove("active");
      if (s.id === "profileScreen") s.style.display = "none";
    });
  } catch (e) {}
  try {
    document.getElementById("programsPanel")?.classList.remove("show");
    document.getElementById("homeMenuDropdown")?.classList.remove("show");
    document.getElementById("themesSubmenu")?.classList.remove("show");
    const ts = document.getElementById("themesSubmenu");
    if (ts) ts.style.display = "none";
  } catch (e) {}
  const home = document.getElementById("homeScreen");
  if (home) home.classList.add("active");
  if (typeof closeHomeMenus === "function") closeHomeMenus();
  try {
    loadProgramsIndex();
  } catch (e) {}
  // Le tableau de bord simplifié est l'accueil par défaut.
  try {
    applyDashboardVisibility(true);
  } catch (e) {}
  try {
    renderDashboardHome();
  } catch (e) {}
  try {
    checkTodayReminders();
  } catch (e) {}
}

function showEditor() {
  document.getElementById("homeScreen").classList.remove("active");
  document.getElementById("editorScreen").classList.add("active");
  render();
}

// programs.js chargé séparément.
