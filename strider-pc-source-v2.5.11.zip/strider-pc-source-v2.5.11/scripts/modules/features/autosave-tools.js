/** Sauvegarde auto, volume, alertes, RPE */
// ========== SAUVEGARDE AUTO / VOLUME / ALERTES / BIBLIO / RPE ==========
let autoSaveTimer = null;
let programDirty = false;

function markDirty() {
  programDirty = true;
}

function startAutoSave() {
  if (autoSaveTimer) clearInterval(autoSaveTimer);
  autoSaveTimer = setInterval(() => {
    if (!programDirty) return;
    if (!program || !program.id) return;
    if (typeof athleteModeLocked !== "undefined" && athleteModeLocked) return;
    program.updatedAt = Date.now();
    if (saveProgramToStorage(program)) {
      programDirty = false;
      showToast("Sauvegarde auto");
    }
  }, 120000); // 2 min
}

function showStorageInfo() {
  const mode = storageModeLabel();
  let extra = "";
  if (USE_DISK) {
    extra = "\\n\\nLes programmes sont enregistrés sur le disque du PC (presque illimité).";
  } else {
    extra = "\\n\\nMode navigateur : espace limité (~5-10 Mo). Utilise l'exe pour le SSD.";
  }
  alert("Stockage YhCoachPro :\\n" + mode + extra);
}

// --- Bibliothèque (liste unique d'exercices réutilisables) ---
function loadExerciseLibrary() {
  try {
    const raw = storeGet("yhcoachpro_exercise_library");
    let list = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(list)) list = [];
    // Migration: anciennes entrées avec compName → 2 exercices séparés
    const out = [];
    const seen = new Set();
    list.forEach((item) => {
      if (!item) return;
      const n = (item.name || "").trim();
      if (n) {
        const key = n.toLowerCase();
        if (!seen.has(key)) {
          seen.add(key);
          out.push({
            id: item.id || uid(),
            name: n,
            image: item.image || null,
            series: item.series,
            reps: item.reps,
            charge: item.charge,
            chargeKg: item.chargeKg,
            recup: item.recup,
            rpe: item.rpe,
            notes: item.notes || "",
            savedAt: item.savedAt || Date.now(),
          });
        }
      }
      const cn = (item.compName || "").trim();
      if (cn) {
        const key = cn.toLowerCase();
        if (!seen.has(key)) {
          seen.add(key);
          out.push({
            id: uid(),
            name: cn,
            image: item.compImage || null,
            series: item.compSeries,
            reps: item.compReps,
            charge: item.compCharge,
            chargeKg: item.compChargeKg,
            recup: item.compRecup,
            rpe: item.compRpe,
            notes: item.compNotes || "",
            savedAt: item.savedAt || Date.now(),
          });
        }
      }
    });
    return out;
  } catch (e) {
    return [];
  }
}
function saveExerciseLibrary(list) {
  storeSet("yhcoachpro_exercise_library", JSON.stringify(list || []));
}

/** Enregistre ou met à jour un exercice dans la liste (par nom). */
function upsertLibraryExercise(payload) {
  const name = (payload && payload.name ? String(payload.name) : "").trim();
  if (!name) return null;
  const list = loadExerciseLibrary();
  const key = name.toLowerCase();
  const idx = list.findIndex((x) => (x.name || "").toLowerCase() === key);
  const entry = {
    id: idx >= 0 ? list[idx].id : uid(),
    name,
    image: payload.image != null ? payload.image : idx >= 0 ? list[idx].image : null,
    series: payload.series != null ? payload.series : idx >= 0 ? list[idx].series : 3,
    reps: payload.reps != null ? payload.reps : idx >= 0 ? list[idx].reps : 10,
    charge: payload.charge != null ? payload.charge : idx >= 0 ? list[idx].charge : 70,
    chargeKg:
      payload.chargeKg !== undefined ? payload.chargeKg : idx >= 0 ? list[idx].chargeKg : null,
    recup: payload.recup != null ? payload.recup : idx >= 0 ? list[idx].recup : "90s",
    rpe: payload.rpe !== undefined ? payload.rpe : idx >= 0 ? list[idx].rpe : null,
    notes: payload.notes != null ? payload.notes : idx >= 0 ? list[idx].notes : "",
    savedAt: Date.now(),
  };
  // Si nouvelle image fournie, la garder ; si payload.image est explicitement null on peut garder l'ancienne sauf si demandé
  if (payload.image) entry.image = payload.image;
  if (idx >= 0) list[idx] = entry;
  else list.push(entry);
  saveExerciseLibrary(list);
  return entry;
}

function addExerciseToLibrary(dayId, exId) {
  const day = program.days.find((d) => d.id === dayId);
  const ex = day?.exercises?.find((e) => e.id === exId);
  if (!ex) return;
  if (ex.name)
    upsertLibraryExercise({
      name: ex.name,
      image: ex.image,
      series: ex.series,
      reps: ex.reps,
      charge: ex.charge,
      chargeKg: ex.chargeKg,
      recup: ex.recup,
      rpe: ex.rpe,
      notes: ex.notes,
    });
  if (ex.compName)
    upsertLibraryExercise({
      name: ex.compName,
      image: ex.compImage,
      series: ex.compSeries,
      reps: ex.compReps,
      charge: ex.compCharge,
      chargeKg: ex.compChargeKg,
      recup: ex.compRecup,
      rpe: ex.compRpe,
      notes: ex.compNotes,
    });
  showToast("Exercice(s) ajouté(s) à la bibliothèque");
}

function openExerciseLibrary() {
  if (!program.days || !program.days.length) {
    showToast("Ajoute d'abord un jour");
    return;
  }
  const sel = document.getElementById("libTargetDay");
  if (sel) {
    sel.innerHTML = program.days
      .map((d) => `<option value="${d.id}">${escapeHtml(d.name || "Jour")}</option>`)
      .join("");
  }
  const list = loadExerciseLibrary();
  const box = document.getElementById("libList");
  if (!box) return;
  if (!list.length) {
    box.innerHTML =
      "<p style='color:#94a3b8'>Bibliotheque vide. Ajoute un exercice via l icone livre sur une carte.</p>";
  } else {
    box.innerHTML = list
      .slice()
      .reverse()
      .map((item) => {
        const img = item.image
          ? `<img src="${item.image}" alt="" />`
          : `<div style="width:44px;height:44px;border-radius:8px;background:rgba(99,102,241,0.3);display:flex;align-items:center;justify-content:center"><i class="fas fa-dumbbell"></i></div>`;
        return `<div class="lib-item" onclick="insertFromLibrary('${item.id}')">
            ${img}
            <div style="flex:1">
              <strong>${escapeHtml(item.name || "Sans nom")}</strong>
              <div style="font-size:0.78rem;color:#94a3b8">${item.series || 0}×${item.reps || 0} · ${item.charge || 0}%</div>
            </div>
            <button type="button" onclick="event.stopPropagation();deleteLibraryItem('${item.id}')" title="Supprimer" style="background:transparent;border:none;color:#f87171;cursor:pointer"><i class="fas fa-trash"></i></button>
          </div>`;
      })
      .join("");
  }
  openModal("libraryModal");
}

function deleteLibraryItem(id) {
  let list = loadExerciseLibrary().filter((x) => x.id !== id);
  saveExerciseLibrary(list);
  openExerciseLibrary();
}

function insertFromLibrary(libId) {
  const item = loadExerciseLibrary().find((x) => x.id === libId);
  if (!item) return;
  const dayId = document.getElementById("libTargetDay")?.value;
  const day = program.days.find((d) => d.id === dayId);
  if (!day) return;
  if (!day.exercises) day.exercises = [];
  const ex = {
    id: uid(),
    name: item.name || "",
    image: item.image || null,
    series: item.series ?? 3,
    reps: item.reps ?? 10,
    charge: item.charge ?? 70,
    chargeKg: item.chargeKg ?? "",
    recup: item.recup ?? "90s",
    rpe: item.rpe ?? "",
    notes: item.notes ?? "",
    colorWhole: false,
    cardColor: "#1f2937",
    colBorder: "#10b981",
    colSeries: "#6366f1",
    colReps: "#0d9488",
    colCharge: "#e11d48",
    colRecup: "#7c3aed",
    compName: item.compName || "",
    compImage: item.compImage || null,
    compSeries: item.compSeries ?? "",
    compReps: item.compReps ?? "",
    compCharge: item.compCharge ?? "",
    compChargeKg: item.compChargeKg ?? "",
    compRecup: item.compRecup ?? "",
  };
  day.exercises.push(ex);
  day.open = true;
  markDirty();
  save();
  render();
  closeModal("libraryModal");
  showToast("Exercice inséré");
}

// --- Volume + alertes charge ---
function calcProgramVolume(prog) {
  let volume = 0,
    sets = 0;
  (prog.days || []).forEach((d) => {
    (d.exercises || []).forEach((ex) => {
      const ser = +ex.series || 0;
      const rep = +ex.reps || 0;
      const kg = ex.chargeKg !== "" && ex.chargeKg != null ? +ex.chargeKg : 0;
      sets += ser;
      volume += ser * rep * kg;
      if (ex.compName) {
        const cs = +ex.compSeries || 0,
          cr = +ex.compReps || 0;
        const ckg = ex.compChargeKg !== "" && ex.compChargeKg != null ? +ex.compChargeKg : 0;
        sets += cs;
        volume += cs * cr * ckg;
      }
    });
  });
  return { volume: Math.round(volume), sets };
}

function getLoadAlerts(prog) {
  const alerts = [];
  try {
    const store = typeof loadHistoryStore === "function" ? loadHistoryStore() : {};
    const athlete = prog.athlete || "";
    const hist = store[athlete] || {};
    (prog.days || []).forEach((d) => {
      (d.exercises || []).forEach((ex) => {
        const name = (ex.name || "").trim();
        if (!name) return;
        const kg = ex.chargeKg !== "" && ex.chargeKg != null ? +ex.chargeKg : null;
        if (kg == null || isNaN(kg)) return;
        const arr = hist[name] || [];
        if (arr.length < 1) return;
        const last = arr[arr.length - 1];
        const prev = +last.kg;
        if (!isNaN(prev) && kg < prev) {
          alerts.push({ name, prev, kg, diff: Math.round((kg - prev) * 10) / 10 });
        }
      });
    });
  } catch (e) {}
  return alerts;
}

function updateSessionStatsBar() {
  const bar = document.getElementById("sessionStatsBar");
  if (!bar || !program) return;
  const { volume, sets } = calcProgramVolume(program);
  const alerts = getLoadAlerts(program);
  const rpe = program.sessionRpe != null && program.sessionRpe !== "" ? program.sessionRpe : "—";
  let html = `<span><strong>Volume</strong> ${volume} kg</span>`;
  html += `<span><strong>Séries</strong> ${sets}</span>`;
  html += `<span><strong>RPE séance</strong> ${escapeHtml(String(rpe))}</span>`;
  if (USE_DISK) html += `<span class="storage-badge"><i class="fas fa-hdd"></i> SSD</span>`;
  else
    html += `<span class="storage-badge browser"><i class="fas fa-browser"></i> Navigateur</span>`;
  if (alerts.length) {
    const a = alerts[0];
    html += `<span class="warn"><i class="fas fa-exclamation-triangle"></i> Charge ↓ ${escapeHtml(a.name)} : ${a.prev} → ${a.kg} kg</span>`;
    if (alerts.length > 1) html += `<span class="warn">(+${alerts.length - 1})</span>`;
  } else {
    html += `<span class="ok"><i class="fas fa-check"></i> Charges OK</span>`;
  }
  bar.innerHTML = html;
  bar.style.display = "flex";
}

function onSessionRpeChange() {
  const el = document.getElementById("sessionRpeInput");
  if (!el) return;
  program.sessionRpe = el.value;
  markDirty();
  save();
  updateSessionStatsBar();
}

function openSettingsModal() {
  try {
    closeHomeMenus();
  } catch (e) {}
  const m = document.getElementById("settingsModal");
  if (m) m.classList.add("show");
}

function exportAthleteProfiles() {
  loadAthleteProfiles();
  if (!athleteProfiles.length) {
    showToast("Aucun profil à exporter");
    return;
  }
  const payload = {
    yhcoachproProfiles: true,
    version: 1,
    exportedAt: new Date().toISOString(),
    profiles: athleteProfiles,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  window.yhSaveFile("StriderPro_profils_athletes.json", blob);
  showToast(athleteProfiles.length + " profil(s) exporté(s)");
}

function openProfileImportFromMenu() {
  if (typeof flushProfileAutosave === "function") flushProfileAutosave();
  const input = document.getElementById("importProfilesInput");
  if (!input) { showToast("Import des profils indisponible — réouvre l’application"); return false; }
  closeHomeMenus(); input.click(); return true;
}

function importAthleteProfiles(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      let list = [];
      if (Array.isArray(data)) list = data;
      else if (data && Array.isArray(data.profiles)) list = data.profiles;
      else if (data && (data.nom || data.prenom || data.id)) list = [data];
      else throw new Error("format");

      loadAthleteProfiles();
      let ok = 0;
      for (const p of list) {
        if (!p || typeof p !== "object") continue;
        if (!p.id) p.id = uid();
        p.updatedAt = Date.now();
        const idx = athleteProfiles.findIndex((x) => x.id === p.id);
        if (idx >= 0) athleteProfiles[idx] = { ...athleteProfiles[idx], ...p };
        else {
          // merge by name if same
          const same = athleteProfiles.findIndex(
            (x) =>
              (x.nom || "").toLowerCase() === (p.nom || "").toLowerCase() &&
              (x.prenom || "").toLowerCase() === (p.prenom || "").toLowerCase() &&
              (p.nom || p.prenom),
          );
          if (same >= 0)
            athleteProfiles[same] = {
              ...athleteProfiles[same],
              ...p,
              id: athleteProfiles[same].id,
            };
          else athleteProfiles.push(p);
        }
        ok++;
      }
      saveAthleteProfilesStore();
      if (typeof refreshProfileSelect === "function") refreshProfileSelect();
      showToast(ok ? ok + " profil(s) importé(s)" : "Aucun profil valide");
      if (ok && document.getElementById("profileScreen")?.classList.contains("active")) {
        if (athleteProfiles.length)
          selectAthleteProfile(athleteProfiles[athleteProfiles.length - 1].id);
      }
      if (ok) window.dispatchEvent(new Event("yh-profile-import-complete"));
    } catch (e) {
      console.error(e);
      showToast("Fichier profils invalide");
    }
    input.value = "";
  };
  reader.readAsText(file);
}

// attendance.js chargé séparément.
