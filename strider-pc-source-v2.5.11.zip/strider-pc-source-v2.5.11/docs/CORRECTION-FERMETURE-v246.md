# Version 2.4.6 — Fiche épurée et fermeture

Suppression du récapitulatif du bas (durée, joueurs, nombre de schémas), du texte décoratif sous les parties et du pied de panneau sous le terrain. Les champs en haut, les durées des parties, le calcul de durée totale et les objectifs restent disponibles.

La 2.4.5 annulait la fermeture via un avertissement beforeunload lorsque la fiche était modifiée. La 2.4.6 n’annule plus la fermeture : elle tente d’enregistrer immédiatement la fiche modifiée dans la même bibliothèque. Les confirmations internes lors d’une nouvelle fiche ou d’un changement de fiche restent disponibles.

La bibliothèque utilise le stockage unifié de l’application (écriture disque Electron synchrone et copie locale), avec relecture des fiches locales existantes lorsque la bibliothèque disque n’existe pas. Elle est ainsi disponible pour les sauvegardes disque de l’application. Ne pas utiliser de fermeture forcée pour garantir cet enregistrement. Une erreur de stockage peut empêcher la sauvegarde, même si la fermeture n’est plus bloquée.

Tests navigateur : édition, sauvegarde, réouverture, copie indépendante, schémas, fermeture non annulée et enregistrement au déchargement. Le test de la croix native sous Windows reste à confirmer sur votre ordinateur. Archive du projet source, pas un installateur Windows compilé. Faire une sauvegarde complète et conserver la version précédente avant mise à jour.
