"use strict";
(function () {
  const KEY = "yhcoachpro_load_history";
  const esc = (s) =>
    typeof escapeHtml === "function"
      ? escapeHtml(String(s ?? ""))
      : String(s ?? "").replace(
          /[&<>"']/g,
          (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
        );
  function kgNumber(value) {
    if (value === null || value === undefined || value === "") return null;
    const x = parseFloat(
      String(value)
        .replace(",", ".")
        .replace(/[^0-9.+-]/g, ""),
    );
    return Number.isFinite(x) && x >= 0 ? Math.round(x * 100) / 100 : null;
  }
  function cleanStore(raw) {
    const out = {};
    Object.keys(raw || {}).forEach((a) => {
      const an = String(a || "").trim();
      if (!an) return;
      Object.keys(raw[a] || {}).forEach((ex) => {
        const en = String(ex || "").trim();
        if (!en) return;
        const arr = (Array.isArray(raw[a][ex]) ? raw[a][ex] : [])
          .map((e) => ({ ...e, kg: kgNumber(e?.kg) }))
          .filter((e) => e.kg !== null)
          .sort(
            (x, y) =>
              String(x.date || "").localeCompare(String(y.date || "")) ||
              Number(x.session || 0) - Number(y.session || 0),
          );
        if (arr.length) {
          out[an] = out[an] || {};
          out[an][en] = arr.slice(-30);
        }
      });
    });
    return out;
  }
  loadHistoryStore = function () {
    try {
      return cleanStore(JSON.parse(localStorage.getItem(KEY) || "{}"));
    } catch (e) {
      return {};
    }
  };
  saveHistoryStore = function (store) {
    try {
      localStorage.setItem(KEY, JSON.stringify(cleanStore(store)));
      return true;
    } catch (e) {
      console.error("Historique charges", e);
      return false;
    }
  };
  function addEntry(store, athlete, name, value, prog, day, kind) {
    const kg = kgNumber(value),
      a = String(athlete || "").trim(),
      ex = String(name || "").trim();
    if (!a || !ex || kg === null) return;
    store[a] = store[a] || {};
    store[a][ex] = store[a][ex] || [];
    const entry = {
      date: prog.date || new Date().toISOString().slice(0, 10),
      kg,
      session: Number(prog.sessionNum) || 1,
      week: Number(day?.week) || Number(prog.currentWeek) || 1,
      day: String(day?.name || ""),
      kind: kind || "planned",
      programId: prog.id || "",
    };
    const signature = `${entry.programId}|${entry.date}|${entry.session}|${entry.week}|${entry.day}`;
    const arr = store[a][ex],
      idx = arr.findIndex(
        (e) =>
          `${e.programId || ""}|${e.date || ""}|${Number(e.session) || 1}|${Number(e.week) || 1}|${e.day || ""}` ===
          signature,
      );
    if (idx >= 0) arr[idx] = entry;
    else arr.push(entry);
    store[a][ex] = arr
      .sort(
        (x, y) =>
          String(x.date || "").localeCompare(String(y.date || "")) ||
          Number(x.session || 0) - Number(y.session || 0),
      )
      .slice(-30);
  }
  function mergeProgram(store, prog) {
    if (!prog || !prog.athlete) return;
    (prog.days || []).forEach((day) =>
      (day.exercises || []).forEach((ex) => {
        const actual = kgNumber(ex.actualChargeKg),
          planned = kgNumber(ex.chargeKg);
        addEntry(
          store,
          prog.athlete,
          ex.name,
          actual !== null ? actual : planned,
          prog,
          day,
          actual !== null ? "actual" : "planned",
        );
        addEntry(store, prog.athlete, ex.compName, ex.compChargeKg, prog, day, "planned");
      }),
    );
  }
  recordLoadHistory = function (prog) {
    const store = loadHistoryStore();
    mergeProgram(store, prog);
    saveHistoryStore(store);
  };
  const CLEARED_KEY = "yhcoachpro_load_history_cleared";
  const identity = (n) => String(n || "").trim().toLocaleLowerCase("fr-FR");
  function clearedNames() {
    const list = JSON.parse(localStorage.getItem(CLEARED_KEY) || "[]");
    if (!Array.isArray(list)) throw new Error("État de suppression invalide");
    return new Set(list.map(identity));
  }
  function canSync(name) {
    try { return !clearedNames().has(identity(name)); }
    catch (e) { console.warn("Historique non reconstruit", e); return false; }
  }
  const originalFill = fillHistoryAthleteSelect;
  fillHistoryAthleteSelect = function (selected) {
    originalFill(selected);
    const select = document.getElementById("historyAthleteSelect"), store = loadHistoryStore();
    if (!select) return;
    const names = new Set(Object.keys(store).map(identity));
    [...select.options].forEach((o) => {
      if (o.value && !canSync(o.value) && !names.has(identity(o.value))) o.remove();
    });
  };
  let deletionTarget = "";
  function resetDeletion() {
    deletionTarget = "";
    const box = document.getElementById("historyDeleteConfirmation");
    if (box) box.hidden = true;
    const btn = document.getElementById("historyDeleteButton");
    if (btn) btn.disabled = !document.getElementById("historyAthleteSelect")?.value;
  }
  function installDeletion() {
    const select = document.getElementById("historyAthleteSelect");
    if (!select || document.getElementById("historyDeleteButton")) return;
    const wrap = document.createElement("div");
    wrap.style.cssText = "margin:10px 0 16px";
    wrap.innerHTML = `<button type="button" class="secondary" id="historyDeleteButton">Supprimer le suivi de cet athlète</button><div id="historyDeleteConfirmation" hidden role="group" aria-label="Confirmer la suppression du suivi" style="margin-top:10px;padding:14px;border:1px solid rgba(191,150,105,.4);border-radius:12px;background:rgba(6,7,9,.7)"><p id="historyDeleteMessage" style="margin:0 0 12px"></p><div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="secondary" id="historyDeleteCancel">Annuler</button><button type="button" id="historyDeleteConfirm">Supprimer définitivement le suivi</button></div></div>`;
    select.closest(".form-group").after(wrap);
    const button = document.getElementById("historyDeleteButton");
    button.addEventListener("click", () => {
      deletionTarget = select.value; if (!deletionTarget) return;
      document.getElementById("historyDeleteMessage").textContent = `Supprimer définitivement tout l’historique des charges de « ${deletionTarget} » ? Les profils, programmes et suivis des autres athlètes seront conservés. Un nouvel enregistrement de charges pourra créer un nouveau suivi.`;
      document.getElementById("historyDeleteConfirmation").hidden = false;
      document.getElementById("historyDeleteCancel").focus();
    });
    document.getElementById("historyDeleteCancel").addEventListener("click", () => { resetDeletion(); button.focus(); });
    select.addEventListener("change", resetDeletion);
    document.getElementById("historyDeleteConfirm").addEventListener("click", () => {
      if (!deletionTarget || deletionTarget !== select.value) { resetDeletion(); return; }
      const target = identity(deletionTarget), store = loadHistoryStore();
      let previousFlag;
      try {
        previousFlag = localStorage.getItem(CLEARED_KEY);
        const cleared = clearedNames(); cleared.add(target);
        localStorage.setItem(CLEARED_KEY, JSON.stringify([...cleared]));
        Object.keys(store).forEach((name) => { if (identity(name) === target) delete store[name]; });
        if (!saveHistoryStore(store)) throw new Error("Enregistrement impossible");
      } catch (e) {
        try {
          if (previousFlag === null) localStorage.removeItem(CLEARED_KEY);
          else if (previousFlag !== undefined) localStorage.setItem(CLEARED_KEY, previousFlag);
        } catch (_) {}
        showToast("Suppression impossible — historique conservé. Réessayez."); return;
      }
      resetDeletion(); fillHistoryAthleteSelect(""); select.value = ""; renderHistoryList();
      button.disabled = true; showToast("Suivi des charges supprimé pour cet athlète"); select.focus();
    });
  }
  function syncHistoryFromPrograms(athlete) {
    const store = loadHistoryStore(),
      seen = new Set();
    try {
      loadProgramsIndex();
      (programsIndex || []).forEach((ref) => {
        if (athlete && String(ref.athlete || "").toLowerCase() !== String(athlete).toLowerCase())
          return;
        if (!canSync(ref.athlete)) return;
        const p = loadProgramFromStorage(ref.id);
        if (p && canSync(p.athlete)) {
          seen.add(p.id);
          mergeProgram(store, p);
        }
      });
    } catch (e) {
      console.warn("Synchronisation charges", e);
    }
    if (
      typeof program !== "undefined" &&
      program &&
      canSync(program.athlete) &&
      (!athlete || String(program.athlete || "").toLowerCase() === String(athlete).toLowerCase()) &&
      !seen.has(program.id)
    )
      mergeProgram(store, program);
    saveHistoryStore(store);
    return cleanStore(store);
  }
  function formatKg(v) {
    const x = kgNumber(v);
    return x === null
      ? "—"
      : new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 2 }).format(x) + " kg";
  }
  let chartSequence = 0;
  // Arrondis monotones : la courbe passe par les vraies valeurs sans dépassement artificiel.
  function smoothChargePath(points) {
    const n=points.length;if(n<2)return '';
    const d=points.slice(1).map((p,i)=>(p[1]-points[i][1])/(p[0]-points[i][0]));
    const m=points.map((p,i)=>i===0?d[0]:i===n-1?d[n-2]:(d[i-1]*d[i]<=0?0:2/(1/d[i-1]+1/d[i])));
    for(let i=0;i<n-1;i++){if(!d[i]){m[i]=0;m[i+1]=0;continue}const a=m[i]/d[i],b=m[i+1]/d[i],norm=a*a+b*b;if(norm>9){const t=3/Math.sqrt(norm);m[i]=t*a*d[i];m[i+1]=t*b*d[i]}}
    let path=`M ${points[0][0]} ${points[0][1]}`;
    for(let i=0;i<n-1;i++){const[x,y]=points[i],[xx,yy]=points[i+1],h=(xx-x)/3;path+=` C ${x+h} ${y+m[i]*h} ${xx-h} ${yy-m[i+1]*h} ${xx} ${yy}`}
    return path;
  }
  // Courbe fluide validée : sans points visibles, valeur finale sans encadré.
  buildKgChartSvg = function (entries, large) {
    const data = (entries || []).map(e=>({...e,kg:kgNumber(e?.kg)})).filter(e=>e.kg!==null).slice(-16);
    if (!data.length) return '<div class="charge-no-data">Aucune valeur numérique enregistrée.</div>';
    const W=large?840:340,H=large?310:110,L=large?52:12,R=large?22:12,T=large?32:16,B=large?44:14;
    const values=data.map(e=>e.kg),min=Math.min(...values),max=Math.max(...values);
    const spread=Math.max(max-min,max*.12,1),pad=Math.max(spread*.2,.5);
    const low=Math.max(0,min-pad),high=max+pad,raw=(high-low)/4,power=10**Math.floor(Math.log10(raw));
    const step=[1,2,2.5,5,10].map(n=>n*power).find(n=>n>=raw)||power*10;
    const floor=Math.max(0,Math.floor(low/step)*step),ceiling=Math.max(floor+step,Math.ceil(high/step)*step);
    const y=v=>H-B-(v-floor)/(ceiling-floor)*(H-T-B);
    const x=i=>data.length===1?(L+W-R)/2:L+i*(W-L-R)/(data.length-1);
    const f=n=>new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}).format(n);
    const date=e=>/^\d{4}-\d{2}-\d{2}/.test(e.date||'')?e.date.slice(8,10)+'/'+e.date.slice(5,7):'S'+(e.session||'');
    const gid='spChargeCurve'+(++chartSequence),curvePath=smoothChargePath(data.map((e,i)=>[x(i),y(e.kg)]));
    let svg=`<defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#d7b879" stop-opacity=".13"/><stop offset="100%" stop-color="#d7b879" stop-opacity="0"/></linearGradient></defs>`;
    if(large){
      const ticks=Math.round((ceiling-floor)/step);
      for(let i=0;i<=ticks;i++){const v=floor+i*step;svg+=`<line x1="${L}" y1="${y(v)}" x2="${W-R}" y2="${y(v)}" stroke="#ffffff10" stroke-dasharray="3 6"/><text x="${L-10}" y="${y(v)+4}" text-anchor="end" fill="#bcb5a5" font-size="10">${f(v)}</text>`;}
      svg+=`<text x="${L-25}" y="14" fill="#bcb5a5" font-size="11">kg</text>`;
    }
    if(data.length>1){
      svg+=`<path class="charge-curve-area" d="${curvePath} L ${x(data.length-1)} ${H-B} L ${x(0)} ${H-B} Z" fill="url(#${gid})"/>`;
      svg+=`<path class="charge-curve-line" d="${curvePath}" fill="none" stroke="#d0b47e" stroke-width="${large?2.4:1.8}" stroke-linecap="round" stroke-linejoin="round"/>`;
    }
    data.forEach((e,i)=>{
      const source=e.kind==='actual'?'Réalisée':e.kind==='planned'?'Prévue':'Enregistrée';
      const label=(e.date||'')+' · '+f(e.kg)+' kg · '+source+' · séance '+(e.session||1)+(e.day?' · '+e.day:'');
      svg+=`<g class="charge-point-item" data-kg="${e.kg}" data-kind="${esc(e.kind||'recorded')}"><circle class="charge-tooltip-target" cx="${x(i)}" cy="${y(e.kg)}" r="11" fill="transparent" stroke="none"${large?' tabindex="0" role="img" aria-label="'+esc(label)+'"':''}><title>${esc(label)}</title></circle>`;
      if(large)svg+=`<text x="${x(i)}" y="${H-18}" text-anchor="middle" fill="#bcb5a5" font-size="${data.length>12?8:10}">${esc(date(e))}</text>`;
      svg+='</g>';
    });
    if(large){
      const last=data[data.length-1],lastY=y(last.kg);
      svg+=`<text class="charge-last-value" x="${x(data.length-1)}" y="${Math.max(17,lastY-15)}" text-anchor="end" fill="#dfc694" font-size="12" font-weight="500">${esc(f(last.kg)+' kg')}</text>`;
    }
    const note='Valeurs enregistrées · charge réalisée si renseignée, sinon charge prévue. Le détail au survol de chaque séance précise la source. Échelle verticale adaptée.'+((entries||[]).length>16?' Les 16 dernières valeurs sont affichées.':'');
    return `<div class="history-chart ${large?'large':'mini'}"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Courbe dorée des charges par séance, en kilogrammes, échelle verticale adaptée">${svg}</svg>${large?'<p class="charge-source-note">'+note+'</p>':''}${data.length===1?'<p class="charge-one-point">Une valeur enregistrée — les prochaines séances formeront la courbe.</p>':''}</div>`;
  };
  function keyFor(a, e) {
    return encodeURIComponent(a + "||" + e).replace(/'/g, "%27");
  }
  renderHistoryList = function () {
    installDeletion();
    resetDeletion();
    const sel = document.getElementById("historyAthleteSelect"),
      athlete = (sel?.value || "").trim(),
      hidden = document.getElementById("historyAthleteFilter"),
      list = document.getElementById("historyList"),
      panel = document.getElementById("historyGraphPanel");
    if (hidden) hidden.value = athlete;
    if (!list) return;
    if (!athlete) {
      list.innerHTML =
        '<div class="empty-state"><p>Choisissez un athlète pour afficher ses valeurs et ses graphiques.</p></div>';
      panel?.classList.remove("show");
      return;
    }
    const store = syncHistoryFromPrograms(athlete),
      key = Object.keys(store).find((a) => a.toLowerCase() === athlete.toLowerCase()) || athlete,
      rows = Object.keys(store[key] || {})
        .map((name) => ({ athlete: key, name, entries: store[key][name] }))
        .filter((r) => r.entries.length)
        .sort((a, b) => a.name.localeCompare(b.name, "fr", { sensitivity: "base" }));
    if (!rows.length) {
      list.innerHTML = `<div class="empty-state"><p>Aucune charge en kg pour <strong>${esc(athlete)}</strong>.<br>Renseignez « Charge en kg » ou « Charge réalisée » dans un exercice, puis enregistrez le programme.</p></div>`;
      panel?.classList.remove("show");
      return;
    }
    list.innerHTML = rows
      .map((r) => {
        const first = r.entries[0],
          last = r.entries[r.entries.length - 1],
          max = Math.max(...r.entries.map((e) => e.kg)),
          diff = Math.round((last.kg - first.kg) * 100) / 100;
        return `<button type="button" class="history-ex-btn charge-history-card" onclick="showHistoryGraph('${keyFor(r.athlete, r.name)}')"><div class="charge-card-head"><span><strong>${esc(r.name)}</strong><small>${r.entries.length} valeur(s) · dernière le ${esc(last.date || "—")}</small></span><b>${formatKg(last.kg)}</b></div><div class="charge-card-stats"><span>Départ <b>${formatKg(first.kg)}</b></span><span>Maximum <b>${formatKg(max)}</b></span><span class="${diff > 0 ? "up" : diff < 0 ? "down" : ""}">Évolution <b>${diff > 0 ? "+" : diff < 0 ? "−" : ""}${formatKg(Math.abs(diff))}</b></span></div>${buildKgChartSvg(r.entries, false)}</button>`;
      })
      .join("");
    showHistoryGraph(keyFor(rows[0].athlete, rows[0].name));
  };
  showHistoryGraph = function (encoded) {
    const raw = decodeURIComponent(encoded),
      sep = raw.indexOf("||"),
      athlete = raw.slice(0, sep),
      name = raw.slice(sep + 2),
      store = loadHistoryStore(),
      entries = store[athlete]?.[name] || [],
      panel = document.getElementById("historyGraphPanel"),
      title = document.getElementById("historyGraphTitle"),
      sub = document.getElementById("historyGraphSub"),
      svg = document.getElementById("historyGraphSvg");
    if (!panel) return;
    const first = entries[0],
      last = entries[entries.length - 1],
      diff = entries.length ? Math.round((last.kg - first.kg) * 100) / 100 : 0;
    if (title) title.textContent = name;
    if (sub)
      sub.innerHTML = `<span>${esc(athlete)}</span><b>${formatKg(last?.kg)}</b><span>${entries.length} valeur(s)</span><strong class="${diff > 0 ? "up" : diff < 0 ? "down" : ""}">${diff > 0 ? "+" : diff < 0 ? "−" : ""}${formatKg(Math.abs(diff))}</strong>`;
    if (svg) svg.innerHTML = buildKgChartSvg(entries, true);
    panel.classList.add("show");
    document
      .querySelectorAll(".charge-history-card")
      .forEach((x) => x.classList.toggle("selected", x.getAttribute("onclick")?.includes(encoded)));
  };
  const oldOpen = openHistoryModal;
  openHistoryModal = function (athleteName) {
    syncHistoryFromPrograms(athleteName || "");
    fillHistoryAthleteSelect(athleteName || "");
    const sel = document.getElementById("historyAthleteSelect");
    if (sel && athleteName) {
      const opt = [...sel.options].find(
        (o) => o.value.toLowerCase() === String(athleteName).toLowerCase(),
      );
      if (opt) sel.value = opt.value;
    }
    if (sel && !sel.value && sel.options.length > 1) sel.selectedIndex = 1;
    renderHistoryList();
    openModal("historyModal");
  };
})();
