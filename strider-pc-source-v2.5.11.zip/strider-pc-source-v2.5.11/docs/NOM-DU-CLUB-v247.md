# Version 2.4.7 — Nom du club

Ajout du champ Nom du club en haut de la fiche de séance, entre son nom et le groupe / équipe. Texte libre modifiable, enregistré dans la fiche, conservé lors de la duplication et de l’enregistrement à la fermeture. Les anciennes fiches sans club restent compatibles : le champ est vide jusqu’à sa saisie.

Les corrections de la 2.4.6 sont conservées : pied épuré et fermeture non bloquée. Aucun changement des autres modules.

Sauvegarder avant mise à jour, conserver l’ancienne version et tester sur votre ordinateur Windows. Archive du projet source avec les scripts de lancement/construction ; pas un installateur compilé.
