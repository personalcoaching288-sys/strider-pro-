"use strict";

/**
 * Suivi RPE dédié — corrections :
 * - Tri strict par NOM de famille (champ nom, sinon dernier mot)
 * - Uniquement présents / retards (jamais absents ni non renseignés)
 * - Historique replié
 * - Graphique 6 dernières séances
 * - Changement de groupe robuste
 */

function asRpeLevel(avg) {
  if (avg == null || !Number.isFinite(avg)) return { label: "—", color: "#64748b" };
  if (avg <= 6) return { label: "Légère", color: "#4ade80" };
  if (avg < 8.5) return { label: "Modérée", color: "#fbbf24" };
  return { label: "Élevée", color: "#f87171" };
}

function asGetAttendanceStatus(session, playerId) {
  const att = (session && session.attendance) || {};
  if (!playerId && playerId !== 0) return null;
  const keys = [playerId, String(playerId)];
  for (let i = 0; i < keys.length; i++) {
    if (Object.prototype.hasOwnProperty.call(att, keys[i])) return att[keys[i]];
  }
  const want = String(playerId);
  for (const k of Object.keys(att)) {
    if (String(k) === want) return att[k];
  }
  return null;
}

/** Présent = true ou "late" uniquement */
function asIsPresentStatus(v) {
  return v === true || v === "late" || v === "present";
}

function asIsAbsentStatus(v) {
  return v === false || v === "absent" || v === "Absent" || v === 0 || v === "0";
}

/** Clé de tri = NOM de famille */
function asPlayerNomKey(p) {
  const nomField = String(p && p.nom != null ? p.nom : "").trim();
  if (nomField) return nomField.toLocaleLowerCase("fr");
  const raw = String((p && p.name) || "").trim();
  if (!raw) return "";
  const parts = raw.split(/\s+/).filter(Boolean);
  // Format fréquent saisi à la main : "Prénom Nom" → nom = dernier mot
  // Format profils app : name déjà "Nom Prénom" mais champ nom manquant → on préfère le dernier mot
  // sauf si un seul mot
  if (parts.length === 1) return parts[0].toLocaleLowerCase("fr");
  return parts[parts.length - 1].toLocaleLowerCase("fr");
}

function asPlayerPrenomKey(p) {
  const prenomField = String(p && p.prenom != null ? p.prenom : "").trim();
  if (prenomField) return prenomField.toLocaleLowerCase("fr");
  const raw = String((p && p.name) || "").trim();
  const parts = raw.split(/\s+/).filter(Boolean);
  if (parts.length <= 1) return "";
  return parts[0].toLocaleLowerCase("fr");
}

function asSortPlayersByNom(players) {
  return (players || []).slice().sort(function (a, b) {
    const na = asPlayerNomKey(a);
    const nb = asPlayerNomKey(b);
    const c = na.localeCompare(nb, "fr", { sensitivity: "base" });
    if (c !== 0) return c;
    const pa = asPlayerPrenomKey(a);
    const pb = asPlayerPrenomKey(b);
    return pa.localeCompare(pb, "fr", { sensitivity: "base" });
  });
}

/** Effectif enrichi (nom/prenom) comme Assiduité */
function asRpeRoster(group) {
  if (typeof asPlayersForDisplay === "function") {
    try {
      return asPlayersForDisplay(group) || [];
    } catch (_) {}
  }
  return (group && group.players) || [];
}

function asSessionPresentPlayers(session, group) {
  if (!session || !group) return [];
  const roster = asRpeRoster(group);
  const present = roster.filter(function (p) {
    const v = asGetAttendanceStatus(session, p.id);
    // Exclusion explicite des absents
    if (asIsAbsentStatus(v)) return false;
    // Uniquement présents / retards
    return asIsPresentStatus(v);
  });
  return asSortPlayersByNom(present);
}

function rpeFillGroups() {
  const sel = document.getElementById("rpeGroupSelect");
  if (!sel) return;
  if (typeof asLoad === "function") {
    try {
      asLoad();
    } catch (_) {}
  }
  if (typeof asStore === "undefined" || !asStore) return;
  const groups = asStore.groups || [];
  const current = String(asStore.currentGroupId || "");
  if (!groups.length) {
    sel.innerHTML = '<option value="">Aucun groupe</option>';
    return;
  }
  sel.innerHTML = groups
    .map(function (g) {
      const title = typeof asEsc === "function" ? asEsc(g.title) : g.title;
      return '<option value="' + g.id + '">' + title + "</option>";
    })
    .join("");
  if (current && [...sel.options].some(function (o) {
    return String(o.value) === current;
  })) {
    sel.value = current;
  } else {
    sel.value = groups[0].id;
    asStore.currentGroupId = groups[0].id;
  }
}

window.rpeSwitchGroup = function (id) {
  if (typeof asLoad === "function") {
    try {
      asLoad();
    } catch (_) {}
  }
  if (typeof asStore === "undefined" || !asStore || !id) return;
  const exists = (asStore.groups || []).some(function (g) {
    return String(g.id) === String(id);
  });
  if (!exists) {
    if (typeof showToast === "function") showToast("Groupe introuvable");
    return;
  }
  asStore.currentGroupId = id;
  const asSel = document.getElementById("asGroupSelect");
  if (asSel) {
    try {
      asSel.value = id;
    } catch (_) {}
  }
  if (typeof asSave === "function") asSave();
  const sess = document.getElementById("rpeSessionSelect");
  if (sess) {
    sess.innerHTML = "";
    sess.value = "";
  }
  asRenderRpe();
};

function asFillRpeSessions() {
  const g = typeof asGroup === "function" ? asGroup() : null;
  const sel = document.getElementById("rpeSessionSelect");
  if (!sel || !g) return;
  const sessions = (g.sessions || [])
    .slice()
    .sort(function (a, b) {
      return String(b.date || "").localeCompare(String(a.date || ""));
    });
  const old = sel.value;
  if (!sessions.length) {
    sel.innerHTML = '<option value="">Aucune séance — crée-en dans Assiduité</option>';
    return;
  }
  sel.innerHTML = sessions
    .map(function (s) {
      const label = (s.date || "—") + (s.time ? " · " + s.time : "");
      return '<option value="' + s.id + '">' + label + "</option>";
    })
    .join("");
  if (old && [...sel.options].some(function (o) {
    return String(o.value) === String(old);
  })) {
    sel.value = old;
  }
}

window.asSetPlayerRpe = function (sessionId, playerId, value) {
  if (typeof asLoad === "function") {
    try {
      asLoad();
    } catch (_) {}
  }
  const g = asGroup();
  if (!g) return;
  const session = (g.sessions || []).find(function (x) {
    return String(x.id) === String(sessionId);
  });
  if (!session) return;
  const status = asGetAttendanceStatus(session, playerId);
  if (!asIsPresentStatus(status) || asIsAbsentStatus(status)) {
    if (typeof showToast === "function") showToast("Ce joueur n’est pas présent — RPE non enregistré");
    asRenderRpe();
    return;
  }
  session.rpe = session.rpe || {};
  const n = value === "" || value == null ? null : Number(value);
  // Normaliser la clé sur l'id réel du joueur dans le groupe
  const real = ((g.players || []).find(function (p) {
    return String(p.id) === String(playerId);
  }) || {}).id;
  const key = real != null ? real : playerId;
  if (n == null || !Number.isFinite(n)) {
    delete session.rpe[key];
    delete session.rpe[String(playerId)];
  } else {
    session.rpe[key] = Math.min(10, Math.max(1, n));
  }
  asSave();
  asRenderRpe();
};

function asRpeSessionAvg(session, group) {
  const present = asSessionPresentPlayers(session, group);
  const presentIds = new Set(
    present.map(function (p) {
      return String(p.id);
    }),
  );
  const rpeMap = (session && session.rpe) || {};
  const vals = [];
  Object.keys(rpeMap).forEach(function (pid) {
    if (!presentIds.has(String(pid))) return;
    const v = Number(rpeMap[pid]);
    if (Number.isFinite(v) && v >= 1 && v <= 10) vals.push(v);
  });
  if (!vals.length) return { avg: null, count: 0, present: present.length };
  const sum = vals.reduce(function (a, b) {
    return a + b;
  }, 0);
  return {
    avg: Math.round((sum / vals.length) * 10) / 10,
    count: vals.length,
    present: present.length,
  };
}

window.toggleRpeHistory = function () {
  const box = document.getElementById("asRpeHistory");
  const btn = document.getElementById("asRpeHistoryToggle");
  if (!box) return;
  const open = box.hasAttribute("hidden");
  if (open) {
    box.removeAttribute("hidden");
    if (btn) btn.textContent = "Masquer l’historique des séances";
  } else {
    box.setAttribute("hidden", "");
    if (btn) btn.textContent = "Afficher l’historique des séances";
  }
};

window.asRenderRpe = function () {
  if (typeof asLoad === "function") {
    try {
      asLoad();
    } catch (_) {}
  }
  rpeFillGroups();
  asFillRpeSessions();
  const g = typeof asGroup === "function" ? asGroup() : null;
  const sel = document.getElementById("rpeSessionSelect");
  const list = document.getElementById("asRpePlayerList");
  const avgEl = document.getElementById("asRpeAvg");
  const countEl = document.getElementById("asRpeCount");
  const levelEl = document.getElementById("asRpeLevel");
  const hist = document.getElementById("asRpeHistory");
  const bars = document.getElementById("asRpeBars");
  if (!g || !list) return;

  const sid = sel && sel.value;
  const session = (g.sessions || []).find(function (x) {
    return String(x.id) === String(sid);
  });

  if (!session) {
    list.innerHTML =
      '<div class="as-sub">Aucune séance. Va dans <b>Assiduité</b> pour créer une séance et faire l’appel, puis reviens ici.</div>';
    if (avgEl) avgEl.textContent = "—";
    if (countEl) countEl.textContent = "—";
    if (levelEl) {
      levelEl.textContent = "—";
      levelEl.style.color = "#64748b";
    }
  } else {
    const present = asSessionPresentPlayers(session, g);
    const rpeMap = session.rpe || {};

    // Nettoyage : supprimer les RPE orphelins d'absents (sans bloquer l'affichage)
    if (session.rpe) {
      const presentIds = new Set(
        present.map(function (p) {
          return String(p.id);
        }),
      );
      let cleaned = false;
      Object.keys(session.rpe).forEach(function (pid) {
        if (!presentIds.has(String(pid))) {
          // garder en mémoire mais ne pas afficher — on n'affiche jamais les absents
        }
      });
      if (cleaned) asSave();
    }

    if (!present.length) {
      list.innerHTML =
        '<div class="as-sub">Aucun joueur <b>présent</b> ou en <b>retard</b> sur cette séance. Les <b>absents</b> n’apparaissent pas. Fais l’appel dans Assiduité → Aujourd’hui.</div>';
    } else {
      list.innerHTML =
        '<div style="display:grid;gap:8px">' +
        present
          .map(function (p) {
            let val = "";
            if (rpeMap[p.id] != null) val = rpeMap[p.id];
            else if (rpeMap[String(p.id)] != null) val = rpeMap[String(p.id)];
            // Affichage : NOM en premier (champ nom + prenom)
            let displayName = "";
            if (p.nom || p.prenom) {
              displayName = [p.nom, p.prenom].filter(Boolean).join(" ");
            } else {
              displayName = p.name || "";
            }
            const name = typeof asEsc === "function" ? asEsc(displayName) : displayName;
            return (
              '<div class="rpe-player-row">' +
              '<span style="font-weight:600;color:#f8fafc">' +
              name +
              "</span>" +
              '<label style="display:flex;align-items:center;gap:8px;color:#94a3b8;font-size:0.85rem">RPE ' +
              '<input type="number" min="1" max="10" step="0.5" value="' +
              val +
              '" style="width:72px;padding:6px 8px;border-radius:8px;border:1px solid rgba(255,255,255,0.15);background:#0f1419;color:#f8fafc" ' +
              "onchange=\"asSetPlayerRpe('" +
              session.id +
              "','" +
              p.id +
              "', this.value)\"/>" +
              "</label></div>"
            );
          })
          .join("") +
        "</div>";
    }
    const stats = asRpeSessionAvg(session, g);
    const level = asRpeLevel(stats.avg);
    if (avgEl) avgEl.textContent = stats.avg != null ? String(stats.avg).replace(".", ",") : "—";
    if (countEl) countEl.textContent = stats.count + " / " + stats.present;
    if (levelEl) {
      levelEl.textContent = level.label;
      levelEl.style.color = level.color;
    }
  }

  const sessionsAsc = (g.sessions || [])
    .slice()
    .sort(function (a, b) {
      return String(a.date || "").localeCompare(String(b.date || ""));
    });

  if (hist) {
    if (!sessionsAsc.length) {
      hist.innerHTML = '<div class="as-sub">Pas encore de séances.</div>';
    } else {
      let rows = "";
      sessionsAsc.forEach(function (s, i) {
        const st = asRpeSessionAvg(s, g);
        const level = asRpeLevel(st.avg);
        rows +=
          "<tr><td>S" +
          (i + 1) +
          "</td><td>" +
          (s.date || "—") +
          "</td><td>" +
          st.present +
          "</td><td>" +
          (st.avg != null ? String(st.avg).replace(".", ",") : "—") +
          '</td><td><span style="color:' +
          level.color +
          ';font-weight:700">' +
          level.label +
          "</span></td></tr>";
      });
      hist.innerHTML =
        '<table style="width:100%;border-collapse:collapse;font-size:0.88rem"><thead><tr>' +
        '<th style="text-align:left;padding:8px;color:#94a3b8">Séance</th>' +
        '<th style="text-align:left;padding:8px;color:#94a3b8">Date</th>' +
        '<th style="text-align:left;padding:8px;color:#94a3b8">Présents</th>' +
        '<th style="text-align:left;padding:8px;color:#94a3b8">RPE moyen</th>' +
        '<th style="text-align:left;padding:8px;color:#94a3b8">Niveau</th>' +
        "</tr></thead><tbody>" +
        rows +
        "</tbody></table>";
    }
  }

  if (bars) {
    const last6 = sessionsAsc.slice(-6);
    if (!last6.length) {
      bars.innerHTML = '<div class="as-sub">Pas encore de données (max 6 séances).</div>';
    } else {
      const avgs = last6.map(function (s) {
        return asRpeSessionAvg(s, g).avg;
      });
      const finite = avgs.filter(function (x) {
        return x != null;
      });
      const max = Math.max(10, finite.length ? Math.max.apply(null, finite) : 1);
      bars.innerHTML = last6
        .map(function (s, i) {
          const st = asRpeSessionAvg(s, g);
          const h = st.avg != null ? Math.max(8, (st.avg / max) * 100) : 8;
          const bg =
            st.avg == null
              ? "#334155"
              : st.avg <= 6
                ? "linear-gradient(180deg,#4ade80,#166534)"
                : st.avg < 8.5
                  ? "linear-gradient(180deg,#fbbf24,#b45309)"
                  : "linear-gradient(180deg,#f87171,#991b1b)";
          const label = st.avg != null ? String(st.avg).replace(".", ",") : "—";
          const day = s.date ? s.date.slice(5).replace("-", "/") : "S" + (i + 1);
          return (
            '<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:6px;height:100%">' +
            '<b style="font-size:0.78rem;color:#e8d0af">' +
            label +
            "</b>" +
            '<div style="width:100%;border-radius:8px 8px 4px 4px;height:' +
            h +
            "%;background:" +
            bg +
            '"></div>' +
            '<span style="font-size:0.68rem;color:#94a3b8">' +
            day +
            "</span></div>"
          );
        })
        .join("");
    }
  }
};

window.showRpeSuivi = function () {
  if (typeof asLoad === "function") asLoad();
  document.querySelectorAll(".screen").forEach(function (s) {
    s.classList.remove("active");
  });
  const el = document.getElementById("rpeSuiviScreen");
  if (el) el.classList.add("active");
  const hist = document.getElementById("asRpeHistory");
  const btn = document.getElementById("asRpeHistoryToggle");
  if (hist) hist.setAttribute("hidden", "");
  if (btn) btn.textContent = "Afficher l’historique des séances";
  asRenderRpe();
};

window.showAssiduiteRpe = window.showRpeSuivi;
