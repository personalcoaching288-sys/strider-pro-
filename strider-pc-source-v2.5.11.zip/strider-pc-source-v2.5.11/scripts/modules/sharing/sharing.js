"use strict";

// ========== PARTAGE SÉCURISÉ ==========
// Aucun serveur LAN, lien incorporant des données ou QR code.
// Le partage passe exclusivement par un PDF choisi et enregistré par le coach.
let athleteMode = false;
let athleteModeLocked = false;

function isReadOnly() {
  return !!(athleteModeLocked || athleteMode || (program && program._athleteReadonly));
}

function applyReadOnlyUI() {
  document.body.classList.toggle("athlete-mode", isReadOnly());
}

function guardEdit() {
  if (window.YHLicense && !window.YHLicense.isActive()) {
    openLicensePanel();
    showToast("Licence valide requise");
    return false;
  }
  if (isReadOnly()) {
    applyReadOnlyUI();
    showToast("Lecture seule — modification interdite");
    return false;
  }
  return true;
}

function unlockCoachMode() {
  if (athleteModeLocked || (program && program._athleteReadonly)) return false;
  athleteMode = false;
  document.body.classList.remove("athlete-mode");
  return true;
}

function toggleAthleteMode(force) {
  if (athleteModeLocked || (program && program._athleteReadonly)) {
    athleteMode = true;
    applyReadOnlyUI();
    return;
  }
  athleteMode = typeof force === "boolean" ? force : !athleteMode;
  applyReadOnlyUI();
}

function loadSharedFromHash() {
  return false;
}
function shareProgramAsPdf() {
  if (!program) {
    showToast("Aucun programme ouvert");
    return;
  }
  return exportPDF();
}
// Compatibilité avec d'anciens boutons : redirige désormais vers PDF.
function openShareModal() {
  return shareProgramAsPdf();
}
