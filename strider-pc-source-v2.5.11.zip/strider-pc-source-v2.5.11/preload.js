const { contextBridge, ipcRenderer } = require("electron");

// Traduction des documents imprimés / PDF dans la langue choisie (fournie par l'écran).
let htmlTranslator = null;
function translateHtml(html) {
  if (!htmlTranslator || typeof html !== "string") return html;
  try {
    const out = htmlTranslator(html);
    return typeof out === "string" ? out : html;
  } catch (_) {
    return html;
  }
}
function looksLikeHtml(text) {
  return typeof text === "string" && /^\s*(<!doctype html|<html)/i.test(text);
}


// Mémoire rapide des données déjà lues : chaque page relisait tous les profils
// et programmes sur le disque, ce qui rendait l'ouverture des écrans lente.
// Seule cette fenêtre écrit les données, donc la copie en mémoire reste exacte.
const diskCache = new Map();
function diskRead(key) {
  const k = String(key);
  if (diskCache.has(k)) return diskCache.get(k);
  const v = ipcRenderer.sendSync("yh-disk-read", k);
  if (v === null || typeof v === "string") diskCache.set(k, v);
  return v;
}
function diskWrite(key, value) {
  const k = String(key);
  const ok = ipcRenderer.sendSync("yh-disk-write", k, value);
  if (ok) diskCache.set(k, String(value));
  else diskCache.delete(k);
  return ok;
}
function diskRemove(key) {
  const k = String(key);
  diskCache.delete(k);
  return ipcRenderer.sendSync("yh-disk-remove", k);
}

contextBridge.exposeInMainWorld("yhDisk", {
  enabled: true,
  restoreInputFocus: () => ipcRenderer.invoke("yh-input-focus"),
  onRestoreInputFocus: (callback) => {
    if (typeof callback !== "function") return;
    const listener = () => callback();
    ipcRenderer.on("yh-restore-input-focus", listener);
    return () => ipcRenderer.removeListener("yh-restore-input-focus", listener);
  },
  read: diskRead,
  write: diskWrite,
  remove: diskRemove,
  listPrograms: () => ipcRenderer.sendSync("yh-disk-list-programs"),
  getDataPath: () => ipcRenderer.sendSync("yh-disk-path"),
  saveMedia: (id, base64) => ipcRenderer.sendSync("yh-media-save", id, base64),
  mediaPath: (id) => ipcRenderer.sendSync("yh-media-path", id),
  deleteMedia: (id) => ipcRenderer.sendSync("yh-media-delete", id),
  mediaAsBase64: (id) => ipcRenderer.sendSync("yh-media-as-base64", id),
  setHtmlTranslator: (fn) => {
    htmlTranslator = typeof fn === "function" ? fn : null;
  },
  exportFile: (filename, content) =>
    ipcRenderer.invoke("yh-export-file", filename, looksLikeHtml(content) ? translateHtml(content) : content),
  exportVideos: (files) => ipcRenderer.invoke("yh-export-videos", files),
  exportBinary: (filename, bytes) => ipcRenderer.invoke("yh-export-binary", filename, bytes),
  exportProfileList: (filename, html, landscape, mode, pageRanges) =>
    ipcRenderer.invoke("yh-profile-list-export", filename, translateHtml(html), landscape, mode, pageRanges),
  exportSessionSummary: (filename, html, mode) =>
    ipcRenderer.invoke("yh-session-summary-export", filename, translateHtml(html), mode),
  exportPdf: (filename, options) => ipcRenderer.invoke("yh-export-pdf", filename, options || {}),
  getLicenseDeviceId: () => ipcRenderer.invoke("yh-license-device-id"),
  verifyLicense: (key) => ipcRenderer.invoke("yh-license-verify", key),
  readClipboardText: () => ipcRenderer.invoke("yh-clipboard-read"),
  createAutomaticBackup: () => ipcRenderer.invoke("yh-auto-backup-now"),
  automaticBackupStatus: () => ipcRenderer.invoke("yh-auto-backup-status"),
  restoreAutomaticBackup: (content) => {
    diskCache.clear();
    return ipcRenderer.invoke("yh-auto-backup-restore", content).finally(() => diskCache.clear());
  },
});
