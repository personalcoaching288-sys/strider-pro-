# Structure technique actuelle

Consulter le README.md à la racine pour les dossiers par fonctionnalité.

Les fichiers de départ Electron main.js et preload.js sont conservés. Les scripts de fonctionnalités sont regroupés dans scripts/modules/{core,programs,profiles,attendance,sessions,sharing,features,security}. Les ressources partagées sont dans scripts/shared; les styles sont classés de façon analogue.

L’ordre des scripts classiques et des styles reste explicite dans index.html; ne pas le réordonner sans refaire les tests.

Le détail des déplacements et les validations se trouvent dans docs/maintenance/cleanup-report.json.
