# Sécurité des licences YhCoachPro 2.0

- Les licences utilisent une signature **Ed25519**.
- L’application embarque uniquement la clé publique de vérification.
- La clé privée reste dans le kit propriétaire séparé.
- Chaque licence est liée à un identifiant d’installation aléatoire de 128 bits.
- La signature, le produit, l’installation et l’expiration sont vérifiés à chaque démarrage.
- Toute modification du client, de la date ou du code appareil invalide la signature.

## Limite d’une licence hors ligne

La signature empêche la fabrication et la modification de licences. Une révocation immédiate et une protection absolue contre la modification de l’horloge nécessiteraient néanmoins une validation périodique auprès d’un serveur.
