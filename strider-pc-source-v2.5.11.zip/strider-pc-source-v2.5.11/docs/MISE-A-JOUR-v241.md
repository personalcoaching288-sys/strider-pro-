# YhCoachPro 2.4.1

## Changements
- base modulaire de la 2.3.24 conservée ;
- sauvegardes automatiques réintégrées (10 fichiers, restauration sécurisée) ;
- stockage unifié dans `scripts/modules/store.js` ;
- Font Awesome embarqué dans `assets/vendor` ;
- 69 illustrations sorties du JavaScript Base64 et chargées depuis `exercises/` ;
- chargement différé des images de contenu ;
- réduction du flou sur les cartes imbriquées sans supprimer l'effet translucide ;
- anciens scripts BAT remplacés par deux commandes explicites.

## Sauvegardes
Dossier Windows : `Documents/YhCoachPro/Sauvegardes`. Les 10 dernières sauvegardes automatiques sont conservées. L'export complet historique reste compatible.

## Installation
Lancer `CREER-INSTALLATEUR.bat`, puis récupérer NSIS ou Portable dans `dist`.
