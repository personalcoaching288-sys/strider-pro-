# Structure technique YhCoachPro

Version 2.3.14 — nettoyage sans modification fonctionnelle.

## Entrées Electron
- `main.js` : fenêtre, sécurité, stockage disque, licence.
- `preload.js` : pont sécurisé vers le rendu.
- `index.html` : structure des écrans.

## Modules fonctionnels chargés
- `scripts/app.js` : noyau historique et éditeur de programme.
- `scripts/modules/programs.js` : programmes.
- `scripts/modules/profiles.js` : profils athlètes.
- `scripts/modules/attendance.js` : assiduité.
- `scripts/modules/exports.js` et `sharing.js` : exports/partage.
- `scripts/modules/backup-sharing.js` : sauvegarde/restauration.
- `scripts/modules/planning-v230.js` : cycles et suivi.
- `scripts/modules/modern-programs-v233.js` : accueil programmes.
- `scripts/modules/charges-v235.js` : historique et courbes de charges.
- `scripts/modules/session-sheet.js` : fiches de séance volley.
- `scripts/modules/licenses.js` : licence locale.

## Règles de maintenance
1. Ne plus créer de copie versionnée d’un module actif. Modifier le fichier stable.
2. Exécuter `npm run check` avant chaque archive. Le contrôle découvre automatiquement tous les fichiers JS.
3. Garder les anciens rapports dans `docs/archive/legacy-reports/`.
4. Ne jamais modifier l’identité visuelle sans conserver l’arrière-plan, la transparence et la palette noir/or.
5. Ajouter une migration lorsqu’une clé de stockage change.
