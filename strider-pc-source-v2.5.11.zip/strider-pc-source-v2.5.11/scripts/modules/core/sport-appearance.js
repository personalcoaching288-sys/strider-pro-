/* Préférence visuelle indépendante des disciplines des fiches et tableaux. */
(function(){"use strict";
 const KEY="yhcoachpro_sport_appearance";
 const labels={volley:"Volley",basket:"Basket",handball:"Handball",football:"Football"};
 const files={volley:"accueil-volley.webp",basket:"seance-basket.webp",handball:"ambiance-handball.webp",football:"seance-football.webp"};
 const DEFAULT_SPORT="volley";
 let current=DEFAULT_SPORT;
 try{const saved=String(storeGet(KEY)||"").trim().toLowerCase();if(Object.hasOwn(labels,saved))current=saved;else current=DEFAULT_SPORT}catch(e){current=DEFAULT_SPORT;console.warn("Ambiance sportive",e)}
 const background=()=>new URL("./assets/page-backgrounds/"+files[current],document.baseURI).href;
 function apply(){document.documentElement.style.setProperty("--sp-sport-image",'url("'+background()+'")');document.documentElement.dataset.striderSport=current;document.querySelectorAll("[data-sp-sport-select]").forEach(e=>e.value=current);window.dispatchEvent(new Event("strider-appearance-change"));}
 function set(s){if(!Object.hasOwn(labels,s))return false;try{if(!storeSet(KEY,s))throw Error("Écriture impossible")}catch(e){if(typeof showToast==="function")showToast("Le choix du sport n’a pas pu être enregistré");apply();return false}current=s;apply();return true}
 window.StriderAppearance=Object.freeze({get:()=>current,set,background,labels});
 apply();document.addEventListener("DOMContentLoaded",apply);
 window.addEventListener("storage",e=>{if(e.key===KEY&&Object.hasOwn(labels,e.newValue)){current=e.newValue;apply()}});
})();
