# Version 2.4.20 — Sélecteur Afficher près de Gestion complète

Correction complémentaire à la version 2.4.19 : elle vise le sélecteur Afficher / Tous les groupes, pas les cases d’affectation.

- Le groupe choisi dans ce sélecteur reste sélectionné à l’ajout d’une fiche, pendant les sauvegardes automatiques, à l’ouverture d’une autre fiche et lors des rafraîchissements.
- Le choix est mémorisé après Retour, passage par Gestion complète, réouverture de Profils et redémarrage de l’application.
- Gestion complète ouvre le groupe sélectionné dans Profils, et non le groupe caché du tableau de bord.
- Une fiche ouverte directement depuis une recherche ou un import n’impose plus Tous les groupes. La liste reste limitée au groupe sélectionné ; une fiche extérieure peut être ouverte dans le formulaire sans changer ses affiliations.
- Tous les groupes reste accessible en le choisissant volontairement. Si le groupe sélectionné a réellement été supprimé, le filtre revient à Tous les groupes.
- La petite case orange affiche uniquement le nombre de profils du groupe choisi (ex. 32), sans « Filtre actif », ni comparaison au total. Si Tous les groupes est choisi, elle affiche uniquement le total.
- Aucune case d’affectation existante n’est modifiée par le changement de filtre ou par sa mémorisation.
- Les corrections d’assiduité Nom puis Prénom de la version 2.4.19 sont conservées, ainsi que les exports de profils complets et les listes personnalisées.
- Cette version remplace la règle ancienne d’ouverture systématique sur tous les profils décrite dans le document de la version 2.4.19.

Avant remplacement : sauvegarde complète et conservation de l’ancienne version.
ZIP du projet Electron avec BAT, pas un installateur Windows compilé.
