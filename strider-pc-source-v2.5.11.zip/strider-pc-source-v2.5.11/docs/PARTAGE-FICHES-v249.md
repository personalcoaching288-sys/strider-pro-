# Version 2.4.9 — Partage et résumé A4

Bouton Partage à côté d’Enregistrer : PDF — résumé A4, Imprimer — résumé A4, HTML — lecture seule et JSON — sauvegarde. Le PDF et l’impression reprennent la deuxième maquette validée : une page A4 claire avec logo, club, équipe, date, durée, effectif, lieu, coach, objectif et toutes les parties avec leur schéma. Les consignes, objectifs et matériels proviennent des champs réellement saisis. Aucune partie réduite n’est omise.

Aperçu avant PDF / impression. Export du contenu courant sans changer la partie active ni déplacer ses éléments. HTML autonome sans outils d’édition, imprimable depuis un navigateur. Lecture seule signifie absence d’éditeur intégré, pas protection contre la modification technique d’un fichier HTML. JSON exporte la séance complète et ses schémas ; cet export n’ajoute pas de bouton d’import JSON.

Une séance très longue est réduite pour rester sur une seule A4. Un avertissement apparaît sous 70 % de l’échelle normale ; réduire les textes ou le nombre de parties peut être nécessaire pour une bonne lisibilité. Aucun texte n’est volontairement tronqué.

Electron : dialogue d’enregistrement PDF et dialogue d’impression système, dans une fenêtre dédiée à la fiche (pas une capture du tableau de bord). Les autres exports PDF de l’application sont inchangés. Dans un navigateur : le bouton ouvre l’impression, où choisir Enregistrer au format PDF.

Avant mise à jour, sauvegarder les données et conserver l’ancienne version. Tests navigateur / simulation des appels Electron ; imprimante et installation Windows à confirmer sur votre ordinateur. Archive du projet source, pas un installateur compilé.
