# Strider Pro — projet organisé

Base fonctionnelle : version 2.4.29. Nettoyage en préparation, sans modification de l’identité visuelle.

## Utilisation
- DEMARRER-DEVELOPPEMENT.bat : lancer en développement.
- CREER-INSTALLATEUR.bat : générer les exécutables Windows dans dist.
- Faire une sauvegarde complète manuelle avant toute mise à jour.

## Ouvrir un fichier JSON Strider
- Avec la version installée par StriderPro-Installation.exe : double-cliquez sur un fichier JSON exporté par Strider Pro.
- Avec la version portable : placez ASSOCIER-LES-FICHIERS-JSON.bat dans le même dossier que StriderPro-PC-v2.5.12-Portable.exe et double-cliquez dessus une seule fois. Vous pouvez aussi utiliser clic droit sur le JSON → Ouvrir avec → Choisir une autre application → StriderPro-PC-v2.5.12-Portable.exe.
- Strider reconnaît les programmes, profils, assiduité et sauvegardes. Une sauvegarde complète demande toujours confirmation avant de remplacer les données.
- Un JSON étranger à Strider est refusé sans modifier les données.

## Organisation
- main.js : processus Electron, fenêtres, accès disque, sauvegardes et export PDF natif.
- preload.js : pont sécurisé entre Electron et l’interface.
- index.html : structure de l’interface et ordre explicite des styles/scripts.
- scripts/app.js : état partagé et fonctions communes de l’application.
- scripts/modules/core : navigation, stockage, démarrage, affichage, saisie et images par défaut.
- scripts/modules/programs : programmes, jours, exercices et bibliothèque.
- scripts/modules/profiles : fiches d’athlètes et leurs partages.
- scripts/modules/attendance : assiduité et statistiques individuelles.
- scripts/modules/sessions : fiches de séance et exports A4.
- scripts/modules/sharing : exports, imports et sauvegardes complètes.
- scripts/modules/features : tableau de bord, planning, charges et autres outils.
- scripts/modules/security : activation et licences.
- scripts/shared : images embarquées mutualisées, avec les données d’origine intactes.
- styles : feuilles de style regroupées par écran et styles communs.
- assets et exercises : médias et bibliothèque d’exercices.
- docs/history : anciens comptes rendus de versions, conservés hors de la racine.
- docs/maintenance : rapport du nettoyage et précautions de maintenance.

## Vérifications
Après installation des dépendances : npm run verify.
Cette commande vérifie la syntaxe et les références aux ressources locales, sans lire ni modifier les données des athlètes.

## Compatibilité
Le nom public est Strider Pro. Les identifiants techniques historiques, les clés de stockage et le produit de licence restent YhCoachPro pour ne pas casser la compatibilité.
Les scripts continuent de partager certaines fonctions globales : conserver leur ordre dans index.html. Une migration en modules ES ou un changement de framework n’est pas effectué ici.
