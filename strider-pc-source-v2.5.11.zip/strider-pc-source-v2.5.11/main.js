const {
  app,
  BrowserWindow,
  Menu,
  nativeImage,
  ipcMain,
  protocol,
  dialog,
  shell,
  clipboard,
} = require("electron");
const path = require("path");
const fs = require("fs");
const os = require("os");
// Preserve the previous Electron data profile after public rebranding.
app.setPath("userData", path.join(app.getPath("appData"), "YhCoachPro"));
const crypto = require("crypto");
const { pathToFileURL } = require("url");

let dataDir = null;
protocol.registerSchemesAsPrivileged([
  {
    scheme: "yhmedia",
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      stream: true,
      bypassCSP: false,
      corsEnabled: true,
    },
  },
]);

function ensureDataDir() {
  dataDir = path.join(app.getPath("userData"), "YhCoachProData");
  fs.mkdirSync(path.join(dataDir, "programs"), { recursive: true });
  fs.mkdirSync(path.join(dataDir, "media"), { recursive: true });
  return dataDir;
}


/** Charge du HTML volumineux pour printToPDF sans data: URL (évite ERR_INVALID_URL -300). */
function loadHtmlIntoPrintWindow(printWin, html) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "strider-pdf-"));
  const file = path.join(dir, "document.html");
  fs.writeFileSync(file, html, "utf8");
  printWin.__striderPdfTmp = { dir, file };
  return printWin.loadFile(file);
}
function cleanupPrintWindowTmp(printWin) {
  try {
    const tmp = printWin && printWin.__striderPdfTmp;
    if (!tmp) return;
    try {
      if (tmp.file && fs.existsSync(tmp.file)) fs.unlinkSync(tmp.file);
    } catch (_) {}
    try {
      if (tmp.dir && fs.existsSync(tmp.dir)) fs.rmdirSync(tmp.dir);
    } catch (_) {}
    printWin.__striderPdfTmp = null;
  } catch (_) {}
}


function safeKey(key) {
  return String(key || "").replace(/[^a-zA-Z0-9_\-\.]/g, "_");
}

function fileForKey(key) {
  if (key.startsWith("prog_")) {
    return path.join(dataDir, "programs", safeKey(key.slice(5)) + ".json");
  }
  return path.join(dataDir, safeKey(key) + ".json");
}

// Écriture atomique : évite qu'une coupure pendant l'enregistrement
// laisse un fichier vide ou partiellement écrit. La version précédente
// reste disponible dans un fichier .bak.
function atomicWrite(file, value) {
  const tmp = file + ".tmp";
  const backup = file + ".bak";
  fs.mkdirSync(path.dirname(file), { recursive: true });
  if (fs.existsSync(file)) {
    try {
      fs.copyFileSync(file, backup);
    } catch (e) {}
  }
  fs.writeFileSync(tmp, String(value), "utf8");
  fs.renameSync(tmp, file);
}

// ========== SAUVEGARDES AUTOMATIQUES v2.4.1 ==========
let autoBackupTimer = null;
let lastAutoBackupHash = "";
let lastAutoBackupAt = 0;

function getAutomaticBackupDir() {
  const dir = path.join(app.getPath("documents"), "YhCoachPro", "Sauvegardes");
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function listDataJsonFiles(dir, baseDir = dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "media" || entry.name.endsWith(".tmp") || entry.name.endsWith(".bak"))
      continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) listDataJsonFiles(full, baseDir, out);
    else if (entry.isFile() && entry.name.endsWith(".json")) {
      const rel = path.relative(baseDir, full).replace(/\\/g, "/");
      out.push({ path: rel, content: fs.readFileSync(full, "utf8") });
    }
  }
  return out.sort((a, b) => a.path.localeCompare(b.path));
}

function automaticBackupPayload(reason = "automatic") {
  ensureDataDir();
  const files = listDataJsonFiles(dataDir);
  const contentHash = crypto
    .createHash("sha256")
    .update(files.map((item) => item.path + "\n" + item.content).join("\n---\n"))
    .digest("hex");
  return {
    yhcoachproAutoBackup: true,
    formatVersion: 1,
    appVersion: app.getVersion(),
    createdAt: new Date().toISOString(),
    reason,
    contentHash,
    files,
    note: "Sauvegarde automatique des donnees YhCoachPro. Les medias lourds restent dans le dossier de donnees de l'application.",
  };
}

function rotateAutomaticBackups(limit = 10) {
  const dir = getAutomaticBackupDir();
  const files = fs
    .readdirSync(dir)
    .filter((name) => /^YhCoachPro_Auto_.*\.json$/i.test(name))
    .map((name) => ({
      name,
      file: path.join(dir, name),
      mtime: fs.statSync(path.join(dir, name)).mtimeMs,
    }))
    .sort((a, b) => b.mtime - a.mtime);
  for (const old of files.slice(limit)) {
    try {
      fs.unlinkSync(old.file);
    } catch (e) {}
  }
}

function createAutomaticBackup(reason = "automatic", force = false) {
  try {
    const payload = automaticBackupPayload(reason);
    if (!force && payload.contentHash === lastAutoBackupHash) {
      return {
        ok: true,
        skipped: true,
        path: null,
        directory: getAutomaticBackupDir(),
        fileCount: payload.files.length,
      };
    }
    const stamp = payload.createdAt.replace(/[:.]/g, "-");
    const file = path.join(getAutomaticBackupDir(), `YhCoachPro_Auto_${stamp}.json`);
    atomicWrite(file, JSON.stringify(payload, null, 2));
    lastAutoBackupHash = payload.contentHash;
    lastAutoBackupAt = Date.now();
    rotateAutomaticBackups(10);
    return {
      ok: true,
      skipped: false,
      path: file,
      directory: getAutomaticBackupDir(),
      fileCount: payload.files.length,
      createdAt: payload.createdAt,
    };
  } catch (err) {
    console.error("Sauvegarde automatique", err);
    return {
      ok: false,
      error: String(err),
      directory: (() => {
        try {
          return getAutomaticBackupDir();
        } catch (_) {
          return "";
        }
      })(),
    };
  }
}

function scheduleAutomaticBackup(reason = "data-change") {
  clearTimeout(autoBackupTimer);
  autoBackupTimer = setTimeout(() => {
    autoBackupTimer = null;
    // Regrouper les modifications rapprochees et eviter les ecritures permanentes.
    const elapsed = Date.now() - lastAutoBackupAt;
    if (elapsed < 15000) {
      autoBackupTimer = setTimeout(() => createAutomaticBackup(reason, false), 15000 - elapsed);
    } else {
      createAutomaticBackup(reason, false);
    }
  }, 1800);
}

function restoreAutomaticBackup(raw) {
  try {
    const data = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (
      !data ||
      data.yhcoachproAutoBackup !== true ||
      data.formatVersion !== 1 ||
      !Array.isArray(data.files)
    ) {
      throw new Error("Format de sauvegarde automatique invalide");
    }
    ensureDataDir();
    createAutomaticBackup("before-restore", true);
    let restored = 0;
    for (const item of data.files) {
      const rel = String(item?.path || "").replace(/\\/g, "/");
      if (!rel || rel.startsWith("/") || rel.includes("..") || !rel.endsWith(".json")) continue;
      const target = path.resolve(dataDir, rel);
      const root = path.resolve(dataDir) + path.sep;
      if (!target.startsWith(root)) continue;
      JSON.parse(String(item.content));
      atomicWrite(target, String(item.content));
      restored++;
    }
    if (!restored) throw new Error("Aucun fichier de donnees dans la sauvegarde");
    lastAutoBackupHash = "";
    createAutomaticBackup("after-restore", true);
    return { ok: true, restored, directory: getAutomaticBackupDir() };
  } catch (err) {
    console.error("Restauration automatique", err);
    return { ok: false, error: String(err) };
  }
}

ipcMain.handle("yh-auto-backup-now", () => createAutomaticBackup("manual", true));
ipcMain.handle("yh-auto-backup-status", () => ({
  ok: true,
  directory: getAutomaticBackupDir(),
  lastBackupAt: lastAutoBackupAt || null,
  retained: 10,
}));
ipcMain.handle("yh-auto-backup-restore", (_event, raw) => restoreAutomaticBackup(raw));

function mediaFileFromRef(id) {
  ensureDataDir();
  const mediaDir = path.join(dataDir, "media");
  let name = String(id || "")
    .replace(/^yhmedia:\/\//, "")
    .replace(/^yhmedia:/, "")
    .replace(/^\/+/, "")
    .split("?")[0]
    .split("#")[0];
  // host/path forms: yhmedia://file.mp4 or yhmedia://host/file
  if (name.includes("/")) name = name.split("/").filter(Boolean).pop();
  const direct = path.join(mediaDir, name);
  if (fs.existsSync(direct)) return direct;
  const stem = name.replace(/\.[^.]+$/, "");
  try {
    const files = fs.readdirSync(mediaDir);
    const found = files.find((f) => f === name || f.startsWith(stem + ".") || f.startsWith(stem));
    if (found) return path.join(mediaDir, found);
  } catch (e) {}
  return null;
}

ipcMain.on("yh-disk-path", (e) => {
  e.returnValue = dataDir || ensureDataDir();
});
ipcMain.on("yh-disk-read", (e, key) => {
  try {
    ensureDataDir();
    const f = fileForKey(key);
    if (fs.existsSync(f)) e.returnValue = fs.readFileSync(f, "utf8");
    else if (fs.existsSync(f + ".bak")) e.returnValue = fs.readFileSync(f + ".bak", "utf8");
    else e.returnValue = null;
  } catch (err) {
    e.returnValue = null;
  }
});
ipcMain.on("yh-disk-write", (e, key, value) => {
  try {
    ensureDataDir();
    atomicWrite(fileForKey(key), value);
    scheduleAutomaticBackup("data-write");
    e.returnValue = true;
  } catch (err) {
    console.error(err);
    e.returnValue = false;
  }
});
ipcMain.on("yh-disk-remove", (e, key) => {
  try {
    ensureDataDir();
    const f = fileForKey(key);
    if (fs.existsSync(f)) {
      try {
        fs.copyFileSync(f, f + ".deleted.bak");
      } catch (e) {}
      fs.unlinkSync(f);
    }
    scheduleAutomaticBackup("data-remove");
    e.returnValue = true;
  } catch (err) {
    e.returnValue = false;
  }
});
ipcMain.on("yh-disk-list-programs", (e) => {
  try {
    ensureDataDir();
    e.returnValue = fs
      .readdirSync(path.join(dataDir, "programs"))
      .filter((x) => x.endsWith(".json"))
      .map((x) => x.replace(/\.json$/, ""));
  } catch (err) {
    e.returnValue = [];
  }
});

ipcMain.on("yh-media-save", (e, id, base64) => {
  try {
    ensureDataDir();
    const mediaDir = path.join(dataDir, "media");
    fs.mkdirSync(mediaDir, { recursive: true });
    const safe = String(id || "m").replace(/[^a-zA-Z0-9_\-]/g, "_");
    let ext = ".bin";
    let raw = String(base64 || "");
    const comma = raw.indexOf(",");
    if (raw.startsWith("data:") && comma > 0) {
      const header = raw.slice(0, comma);
      raw = raw.slice(comma + 1);
      const mime = (header.match(/data:([^;]+)/) || [])[1] || "";
      if (/mp4|quicktime|m4v/i.test(mime)) ext = ".mp4";
      else if (/webm/i.test(mime)) ext = ".webm";
      else if (/ogg/i.test(mime)) ext = ".ogg";
      else if (/png/i.test(mime)) ext = ".png";
      else if (/jpeg|jpg/i.test(mime)) ext = ".jpg";
      else if (/webp/i.test(mime)) ext = ".webp";
      else if (/video/i.test(mime)) ext = ".mp4";
      else if (/image/i.test(mime)) ext = ".img";
    }
    const file = path.join(mediaDir, safe + ext);
    fs.writeFileSync(file, Buffer.from(raw, "base64"));
    // ref courte stockée dans le JSON programme
    e.returnValue = "yhmedia:" + safe + ext;
  } catch (err) {
    console.error("yh-media-save", err);
    e.returnValue = null;
  }
});

// Retourne toujours un file:// lisible par la balise <video>
ipcMain.on("yh-media-path", (e, id) => {
  try {
    const file = mediaFileFromRef(id);
    if (!file) {
      e.returnValue = null;
      return;
    }
    e.returnValue = pathToFileURL(file).href;
  } catch (err) {
    console.error(err);
    e.returnValue = null;
  }
});

ipcMain.on("yh-media-delete", (e, id) => {
  try {
    const file = mediaFileFromRef(id);
    if (file && fs.existsSync(file)) fs.unlinkSync(file);
    e.returnValue = true;
  } catch (err) {
    e.returnValue = false;
  }
});

ipcMain.on("yh-media-as-base64", (e, id) => {
  try {
    const file = mediaFileFromRef(id);
    if (!file || !fs.existsSync(file)) {
      e.returnValue = null;
      return;
    }
    const buf = fs.readFileSync(file);
    const ext = path.extname(file).toLowerCase();
    let mime = "application/octet-stream";
    if (ext === ".mp4" || ext === ".m4v") mime = "video/mp4";
    else if (ext === ".webm") mime = "video/webm";
    else if (ext === ".mov") mime = "video/quicktime";
    else if (ext === ".png") mime = "image/png";
    else if (ext === ".jpg" || ext === ".jpeg") mime = "image/jpeg";
    else if (ext === ".webp") mime = "image/webp";
    else if (ext === ".gif") mime = "image/gif";
    e.returnValue = "data:" + mime + ";base64," + buf.toString("base64");
  } catch (err) {
    console.error(err);
    e.returnValue = null;
  }
});

ipcMain.handle("yh-export-file", async (e, defaultName, content) => {
  try {
    const win = BrowserWindow.getFocusedWindow();
    const ext = path.extname(String(defaultName || "")).toLowerCase();
    const filters =
      ext === ".html"
        ? [
            { name: "Page HTML en lecture seule", extensions: ["html"] },
            { name: "Tous les fichiers", extensions: ["*"] },
          ]
        : [
            { name: "Sauvegarde JSON", extensions: ["json"] },
            { name: "Tous les fichiers", extensions: ["*"] },
          ];
    const { filePath, canceled } = await dialog.showSaveDialog(win || undefined, {
      title: "Enregistrer le fichier",
      defaultPath: defaultName || "StriderPro_export.json",
      filters,
    });
    if (canceled || !filePath) return { ok: false, canceled: true };
    fs.writeFileSync(filePath, String(content), "utf8");
    return { ok: true, path: filePath };
  } catch (err) {
    console.error(err);
    return { ok: false, error: String(err) };
  }
});

ipcMain.handle("yh-export-videos", async (e, files) => {
  try {
    const win = BrowserWindow.getFocusedWindow();
    const { filePaths, canceled } = await dialog.showOpenDialog(win || undefined, {
      title: "Choisir le dossier pour les videos",
      properties: ["openDirectory", "createDirectory"],
    });
    if (canceled || !filePaths || !filePaths[0]) return { ok: false, canceled: true };
    const dir = filePaths[0];
    let n = 0;
    for (const item of files || []) {
      try {
        let buf = null;
        let name = (item.name || "video").replace(/[<>:"/\\|?*]/g, "_");
        if (item.ref) {
          const file = mediaFileFromRef(item.ref);
          if (file && fs.existsSync(file)) {
            buf = fs.readFileSync(file);
            if (!path.extname(name)) name += path.extname(file) || ".mp4";
          }
        }
        if (!buf && item.base64) {
          let raw = String(item.base64);
          const comma = raw.indexOf(",");
          if (raw.startsWith("data:") && comma > 0) raw = raw.slice(comma + 1);
          buf = Buffer.from(raw, "base64");
          if (!path.extname(name)) {
            if (String(item.base64).includes("webm")) name += ".webm";
            else name += ".mp4";
          }
        }
        if (!buf) continue;
        let out = path.join(dir, name);
        let i = 1;
        while (fs.existsSync(out)) {
          const ext = path.extname(name);
          const stem = path.basename(name, ext);
          out = path.join(dir, stem + "_" + i + ext);
          i++;
        }
        fs.writeFileSync(out, buf);
        n++;
      } catch (err) {
        console.error(err);
      }
    }
    return { ok: true, count: n, dir };
  } catch (err) {
    console.error(err);
    return { ok: false, error: String(err) };
  }
});

ipcMain.handle("yh-export-binary", async (e, defaultName, bytesArr) => {
  try {
    const win = BrowserWindow.getFocusedWindow();
    const { filePath, canceled } = await dialog.showSaveDialog(win || undefined, {
      title: "Enregistrer le fichier",
      defaultPath: defaultName || "export.bin",
      filters: [
        { name: "Video", extensions: ["webm", "mp4"] },
        { name: "Image", extensions: ["png", "jpg"] },
        { name: "Tous", extensions: ["*"] },
      ],
    });
    if (canceled || !filePath) return { ok: false, canceled: true };
    fs.writeFileSync(filePath, Buffer.from(bytesArr));
    return { ok: true, path: filePath };
  } catch (err) {
    console.error(err);
    return { ok: false, error: String(err) };
  }
});

// PDF natif Electron : ne dépend ni de jsPDF ni de html2canvas.
ipcMain.handle("yh-export-pdf", async (event, defaultName, options = {}) => {
  try {
    const win = BrowserWindow.fromWebContents(event.sender) || BrowserWindow.getFocusedWindow();
    if (!win) return { ok: false, error: "Fenêtre introuvable" };
    const pdf = await win.webContents.printToPDF({
      printBackground: true,
      pageSize: "A4",
      preferCSSPageSize: true,
      landscape: !!options.landscape,
    });
    const safeName = String(defaultName || "StriderPro.pdf").replace(/[<>:"/\\|?*]/g, "_");
    const { filePath, canceled } = await dialog.showSaveDialog(win, {
      title: "Enregistrer le PDF",
      defaultPath: safeName.toLowerCase().endsWith(".pdf") ? safeName : safeName + ".pdf",
      filters: [{ name: "Document PDF", extensions: ["pdf"] }],
    });
    if (canceled || !filePath) return { ok: false, canceled: true };
    fs.writeFileSync(filePath, pdf);
    return { ok: true, path: filePath };
  } catch (err) {
    console.error("yh-export-pdf", err);
    return { ok: false, error: String(err) };
  }
});

// Résumé A4 dédié : ne touche pas aux anciens exports PDF.
ipcMain.handle("yh-session-summary-export", async (event, filename, html, mode) => {
  let printWin = null;
  try {
    if (!["pdf", "print"].includes(mode)) throw Error("Mode invalide");
    if (
      typeof html !== "string" ||
      html.length > 12 * 1024 * 1024 ||
      !html.startsWith("<!doctype html>")
    )
      throw Error("Document invalide");
    const parent = BrowserWindow.fromWebContents(event.sender);
    if (!parent) throw Error("Fenêtre introuvable");
    printWin = new BrowserWindow({
      show: false,
      width: 900,
      height: 1200,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
        partition: "yh-session-summary",
      },
    });
    printWin.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
    printWin.webContents.on("will-navigate", (e) => e.preventDefault());
    printWin.webContents.session.setPermissionRequestHandler((_wc, _permission, callback) =>
      callback(false),
    );
    printWin.webContents.session.webRequest.onBeforeRequest((details, callback) =>
      callback({ cancel: !(details.url.startsWith("data:") || details.url.startsWith("file:")) }),
    );
    await loadHtmlIntoPrintWindow(printWin, html);
    const scale = await printWin.webContents.executeJavaScript(
      "document.fonts.ready.then(()=>fitSummary())",
    );
    if (scale < 0.7) {
      const answer = await dialog.showMessageBox(parent, {
        type: "warning",
        title: "Résumé A4 très dense",
        message: "Le texte est réduit pour tenir sur une page A4.",
        detail:
          "Vérifiez la lisibilité dans l’aperçu. Vous pouvez raccourcir les consignes avant de continuer.",
        buttons: ["Continuer", "Annuler"],
        defaultId: 1,
        cancelId: 1,
      });
      if (answer.response !== 0) return { ok: false, canceled: true };
    }
    if (mode === "print") {
      return await new Promise((resolve) =>
        printWin.webContents.print(
          {
            silent: false,
            printBackground: true,
            pageSize: "A4",
            margins: { marginType: "none" },
            landscape: false,
          },
          (success, reason) =>
            resolve(
              success
                ? { ok: true }
                : { ok: false, canceled: /cancel/i.test(String(reason)), error: reason },
            ),
        ),
      );
    }
    const safeName = String(filename || "StriderPro_Fiche.pdf").replace(
      /[<>:"/\\|?*\x00-\x1f]/g,
      "_",
    );
    const { filePath, canceled } = await dialog.showSaveDialog(parent, {
      title: "Enregistrer le résumé A4",
      defaultPath: safeName,
      filters: [{ name: "Document PDF", extensions: ["pdf"] }],
    });
    if (canceled || !filePath) return { ok: false, canceled: true };
    const pdf = await printWin.webContents.printToPDF({
      printBackground: true,
      pageSize: "A4",
      preferCSSPageSize: true,
      landscape: false,
      margins: { top: 0, bottom: 0, left: 0, right: 0 },
    });
    fs.writeFileSync(filePath, pdf);
    return { ok: true, path: filePath };
  } catch (err) {
    console.error("session-summary-export", err);
    return { ok: false, error: String(err) };
  } finally {
    cleanupPrintWindowTmp(printWin); if (printWin && !printWin.isDestroyed()) printWin.destroy();
  }
});

// Liste de profils dédiée : plusieurs pages A4, sans modifier les fiches existantes.
ipcMain.handle("yh-profile-list-export", async (event, filename, html, landscape, mode, pageRanges) => {
  let printWin = null;
  try {
    if (!["pdf", "print", "preview"].includes(mode)) throw Error("Mode invalide");
    if (
      typeof html !== "string" ||
      html.length > 24 * 1024 * 1024 ||
      !html.startsWith("<!doctype html>")
    )
      throw Error("Document invalide");
    if (pageRanges != null && (typeof pageRanges !== "string" || pageRanges.length > 10000 || !/^\d+(?:-\d+)?(?:,\d+(?:-\d+)?)*$/.test(pageRanges))) throw Error("Sélection de pages invalide");
    const parent = BrowserWindow.fromWebContents(event.sender);
    if (!parent) throw Error("Fenêtre introuvable");
    printWin = new BrowserWindow({
      show: false,
      width: 1100,
      height: 900,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
        partition: "yh-profile-list",
      },
    });
    printWin.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
    printWin.webContents.on("will-navigate", (e) => e.preventDefault());
    printWin.webContents.session.setPermissionRequestHandler((_wc, _permission, callback) =>
      callback(false),
    );
    printWin.webContents.session.webRequest.onBeforeRequest((details, callback) =>
      callback({ cancel: !(details.url.startsWith("data:") || details.url.startsWith("file:")) }),
    );
    await loadHtmlIntoPrintWindow(printWin, html);
    await printWin.webContents.executeJavaScript("document.fonts.ready.then(()=>true)");
    await printWin.webContents.executeJavaScript("Promise.all(Array.from(document.images).map(img=>img.complete?Promise.resolve():new Promise(resolve=>{img.onload=img.onerror=resolve}))).then(()=>true)");
    if (mode === "preview") {
      const previewPdf = await printWin.webContents.printToPDF({printBackground:true,pageSize:"A4",preferCSSPageSize:true,landscape:!!landscape});
      const pageCount=(previewPdf.toString("latin1").match(/\/Type\s*\/Page\b/g)||[]).length;
      if(!pageCount || pageCount > 2000 || previewPdf.length > 40*1024*1024) throw Error("PDF trop volumineux pour l’aperçu");
      return {ok:true,pageCount,pdfBase64:previewPdf.toString("base64")};
    }
    if (mode === "print") {
      return await new Promise((resolve) =>
        printWin.webContents.print(
          {
            silent: false,
            printBackground: true,
            pageSize: "A4",
            margins: { marginType: "none" },
            landscape: !!landscape,
          },
          (success, reason) =>
            resolve(
              success
                ? { ok: true }
                : { ok: false, canceled: /cancel/i.test(String(reason)), error: reason },
            ),
        ),
      );
    }
    const safeName = String(filename || "StriderPro_Liste_Profils.pdf").replace(
      /[<>:"/\\|?*\x00-\x1f]/g,
      "_",
    );
    const { filePath, canceled } = await dialog.showSaveDialog(parent, {
      title: "Enregistrer le document PDF",
      defaultPath: safeName,
      filters: [{ name: "Document PDF", extensions: ["pdf"] }],
    });
    if (canceled || !filePath) return { ok: false, canceled: true };
    const pdf = await printWin.webContents.printToPDF({
      printBackground: true,
      pageSize: "A4",
      preferCSSPageSize: true,
      landscape: !!landscape,
      ...(pageRanges ? {pageRanges} : {}),
    });
    fs.writeFileSync(filePath, pdf);
    return { ok: true, path: filePath };
  } catch (err) {
    console.error("profile-list-export", err);
    return { ok: false, error: String(err) };
  } finally {
    cleanupPrintWindowTmp(printWin); if (printWin && !printWin.isDestroyed()) printWin.destroy();
  }
});

function getAppIcon() {
  const candidates = [
    path.join(__dirname, "icon.png"),
    path.join(__dirname, "icon.ico"),
    path.join(__dirname, "..", "app.asar.unpacked", "icon.png"),
    path.join(__dirname, "..", "app.asar.unpacked", "icon.ico"),
    process.resourcesPath ? path.join(process.resourcesPath, "icon.png") : "",
    process.resourcesPath ? path.join(process.resourcesPath, "icon.ico") : "",
    path.join(process.resourcesPath || "", "app.asar.unpacked", "icon.png"),
    path.join(process.resourcesPath || "", "app.asar.unpacked", "icon.ico"),
  ].filter(Boolean);

  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) {
        const img = nativeImage.createFromPath(p);
        if (!img.isEmpty()) return img;
      }
    } catch (e) {}
  }

  // Fallback: icone integree dans le code (toujours disponible)
  try {
    const b64 =
      "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAEAAElEQVR4nMz9d6Bt11UfCv/GnGu30+65Tb1YlizJcpeMLVdhg7GJGzaI5AFphMBL8JdHvvcFkpeXzxjnkQp5yRfyEiCUQDBBuMTGYOOC5Y4suctFxertlnPuqbusNef4/hhlznXuNSQkkGz76pyz915rzTnmKL9R5piE/4lfDNDP//ANzdUXrvDL3nJrV3/2737i2w9detH5/PjJR198Yvzclzy0EzBd7KLpdl88WYovPjx9KB8Pp8J4GDEeDTEYNhgMGoQQkJkxn7XY3J7isRPbOLGxj82dBRZtRs4MAAiBEANAIQAMMBjMQCAgBGDYRAyagOEgYBAJRAQiHTfD75MZYGakxGACcpaZMQMpMUByAUOuyRnIzMh6D4Z8BQCIAALpGwzSB5J+g/W/kQjDYcR4GDEZNZiMGoSg3yS5T5cyFouEtk3yDP2gCXpPkjEyANZxMMu1rMMmgo+PiMA6Dx9MAIKOV+hhn5L/dzpP6HIWMlSfMgvt5G8Gg/S5OghZFHluRR8fEKP3PtsfRmsnPTvdbG1Sykgpo20TUs7IjNw0TUgJHw8BH2+GQ6xOhoix+dgzn3Ls43d+9RT9/Ae/sVXz5003oblmF/Tzd6CrpvY/3Yv++K/8mb/o5psRbrkFqX7zt95808rKoeELR8Ph8ze3poPZbP7DXdcN5/P5Oi1fRNPBUawsR5w3mWNtbRVH11cxWlnFeDzGcDRCMxghxAahGSizAjknpK5DzgmcM5hZGMS4hciFDOTSC5d0FKG3l7CqaQL/T48D7PmiCEww9Koet9bP0vHYc7iIiwmifqDKKIICgUIogtG7jsE5u3IzBYDqPiZMXP1+9kvHrgqgflF1P59nJeVsWgXVe/Vj7Oumefx3OG2JAkyE5Xn1HM4xZhP4g8/NGcwZOYlSnM9b7E9n2N7ex6mTJ3HqxAmcOrGB0xtbOL2xg93dKfYXmWMcnGliXEyWhj8/GcV2f7/9wxy6T95y68nd+rE334x4yy3IwP9cyuB/JgVAN92EeOutcEv/f/3Vq46vrKz90PGjK2sx0F9vGjq6Nomg0ICbEZbX1rF65CIcO77erR87jvHSGjAcBxAFFhMqljQlCMMrE5rlFImrLCn6Jg4B4AxQcKbz71A4S/jlJkF+GsNTQI/x/XvlYhdq9IXmnC9n6tpm9m584KMiBQwG+VD6Qs+ZqyGRCz6R0gD2XS7mszfyA7NxK2wKkc/6rLbkffONswT0m7Iq577Chiobouq59t2ijMkUAQHILEhP74EQZN1iAGKU+XMCupS76TRvnHgM9937EO6554Hmrq/ehfsfPIHtrW10GQhxgGbQnG4G4ReQeHuZ+Rd/+eOPn7Qh3HQTmltvRcK5F+/P/PU/XAEc1IyvuurI2uh4fMHKZPi3VyfxBecdHq9dcGSCtfVVXHTJRbj4iqvaoxddQivr58XRaAzESLnr0C5m6BZzdIsZcjtHTq3CVqOzLbAKmTOdvR0c17JaUZgAKOQGgkJORggBbFC2NsEK05kZFPrWqA+AbVgBZg6JCAgE0rGxChvZdwiVAEPGBi5WjWQebhGr/9ABUexbVfvPgW+5MjQLDzBnV4JsMNyfxkq/WsZJhLRHpzJCvUv/mRXNDqKkojBUQdnXFAnlXMbnSoQZlXNSvbj3jEqP9K4LIYJCRGwGaIYjDAZDhPFYFmOx4DMnT+Leu+9JX/zcnXz7Z786eOjhk2BmjEZDNIPBdhPpU22b/8X2fP6p9922sW3Ldy6k+2f9+h+mAN4MhLcI+RkAXnPDhccWqf1REN7UpXSMcovzji7jxhue0r3oRc/ly59yZXPo2IUUYoPUtWhn++jaOVK3QE4dGIRAEUSMGBs06u83TUAIEcF8dHMw7Q+3PKGsfM8YUSVJ9fepuofNAgAUMbi1qxixZ+rt3oYyqu+f+8vn+E41F0MqztRU5qpxjJ4l5XMJhD7vrDHYOOrr6/fso4oWPmcG+JvR4iACqJ91EG3YPV36KwXGB65FudYf9k0UAAV17YyO0DUBkMRFbLsOqW3RtnOkLoFzEoUdAprBEMPxEibLy8BggMXuLr7x9bv4M7d9ofv0p79ADz1ysgkhYjgaIcZwKuf0ryPRz73t1sdO2Qh+8s2gt7wF+RwD/FN//Y9QAHTDDWjuuAMtALzy+sOvbMLgx7rML5zN5muLdoEnXXKMX/HyG/LLXv6CcMnllxIoYra/h/l0FzklMGcAAbFpMByNMZ5MMBhEcM7o2oTtrU2cOb2Bkxvb2NjYwZmtXezu7mO+aJG6hJS72jgUUlT8e9AtoHMoB/uGWSKzoH5HsvdMFtXWVfxbPoMIS/1Swahxirwt1mrKDSboEAJjkQMiMWJPNxSB8WCZP7cfOiRVbLMcQUQYhw6Zq5iDIhu4pWRkEBIHDKkDI/RiEfaMaR5gQou+3vX5GugSZco5gwKpO1LGa7Cn3LtWJPJ7ywERLPjH9QpXC2wGgPzhB9FOoIDBIGI4HGB1dQmH19dwZH0ZR9ZXsH7kCFYPrWMwjAAIi0WH6XQP7XyOnMRFCIMRRpMVLB86jDAZY35mC1/63Bf51g99LH/2818PO3sLWllZQhPDds75k23H//dvfeyx9wPAD9+Awf+IgOGfqQK4GYi3QCDPy5995BXjJvzvMYRX7s8WWCxaPP2pl3SvftUL44te/FxaP3oM+3t72N/dRjvbQ04JIYrAL68sYzwaYrbocPLxJ3D3vY/ia/c8hAfufwR3P7iBJ07vYXfa4cxeRpsimAICCRKgJiIqp1IMcJ6g8jsgzBsAj+4zAkCMULsPytXCkGbJDeCaQjnbkptikHf1nlUAq/4cUOclqByEoP4rIUOEnpCREUAKqQkMJgZxcGBv/7X7O+ymMhKoQBMxIjGYK/YIGj8w90TjAsyEQHp/ZgBZ9RiBCUggRI29MKG4MHoPIgAJYCqCazRlzYbULo0oBYKpMFb4njmASOC/BPNzDywEVQSZKgXiXo5cxQSklJHTAty1yLkDcofVMWEyCjh+ZBlPedJRPO3aJ+Pap1yMq6+8BEePHUNoAqazFtP9faSuAxGhGYwwXFrByqEjQAAe+cY38AcfvJU/8pHb0xMnt5vV1WU0MSDn/P7FovuZWz5x4gOAu8R/Zm7Bn4kCqP38b7t29ehgafQmCuEf5Jzi3t40P/tpl/H3fu8rw/NfcAMNRiNsb25gtruF1LVgZsTBAMtLYwwHA2yc2sTnv3QPPnH7XfjcVx7G46dm2N7vMMcEq2uHsby6hpXlFYzHY4yGI8QosLi4AOIqAMJksSFA/X8iS1tJvICIQSGCOIhvrkIlFiuJwFFUxEggrt0MM2+ooGtECAHgpI9oANLgWwCIo18aCaBACGwDk3gEAcq4wvBQkS/+tYzTg2AZADGYLAVYKTC7OqiKoABQg8AaNA0BQQVQrKkiAFN8zHp/kh/IKleqUlhoWBlxRRAibKIQMjgTQBkEctQuacMMsIwt5ySZG2QQk1v4zFkVE4H1ITlnMLIrE1U/olSyxQMUVTAjedwAyEnvwQltl7FYdNif7mF3f4YzG2ewvb2Bva0NIE1xwZExnnrFUbz0+U/Bi5//NFx9zRUYTSbYny4wm07BOYFixGC0jOX1oxgsL+PMow/jQ+//A/699340P3F6l46sr4RFl1OX8ls353v/+kOf2TkN/NnFB/7UFUCt0V71nKOvbQbhlwPR0Y0zu7jsoiPpB77vlfHlr3gpmsEQ22c2sZjvgdsFUuowmUywtDzB9plt3Hb7V/E7H/gcPvG5B/HwRsJo+RCOn38Bjh89htXVFYyHA2V6FuXPhMRZfLYqKmWBOQnsZCVCFItJUIELLpgxBLUQqgAQJb9NADnsFSEijkWgUZgUxKIcEBVt6DiYEExJhOK7MyJiyApnG4CyQHtWQdeINZl/j4I0JBYCtY4ZAQArnLZnMUyRqKJgAlEAB+4rMf/ByK4AUAXf1AqzWXcGNAgpCiMAyJprZx+zWfGs71rY0kIhTBnIAWBG1utzVsFEFjMO+1solnN2hGGpXEZWhcJFB4OVBopiWJUWs96HVemwvifGIQRBeYyMLiXs7c2wsbmJU6dOY2vjCUzCFM+48jD+3Muege/4tm/Bk696EhAb7O7soVvMQRQQBkMsrR7GeG0NG48+gnfd8h689/c+mRYJcX11jLZLpznxX/2tTzzxnoOy86f1+lNVAG9+M8Jb3oL8nTec94oY8/8OhFfu7M3QENrvfv0Lm+/7/tfR6vphnDl9SmB+TgAClleXMR4E3HP3/fjt996G93zwS7j7kT2MVo7hgosuxnnHjmBpNHbhs5kEiggxIsYGg6ZBbCJCiIjBLHgU4QiMELQ4RoU7BEhkn0ksb4BY+0CqDyQ1VFBEcIGiEBRhqPUFAIogLoJOiuMN7VMwhaCWPYgVDBQARCAQgrJ3sDgAkX63v3CkCkvIEBQRiHKTbIV8LE5Nhps7c2kQlY5ZFYe4AVBrTsTIKbvyZFNUbAU8WeimLgHnJNZZrbjIpAmWCBwxuWKw7EIGNHCnNlu/D1XqIIX7VkyVGVkRRWYS5aJpQYupZKt1cCVUrmEmcJJCqC4l18Fd6iSelDp0i4TFYoFFK/GjLi2Qk5BvMAggikgpY29/H489fgIbJx/G+nCGG591MW5+7Qvx4hc9ByuHDmF3d4r5dE8UQTPAZGUNk5UV3PXlL+NXf/nt/NnPf6NbXpkMhoMGXU7vn83zz7znD098wGTov4tAnuP1p6IAbr4Z8brrwG95C/Jrv+XYayiEd2XmeGpjj5953SX4mz/8Bnr6s67DztYOpvs7roVXVlcxHja488678cu/+WG868N3Ybsd48KLLsUF5x/D0ngI5oAudcg5I4QGo/EIo9EIE4X8oYkAgNQlLBYt2rZDu1igS61U1jED6MA5uI/OFSVI4bQIqL6jMJ/MCobgHrUIdLQko1gvCg5T5T3yaykAHMXgk7obcg/zewELOgq4j/qcqtJQBRXuv5LPRUIT2f19C3oxSeyANEthMQ7xzUvcKVBwAQdnMKl/7O+VMCe5RRUUYYLOpKbZ7o9yrY1MwrhKxZzAHMCUQUmvMGlUJRBIKiS5vq/RF+aCcfmbc6lgFA8KmTsAQVAEJ0UoMrSsEZQQAgYhohkMMBgO0AwHiDGgCRGcEubdHO18jul0gfl8jpQSQiD5ftMgZcaZrR089sjD2D79EK65ZIzve/3z8PrX3ISj5x3Dzs4e5rMZAhHCYIi1w0dBAD70/g/hP/7G+/jE6T0cP7pC83mX2sTf9a5PPfE7AMLNN4P+NNDAf3cFUMGW+NrnHX/nYBBfu707zwE5f+8bXtTcfPOrEJsBtjZOCeYLEePxGCsrE9x55734+V/9ffzux+9FGh/DpZddjiNrK8gMdN0CmcV/HwyGUuE3HCE2ATlnTPenmE1n2JvuYbo/RTtv0XrEv1iUQGpVNJBmuXRW6Qrmu8PcZCqFJVYRF0n5njxLZcFB1oCY+eqskLMG6f1ovwcK9HmKQtS/l3FQFUFnh97Q+2VVJp5T1/9YbIBZkFUIlrtnqG+ggUIuY6EyPFYpLlAfJseu8My1sgyHo4vqbytAEjQgEMhcBAlWsj/TXISs8zaFI2GHUp+RIe6KDcADiDYm/dPepkpxeWqSbY5aQ2B5f+ULogBqAoZNg/FwhMlkCatry5gsTbC8vIomBrTtAvPZHNPZDG3bggJjEIdomgZt1+KRxx7D4w/fi0sOJfzFN9yIm9/wrTh8/Ci2zuwgdS0oEAajZawfPYYnHnkEv/JLt+DWT3y5W15eCsNBCG2X3/PbH3/8DQDSn4ZL8N9VAWgqo33jjed9+2AQfjzE+IrTm7v5souPhB/+wdfgGc+8FmfOnEE3nwIIiIMBDh8+hAfufxT/5pffh7d/8GsIS+fjiiuvxNrqskCuTix3M2gwHk/QNAMQE2bzGba2trG9s4P5bIp20YqQBAAhIFJUq0kuyC5kyvRW1GPw2kCyMUoIoUzOYCSxBvIKAU3kxTuwgJpcxCBkYq+JB5vPG4q8KDzPGrwLJsBsLoXjC0/Xme+t0g63zlUBEquSApILXjUjdRfKBM2gl1f2b5YJ689sM3byAK6C9NJA1T3sWwbtDX2JCAZF/rYmmXP//pYZAFyh12PtpWJdW6ry1YwAW52EojG2TAFI0IfqLdbApitwzkgp+f6OGALGkwmWl5dx9Mg6VlZXMRwOkVKH2Wwfi3mHxBkxQFFBxmNPnMTpR76B48sL/NXvfQH+/He/DIPRBNvbu+KiUsDyocMYjUb4vXe/D7/y6+/DokNeXx2F+SJ9ICH/03d8/MQHTcbw3+n1300BmHb6C996/qvHg8G7A1HYPLPXvfD51zbf932vxNLyCrbPbII4I2XG2toymIHf+O2P4l/8ykexkw/j6muuxuG1FbRdh5xlQUejCcZLE0Qi7OzuYHPzDLa3dzGbTdUHFcsWQhCGJoPIFhyrBBpQS1+/q4QohYDIOVT+vJHIFAj1bkgazCrfIn0QVwJeKQWPVFH5vv2tqcWQDabbcyU6ZrHMorDkcyazhmYpq8Iil2rSID4XZQW1ySYssOCeKUh2OXP0YoFPtnfcz9G/s6Aqz79zobWiLmjE3tCXW/OUVWmYkB98FdjffxdSMUl9q28viy2QzolRCTpQUGFg5GzoTpUFQd0bKf5hza6YQgggxAFhaXkFx44eweHDRzAcDbGYT7G3t4eu7QAQQkPgTHjk0Sdw/z1fw7OfvIT/7//79XjpS67H1vY+unYhQefhEg4fOYKv3flV/Ouf+0+4/6HT3bEjy02Xcp5P29e987ZT763T6f+tr/9mBcAA/SRAbwHyX3nFRa8dDJp3gDks5ov82le/qPm2b3seZtM55rOpPDAEHD28hs9+4V78vX/2bnz2ri085dqn4aILL0DKCV23QAwR4/ESlpbG4JyxeWYbp06dxt7uLjInFXoroaXKhzUf2Ji6zn1TEUqqmEy5JoTKYkB82mK0S125yVMg8gK3ihbyzSBXiJ/L6mtW96b6bvJZnZtnMo+0D7vNly1jAlDNyxbUdrh58ZK5MG6huVznIkPle2TzLG5IubnRrpqDgxQLxBVLLkNUO8/2iOjWtaiRurbAfRBBXCC/HvXc6zvkXKEvQwoZAcGDfqRjAUjrC+BxAwswEgWU+gcJQBKLe0BkKLAoW9LYRdK9J8PRGOuHD+H8845hZWUZi/kC27t7glAzIzYRKWfcffd92Dn5DfzQ91yPv/OmN2CyvITt7V0EYjBFHDpyHHs7Z/Bvfu438enP3NWtr68E5pwD+I1v++gT73nzgUraP+nrv1UBhDcD+MhNCJc3F79jPGpeO5u3eTiI9Jd/4FX0zGddjTOnN8GpRWbGeDLGZDzCv/2VD+Ef/+KtGBy6BE+9+kqBSdyCKGA8HmF5aQU5MTY2N3Dq5GnMZnNQCIhRWS4X6J41lUamxSsBcx63z1V6a2jPEGtlQTjArE+RKBMdUSgK4KkncZXwlGyABBrZx2SMLdmGki6sfVvlylJboAqCe1U0/uCyiFT+FmGu5FV93pLekwBYUQiFGl6/wDbfut7evuY3KtC8BA50BOL6ECddG52/W9fqmfY4SA6/95GjKLP+5Vk+Ol3XWumVDEWhrygY+T1DlZjtU1AlWhSbqhfOPhTo95gU9WV9njIbMSGnjJQTYiSsHVrDeeedh7W1Q1gs5tjZ2cWibaXisAnY2t3BV770ZTz14gb/10+8ES950TOxsbkjpcZEWFo5hMGgwW/8+nvwzt/5JK+uLnETKMwX+T2nBo+/8VtvRX6Lkg1/wtd/iwKgNwP0lZtBo1MX/eelcfPqzZ1ZWl0exTf9r2/Ak550EbbPbIGQsGhbHFpbwemNXfydn34Hfv+2x3HNNdfi8NHDaNuMQBlN02B1ZRUhNtg4vYFTpzewWMwlX08GO8sCyuDJLZIUkki0u2acniXs/W73iZUw9pWpXUtGKWZAo/KABv6gQTk3pBo8qu52UICYYJn4EoQ0H9ZkPEKZL6j8ljhA/ZMs+uXxjAMludDqNzX6IM1hcR3t+CYvLdABQYp1Dj5LlZWJo+Ete5483NyRqOv3Rzwu/xGfG/TqexxFOdhfBFiQF7A6qGrNdfzZszR2Q0HUmUtsgzWVWn+PIVWFym0eUyGlEUMySMhSLwACVleWceFFF2N5eQn7+1NMp/vIKYlRCwH3fuN+nHj4Xvy9H3kpfuxHXoPpvMViIUiYmiHW1pbxnnd/GP/hbR/CeDxO42GI03l+b7z48ddfdwv4vwUJ/EkVAN10E+K3AvgaX/Cu5fHg1ae29tvjh1cHP/amN+KC8w5hd2cXREBKCUeOHMJtd9yFv/nmd+HxvRGe9fSngiigyx0IAZPJCOPxBPt7U5x44iSm8zmaGGE59zJUg7IlOEUwa8piOQ0u6s69c824BJcsuk4O70CFkXvXuzktghMooJdyA0OjkCqEdbS+TKF/77Psq9yJSvmq/OHqrNyuJwxF5HtxBRRITLBA1wH0UP3l1o/YKpvVUtbPyoowApiKK6rlRj1UQZngsvZHvDIzSJWFyJuupQ4wm8KpwZkWILG5L/5xkQdm80+4/6lab4mfwDMlZQHkm5kYYKuPUIBk6UUdiqkCQygSd2UDYki5A5hx5MghXHDhxSAi7O3voW2TuA3DiK3tXXzpi1/E6154Pn7mrX8Za2sr2NneQ4gBITRYO7SCD33gk/h3v/J+jMbDdjKMg715997NwYnvAoA/6RbjP5ECsEjka593/N1ry8PXbmxP24vOWxv8+N/+CzhyeBm7W1uSc2XgyJF1vP13PoOf+Ofvw+TI5bj88ovRtdJ8oYkRy8vLYGScPHkK29u7IAolys7QAp7KAIcAQqpSVcbkUIIXoavTZwZ3WYNM0SFsud5chCL3Wqln15pwCTRwNwM1bGetjw/nIK+N44Ar4B9XboJdQAbBCbBwo8fya9R9YCNRH2brvVRYjGmtDtKoyGz+tkThA0jgrqXpqtSe60MXqgypxS+C4O41Droa5eVpSV3vTCaiRnf42Mo+Apsue1EgTM4BFVgZoEN5/S0raiwZEgCQQF3OcOVJvj/Aqghdc8sjKjeRKIM5+vume9mUgG6iENcg4rzzjuPIkSOYLzovGW6ilIV/8Yt34pL1BX7pn/8VXHP1pdg4fQaxIVAY4tDaMj5y6234t//+fRiNh+1wEAezRfeed37yxOv+pNmB/2oFcMMNGNxxB9qXP3P9tWvLo3fvT9v2vKPLg3/wd/8ijh1dw/bWGeR2DiLC2uoE/+zffgA/+2u34+rrno7D60ewWMzByBhpXnV3bxenTpxC27YIw6FYAa1/Dz3UWcxIMG1gQm8+dM/aFiVgbM8o+eIYjAkkmFjSTMY8cCtKMCY+uzFIMeSqaZzPK8VUW+0eA/VRRk8BMKRGnwvUrsJqMG4v1/igxHUIaokrrEwH7lvupdeQFsQwA5wQEN2KCfo29WGBsAMmua4yZAm+gaoq5wMvqaPI51AATgL9hX16pgD6j1VrTxm6Y8qHU1wjcR8zgtDEA5wMcYuCuDmuENkF19WRWpPsSlppp2toLowNLzM8hqB+H5gzuq7D6soyzr/gfAyaIabTqRcUDQcD3HXPfcDeQ/iFf/Tn8cIbn45TpzbRRALFEQ4dWsaHP3wbfv5XPoCl5XHbRAzmbX7dOz7xxHtMNs9B6m/6+q9SAJbq+9anH3710ii+q00Zq8uD+FP/x1+iCy88iu3NDReI5UmDf/BP/zN+4d134RnPfAaWlpbRdi0IhMlkjKZpcPrkJs5snZGqO4pGoz7MI4O0+nfW9BFl5W0yPAernvOAGQgHA07OOy54Fl8QE0KBi7bXa8CkRTQFCjvqJNLt9qYmlLFMWYUq164wIyi0tVRnT5EwxIuw0ldfInImriABerBVCWfQmIjLvEhdJRuNoyII3Fb05IiKTflp3p7I7511151Py56uirtGMWe5Qf5dLt8wJcUlkm/3Zf1uqXs4sDQHVItXSRpesmvMRaiKh0zQE1h1Vyh7uLQoCE5LGyO7q8g5gxBdyfTQmyqO7GlXLiiSGSl1iDHg+HnnY339EGbTGbquA1HGcDjEw488jtOPfh3/5s1vwHe+4rk4dXoTMRAQGhxaX8P7fu8T+OW3/QGvry4n5ozpvPuud9926r3/tcVC/8UKQFsZdd/+zMMvDjF8JDNTJKaf/Lt/ga6+6hJsbW6CwKAYsbo8wU+89T/h137/fjzzWc9EExq0qUMIEUuTCTIzTjxxAvvTGZomosZvBy0mAN1oU5teUwyFAZgyggN7FwWADnCMLg5AoBDNSGiZrFrUA0wlckaaS5aiDQuCyeYc+VZVYKZMpPc7QGWzMTIiTfkZYnFLUY1XXybqUlgEsCsbAg5CfgYQkj6vAXJRCgfhbP+6gy6IionBYH/MQZtO1aW6VqogPcLe+25G/W0DK5JQKVmR2hmoO5OJwFVDIaAEw/uulaTMA7z4x4yKbSViSOFRjcY4F0t/gEy18iIONjofD1vGSQOL7hLUZKOywenw4UM4fvwY2rbDYj4DCGiaAU5snMaj3/gy/s0/eB1e86rn4eTJ02gGDSgMsLa2gt/8rQ/gXe+9nQ+vLzHnzLNE3/quTzz2cZNV/Be8DjqK3+xFAHAT0FCgn24aivP5Iv+tv/4quvrKC7Bx6iSgJbdrKxP8Hz99C379Aw/i+uuvRxMHLvzLS8tYtC0efeRRTGcLDAZNRREVQOMCVEKUlXH1cyd0zUQc+ryLmtr2u66EC63suCMun3khiPu9uuAZDiTNipvLwMmUUEUs/eVsMelXsxXLgvK8jFJ2XMmrMCqAbB5tcKRgOWs29UUAOAKIxucy5qyuDNSNYCpaS59lNhKARssteq7FNCqtqrI87gFU1YGmbByWZ1jw0DboANWc/ffirxs6sS9Qpc/LWh9ABbWycjqTbz6yL8tmIPvHblBk05TuLFTkyf0H1o+SGAEg+w4KFIJlG5ygtr46Jk7CgoECTp/exMOPPoamkc5BKTHmszmOr6/j4iuejh99y3vw/g/ejmNH19EtWnA3x87uHr73e74NL73xato8s5+bJsaA/NM33YTmW310f/zrv0gBWLPO5llH3rE0Gbxka3ua/vL3vqR5wfOuxaknngDlhJQ6rB9awU/97Lvxa+97AM95zrNBFNHlDjFGLC0tY2+6h8cffwJdl6oAmHF4teyaUzWxFKIJg3GNlWHMWQjfuwamJIodKShAFwJ2TckmZKr7/dlCGuqQ9/2umn0oyqhYV7mvNa0sdfWAFB4ZMjWWl1r07DDdwT9VdyabtgguU4Ano1iuDZRVYVbKjSQvD6hbpBuWyv+0oUggHzuIEUIuGRYqbc4ZSZqscr0e1X+5CA6rQMlc+ZzAw2hDEKEAV/AdqEsP1OUvrpE8yXx65YmKT2wdHFzmDOs/AC5bKwvvmJKAK8dziL8aHd3W7KxlBowlW0Dh7GttmAI90TQRu9u7eOihhwACxuMRGIzZfIHD62u48Iqn4W++5T34xKfvxOHDa2jbDmkxw2ze4i//xVfh6ief12xszdJk2Lzk8Oz4O95yK7qbbqry1X/E649VADdDhP/lz1x/7dK4ee3W1rR7+Yuujd/1mhuxeXoTgRhtu8D6+hr+1S9+AP/27Xfi6c96BogC2q5FQMBksoSd3V2ceOKUaD7tgydKNcAi6rYIlrdlWArJmLj8EEL2IT7X8PbA6+C7IkBSPuxLr74toRjGWneQYgA2hvM6fSsvNaUEWXwuLMVuZfUePXhbtwOwIpXKkqNvlc+aE8v9zbKzWTtKsBJXC5BxsGi9Brl03qIIc4+unBUe21qYFGqqk89yl/gc/+BjOislWv0qj5TnZkM/51i4omZ6ar7/BSpjNmXHBwnIKBV9udxVfiofOX3gfFa7FqaIDAnJtaro2YfSG1q23AuZLmJwZjQxYjpb4OGHHkGXEwbDIUCExSLh6OE1rF/4FPz1v/8OfPkrD2BtdQndYo757hYGoxF++Af/HNZWhnFv2naDQXzt6288+tpbb0V3881/vBL4IxXAzTcjXgfwy5+x/pLxsHnHbNZ2l128Hn/wB74d+/v7SO0cbZtw5Mg63v3+z+Gf/tIf4prrrkMTIxaLBQBgPB5jZ2cHp06egtGpp8Ar4hRymk2uNonYhYLRtI67WP+ezeQDioDP+gbIoKlbQO0+ox1mvOuMmg0RhJIKlPRgrhCLoIBe2E4FBYB8rp1qasVA9pn69W75qnlQzeDnePWYjIX7RXjFBRAAYjRhh77g5OOxohfmCqKzuADsCsbmCZ1XXUxUr4S9py5GNjQidKWqrgBQQWTo/v5cLKqtjl6XLQB3TgoE2CYju85QF+l4WRWzlI7Gsg6horAGOxmkqOePQNIEpecBJUTwv0upMXQtqXxckY6ZEQJhMW/x6MOPIKWEQTMAOGO+aHH+eUdBKxfjB3/iN/H4yR1MJhN0izl2Nk7jkksvwl/68zdhNl/ElLmLoXnHq5937CXX3QL+45TAH4sA3gJkEL2ViBoC46/9wMtpeXmC6e4OupSwurKEz335AfzEz34Al1x5DUajCWZzFf7RCDu7ezh96rQGw6gyZX3RhSrcAsqzSblodDYGMuEkZ0pWQguNzXJWyACM4Lvfq5fuGa9WzS0MO5yrmJUtlps1gh8qYYcH2Ly/XfU0NjMPVW1MPh/0RLxvqop7X/mYvREfMJbEfRq7MSbJsWVyQSkQ1/B5gbseCwEEJVVxkvK0g39bHEIVBpsIyvWu+E24D1h5S3mW7oZyaTEKFbGVAhY09uImsnyMohxVzPZwUXTsiqieRTDl666pljYRnLf6rwOCX83J3KteZTVz4XGNHfgICAB3CDGg6xhPPHECXdehGTQAgPl8jssvuwin21W86R+8DcwZoQlIi31snDyJG298Jl71smfS1s4MAykqeOtb/gtKhP8oBRBvuQXppdetv24yGtx0ZmeaXv3tz2yeft2TsHHqJDh1GI2G2Nld4Mf+4XswWL0Qh9cPYbFoAQYGgwH29ndx+vQGrCrPtGERZKWzwq06iCJCRJUlqIneU7K9FJqlA8uKQHveCblzbxFFyyNrUacJMTRgVdSBM67Vlst6lpJTdmsHOXHnrJdaKVMalQtgQuN/VcOXClyrXivPw4Hvuyga/1YVjUITcbXKbsiA0r6cII1HLJUaerEPgDVT0ntq9ZPhIXquMjbgkpI096RS8UJDtfqV314rVWaW7mCKvTywpha+gD1VPqy4jFPhLR+PunjqInnKr5oHG6rTD+vovlEKtn76bKruApgROlthW/bBipiEBxRtMABuwAxVAh1OnT6FnBkxyhMWiw7XXPVk3Hb3Pn7yZ96N1eUlZAYW023s7e7ija9/EZ582ZFme2+eJsN40+uef/R11pvjLKbR1zdTAPTmN4O/47q1I0uT5m1t2/HVlx+l173qBpzZPIPcLpAyYzIe4qf+1fvw8NYAl158EeYLqUFohgO0XYeNjS2FyxXud8KWpe6n/kjr3kP5XDCS+KxmsFwgy6sOAfaUgjICV6keMqWkrGXwzJ5LFrwhckGRxS6MKs0n7WGWerVnJFc2kh7UJxk/BsD745B11pXr+9SpZlbkyu9r/ywS4S5IzlUtAYrS8su5sooVUOCKpgRpdmwjqLV2fSd2ce/pJ3L6laV3EdK/sykkVXS6s6usHSRFZ2MoNtuUdP1Vq5xkyB6KUKVpGUG3Un5Tp4osyoO+MlL3TVanuH12k5qyTGbQyqiM9b39ubk81X2En7U+hBkUIhaLFhubp0CRAIrIyFh0CU+95lr88u/cjd945x/iyOFVdF3C3vYZTCYTfP/NL4WGe7mJ8W0333jJkTe/udiHg69zKoAbbkDzlrcgY9i8aWnUTAK4+1/e8PwwHEZM9/bQpoT1tSW87T/fgbd/9CFc/ZQn6yGTGU0TgMw4s7EtAuOVWFbSWqyd1XG7YFXLWQLAXGA9Vx52tTfGLZ4xk2l+XcL6dCCq7s/+Pb9JpSx8VZQhDVqKFZdmHVGvKSaCoj8BIE0zAe5qFFjKZW6cvYs1k9UTFAvlLypBUWazVW4CPfIP36rCGlAzGJxVMej8/fqsQqbf4SooyAUNWYyjqIiyJ8PpcEApQ9fN44v1eyx7K60Ow+mhirWg+pIZKRkAEXIo75zFyBR8lwZlRSLMGo6weEutbosgmzItQUsxCBp2KkajnmJvmaj3HilPZRjCqIKttnb2fFaMyIwYI2azFltndhCbKLyXM2KMuPzKq/DTv/Bx3P2NJ7C8PEHXLnBm4zSe8fQr8bIXXhN2dmbd0ngwmefFm97yFuQfvgHNQRIB51AAN9+MeMcd6F79vGMvWV0e/p3pfJFvesGVzdOuvRRnzuwgpQ7j8RB33/cE/vG//yQuf9KTQUTIudNGmQFnts5g0S5Ql98Wq5MrauWa+m6CyDZrG+OZdgS8+6ssRInA5mqxrH6bzuJGIXDZuWcWTZ+Tc4mMIynTVbCbSqS8To1ZtZ0M36rrFOpRAkMaTlptvcBAs1W5pxDK84qtqxnp4MtFkaUoJfiodXwmyNV8S/tuhtTBGb35wEMOCHjtPsCyDf3x1O297JaGhS0zkhU+lxoALWnKDLJ4h8bLi7kgRTpGkcqK2/Crz3zY1UBSDfi1RkFar2mZcJZ1h1PQlFL2u5J2gj2rKrF+PCrW0jmU3zMomzkpZM1cjIShBWYgUMT29i6m+3sYxAZEwKJrcXT9EBbNEfzk/++DUiFIAYvpHvb39vH617wI5x9bbrb32jwahL/z+ucde8nP33HurMA3cwG4ofDW4YBWLji2xK962TNoOp2jXczBIAxCwE/93Eewx2tYXzuEtstAAJrBALt7U0xnc/e7jQkKbdQfr9aILKVkhiRYXly/4zCyZK0FMjIkbVRQYy3xmbMH3spSoKolgFRyUawWU/620mRDCYQA0g0fpm7Ecpcto7XF8L+yBh8r5KMPVjfEWhEZoRh+PuB/wasunbVjxSUeESyA4AU2RmBJj7GSRgQ6KCb3cmcmiOsY4HUKGkn3rruupMpgbR3rkmkYarH59c2lfo3EHTBFpZbf1sSfU5XVWZ+/EnCtFKdrJgYHsdiByXnN93A6DQil/Vodr9AaBt2IhUwgjnC9UU2zftVpx0oHyri9nsSEwALkqpy42BwrUjpz5gzadqadr4D5osWTLr0It37hFN7+u5/D4UPLSJmxc2YTx46u4zWveA7N5wsejuIKKLwVfar7q6cArI74dd9y7KWTcXPTYt5133rj1c3x4+vY29tH12WsrYzxng99GX/w+RO44vKLMVvMkXNGDAO0ixa7u7v9Qo+zTARV74vPxwRYi5Ye4+iCkkNBVQbKRJyrAE0u0Kus7dm+XmFYZUQyry9U8NoGoAIEY6iqNBYoXYlMBDJAqSoVompMMLeCYQFAcstQBNNcIq64oK6WO/jyTUVu2XSWMnSdKaF6NEwfZFsGRwP2Pvm96yj6uTznio3Le9wX9swlINbzqoAqYMqQLsTS4vvsicp1OdcVfcEVhe/BkBofXxeJ2VjNgr3MpZCBkCLGftROo/gasKlCqt489OyJCwGLPj+whgBKq7fCncyM4G5OLQTyCiEia7dhkQedNwVcePHl+NlfvR2PPLaJ8XiIlFqc2dzEi1/0TFx1xdFme3fRTcbxpje+4NhLb7lFGov27n2QzjdfhyGH8FbOmS+96BC94HlPxf7+HF3bYjgc4PTpbfyLX/sMzr/wEgQKyCmLIBCwsyXdTJgskHY2jZzjdPIGBysb4kQrJav+Sc+S1Dv94Jbab60WuM+kVK1LGUW5u42vBPy4+NYahNSAuuswg4TGQ8JHwWF2uX91lDXOhs8itBVyUnr59mGzlufITdsVwdzLA/zJoZS6An0e6z1PP2SwW6pircjk6uyXW7bKyKtGCZa27X9dHhUqBasohUJZVw/GkVUQqnLyAKopLjqgJEtWQMIYpnht1e2++jmyGn4jkMWmtJM0W7PWfvFTr7zX+LZS6qbe8tlV1z3eOztvVN0PDAoNZrMF9vf3EaPUMHRdhyOH13BqPsbP/+ansDwZImfCdG8Ho8kEf+7bbkBKHRERJw5vvfk6DA8+pVYAdMstSBt5dbWJdGPXdXjR868Ja4fWMJvOAQQcWhnhV975WTy8QTjv6GF0Sdo9NU2D/ekU80ULChEHz48/CGerkCCI2fvcOY+R1UkzmFMJCGpC1gStB/sNJoDPUmsFsupEYauuSqi3HGqNNeDYg3KaLvQSWo8DyO9Z/4kvRxKFtvGVh2t/ew201RPnymNxZQCNxHOlPPpKoM7Y9UjtzImDnxQ6HFAmLvQkNMiWnqVKuZoiPHA/zpWCO5eSqJbIfpVWegdSrrAsjChNe9e6JPvhK+avU4n9C5y26wggPfTEYXetkFmLj5RHXDGwz4UBcCrukmV2ajfyXPUBVoLuidbauBsyrOoZnCiKanQxKpJJodDe3h5SXiA2DZgJqUu47JKL8c4/uA9f+urDWFkeI3UJW5ubeO5zn45rrjgv7O0vEALd2C6vrmpa0AfvonLTTYg334y4vD55UyDE889bS8951lW0s7OHrmuxtDzCNx7cwG994B5ceunFSFkm2TQBKSfs7071FJxqJ5cRsCdcBfDCNapaTWbVxrW1CE65QmeugQI8u8xedNZbaFfIvXeo3KNnOeQN6z9AqJtEygXirVhbKTf5qu8TzOzY/oBiFcWn9E0ysIq8DtAQVV+AyziqtyQQWm2EEtqV9Brg7n+hd0Uvu0aO2ap2wZmiM9hqNKjQhPU8dErZOlNlsSq4L/+M8w+ugTrS+rmhFDl6x5S6CqTl7m3zToWk+uZT1w+GOqqVpYqzKr9SkCqBaqLpOhlNuTpTwWNV9vVqeqz3KuMoL8sG1MXDZpy8x6Qpwl4gAMILIKSUsbszhTTOEZosTYZowxp+5e2fxWgo25Nne7sYDCNe9tJnUdt2aTKIMcfJm26+GbHeJ+AtzW69FenOOxEj0ZvatovPe86VcXVtBft7u2AmLE1GeNvvfB57aYxDq0tyWi8RQojY3dk70MyxjvTrYnNhRAN4/pVQRbzVQsptxEfOqmxIswZWwZVVwUh9DMP2FRTlcJZN1IXgwlu6SGXLhqksTdpUcQaXIjLFIQU03GMqKgxNLKW0egSY7zro60PVV0lPrsl9Qa3+6O8tAOrdbL0AG/XDkTCmrJUCFwRQu07GeCUVKt/Pug6ifKDxl94iu0WrQFP/VRXkWGS9r6wzLNVpc2FVtkwJTOUa6ewj9jX3Sgqrnoe1EBUz4bQsHzMKASwrUxLTxaZwoR2Lu+U1GLUOJeNv7+BQfVgpTa7HfQ6XsL5WDUigiPmsxWIxR2yEa7uccOFFF+DDdzyGL33tEUkLdi22Njdxw/XX4rKLDse9eRvBeBPuRNT2YYY3gJtvljlcsXLs+Rm8tr46Ss977rW0t7uHtm0xngzxwIMn8bsffwAXXXQROhbtPBjKVt/ZYuH+uMMxqielWvygMJo8VRq0dNVV5iSJJZQiEnIOcyQRSeMQWgBKxhyF6oXgdlV/H4FMqWLgOninC+wRe+8UWxishnlisVgzeqznxwewpuk8fuDfBZis+44EwpxnanpUzCJ/l76HNdpy+MqF4qYsBWWdvRY9OfRCFSefUcmfdU4Bt+ejsoyVUGXNgddQ2xaeKCg8Zs25F4svwwg9xeIpZreolVblfn6/N34K2kZMjUAoM6FYhD4Ee2IoiLbc3q25VxTq7cUgcaEfKr7wuFV52dqea49DCWqrpvHSRcb+/r4crBUCcmKMx0PMaQ2/+TtfwHAo9Sl729tYXpngRS94Ku1PF2kyjGuLlWPPB8Aq88UFuOEGDAjhHy7m7fDp112G48fXsbu9A86M5ckAb3/fl7E1H2JpMkbXyeEPzSBiur/f17K26UQ5wPw1+2+pCTCDoYt4AH7WBBCLUzEll91zOXPJF2o8QfXTOV4qmOSqQ94lHLiAewqBIc8oYQNFJG4xCZklfWS7z+DUVSRgSIJDYbwDFtTixwJvE9xSslhe0YkGia0G4dyiWLNT8csLmmH0LZHB+AJRDAHUQlbf85tYeSujYXNxBE0BCSDpUUGgst4k1jyz1nfkMl4/qZjh9C744qB4K4dRbydB9bJWb+xZAgYpYFAEapU+AOoah1yjHSZt1sr9oN4BBADyPjHCWxZL0dcftcmoj/rsFyoIiwiLtsVsPkMMYjhSl3D+Bcfx+59+BHff+zjGkxEW8xl2trbx3OuvxuHVMdqUhwn0D2+4AQO7fwAk+HekPf9w5nwjAH7eDdeEtu3QtgsMR0Oc3tjBh29/EIePHVPtxhgMIto2YT5rK83sUqyLfkAPK7V6hSJg2HZUs7zG8B6xJSkZzTCGVLfPfdUDisO0c/UMGWO19bd6GT7Jehimj0sRgy2VlaQC1gbMLJ4JjAmVfIchGj9QUH9S6gZSguSkFaqTooqiUFDdK0MCoRk5Z4fgxiiWJ3ZuqRAJo7hTvcl+c/MNFKr3Yqk1mgC8vKFn6fSJ/rPQRqnPpSYC5kvbgLif/iQwWLW8VifA9lucbSttbYUGnuPvoRebnt6bLCwPye2jUjwwFynAWh7UAed+SrE3CEdHhlBglKjWzH7mCqnVdK5/rzMfNZkDAqbTKVhPlM45Y2kyxE4a4z9/4E5MhhEpM7bPbOL8847iGdddGrZ35xwC3XikPf+wBQPDDVoiOBjkH+SU48UXrndXXnER7WztImfG6vIYH7/9fjx4ssXa6hJSUusfG+zvTWVp9ERZUm722n3ljroKChUjWemuQXOzSmWe5FAyuD/KIMq6kPI/Lxw0ohkHZ9uYUgpWTMEcVBjO9ZVfZkqsZuMi6OgtccUD8kwuZaqkSkz+ZQSSMefK13RQXfme9StY7Sr66KCfWuwzyx8l64X+qnT19ww40nSLRb0fADKClg8DCXK6b9nmXFyt/kv0Yql1AJMc0qtKs1RH6jLk+qmWmemjkb7xKfCy5gePk7jAAbAGniSiKsrdsEPFL5y1jLh6yjdRQsbbpmjEUplSNheoCgIeQAG94Os5X4U3iYHcZbSLubTVI0bqMo4cPYoP3fYgTp3awnA4wHR/D6nr8PznXkPEuWtiiKNR/kEA+OEb0EgMAIhhQOttl+Kzn345lpZGmO7vedee3//EvWiW18U3yx2agWiX+XxRcqeu/bhEQvuxQADQtFLxV6F+lk+RCgOCCyowS2m+rClGVmJ4IIwADtIuWhguOCcTDqSc2EQazpg1LBeWyr1tSbZn3cyCZCYDrNZefFc7hirq37ZsZq0NGpvVM0UIRQwHxqA56VqixTqYG1DtOXCUZDD8bMSD6u7m3/pOTZh7xXCfR++VoYFKu78Ju5hPH1d5FUXrat8QDhUFGcCgoIVT8h8tZbZLyJGR3Ks0ZREXAkXYXDnIvIlYPDKtAiSyg2aU5gRkSq6C2S4lWJG0vkqy+FxZe7vMf1eGLUJt8Z9KeSiP9mM8hYbW/6D3GUqMhQMwm87k+hDQ5oy1lWXcfzrh47ffh5WlIbq2w9bWNq695nJceME62jbFEGn95psR7wAQ7rgDLW4G5vP0g0SEZ153eTObztAuFpiMR7j3gRP4wj1ncHR9HamTIp9m0JRWxhahq/wi8X0MCFWWBMUa96kNF/YA2wxDhVlMs3JBFMZ8wgZaP+/87r1x5JilaoGsSYeMrCuLqdcwledIRoL0d2XIINcmzp59kF2G9mzRepnFSpNxqLkuOh9QroSOfa7IdKDllXz/7KBWMTKuUExQuXO3IaUOOSfk3CHnzl0J+dnJ59yB62ty0mtY5piMGFRorFCBFb77gHqvYpWJFb4za9pGbmRn9TGrEiX5zIp/bTOTBkDQt70BSubq2VzpPJVkjdJx0FZvJnC2CcrLnqu55OydgnwuZOtdvevsWyltKkgCITjqJM3xu+K0l47fS95tHm6ozlbgrKXki0XGom0RKcheCgCD8Qre98lvICta39vdxurqMp7x1Eua/ekCBPwgANxxB9oAAGe+ceTb2kVaP//Yar70kqO0vbWNlDNGo4hP3H4ftudDjEYjZM5oQgRlwnQ61VbZQhyRO/INL0oJOHB2GMm9qH893dLxpYC8vkuga4QC3+wTr3cHADIBr0FwseOlLp9gvqdrpMpa13vUTUbl+mI5s23sUCazKTOAnFQoA8BZg1NcnpsBZG1QUSrahCGt1sD8YvI5GjWoyKEFXOExbKfZ2TCzxBQswu7VmBX9RSgL7M6er7eiW43Ks1rkg6WHps6rngNuDf2UIygkLsRlFxBbz4JM6pJd0j0KVhhUlWOgaClyepZVZd0zIWMm7elAtu/ZXJSeo6Ez0rR0/T5b27X6PcDjVeAi7CW16kwmqBS5BBrN7eFzBF51ao6GmAWJz+YIJJ2fui5h/dAaPvv1DTzw8GmMRgPM92eYTffx7Gc+mQDkEGl9+sDxbwPMWGe6qctpcO1V56fJMGJvbxeBAtpFh4/d8TCWVldgzS8GgwZtu0DqUhFwtmKK7IU89aClOcPZWuzgqz7k4pxpEVtEKy1lURUBoZTQqZll+x3FDWNlVmPaSs34f2uw4krFK8vMV1UkIsbE9ySwMjmTnCMAhfuGJmQ41sRTS6WZ3AqRF0lkOSAlcUEDjiSoio73LVQxfH3afbPUk2UUAtUKQ+Zq1Y3OpWTgU56VSdQCBeuroA9nqtaH3aozkq5RnfIy5VKtAZcTrtwnN8vr+z1YEJamx9jHJzERScRQpSzFWloFp4loOU8ioLREk/tYeg+AK95vysHc4xxXXGelb93QnONF1Q/jh54Bq0CzjQkABaBdLOTU7Ch0GY+GOLMf8OnPP4jxqEHXddjd3cOTr7gQx44uJ0550MR4E6BmMQMpEPD0qy9C27aYz+YYjRrc/9ApfO3hXaytLVfBv4jpbOaMZjuy5GV7ytn5xgdvPvo5CHDQBzr4WQ2HnCjmg6pVkt/tq+zavBBVrg8UnRn66UCjqMYdPD5QovpQJefZMh2LMykA+6UvgxkU2I8lsyozKBy1LIEP1iASqW/urji5p5M1ixCU0L2yFaJeyqnQuKbpuX4vPQztoaUduzILBQQqNtLWlJmQk9FFBb7c2dfOl4i0VsRKfk2ISBt5uB02C58RAsvBLUGyqBJ/If1d6Gi0MMVt8zZ2IDIEWkE1R61moQvPuKoyK95DGoC0Xi+9Ecv5DuUaKisDGIW5FF/Z7YihrTwKbevt1fB4C8r9GEipQ5c6DGKjpxERRsur+NjnHpZDSImwv7uL9UNruOaK8zBfJARiyQK8/lmXH1os0g8vL41w6aVHm93dGbo2YTSI+MyXHsHmHmHYDJFz9qDgYt7KQtlEfAahMG9Pc1Upl4qgB6HRQatv6b2CmhiFi/VROYM4IdheDucwCxTpSHThJIgnFoE5FBQDU9yhukkhfA1JmQ7AVqqAgt0oCyMW9zgL3ETyZhScdTtxTRsuu5eYgLJRQgWB2avwcibt70Goo9RA7S4YjM99Zj7LnFVpOPjU7Ar9Kc1eUk7wGEzO1kPErXDRKYaaWGWtSvfmDE4MTrY+1pJN1zYEBC2piAQMCKp4MhoCYiTEyKCogT6wKgK9TwzuUwsiYEjvg4zk1YLk60C5ijcoYjOFVQckD75q81dnmFjpzOlA4ZNdYd9FHd9hr/cpHZtREBCKaPmKyJJgsWjdLe26DqvLy/jyfVt4/OQWBoOI2XQKcMbVV13SLNoODPrhm5516FD4se960u6iTcOLz1vFkUNLmE5nABFyTvjMlx5FHA59oQdNg7bt0HUSeckgr6SSYFcowg6z+NZC6ZsQsA6eHHivrAfX/NTjS+nLTmDEghMCSRZANwYwy+91q25rDik6xQQoiILIAPd2Tao+5tKkgrx2n0s5aDWRTJXisppyQOMP6ko4QzCSCpHoOXURVJsbAGGzyCSIyvaa2Rn3DNmfIGfclbMNWN+zs+/Y/mdBOUCVS1JLWa7rCUrKurU3eGcdj30E+FkHDqYq1q/BrOXKAwEhWqYHCJQRAxAjI0atxqOMGBnB/xFCZMTAiJExoIwBZcRICEHeD0F+D8SIGiMIpNkGZsQgzCQFWRKbydW8BVkZquO+ya+QAzPcTarrV4yXqUJiZ8WyDrCy3dopVqWvC4IQviWwulNJDUhA13ZICnMyM8bjATZ2Eu76ximMRrJVf7q/jyuffBHGw4iU8hDrz94N//x9X/+OlPL4SZcezYNhg/lsjqYJ2N6d4e6HtjEZLyGlJIsWI+aLuRJJK77qJDypltUIL1tq7cBkvxnczzWdrYUWqXLhmkBGDJZ9BFmLhPR5nm3VA0CrGJDZn34HFvPZKnKXPfBACfKQdq1h9xHF6bGipyrPXME/ZhMmERRWWiFENXlyJpy4T/1CKDksM/shHDJmq09QSOtEM8krik4HUQggoFno7flxU3qiTLIqEEGjVnhk5lkto8EqKh+xqWCL7CPIVlpdTzuz0aB8DAExEJpIaCKjiQExBDQhIEagaYBmEBEioWkCmhgwiIRBlM9jIMQYEWIjf6uSiBGI4KJIoC6C3ncQgvdDJbFbhUShQoOA09F3gPbqMdgbV5uAB0XGFgrz+eObvLgCzZpVkWfJ9TUqA5sskPMmacC77RISy/kCOTFiDGAa4It3ncQgEnJm7O7s4sILjuDokdWccx4f5a9/RzOfta8cNjR50qVHupy4WbQtlpfGePDh03j45BxHzp8gpYwYIgjSt9zJpaeqCMQjN4PFF69m4b+eTYqDuc6z3q8Vg1ptWOApqxZWufAdiS7sbMFrGwLq34rVFqGxgJjf06tiysKbaJviKOfyMaTOVLU3AdDqQttOyknHRHZinSk68nuKKxFKaaz5sbrNuq4yE3pGGJIwrrb5MwucZj2njrkqRAHDsyPEVfMkEXqPo1EVSRdHVcYbxQwSqKdwzMIb+jIuD+qjBVsXi7cEmVPUZhk232CW1cZLBE1BIDMjWviQGZmioh8dg8UXcvYDXxNDs48sNfTqu1na2vsGWgo6sZ5QzX1eMpPga0HwPQuWFocpQaURkRYfUc+QFdtUkKQYT1UKamSZtBiMS4aBVdlwBHLHSItOj9vLII4YTZZx532n0XZy8vBsOsWRY8fo4gvW05kz+xN0eGWz6PL+0mSIyy48jOlsAc7AcBBx78Nb2G8Z5w/E748xIOeEtl0IbKqE1nwUUhjtkIUz/HTeWoiNCav3MrRxhL3OCRLYNSVgUi2WhUjcFJBaHSWeRcuzRs5JNZTt5bdNQ/a4bDXjmRwaOghzRWDDya7UWJkIqv8JlVWwZXVEQbBEFvQbriz102wMwMJsAbY/3oqCTNtqF0ACrNusrAmj7Jq0wiRVE7p2gUhOxjU9RvZ0EdzcU+TsYzOBIDYkUZhZ5kiKaEoQTv5lEEUEFijvcSRIcDYESc8NglRLktJ0RAsMaAZGRIntBOznJRwKG2h5iJ28KkgwBGQEUM7oGOAYQDkhQ9wBBG1iY7tXiZxfxL3R+FDl07GjQ9ZDREucyFaw9v8FmFKPNrURBOBW3lPS5jYba7MFBKE63ZClDxvst5UPUttiOB6AY0DKGUuTER47uYHt7SmaQYP5fAHiDhdfsI7P3/kQRqPhfjOfp/3zjyzjyOEVzGZzMMRH+vo3NkDUgALQdSy9ytuEYj+qiYncw0ZrTOKME4Kek1aEyFGD0cQmWvObowu7a5WfZV0UKk0aAsmZ9AlSGVWn4CyQ5zLCRsXyJpGJukhfnbXIDs009eQDl/c8rkYB0a0luQIsSKPk3b0mIBSayvkEXF1jkXOzropOciGYCbQpYSuXcSvDhcamYgAgWeCQRaCyhJCdDqKoI7SLpVyXFY0Qg5MhNA3+IVRdvVmbxCq6IIWrUZUfRTSUEENEoIxJ2ENGwCgsMKGpIHFHAhlRHS1DPzkDh3gPYjo6rPI+2twgIWKeh5imMdZoFzMeYK+boOGkpw4BIQZwSKBk/BUFOYSynwBgcCOxIQkZVK6QqvTCA4biBKURtGLUCG5sb5CqRsGsq6586tiMzcobbxg60toFqNIBYH7IouswZhbFzozxZISTjy3w6IltXPWk49iftehSxoUXHlX6Yr9hpO9YXxtjNIzhzLb49ykx7n9sE8PxCDkZhAnoulYmaBCGqmYSbMJSzbj+rGAd/5wOKAHmHhUqhq3uX7XMKfCq/K162o65qL/pFp0CtPmD5IFZdTxyFcH2Ei+zFNHHIAuvMQIqaUBSqc6VZcvacMMQT8l6V/TKVU2CKRW24hqzJIKt1GxUxGFpeukWJoM5uvLwMu18QC3UfhqTUUAsIdTigGCVeXL7CFeqilEzMjSxCgTxyyVIRZqaU5UabKckYUAJa3Eby3GKGISikQSWB8pgBA0KKhEhTVqJqtJ6WCef4MIy5ASgQ84ztM0OAjK6RBhTi+1uGV1uINV/DMYAREmUNxKYCJGgOIslMAAuvBFIkSbKdmo1IClbhkbWx7eMVXQ1oye9K4vyIADButq6XmAxqLlwcMFmKIbRt6ULos25AzIQKaLtWsSmwbQLePiJHVxz5QXI3RSLRYvzj68FCgHztvuOJobw4vVDSxgMmrBYdIghYDpf4OSZOYbDifiCQXKti24BsYWNM2bRZey+nx+6aFbczLAvqE+znzEkWY7iRKC6D1WCUcmK3Ud/SnfbWsTEaslEhLlDKuMkEEp3mZLBcN1FRnH13/TOIleGIAxm1LRQ5aATzBas4wKx7TPiWiGw36M4CcWVcZRQ7Wx0sKWqzgODNmaGIheloToVruMsrek0JVfwTkPPK8q/oPvkfY6GHCwKr8IvsZoGwwCE0GEpTLEU5liKUzBFCeSF4NeAoqIFVR4VWRV1ezm1bagykmUWZJAyI+aMxA1CYByNe5g0HWZpALAVVzHmuZH37OAXQFuDyzolNTCs65MzIXNCDqKJmKkqBw8olZWVy6j8a/il8LrNpbjSUvNgZyCWmglX9EwezzIpsbMagn0nszar1axHHOCxEzsIxJouXODwoZUwHDToMr+4aVPOxw6vBAahaxMGg4i9vRl2djsMmoicM5oYAQ7eB8DkuRxoWSSSUSyyiaYxuGmwvh6o3nEnuRLeWjGiOCC9q92fcvvmSsAppnAp9IJWtiD6WSVkOXPx9XRccknS75fgWVlQVoisep9NfM8eN0EshXezrReayhgtKgyCtMwyZKBTDIEk0GUBtFwjqIMqskynRmW1KmcluKsXBmBVk2RBUvZwR4DKT6BSKBRFQQQKGMYOy2Ef4zDHKC7QBNbI+ACDKBmAGAhNIE3fyVZrC8Z6alHZScZUhJKzrzhSZt+/kDKXvzlizAmcWylPUt5IWRqPZASkLPTbzEeRM9DljNQBKSe0SbZw55yRmJETvHS3fyw8CeJT5W/k91iKvqRkgnVDIqtrUBCYb7CqxAJZPBR2BFRcX1nTALDs+QgxCrIIhBBHeOCRLX/2Yr7A0vIS1lZGePzUXm4CIRw+NPatkk0TsLk9w8b2AstHRasFaipLXlkr5ipIXv3XeEuj0RWXHQQBThfbgXZQSfjvDnHJm4EIClX2rTWrEhZEDstqd6OGW2bASWGVxQCE2FVJpikUHzh70E0AQBEMc0TsvBoCNIJfAlulNkBBJlngzKyRRqWLmZZ7ZGgJnNHa4gwlJmIjkJ5x2X1Fi3Kjem7vPABjOBhy0NXQI7bMhSUVdrP6IZDWgGmqDYRBzFiNO1iJexiGJPA+itWKsQh80xCGTUCMkhIMQeF/hQo8E2QK1QSMGclalLEU8qTESCkjpaz7KYRmSQVOUEJRIMnanOUOiw5o0gw7aYzUZUmtpYQuWZ2G8HyXTWnXewBUKlRwiyEyhFKCtbBgoWU4sgaTydwZoa0kfeQ6SV5k52nhpKTKXPiBGeiYMdBqQoYc03fizBSLVrJAi/kch48cxurKCI+c2AnNIAasH1p2WNXEiK2dOeYZWA1RGCiQ7BBrU7HK5n+wIgHf9AGNyMOtstsYEzDFrCWIYZ7SQevOPQEXKFUUgbyfte20yryeM+D+kt+/tmoGqU3bVlaPVNCrtc1I6o9KCbEEM8V2lKBdUTAO+7OhISWGFeewjk+htwUKc30b5SbrX+ioqrEApwq68ZdhJkuL6mRCjAoLdd08hiNWVrYuS04CXO3uBHoIT4RcGFi7r8mKkQh/IMnhD6jFStgXwY8JIUSE0EguPxBiDC78MQBNEzBsouf5o/4bxCBFP8pvpUin2AK2+eciyGb1k1voIuztImG26LBYdJi3jEXHmC8y5m3GVreE7cUIi46QMEVKiiT0J7OtT0GDVPFOsXOklabCz8wldGnLJIpAGSxHVw5ZITwqbrWSalP2JUCc3ZjUMcXcdQiDARiC3gdNwPZ+65WCbdshBGBtZYyUGE2MhOXJSDRmzggB2N6dSdCJIEUhRAq1sgpXOSjBLbVGH1WqFHJLYYvnuFHiBAgwF9UXV5iTei41maU1AnNRBo4N3XIZ6Uqe3FfHGMcEHIXJbXQZJYqedVyio0OlvOx6X035ywTLtL0LbUEE9XMztKDI0nkkWQsKGlwMEVG3r3Y5YdF2yCkBSbfu5gRC54gs6LgoATkUpiC9rz2fmcpuPA7CiL1lo6KEbLqkCkCFP9je9kCOBsYxYRgTJnGKEBKmIWCuVnzYEIZNBEdCjhmIhEEzAA8aUIigHBE4oqGI8WCA8YgwHEp8gKpnm3AZGJMOSZLiFaEHui7LvyQ/25Qwn3fY3W8xnSfszRaYzhJmLTBfdBgOBziTD2EvTbRbU0JmiMVH9kCjaho1zn0k6TxtCAlU/H5Flk5MCyA6dDYeKkaHAmm6kUCcVPC16Y6lCznB0sdMRV3knIpM5oxBJOztd5jOWgwGDVLXIRBhMhkr4m+E2BZBD0Q4szOXIglV8yEEPeqrCFrB+QHm93NmqXRjK61Sa8W1wBZKsRtPdghaAn6MHp1QCb4+XxCGFYoUeMgGteyrZIG3IsQWYTd4b+IJzZ8HWEEIVJtbLt9XCd72zCxmNbZswgSgYA8rt4MG6qgIGQMhRiAQuo6wmM/QLeYgnuK8tYAjRwe47PxlXHT8KI4dXcP6+hqWl5cxHDaIMYowkgi8RcmlgQvrQSZWrGSWlPwfAEdqxpPmrrjS9HFTj46OBADEANQ7HS2VFyN5JV4Yn48Qhoi8Dco7CKERQQ9m/aP/LEjFYjZakMRcrD8zkDNyTkg5I7Utuq7zDsZdl9B1HRZtQtt24JyxWMyxt7OLtdUlfOjWL+Ddn9nDaNShTRozUObMmmEw2RBEVqpOiVlcZ82pWaqbAO9UbApUUhhZZTyUoG6lB9yQsRhZ62VBrDIGM6pVRgCGLyp62DtMiLHBfM5YLDoMh41W9WYsLw0V8YeApolmtEFEmM46H3N9pLbc2/xN1URVukxZHAhBi3pI86LVS7WdQNV6FxVX1l0VijKl6AjuBVYM9ZsiMA0TlBCmkXvwq/ds0SYMsZbBnlVZGCnqM7Vugb1CC50hyiEWZQVdJalCIh+LfELVIGOMSBwwm8/RzbdweJJx3WWreO7TLsVTr7kM11x5IY4dP4LllTU0gwFCVJfB7uexBSktdiuuJzb57/Zs0pScvWem3SN7hvErpeGfo3zPf9fveNdk7n/G1e80hFiuFsht4XjXwly9R8JRUrctgp+tUWqSvQmpQ+oWyN0cuUuaCkso6TdR0qlrpRVbO8f25ikcWrsUH/vUV/GJL51CaFax6KQ5SMoE6N56Vr+/7B/RtdWgHSvjkK4GFKW4gLpBQ3FH7DvGstDCqmJHPB4l3BUrGiZHILZ70a1H7Qfoc2xZBg3QdV2lIKTYLxDQhEBoYgk+MAQGib8bECCn25of5HlSErCNzOVAB13EkgWvxo5iZe27tXIBa+iJcc5rTfas0tbnrdbcmF4+5ALV6og6lbEllm49gQhZz6OjqsBDFoq9mk4T8YXvAfRKoY1ZCbC6fxc+tnSPTJCsYjE26BJjb3cHhwZTXH/lGm668Xp8y/VX4dLLLsLK8hI4NGjbjHaxwO7+HlLbISdxATh1xQqQIQ5FXaTziZIyrPPwREGgdwz6ncYpTUE/I1MsdcwBBdEFAoWoijn4mpTKT/Jn2XWu/IK05gIAhEb4qGwLdPqy85T+U3+XtUNzbveRulaNj8UiYlVAQEAYg8EYjjM2H70PTzx8Hw6vr+D9H/wafuZXPo29eBQBUjgjQcPgmQWXKRI31KG+KofCCJUwG9KshLp/tgTKHhQoomS7QSU3FU95Bp0YxLEY3axPNBTs8Q7S8zqlvdzePGM673BIg6Q5J5F5EJqgPpbBRqN3INuown4AiL1q2OiW3pbMlHkwC2nzUQYzebe22FSgjFn7oikItaIrxydToY8P22BRsfZOENW63jOEYL0pwMjllFyr8NPZSP22am0PgVe3N50D/6WKWMMDQDJvvXPOCCGi7Rjz3Q1cdjTjFS+5BK/8tutx7bVPxmRpSYJT0z2cPLWBNJ+hXcyQ2jly1/aq9UqevPjKolikDCrERtZNhV8EXwSeQiPXNANwtu9HgAmcLE6gysCZnSQLqs9jhfXivgmiYFMOeiCnKx9bT32uKIEMNKvgyVUAIkCiiMhZQ62pMkExJNoybP6ECA4z0J4CBkcBstZeomS5OQbKD+PElz+Mh75xN46sL+OzX7wf//ev3YZpc1zPt0zi8iJ4jQCyVVYWXqJA4sU5ekMVnBZDBEO8ZHxaeJZMPhwYWaFQX/gdhVYgn70Ppb3HFjaScQaIy6ouX1AlGKjB/jRhseiMKWHZPiKgYQaianIbRM5Zh5Yr2EtqbYtuRi9ApzAJ4jsHXUB3FsjOnLX/6nXZ9gvoswkHgmdFCfSsqqVM7G7VothwXLFoRLMGFxwkYp5hKTgLBtr2Yiv2sXuxPtexjpHA/eDKb4EFNMy9YJadaCkB21sbuORIwhtfcy1e/6rn4ZJLL0DHwHy2wO4TT2Ax28diuod2MUdKnSqNIBH1GDTiHnu+vQfLQgQqYSdTACbgFEEh+kEqdi2IVOnbusGtutEYDFCU+0ODvmLJTUjtAlUcgCikUMqhveiKswhruwXqPgsMjgGjS5DDCMQDGLwzHnT/FwTbjhxGVwAkxTloLgTiCJmCbrqJyHmG4eyLePhLH8PX7vgUjh0/jC9+9WH881+9DWe6NYSYXZh77l0u2SkRPuOj7Iqpt723ikkEf7PwDqmFd+Nm/O1NWwt4NaNVnqEoQIu3+pZP5ZFNsahr4OsmPCjBfPsaV/NiNKKkiwXzzQuhPIaNoTPLDrDqJbcqxSzmA4lmi1qmChRPXFNLto0Spu796r6gOjUNaRhR9RlaHVGTpRezqFZC1qFwNdt32VRXUT7G8JYmNK3e61+gp8f0cuv14DUlRyBwCNja2cGhZhd/47uegje++vm45NLzMV8kbG5sYj7dx2x/D7Ppnhy7pgJPkRDiAFTTgCX/HaBR+WBVaE2fch5MZbGGCk3LqygribAn2XRUxxDgEKpy1zQCbZbJLG6ogopZ24X5GlIRhEqgTOWi20Bu1gVFUCzVkRZf0Saq1tLN3YYMEGXk0EiNfO4kvdluYsiP4qEvfhRf+ORHcd7xw/jqXY/hZ3/tDpxaLCFGQmqlBDiQoJJsdfzWKkwb4FgNhwU/vYcCIEbEBNDfFL4u+1+qdTAlU1v3il96zKPyYHsK2GhoK6x10WTCWvUiKAVh2oZFLX9dPBRIanpdYOWujOm8q/Ko/fr4bDnlmtFU+mwgfpoNEmS3Wg1vNJLrkNo0I3nMqbc9mItg2vvE8NJa4r7g+o4sjwnY4ilZ2ewJCv/b1Il9cUOw2v+ysPWftvepWBD4tlJXpgpV5x0j7Z/Etz/7CP7GX3oFnvrUJ2E+73D61Ab2dnewv7uLdr5A8Oh3FWxgFhZwCGkR6WKdTH9aTXydjhXfuDbl1KMpUaVAS+TXrTwO+v86e48RWNDRkUjU5+l7WjlaYhTVYgHuaiC3oLwPdAK1OUzgR6RZaa2jQT5wH4l3kBkdZkR+FA/e/l589uMfx9Fja7jz7sfxr972BZycDdE0jLaV+FNslG5VGtfQZVJXSwJD7OllQ31yWYH8VpEqWYTsEL8s1wG3ovfiYuWB6hmMgztWTUkJqrZgo2xSK3rFc+yCzVUujHY29sZ7plUlldk3J5hlD7BDF0m1imx+6KeWALlpUOjhAyKgaLTgcmlFJi5XJnxUEataaGcgi8Iq4chhWpHQoiz6MQbr4GK11qDC6/U8akVifjbAnpIqjzMnB6jrtxlA0zSYTnex3mzjb/7Qc/HG194ICg12dmbY2jiN0ydOoF0sMBgO5XAHvw8rLTMoBcTGrCqDoyowX0suPilnpW8pRIGNU4W97nJcTdaIXhRBRQdZ7+BW3YnmAm1BQMLZ3F39XQUGLY1YPmdQmiKPLgdl2W5el8gWcqsA6X5+v0+W2g3khJjvxv2feS/u+OitOHJkDV+79yTe+ou3Y5+XMBpJSbu1G2Pt6Wfo0Dd1sZSN12RyOgYV/KKfYCgxK72KkrbvmBLto0gljBjaaoM4QLovodBHiVwFEYOXv8tjqdgftwFUoQ4dS7biMkLjCweDFAZpqEAXMKA7zIoCLik8D3oHgyhmESorHCIcuuvCW+7faOXujQV/Kt5x2HWW/2XkLvcq68Xov1lSjf45A6m2Tn6/8tyiCHQ+HvvgMn7XIvJeMxhga/M0nnfVAH//R78HT77yYkynLfZ2N/DYww9jd3sHTdOgGQzE2qTS2z9EKbSRgA5rrb/YNxd61/Ym7rWYcPm9J6i1ImUfL8NiNmZdLGMRytzcrSpuhCtH588q6g+qEAOqLETp1WfrZ0YFzRoCDcHohLG9AYqlmyO8CWdvmqq8ckLD9+C+P3wnPnPrrThyZBV3338KP/kLd2AvjbA0iUgpoxkOdGpRjRgXwWEzVQKXg441a4MGSSOb4pHBWyGoRgJ8NcxA2TxrfnGvFwxUPQqJDigdNVoeF7BComq1ofzJulXd922BYMfVmyLPB65vYN+rKDqdp2qXkjJ1yP3Fhmg1g+BlF15hSeMxshn7I2zVS6OOetK67uVRPY1pvxfB7isF6n1VlIDd74AyIH2WqH+/tQl7cSVkIi4uVJpI+DgtoEMBCBHzncfxF7/9EvzoD70Kk8kE29u7OPHoY3j8kUdBgTAcDqXiy+rKWeBrhgp7UCjM5jOTWw86IMiVffCmKPVZeR5wc3fFau6taEdnQaSKpVYoldWuFIkrQ4sXuBVUFFFleeqeCH0lbc/Okq4bHgVx59bUUGDJzQbNIqBXXyIWsEPDd+PeT/42bvvIrTi8voJ7H9jAW37hc9jqBlhZHoJZyotlToa4zIUpfGb79inB190nmcmBsfG/uVoJ5iaYDFQWDNnnw2pwyOMLSpgKUpQeD2rFUUH4ymg6X+q61Uj4bEVhl5O7F40o+lAdDpG9rLQoEiq5VS4/nDFNttlOsLVqNKUZZ4F1NlG7s0J0KMOIf1SKKLhiFpfDiqRGBF8is1z6DR9XbRwNLXBfmMp4+zCiTuPUxJeglxaMKEwNQY+13n0Mf/sHnoPvv/llmLctzpzZxn1f/zrObJ7BaDQChYCuS4hNBJHWXISggT1Jj0lQSvmiyjUJ2g49ZOIbSKJmL7Q6jbSEtEArY7SaVvoKJHPK1i/P/SLNsEhkvbcCrnnUBOi9ZV9IKRizGEEpCdeLD9IaJQ2odl+9PQJx9OeXZQiQHpSEyN/AvZ94Oz76/g/i2NE13PfQJt76y5/HVjfE8mSoYQ3JTgRIulNQiSnQyqB4tyAVPoZY4VwhSIL0hyRtQMusDZzrmJQIWtlirPTUZ1ltCKuxzGTZJ9tnU8Z0ttvQN5r2ZHP9ssNy1hoGu4fhFKgLYEvCZdCJy8T9SVk6sLkjcMA3q6FNzSQMGYBMVCGSJjDFl06gKpZQ3IOaVDbKOspusOcAEbj6rNKUjiRU2UuQtCIwoMHu7ErJAqmk92RfR0sZlsIQikGCuNPH8FNveile/aobsbc3xebpU7jrK19D13YYDIdgLQcNQVqsmZYnkpoKj9bmrE02RDkHT7ToZhOGQL4QYI0qLEBrm4z6MRR2y1qEEgUheI8BW74DqpYB26Zsa2kwX+zAQSuvk6phIwW3POUwEl3XyZPcjcqGKW2vBEERDPoGCAkZEU3cwL0f/2185Hd/H0eOrOD+hzfxj/7Dl7DVDrG0NBIFQVE3JkVQaBQBmSVEsfRsI9L/hrJJCyb8FUtKzwCln/G4KyhDeH0eFbJ3wkHuVkJlivvPR9/lhSEHUqvvT3JKVopVi4w8oG9zzYoGLCOXubfWk6Hkm0sn+TKYUh5aP9aWRN4zTePWFma+5W/z2dnGqAwP7V2XfPzl5FvWfdbWa82jmvRNtKNZRRuVCX/lLtQQKagv55u0mBE4F7IoreucLqfsARUR/sfxj/72y/Ca77wRu7v7ePShh/HFOz6Pru0Qm4jUyUYTO+Y7JTtJidGljKxxgK5Lfgw4++IVlFMLV71Chr48mm+fGWT3v6sju6hCCbW8O29xuQfsklDds84EUEF/FfSX7xQk0ksn5j2gOSxTmj5Q9oKQnbdoAmablmz+DFBEE/Zwzx/8HD747t/B6uoE9z+yhX/8q1/G1qLB8kSFPw4R40BTq43XJQiLFfoy10ZKXDqvkK2tnPEfbH1qJkFBq3xQ+OH3LC3XfVFQDjpUmrms9PmbVahdgLROgCv5IsoFKbpxzj0FxQw0BgVcIJUoMHhi1pngRRy1EFUucqGPEpLsPWNUhsCbYAVCpZS2VoSmaq07ij+zZsiqv1pdnFMLLMMyEugVLJlfz6gu6FlLewWnvYd1CNJOzJ8ndWl593H89N96CV7xshuwvbOPB+69H3d/7esYj4bCZG3ndIsxqoUP2ilGfNOcM5DFe096QlYcxMp10gBtSiDK8KOyAoFDBBIQYtIiIekMk4xGsWQrQJr7hm5oShkcojf0EIOWYYek6HZ1FXzIMVRBjqRGSCBEWArL6hXsu/K4pGutcYgQAM7gwTFgsAZujsjY0kwYOSdQXJKiHgCECNKaeJPDxEAkxtc+8u/woXe+E+tH1vHgY1v42d/8Kra6AZaXxwATmthoxyExavW42JFPVY/AOBB7MZ4x1INedL7v1hhDsd+zfsn6a66+V8jGIpxaNyH2WEXfYafcjsDesNQtvhKFDfXp3xLw0zRwJReu98krR8pDGIxBo0dUV5a8pLqqHP0BzXTwPds8UeAkWVq4fJcqxrT7V2TsKRuFkQZdJPAi6Rr5nJzmVD9fieCLqgJFFYGLIizXo/e5aQJya8kAMgW0O4/j7/+15+JV3349tnd28Y2778ddX70Lk8lY+sXBDquQWaWUvPy6R4sQgA6yrU77zKHLyF2SJhpNg8FohNF4guHSMgaDEWJsgFCKhUjzW4GiVu0RYmhAWl9glYLBS32Dp/bMsrMKQXm//7vQziw+9SmmCEHWtgHiEhCXhW7zE/CtyWEEHh4H8QLUbYLaTaDbBrWPixoZHC+KhN3ZAhhIOSNOlvDlD78Nv//2X8PRo0fw8GPb+Ne//XXsdEPZ6UaEJg5AJOcKSKWk5djZBZB0H4lU2pJkXRjw/Rwwwdc0Xw/S1yanj9DcPdUuwlYvcLAk3q6Rd4MaokpRoOIRRyj1q8RF/AIiZf5cqoddRuQ+1ltRMswKSXRoSHruYoEYqi3VzHPOLjAeoQRK2lPlMPf5AiD1p3SMkmaxdGCV9zerzZZNkAMyApOjENb3+0G7HgYAAD1shFWg+t9lH0vxvfs5cPR+LzNlcGI0g4jTpx/DD7/2Ktz82udjd3cfd9/9AO76yl0YT8YS6ItqcXSnk6MiACGIFZcArJ8QAApAu2jR8gyj8RiHj5+Hw+ddiOW1w2iGIxAYXdsida3uhOuQuw6WoZA5lU05UpEXvEbfBkAhesluX8iDKgxRxV42bOXF9f1B1eYjoAT7AFAE0QwUtkW4cjlUhtGCFl8Gc6upLeOlrAeVPO7pIFKcRZDGNEurq/j8h/8Av/uu9+HYsaN45MQ2/t277sF2N8Ly0gjMcJ9fjhgLPYH3Y9TcuAjNoYLPXJet26pzr1Kv7PLLB1Aj/G+vksyCCKyTj1hqva8Lugm/uSKVEQQKjM8mpSqe3s+Bi71W2QAYfgYioL0TCnIHqtpRgpWVEhbaTgmoGjCI/UWohiW/lZLFWg1VFbeG6FGGUvnhXCqf4KQmt+oW1BCtqHcPVH4eNMy2MEpkKl9R+FmUSHmbe7/X5cGGfnwXpB4jHWPE9vY2Xv284/jf/trLMZ1Nce83HsUXP/9VrCyPpdiEoBYG4EDglHVjFbznYM7l4BAiwrxbALMOq4fWcdEVV+GCy67EeHkF8+kudjdOYufRBzDb3cJiPkfqZJ+AMZt1IK5ZpxhockE32pV2W7pfX4U+aKOPqLsCQ4xVafLA35NdgwHUNIihkW3goRE0EgsKEUEkEDWuXAw9iLU1OvcZ3+GaWunMwMrKGu649Va8553vx5Ejh/DoiW386u/dhzPtCOOlBpyBGBvf7+BjrPhASCRMaach5+pYKo9D6LikzXY2DCucQNX3+tykG8hKKjWr8hI2UwtAJvxFIEXwA+puP2A7y7JSVnqVjYGVr4EqVqTymrkIfV0JKLKt24GhRA9K5CNrIwyaUvssDBJ8EGSTN4JUf0M7pp5FGPe5C2QkqgROx5DNR9OBBrVK3l6LrRxZg00Gx1mE0wpkLGjFbAqkrI8X9viKEw5a/zJUjT2wMURGCIS96T6uOi/h/3zTqwAiPPLwSdz2h1/CZDzCohWI3wRdTCIQJzn5RqvIzB0gksKfnBOm030cOryOpzzjebj4yqcCYGw8/iAe+Opnsbe1iS51rnzcWqv1DdRI+kqtR6jmYvET2wot1p7UD9RGHaEED60TTwxBtwxLYwkyobfdhRZVrwqGLLJOKEwhfF8xiTKiq/ikATffZ4+y916Dh4kZq4cO4Y6P34p3/ta7cfjwIZzZ2sdvffhBbMyHmIwHYBZXqGkaVzCWRIDTpI5fGfJVj1tT4Awrj9ZzMHKo0G1lLIwlXIhNuVY1GNBN5opE7erM1gqeylcrAQZIsiDGsyhIQYyiygKU1gwEkuPWSA2P7Xi1VwikLcxljWIgcQHMBzG5nS0SUirRUdOYDGtDRI4HWM2uHBRagSbuE8WJdiB46O/DClhUg+q1ObMXSLJpaVICqga3PgJEThd4eWyfBjAfS+5niqpoyAJfZbksFCJFH/LdLmc03Rn8Hz/ynTh6dA0nT2/jU5/6ovt6nARadZBUHpGEsZL2HfC9FJwxGEQsZi0oAE+9/nm49oYbgZzx8N1fxuMP3ov5/j4oRDSDAZpmqJC4//KKOXejDK3YN0Ur5Moqec83oJxdYFAyS1BS5s++KcYLEzzrpXUBrLhN93mIuxhUQrK7P1I7oSiqR3c9d8CbbaIsXM7oUsLaoTV89hMfwy2/+W4cWV/F5vYU7/jowzgxHWA0HiBDUn3WHQnQQ0kqSCGFOvZYdpSoNkKtr+FoDfmZwUBFTh1cfWZkz/r2frKWcBR3ls0+S7BFlBUX91gXyNhV17xCpcabWkEoCFItPtm8zJUozVxlWGp4dN3r7WNyQQaGjQZDbJCacvDgkDYBkWnJgvp6VlJ9UPjrda1/81SLbtgvAUcqC1FFMvtCKpDefVKXaSezCL31VNY7wgmraRGqxuL3hm8JtqOjYwzYOH0Sf/O7rsWLnnc1tvfm+NSnvojdvRmWl8fISZuoIpihk7pzXWsYvQCEJmB3Zw/Hzj+OF37nd+HwRU/Cw3d+Bvd/5XOYTaci9KORQvcSgCIK/UNsjEoOvLQ9tf3OmnfXCZlydXoFLTFVJVJBo5o79E/Dqhq5ZkMylazp51ZTL9dyEXKN+8iXy4Gqdvy5W34Cui5hZXUFt3/i4/hPb3svDq8v48TmFO/55KM4sT9AM5D9bIEad2EE2odKKRoXVcUybHF2qDAqFW2PSDbUVHihJgXXAQHHMsam1vJbP3EBZjeY8uCSjuynsosCospSWnEcsRYLESQjpUEmTy2iVBCaYfciIN2kBEBRajTYYv4y2/OrWetNISkq1m2iMrkDQl4U+zdHAbYILqgmtJqGiU2xvlB9ldgzCJa88Y6r7rNXj1etKvCXvZ7+rBdVC1OPlTWpFaQRg9XK7+5P8fRLB/ih73sh5l3GV796P+6771Gsr6+g6xKsCJc5I2Sg0Y48THL2oVlWUMDuzi6ufsYz8eLX3oxutofP/f5v4/RjD6MZDDEaT4oCpuIC2dbfnMkFvDCRTceQDKkwyXhsPwEZj+m6lyxLhRBco5uiVwdCNZoFA/Um/jzrC2kKwpRdTlk6FKsFFI3GpdaDUDakMcCUkFPCyuoy7vjkp/Ab//F3sLq2hNNnZnj7Rx/FVjfCeDwURRqiKLhACKHxdXfXznjInuOMXeJKakqQFY0YJXqCb3Sr0SUXZGBl8YW1ivA6yStD0zth21/iDpFtblKk6/sOUCo/M4WS5kYAsWyZDvo96XWR0d8CXng8Z0YTtVGGtSMOgTBv/RwTHbgmpT33HIomggqYSnFgB6Dl+nP410JD+Ra5JbZ0XdJJG7GyI0h3E1QpGR+R1dCbQFej7ykkZexApZy2XshaGGBzMAtAAbHbwt/4X16Kw+ureOSx0/jD2+7EeDxC2ybEQMgBfmYeB1k4Oa4S4CaAMoEDsLuzgxte+CJ8y2v/PE7dcye++qkPom1bDMcTZYpcrAcZxCSH6xYQEutLxVWp6WvQgQqKCX5VxRAo37W4gCEXoWCdqNV9BTBrA7XiGrittnlbAwvuWSg4mDB0JsKvboAKRte2WF1bxWc/fRt+/dd/B6srS9jdb3HLRx7BVjvE8vIAlKFWXzYIRcgJ1hRKHEm4Ole81Mc1ME4htdpMBz6vv2m80Rf88rn+x9fLUn8HH2y1B9z7vvcZyxVtDcUSadc0mYu7c35PVjm0QiwtnoIDLeRUlI3ppWYQyoRtwIs2g5PFBYyrCCGbNy5W0RVcD2qd29L2lQD5nI0VbfNRHwnJH3X1H1mXIq3hRsV4BIBTLsEfEwqq9pOoH1uAkA9Jnq/n9JkSg+5wjETY3d/DS595FC9/8dMwm3f4zG1fwf50jrWViVT3MSFyaQkuw8/SYSYQuMsITcBsZw8vecXL8axXvA4PfvYTuOdzn0BoBhgMR0gpnUW/lLLHDWqkwlyCiQ7Y2HkdZsEd3uuMy67zYoms6MrQVCCG9e0TodLTFm0rrwwCzqA6ClLLL7lnq/ZU66WxCqlNzy4cJZMha9J1CxH+P7wNb/uN38XK8hL2Zx1uufURbMwiVpZGQCJQI8IfLD1pgT/o2qOiDXPFR/X6yPc496prjCVcRnu23Y0OPFhZMEW5RmJYuXpg/aVqLXMRclSuQ73vwGIHdrE0otHIQi4NWggdCNzbZOYuEBWa2DOCuQAAtPEq67FKlQWE7U2WQZpvbVYfOthe9dI3UQKFVcr/5LbOkvr/Ml02QpMe162C7QUOarktyMEHrhf7Y8OXheCUqxSnMWWZj6XCbG4MwoT28Ze/+/mYrCzjwYdO4Gt3P4TxeIiuS3pyDMsBKtqSOrP2p9d/zISt7W08/yUvxrNe+Qbcd/vH8NXbbkUcjAAQuq5z6hSa2drUQSabL+u69BWnX8Mm4GblyWFkb11Q6MmVUq7jIU67+mWmBbb2dl329BPnJP88ZpDBqRX6JP0sZ1UCjC4lFf7P4D+97fewsjLBfJHw27c+io1pxPJkAoC0qo9AMSDSAFGLmmybdvbniRR55yZNy/qYWd1Dn3bPAgHVvGpaGM9Zsy7Ul6qwZnVvvAo1wLNk1HtW7j2tXh4T1WxK1daFyxpZmJzJE4iQrdPGJ6r4enOTVzNoNAWEohXNqrsIqTxnztI3zgZCsh9LXPcDA89W/tl/oG/jDP0P3H8iJYgKY4YNCp6KdNTgqlSuyzD/Ew7DA1lDyr5b4Mzs22e5mpfO2ZUTYTrbx7c98yi+5TlPwXS6wOc/fxfMH+sYiJyBSAiZJPpPtuLiQDVNg90zW/iWG5+Lb3nd9+DBOz6Buz/7SQzHS0hqJYK7L32YbpqbTONX1gsMJGTft+4k1N/OGYdRtOORf0cQJTHFPYiP8sB6rwEzoE0+LeZS2oIxDCkKxE/I3l20KBc3FpyREmNt/RA+94e34x2//X4cObKKnb0FfvvWR3B6GrG8NAZIhV+bm4agtQWecnQ1VNGPTLoK0XL1jcqKFzPEzob2uVX3uXXGgVeo1kWpGKiIt1j63LuwdPi1rZ+K7KC9KTlrlqdAWjL3yuy58jjlDpaWZ1LVRH0PwzIuEl8iNE20XHKZuIuKm4ZiNbxaTykjba+CClglWBqlBCR9xmScV8C3QDW12FYSrPclUuYB9N4B5RQfO36pEhVjZgcqpvUMCpWimJLTLfXTXL1fagRk6RIN0KRdvOGV34LJ0hhf+ep9uO+BxyT9ZFtCAeROm3eSbGjKKpgxBGzv7OHyyy7Ad/yF78fjX/0ivvypP8BoMnErZbEUoRf6yrRnLbh83xiLyXdcAmWeFmy1LjXmM0qBjC5vBoikrkK63GTZgcfSPtp3LQIASVozsShs6RSthUwg2ZOQkghpiOCse/tZjpiDq2/zu/XwC2X6Q+vr+Pztd+Bd7/x9HD68it39BX77Dx7GqVmDpaURiLRlWoSUN4eISKGE6mWIboyYe21rvLlKTnBauElQGTO1X6NHVaEVsioSbKlht842P5UdVikBlU5YlXBpyru4VVLLL6jBlIVxsgwo61j0xCCIO6sHt1dxB3t28A1npjBs0x2gQUCTnJzrIAGXB4PVSqqA+pZT+OI5FPfB6ndYH0vGycadooG4qlawwKL8WdqQW2CGNXftaAUGPeV+xNB98Kb1K+E2HtHbZ5Qsgyiiou3LQaKCjBbtDDdcuYLnPucpmM1bfOHzX5c6CY/jsP/kLPXXIQSJo5D0n4uB8Pof+H5Mtzbw2T/4XcRmoGhLrSKZMNrkLDtC1YJqEBDAYNCgaSKiIrgaLggYKNbf3TR9n4JZfzuNV6y6Ff7EqCk1aBWgFwBFT7VJhZ1V+NmGJcvBU9/dIG1aavl+APWhMAzCYDjA5267A+9594dxeH0FO3sL/OYHH8TJWYOVpTGYpQAqNLGqWgxF2PROzrVchNcKanxzDOAGicDKy8GNgfFIP8jH5b51TIqzCit8zVxJk9XNqvLI+cDGHFOHAAVR5CYvrMoBRNpiv9DKkanOO6r1ctHh8lnWtGt5kf8jApommguQfJLmaLPXTavI1CrVrGk/XYCyC4p88vVgz9oMYQduKAFtI1pBJEUDilzYvgAR9lyl95j7cxWBDr4gyFIzkKnPoHY4g0M8Zp9LGDSY723hphufjSNHD+Mb9z2Me+57FINBg7brqn3thfo5EIJathgDtrd38F3f/edw7OJLcestv4q27dA0QzmnLZQyVZ+HwUFdL4ZugAkB4/EAKTG2dqY4vbmP3f05FosO3skWJWjqridV8QySQzlRKYJo4X5ShaOMa4E1VGMzd9FcOKrXsn6oQXz/T72aqjAJsPMgu67D177+AA6tLWFv2uI3P/AgTkwHmExGIBbYH2JEoIgmkhqkStETodQkHIhymGDaGnu9iVnYoKliVw89JVBCrBWf+QMqRVuIAIfzdQuuSlFA+c4yOGBJQQaUngjuSnnUtsgjszUzYd+SLMrMhlllGsjWj+AxEEVIja297Q7KbFCePcjhC2bQk4ultk0W3iNP7AZ8hatJUOz3EjCEUFPU9YJpuSp66kuQ2c95dwtZXVxSeXAf05QIw2oIuJj9SvgtgAOW8XVdh/Ul4EXPuxoMwte/9gCm+wusrE6QEpCQEKNsczULHiBd3kIA9vbmuOii8/Ci7/gO3HXbx3Dy8UexvLKKLonySFo4RKRpN5+rxAQs+Lo0GWJ3b447734cd993EqfP7CN1GU0jpbsxlhJeievIKhQLr2PTWEEtuC4wzvvqaoW+IJWYAXqHktj9lMc9PNBTDNU94HSGhXeQc8bhQ0vY2lngN95/Px7fjxiPZUtvaARlhBBlf4K2pTG0Z0JIOgDjh1IXbzxggUBjJlLLWQm8maySNnKuMYVTAs5FcRekScXY1alc1IhC4J5FXAzFWBbMW/NT+WmyR5mlDgNORmi7Qh0PgaDbrk0Osv1pgUlbZ8jJQIY67Y7FVy4+m/lVtSABOlhi3fyg77n2QoVrLdWHyiJURNFRBVUaZbeVkfUAkrFryGIIlcCjKKsCsvSxtg2XGUjGsFYlB7hLo0pguj/Fc687hKuefBG2d/Zx190PgWJE12VnnEwlpQUTWl352WyGl7/q29DN9vCVz96G4XAsQk92AizAWY8o0x4IIngkDSybiOGgwVfufhyf+cKD2NmdYzRqMB5GzEDYm3V+AKitZbQIOdmUqFcTb8JQFIBS2GiI/vsVGNE6DfiJvSpbzrz14taBx5IGLsJjzG8KOKcpPnTHSTy222CyNHZ0ErSNlwWBqw2NZQBaLMPGZz4J+JfZqiDtUi/AqRmysvoE2G66Pm/DN+HIlCsCKQ3qxzv6MP5kK8u2Z7OkiRmC5KoUto2fWLe+m3bVepO6toWZPP1PYGSWvQy608JMagXS7GCQaoqZgaOHxmhiU2k0ckJYDr72/b2yiLRiji1GQBXxlQBnVeTVSyIFDgUnkCsGD3Kx0dsEvWL0ailJ4Zc/v/pP3Q5MmFG3apKhG9n9FQLQzvbxwuufguXVFTx45704cXITgyb29oUXxC7jzSx1A3v7M1xy6YV41nOfg89/4iNYTOeYLC9pMxBIAwjj32o3F2lB1KBpwMz48Ce/jvsfOo3lyRCDQ2Pc9dAO7n9iio29hO19oQ8psxo1692YvvC66HW2QT4vJsQKspx5DaW55qbKSKj1smXSa7Jt29b3a8tHpQsrbIsvSOrVEYBmMMFkMgQhaCpWTkGqNx3VqNLGzaaMUA2kZi9TCpoNEoRVxuWlskFuZjHoUgRV6k5IkbFFFBwxKWLQzGwxnpwFshuXVqlIVKi6KA81giQKweNo1ZohJxjCdnRBStsAPZ04SoLQ3DcXfCMjoWms8YPXmQN7U7UqZimpFjpjAmEp330HCaQ4hM6AHsMLaBaA7OQVMiZS7VpuKdeb1jNoZNWKriuKbwOGM2xhDl9XeDClynQE38aly1czSWVZUmIMmxbPeuolyF2H++9/GLNZi5WVBilJliNUSskFgQE0hMV8gRfddCMW0z3cf9ddaIZD7yaTiWT3nu5RsDyvBceaELFoO3zkU3dhe2eKY+sT3PPIDr50/y4eOp3QMYHiAM3Q5hVAQdpAWekoq+IMynzuVqEISjHG5pMyoL0JAnGvQ3MuJgEedFKFXVfGuyCaArBlY1PYJLxhVokgzVCDHU8WEKpIP4VYBc+osKAxjmYyWG/m3cc0ECc7OKHpanI6l0C3UcXMrgiTGTIun4I596Jczp91zKNGJxVluKJ/RahStAPA9jKAqhZf7tKauunfRYYrIxS6s05F5C3AeJMdrRmfNxbUyVwKF4wIWW/GKpTeBtlLK2vrymXRoYE8UxDGbCSBGvf7hdfk+6bCYQKtzEam6LkivNkzqpRCNQ4qRFOqloU9sEDZlBHLAmWtUwhM2J3N8eTzx7ji0iPY2d7Gvd94DEwBKVd7tFEq5e2ZIRAWbcLRo4fwrOufhXu/eidmsxmWlpZ0sW07s6R8iORUYnGRZHtw2ybc+um7MZ0tsDwZ4mNfOIkvPDAHmiGGkyGGWVuqVxoelk5SK+YCoVYymD1zUlNRYEonU8om+I1XIFqs1uYYS+0+AdGEnQlUHeFMKCjNlEaJxcPbq1vTjhAZ0RqShKguQFV9aGPQMftmHbWEmVW3qPGQvfiMndkCw2aAYdO49baToIgr/qgRY4WihAZ9F8IsvI3FKh3FIMg6Z0VlspekKCyryZZKQUWfWtlim8YyAGQgcFDXw+ImFvDVEag+NZeAXPMmPbmbYf18wBrb0ziGuAC68ARJlUwmUY4PrgQnoDzQBV/MAiwGYBo1hIAcFBkwYG2RYBqXAdgW04qiUhMgF5kjYFUDth9CLrcgo1FLdaIHaKoYxIGX+N5Q5oPf25p7BiIkZZqua/G0Jx3B2toKNjY28egTm9JnL5lWL5VXuVIwMQbMZjNcf/11WFldxUP33I2maZAt2+AWQ2nmuV0Zd4wBt33uPuztzzAZD/Hujz6M+zaA8dKScZcUwii/mh0LysACyzWN6iac3UUoNRfUHwPZgkZEFWTT1RZtz1RiK3ZOZBHnorwPiKsIUy6MXTbKyFrb8WUhBg32Ncq8RSmxGR+zlrU9VLvlz1WLx0zoFvu4+Vsvxx9+8UE8vj3CaDRA6pIrSa7GWHFKNXgVfONV6j/LSq2NEs6zduiI62iDoGUGtpXXjZ8epwcEL46zeEQuXxNBNvjPRvGC1QSDUaXcy3SsPToza1twI5bdLJtcE9gaMjJAOYnfqkigvrGNLTODUgbZLkPWdkxVGzEbtSsDFqZ0C+QTt69WzT2h3zUtWJVk1Vbfg0sg1JFHFzyHjKo4qkoy+yClBZ582WEMIuPU6W1sbe9jNBx4UwWwbq4hqqrAZFMJ54SnP/sZ2No8ja3NTTSDobdzQpZz5+r8fVbiD5qI+x46hSc2dnF4dYz3fvJR3HOSsbyyBImIy+nAdiqvjd/9dApVvtmEu2bayo9UBiSuTJLjGVJmJoXCUtnpuwJ1dSSCbT61dpAiCeaahXRhicZTqg3Iut8UNGmnHxNptwHlTS80MyYgwNJoZ695sXYhEnb3d/DKF1yKH7r5BvyVH/8NnFocwngQ0ba6QYlMSRaDZ0Famyl0LPZs40vz4QNL5sflyMo7MlBOpi40E2GRdeJQeC4jIHgBpao4Knxj6+b7DABH5u4qOznF7/Hx+9XyLxAQgjGKMQuz7AbMsg2xQCzVQDZJhc0Ggy2IYlrZdheCNGCi2zWlfbHdx9fO78H1hLgM2ZIxgCEBGZQdZ1Ym3Z9tLdDGHIGqLA8kSGMLnJWCzADlOS6+YB1EwIknNjFfJAAoB6dCxCUzV8wAtF2H5aUJLnvSJXjk/gfQttLJh9XXtw1Wdctvy4fvzxZ48JEzOH54gi/cs4kv3D/DZGmiMFksY4wNYgyITcRwMEATI+KgQWykA24cDBCjBNG8zoOCpAqjwGr52aAJpPfT+8SBdNJVSzyIEXEQEEnafg1CRAiE2ESgkfs0MaDRLkWN/h2aKG3BYtD7RTSNFPLEJvTGEEOU7zQDEIIiM0tXFdMVDpjeKqymgVgzElwhLCkaOr01xTOfcRX+5U9+L86f7GrXpuiKscAA+SVb4RKSYBYNr7stMehQIUDRIeSxOADqG8EtcQbLXgDlcxXnKtsQ3PCVG51da8CuMFBo4t+RsyJ8Ylzwgcf0WOI7DQDdimlMXRg6U0ZGhp8QbHXdgGtLrwt3ieaqlt7Wr8ASuYFvzUEvkqkLF0CoUJGJcXkeiuLp13nrZ4Q+wcx3U6gkPhTD6mG5+h6pEkjMGDaE44cnWCw6PHFqq75d8bUgiMSSAjEEdG2HC84/jpXVVTzx0AMARan3BzvdWBEDKQzKWXrZPXZiGwBj0TI+decZDCcjEEkVnAgOASHIxtdoO8DgLpYRgFgPFFFamv0E5HAXdioaHjXhqoKiuiqxuodkG6TyL3J5T3CtrWt1ghA5DwprWkxBFW8Ijf2lgi9FreITB4shw6pBi5FmbyEmAiWVl951mqwRiswyEmFjYxPXP+da/OI/+Uv4oR//Fdx/Zoy1pSV0KSkaMbRiZctUNtTaejvcL6jX/86aYVLauQFzHca+5mZwnTjKm8HdaS12I89rwICTKy2TgsLcXk0oCqg+K6DmWUVbBIRybFH2oI4XRpAwt0PMYBFg1V7qb4ZKeGpBYoYsigm8FRsSOTNy8JAMTBRdEVcWvdyae8ItSsvKTO2z7PcqK2VUMWUSVH3Wyku/TlLXv74ywvrqEPv7U2xu7cFafhkak12TCvmFD5EZmM07nH/eYXBusbmx4XDNLT+zF1xJcYY8O6WM7Z05Dq+N8cV7NrE5A0ajAYJa2hAjQjNEEweIzRBEUgsfY4NAoTTuBKHUzZf3I8TyUojasDMAWl0nm2vkd/tnvqJE5aNaTC0HRvBrEILA+yD3DxSkQw9pubCOjbw1Esu9o+xJCIEQSa4T/lTF5mbLxQeeDmNG1h2dVgMvlhtuUATtyX1S14K7OU6fOIlrn3olfvFn/jouWNrD9t4ehoPGYTnr80srcmm6wfav4knbbOMCXEdU3S6ZnKAgZmKAkihT40eFFlZXA5I+iHVQ3mTHy0x6/G2KT/kTKhdmoBmqVCvZARA8/6lvcGaMhgLzzGixagNjXAvsccXEBwXTrpP0jAhoVQ9c4AhYUwZcoT32zizf7GUtunobM0zA2fz7olnFFTFHQi1TpXR8XXVMbddifSVgaWmE2XSBvd2Z0IThpZf2LyucsmrKrutw/MILMdvbwd7eHpigiyklvdolWu5T9T9cLJJU9sWArz28j+FoLFDZUmHedJO0+41Gzr2ASIJp0WF/CaABdVWgvB9UyKziT8ZRro3K/PYKpIeiKk9Z5xmyKL1ZqyCMaE6SKV7bdGSlxkWrB4W+hLLnRC1ZAmIm8YtznanSZxuKIi2gsbI34RLYpjQmYDbdx2A4xO7+HNc99Qq845f+P7j8yAIb29toImvGAEBmzaPLIEVZqxW1Oel8wNkymlBOc0srXas1oJarTb/MEGuYHTkWfkSRLfJ3/GVULZ8QzvWSjIEoUvt+X1aUJ1JmdwFk7lzSPcwaJNHncL+mqHzNUm/V2yrkop2DB6Bs0CKGBGmhA190m5Llb11A6eBU7W6ipcuGAvH7ZAzlGsly2Gks2Wfh+VtTPuo+JGYsjWTjyWzeSsefWFakuEyqBDIj5Yy2y8iZsba2it2tM1jMW/k8SV2B9ApgdJy1TzucebqUcXhtgjM7C5w402E8GqhANmJtKZRW3lzGa4rNxlSjC3YFDq93N7Ixa+dYp5x+p7CMry18mFwae9QQVk2eWUqoQjBrbj/Zy8MJ4sgEVEuv41BjAxHKhFQyKOe0fnoobfFdAJsz2E+6Sm0HakY4evGVOHNmG1deeSne8cs/gWsuYGxs72DYBNj5EXVzEUDjUcw9IyPILwtKtrJktdK99UD2zItBepEJUmWoEkeW+Spy0EccJldc3lEFY4q3J2E65mDZHHC9VACA0HbWuCGXWABsEvDJyltqPXyB9WF1JFYn7YkhX7AAaLTY4ZYxVaa6qMuhDDnTyKjN7SjBnmL1UROlerESibMxXUB1sQ3ar6oV8ngQgZwwnc7R5YTGDvmAWf4SELS8qlmLyZCwu7OLrksoa6GQNTNyKoKaM6NLjOEw4tDqGJu7C7Ssu9+CwnhCZdEPzJOqSraeElBVZ4ogV4pLLUyG5aKLXSnqsawpjHmKSvXve5GYrTVX5S96DVXXGAIkXef6HmQC09tbD99rIpZX/UsfLSFnkjV2J1xTfIaXlcdT16EZL+PwhVdge3sHl1x2Mf7zf/j7uP6KEU6d2cJgEJS1bazZlZS8E7V7ENTViIqw1T0hS6dbr8NKNtygBVhn5IqK8CaqPWtHbmT7WS4U3WuSmg2ZKL9BtuvbUta1FBYbCfNF7kWjy6ILwwJcHamUfWLOhueC/4AXWciEZJETVxyidkK0v6UVuRJGKpNzH1oRiHKzFZHI81NFjAOE0gnVPel8kvqneUchl5hGDEDbttifzsBZ/qZymaO25EUW0OwkIVLC/u6OFw1lFrhnp7MYEvDuQTljNB5heTLEos3VdtuIAFLf/sC4XbGwP/vgS9AUVZaee5+Zj8mkJ936jriz/UV/oNHT7sM4OwtzjpEU1aVWMLPvVWfTqH5/e4wIvpcWlwVTi2ZjhbseZYGCKke5KCnqAhEG42WsnXcp9nb3cPS847jl3/8EvvUZKziztS1l8FY5UykeJqvaQ59GFVZnSGzC52z6yISfDakUXjcj4MY3FdcQtqEIKGuotPK4hxli1aS+hU/OK3dEYU8rYwfC/rwrFsPgadLWTbBxFivbC/j7eMrn9so2Ye0fWRSGDtInY5pRvpPJBiqOkzM3GTSsmah+phUBncVDmpu2UVWxiN6r+MFJtXnOjNlsgdlsrgspCCBWm1HqJIgYG0EuuWuxmE2REqPt5CTg5FtD5fnZg4iM1GWMhgMsLYnfX9wgQu+YL4TqoXYvg9vnmBbM0p79viNmDbWXrrbscLanNwL1XCVCIaXJfzibFaAsLnEbjwdnUTh6b2Fu8vUmSJov2MPg5UdwKpKkz8zf5nqeqggs4+OKNknbNQoNBoMhDh27CNP9GdYOH8bbfuHv4jufexjbO1sYDUeOJOShocrDV5a3QsoWSDeCO95VVGhlr4ySUi8GzW7KBYHULhYfICmK02sUYeUB44xyP7tY6VgZzrA365ByEuHXwXQdl+aZPaoGu4U/tqC6/gglr6lOSUbRpg5PuATyUKCqBX/6A+b+uYA961AgaeE7qw+okUmtcdGzZqxmnVXLE6SVWGbGbDbHfLYQKxqgJ69YIw09Rsuo47JJ6No5OHXa+VogvjCgxAJSZf0TA20nbbNX15YxmQwdzvluTf2f97nrvWQuPReKUY6Ns/UJ7AVCgrzgNTAgdjfD1xb6t77Xs/QHFYS5QrAcuvnJ9rMEjYm5CLfRHyRhgqoHga0HlD+yp1ILb7jxtbnrV6TfYHbeTDmjXXRIKektEmh0DGG0hrWjx9F2jMHSOn7p3/09vP6Fx7F5ZhODwaAgPhfSs3VpZovB1PSEKIesSsiQDJn7U5Cukbh2COwWLuaKgJzmZLY8SCsTTr7OdgZhMKOtit75xtaTgDBvkxJNNVXOGI9k80X2tl4ME7BsFpu5in6awPcLFtyeHHQRvOqubOiyAEkvUFhDXb2bf+4as7ptBTJNccpEyZFH0GofVgEwd6LkTIWwGQltypjNWszmiyrwVvxX259CQZRDgG5fJWC6P4X1XytCwEgJyEkQgaSyZAxtJ8eJra+v4aLzD+muSRm7Vca5r59ZeuxV7gOnVIRM3aUMgb22K9LrwSH3CFlStMXQkAiNEU5TG+YmWCCOcyloMuHOkMg5V4LOOUvAsGdEStrOMBcpQpCPc5mj3d/ADVnBmq4DWzWpXM+uhPpBr5yB1CV0XecFalkNHK8+B7RyDVaPng9GRhit4f/51z+ON950ATY2T6IZxGJqrXZc0ZdZURMRNgikWkOa1QQAxX1zO8nFZNkBHkzFvSjGjMszTd4Y8FZ6YJg6JQ/wljI3s/jGs2RP0AGFkuqzdbdzxYUBrLajzke6Ba/VIfU1tn0gMJOqIE6fGeyHp8P0M6+tN/fE1Kpyq9sIrrSQqRTTliqzpqElDsmKbLhkJjN0C6tauZwRKGA2z9jdW2A26zywAtJ0msEtKgEVCrINmAnY3p1Z+hUpC/zvkliirnK1svqlKSUs2ozlQ4dw9ZPPx2gYwMo43At0kuwdzyiRaYZEl2stD4hA2lrl7KgrZxWWbEKcnWHhn3GhHbt4FhjM9fxLSq4EaauaEV/zsxEbVP8ae4nsy/q5e1Etr1tY5Q3nS/1OMAWtVX7Gs12XsFgs5HxFbaPN8xOg/a+Dx1eBl5+NpSNXgrgFhxH+n3/1d/B9r3gSTp96QvbFuAFSR9IMJhs3asrb5FRlyd3jCjYYB8tcCUxZamWc5Q/UsSgPuHyR1hKEXCFqgrfLg2UhggRHe8a3/2uw30owrxQ3kC0G19a1PzaylJvepzw8u6a0f7JW55icjUaf34sF2eU5A5x8CZhTRTCUsXN1VxMOW4xcrIQxUh1bsHCLpVpmi4ydvTn2pgshlhatkEL/GAhNJC2nlWqz2Mihi5ubu7AUWjLor9Y6+e+qFJKUd21v74PDEE+/7km45pIVLNoWpVQbRbHV9DMrUCnisjb2FTIucrQlLkARSJFdkk1aJqiKQGqxNRhaw/fiZSn7qbbkQBrN90WUGEw2RIEyrwolWq0BV3OtlQFLqaYiEVWQzADlUkGq+y4yZ6SU0HUZi3mL1HUAGLlbICcCzx4D7d4ODI4gLz8bo2PPQYhDtInwL//p/wt/7XXXYPP0ScRA4JyQspyZYVkWS9xl5TeuAJQvUe0CqTwVByAJzxMhe5raaG3+jxLKS/zUlfJ1VdfWFZK4HD3jjmLERYdYpSiEqZ23XHMr5DSYqyWKboFZhN9gIUzQRJLKGweIUay4sqZOyq0Bql16haecAW03tgFH8k0sxp0lUGgECvWc7M5cCJyD7H23Zxq835llbO3MMJ913nZrEIIHAa0wxttxBXlmDAGnN3eQc0aMAZ3urchZzgcwJWDdenNmxBixuXEGO3sLXHTZk/CG73ga2vkuQmwctikBQFnBM+sGkJpeB+lNUBqj5MoVfpPBwwNBRVLTUOvSc71KrAYlBYWC3tiZonpVdQhWctuLpPaeKatBxodcGnEUTMK94VlMgMROuN1OKaFtO015amwgd8gcwfOToJ3PIKQN5PE1GJ33AjSDIWYt4x+/5a/hB19zFU6dOqk0TjpPA+rlDEZ2uF3oaJ85zUh9fq7ozaXy0daaK4MlKEoXxWRL6cxcrS2xV+v6pjtUR4NZwNLOTQQQSm19pSUUsoilVL+qglrir1fz0p/m/shTQuFItjLKslT9QBb5ghdrXikPu17MlqfaCOg3XTTOMSYw4MaGQCogR+TQtwzLLJH4bmf2OpzemmK2aAEAg0ZiI00IaKIIfhPJg4KNloIOBxEbZ/axmC8wHDRYtBJPsEKgpEVDSd2ApMGqxWKBhx94BCmO8cbXvhBPOt5g0bY9Rrf5uF/PigRZCnTMGHrthq2HkcEhJFzx+veFn1FwZUUzNsGDFudogC+XAJihMAvoUrKAFPw7wdp4c+G6umaElO9k04wsZFalaXENkSku1zBp8DC4O+QFbnZMW2ZRABoczLkTNZJaOdhldgq8/XmE3duRm/MwOu/FGI4nOLNxBv/n//bn8COvuxKbp0/DGrYQ6ZZxZjmnkatsgL6yHogi3xc+Sb6OtqzWObhCrxI5dpTaKxasQbXzrCxilYAAHA07lPL1JNXwRObK1ikkViWtvgOb4HCZnvlovSAfirvgXSYUZpre9iH7eAymZACpDMHW1sooXVPCgx/ZynEpl+xANg6Xe6QKeoJZC1tLCqSgUYWSXCMFRpsYmztzzObSIWkQI5qG0DQBgyZg0MgON1MGlhUYNAHT6QLb2/uYTAboulRZ/yrnq3lwcQUShqMR7rvnXpx64iSuuOoK/L3/9duxe+YJBK1Vt5QWI5cgZsUPcjIOFBkpKQ4E8qQAqF85WATc+C97AK9edwswitAB3pDA+MzG4XxHVVEKCs+4QbK1yv7TYhPQ6Llkc8SKUciIFnnmgu4AaKmw0BI5ef6cScvKYYqkxDy8+C13SCmjW7TI00dBe59FHhzH+OhTsbS2jjNntvF3fuRl+NHvfgrOnN6AVTVaUxifEGtQO5Bb3dJqrrieFniuFW9VJQ8pgitSLopAZTHXkqTC5AauGHBWk2mKvxgE4W8i1s1SZBasnA40myePQsvTtC7AOooSvMLKA2ecPQgV6omizEz6rPWGX8HbGnOWT43xhU7ysICCTJjtuDAxH1mJa1pXGNoyGKaItKBIzWOpH7BIt2jGLkec2Fxg0SYsuoxmEDDUJp2DQYNBExQF2JbYgIH+bFPGidO7GA9iT2EltfgWBzDlKcMPWMxbfOmOz2J/1uF7vvs78CM3PxuPP/YImtiIy5UU/AYSKyGSBCqLVSA962fqnphQFqaptH71W6hguVddUnkOVZeRMyiKS8Hw5h86IDkZGQGJjOkl8Ok0SMqsWZjaGpkWJSP1EK6kVZmXIivxpT1LoPAXDD3ktLhcYEZOHVj/pdTJcWXdQtDA7kOg3c+BkbB24ZU4fNFVOHV6Cz/6F1+Iv3XzU7C1eVqnpVa0UkYB5IrdsU/texuSrvjfHBpX3L2vVEn3Sp7qilDhaBP4Wl7g50iAawXOtloIMcD7rbH+x/Zje8CIA6wpCOqbcdEwVA/VrElRjD5RTwtVnCNWWa18bydfxZgmKHrwhvMoihWvr5H112afRreqN74Ht8gAC1ekzsJ53ODxzRnmi4T9WYfBIKBpIgZNwHAQMRhERQJB0UHQffqyF/+xE9tSO9AELDQOkLIE/SQmIBkC1urAtuswGA5x/zfux11f/hI4DvFTf/+v4gdfey0eefghZCY/fLeG6K7EdG4BpA05qDBTvafDGIiMVqWkRCtv0EvIsrh3IcObvpIpT5i9qcjvWQCGbXawlCRlC95Jpb8zZxmoNuaE1MZb3IYBzqEScNZ4kLwMWjtCJgB6aKjtoTA+coWRE3KWrEBOCcwJuWvRzuaYb94L7D8GIODYFU/HBU9+Oh4/sYEf/J7n4se+9ynYOXMaDEnRWpGZu0JZRDm7ImZYCrfuHMXQgiDdfejVsFC3hgIYydOaunByrSoZ6SLMnoYXAlRVtKi8OltZrbXIYDQhUCWAcv95m12oROiE4digiTJTZd+F2aoAT5HymrfcK9ddXGqhyz6pWpu4GvRWVoA/2+/M7J1jzBWQvDEjVDu6BHKFyj3SIA3ERfGTakyDghEbwubuArNFxv68A2dgPG6QuoJIcpYFFrfNUjsZk1GDze0pdvdbrC6NcHJjDzGS714TyyHXB2LFjoS2S2gGQ9z28U9jZe0QLrvySvzzt/4QLjz/7fiZX/oEUlzB2uqyzNU6Clkcp6IZan4w6ubacpRTkN3X7AGCAiFtWWzNzbjK49Qr98+UhpA258EtF9QUk7Eh7Mg4u87hNBej4PesFXuVgrCAmhyMWb4juqQE4iy2IGgjgVOLlJO4TQetFRjIAdPdbQwnGc1ogguuuR7tYo57v3QHfuC7rsfSeICfe/vXkYeHESIkowA1Hk73Wh6MtSuZYDgi9gN2TMGrq2fKowxPV81cB6OfIqdqJr5VugbdgqKjt5RrwCT7slVTdZmxutRI00qon6Tn+RnE4x6xdBJcmFBor1xly8osGhFQTaeMUE+OyiScdvazIozxZd0BpoTCSZkJEGdBKEtBBU6gQFkehf9UUSkgICGhGUSc3M7YnUq59HSecHhtjCl3ijzY01xJ9wpInl0yKykxTpzexdH1JRDZMd/BW2dZGiYlIATWfoNKGyZ86Hd/Hy99+Utw2ZOfhB//W2/Ei7/lSvzLf/9BfOJzj2OBIQbDCQbNUDY4GbRGoV+VvS+cZQxnzKKuA7FH5ooRh8fpy5vs7+j7pMwq6ywKkbTHnwZ+k3AoJ6oUdSndthWTlanKxBWIWYMRAT0EK04htu3VqrSJvM6elC9s81epShSfX46Zy3KcvKgpI5pTgajDdOc0hu0KBktruPQZL0TOGfd88Xa8/hVPw/rKEP/4176ENh5CJNJdfxXPOkIrariWf1L+E6YzrgWsf7PcJ1Q0FqLYeZSy5iSHjgYASdLNpW5CjJv1TYGKZHBFDDQElv3mClEIwGyh0UtLG6CyupU2sRpDm6NP03FqmaB1wQXU0rAKrSuKikYeUbVH9BkbpoSymVP7ibKITiB5T3jpwGJwpcz8Xuozp4gYGPMUsTttsb46xJmdOS69YBXDQdRL2OF7ZPhGHyAgp4ywFLCzN8fK8hCT8QC7+wuMhuR7wLMFUAIpvJUCpK7LkppNwPt/90N49nOehqc+7Sm4/hlX4Bf/yffjM5+9Bx//zF24/ctP4NT2Ptq2X1ZtL66s/oHQUQ+gVb+6WzRt5X6TIWHaArMOCF5brI0vSVuC63vBFbhtq5Uj5/zJenotKLplk2fbz1wGQ56oBDNh1DCGduCNDTTLytbFi25UAGk2EgO25xLx9zhP6pC7FhTt/EntVMMMO3LMnsHMmO1toVtMMVo5jMuf9SKE2OBrd3waL3ruFfhxZvyz/3gn2uaQGI7MjjaKUOgsdV6snYCttppsPigBWaGNXB9cUdZrRb7edmo3u1yXIC6xNDWrRYxC0NQ/o5H1kC4vgJS07k07eSCXq0iZHcge5WdSJmaBgiCBdbKjrCIihAg+gUq65Tkll03Vd52J2QZh9QpcGTTzfQvEsmCh+0WA7mE3LFhLQq0QzD0hSfOQFGc8enqO84+Msb27QNtmjIbSUDJQKXRJqRzRzQxwDBgCWLQJO7sLjEcNdvcXuhtNhCNlaUERARBlZCbEIMVOctoPoRkMcftnvoQH738YT3v6VbjggqN43vVPxo3PfQp29+fY3dnFfJF6xVOO8nvTLG5esKCauhAhRr8oREmnZXUcYyRNJEiGwwSzuB0Eio0jyFLHTyAk0PAowEn+NUcBtMD8caBZAeU5wK2O20vING2nab+2RZdaIHXI7QIpSTFP1y7QtQss5hq4yxl1ybWhCzBjtugwGQ8wn00FfaUOKbUIln0AA5r6deKpENpGrHa2j9QtMGoP49KnPx9EhDtv+xhedMOTQAT8s//4FSzCGhoLRPe4S40rV6znbl8tExb/Cm6AxfWuMldKKVF9+ncgWGEcuTaR7taCgmxNTAnqdwhoTAPXF4eag9jAskXOixdj/dRdWN0CVzjIHl5NCMZAbGArqzU2DUe9e0rqz2rjzVeHa05ig/pV/xondmXfrKi8/pLZRmJYTtbgJjFhMBji8TMz2czDjFNnpnjyJYfA3Dm6SBkeoban2m/DQdRcP2PQBHUDSMp0IT0j9URtPSPELCckyh8CJpMxTm9s42Mf/SwuvPAoLr/8Qhw+vIal5QnWDq1K6y8/L86sfVlDxz05V+9ZpD2Uk38NGlpWiORYb7JWYyogcl1TevfHBiEOpGhJe/ojRKAZAoNJESoa6MJcC1AD5A6au5PUXWolGt92SN0CqZ2hne0hLWZo53voFjN0izkWiwXadoh2PsdiMUSn+X3JKgjMtzPwUtdhMiK0bcLufIa2bZFTK8E/4zjdG0KhsK2trXVUEqWUMN0+hXa2h0uufhYAwpc+fSue/6zL8ONg/JNf/woWYbV3pqO7pBS0WtD6HULQPVe8rLRnRTe2duammk9kVYeOVrwmRJB7L1ZXc4E+hxTxgwlNADRNVKKDGk1y4Tbo4jDbA4asDKccZgMpAL5YBdZUBct1hUUPbKY4KLSFXR0JyPMIvgFej9hSVQLTkRYEsvFYf0P5SO9JcpVYfdW+ZoUoYxAitmYBmzsLHF4b4vHTe7jiknU0TVBm6231+P9T96fh1mTZWRj4rh0R55w7ffOQ8zxUVtacWapJoiQhJCExqAWFW0Y2g4G2wcYNbiw3IPPIBgOG7sc8yO02IAk0GOFsgVRZqrmkyqpSzZk1Zw2ZlfOc3/zd795zTkTs1T/WetfecbOEBf2rTz5f3nvPiROxhzW8a9yIDkqVQCViaJqE5WpA1/rJrgogWcVfSilChSKWE2EHfKo1I2lt01566TzOnrmAzc05trc3sFjMMJu13mHXCLVpUsA86/TbeHfexsKXs846B3dztO0czaxB23SQdo7UOiM3bdH2IZbhRUAO1UeF9msAXiwVGWbJ9qZpXfv72uTRycI+V9i8J0e45QLHR4bqkIBmgWYxh3QD0mLAfBzck6/hkHWFH0wbOQxOjuM4YmNrG+v9K148NYICUyDIozkFqamtpZcENYqaL6Jf7uLCS/u46qY7oDnjy5/+GN78uhvw3/yk4O/98lewkh00yRrBJgBamZpkLUYNiDDsZCiOm2dN0iTw8YRJTnIrUZgalXHMfB6VDZVffbR6q8o+bR5d5XHBPs5cVGlxlpGhVX2RSCMlG4qKPlo5ww86EGBU60zLATODKdjehQWEALkMqHZARi670ltUlqd4di32YN7QqS1MG7lBKoU0nvIcetyh+eMv7OOaEwucubDG+Uv7OHZ4A9qPmJwJED4RJuJ4ubAIZh3QDyP29nus1iNmM7u/JRABGIfYA0kSjsIGBtnHbH0ImtZyDoZxxIULu1aT0Ei05m5aZ3omKbUtZl2HbtZivphBEtDmhCQzNG2HdjZHt9hGM5ujmS3QtDM07cyIJDWBTxlDphc9595DUaO/PyIPKwutjYNfPyCP2a6JKr+x0mpMyc2Fjri5FdKLF9GHb03bWqs0uCCxS5pwaguSZwiS+oE8Dlgv95BSQ/cwwt6GQjNNHIBde5QsRvycEiQPuPjS0zh53Y147Vu/B1/+1MfxxruvxV//Uwn/wz//IvZ1B23bQAdPSKLCcXivUCs5Z7pyKE6dmgVa+KL28dp9qhxBR6weBIZmT8AjbyoiCU3ED2KBohVPoaxtRBEycYHIMTh3pdkVlQnACVQQNsMcEDwWKWo26rvx++GqBLfFwnUph5SM89s5vliPQiV0GhaUwKpFDY1WeSgIUpwovTWleB8ESRiR0bQNnr+wwuW9AbNO8PgzF3HiyIZr7rJuBskMBZQEK3F4Lzh6ZBPrfsSFy0tHAo2FAf0aqxW37j1ZfEmcOZrGCdrLlq2vvmtdn2vWYgSJm3LJNzs5xE8pITUtkp8FkNqZ2fBsOkqHcFaomoBTNohRBTQ7g5ujyX53IeCxdfh1Go4JJ3aMUEkQeuxJxFJvoYagKHodbr7QkWazHPNojC/JXY0SAoGwnXtszkRHu+5/CUkCWMdjUnVqnUn94BG/TjEaLY7Z5gHFpTPP4fipq/Ca73obvvTp38Frbj+Fv/ln34C/+wtfwuXVJjqeCOWQuyT2Jk+RcLSp1OS2h7m60tBoEGmgAgkkVRAu54BkJmuNeCfmt7/fzhp1+69xeKIVCblkoUR2KU3fWgLtdrt5oiSl1zP+T+3qi13mEtHoEHlU8GLhOA2kAdoiDp18UwLbEO7bl+PIb8+RinRKQgz7hi22lNRZhUwaaSQRoEm4sKf42hOX8V2vOooXz+7h7MV9HDu8GaE9oNiL3DT7KokR2Fx0OHl8G8OouLK3wv6yR9dZRhurCyUl8JCJphFnGBMqY1K0TUKjDKE1yHlEbgxFtQ1FvZY1SQlpdEbzDEdJAmk6pLZD03bR8rvxv4nmeIBmkJ2H0PJojjsd7fesuUqmYeef0YWAlxPz9zy6snHXvSOBWihH2qw7A1UZz3dzAaOjNAu5CrL5HJAL16A4lrnXhofdXySkmVTmx+/pEIxvZFuEg8J8IkQyAmD3wss4evwEXnPvd+Ern/sMXnXzCfyNP/sG/J1/+gVcXG9hPm8xjDaHktIzwbw+Qntv5JrT0VopxjrhLZCmwlqSiwkYcWWaHJpqMLzfL85aFCTMF2irGOTEb5D8oWSgzJuUVNzCTAhPZw3vqKkzWVEQg2EykAolozh6cE3tZYHTjsMFIsXf3+FX+4LHU/l/ZkhxjCC4Q3km729QBRQys26GR19Y4dIVY9pHnrxQGoIIGb5o+8ZhfLhO3DF0eGeOq09u48SxLWwsOlzZ79EPI9brAas+o+8HDIMXCg1m/5fsQfs5DJZKPIwjhmFEP6j/tK7Ew2gNRoYxYxhY/KKhxcnsqZ0htTM0ncH/1HoX4oZh4QzN5jTT0bLkxqE3h1u/xDiskYfevPPDYOG1cYAOa8+yG0vG3ej30RwpuLw+u9lg4bnBCnU0Y+zX9p3sTr6htyiAp+3m+h5jb848jiH7M1iQE/H/IbL/bH6jCa+ckYfBUMzoRUMsHOL9PMVc/Z4sKgKAvYtnceTYUbzu3u/ChYt7uPX6o/ibf/6NODLbw3K18o7S7uwmIPXoF1CUYqaW92tCWU4IvOI7Kke40KX+VXIeJvWyqurnNXgYcFjsOARNYKihCBmHzyzA0dF1JgUDCuQX1gmIwztx6RPCdnpvqtxMR6P4+jjjKaWdS3+fkCbaOgXySLAxkUQRPN9ROvivzAsouQZw04UaIocASkmwt2rx1Sd28d2vOYqXLuzjxbNXcM3JbayHXGn6Ighq29OQqyUHHd5ZmCkpglEV5y4sMZ8ldApkESRv3dU23vMfowkUwCshzWGYvACpcYRQnIj2L4lgTCPGNoO9Euj5p7ZvulnY/dR0RtzuJFMtjO3MPHpTjXEw+A9VjHkAA/KaR8+RcBg/joESmYue1RyC/Juf11tk9SiO+rygp65ejS5JEMsJEEOxLNIRHgmvGqaSbYnvfErmV09tRFxKL0w/OqzKrqvRmfg97P7Wzm155TJ2jhzCa+65B1/+/Odx07WH8dN/7g342z//RZzdF8xnnc2JtBsORob6PJQOKkSnawEYKauYJ361PUilkEoV3uQKGVabww7UqXIkigDt3vZx5KYFW0wBkTKPEsLwTRBzhGQFkqe1hv6PhaqCm7yNFkk0iRB4PBzeBMSe4Zvnm2/dhSv9nAHlabo0UcSYNhE1qNfKqMJO3vUqQIlpRQhTCf8DJ6Awf1ZIfK7Y2JjhW8/v447rehza6vDNJ87j1PEtO4hDSJDFNOKtJs4btSYgh3bmUCiaRrC16PD0C5exloyNeQNRPwhDNTz76rniOSWkZMkvSZOht6TQnIDW8hcGEYiY/d6OGcM4GoLwxUoNtX8XCECqZDCtNDcZPQ89FNnRQEbW0bUlNWl2X4D5DvJIbz5c8/uKZPcnVBA2UnRrAVBrwtqO9b0oh6TY4qaUTHC7QjLrr4b5Y4U2zQxJal2DRs3mPNSxcnyW3DAKD2W3X0nQ3BczCZ7VmRJWe1dw5OgRvO7ee/HFz3wW157ext/4s2/A3/65L+LsSrExm2McxlCMJTtVw2FeVJHzy1ST2afhR9GqKlFg2UCkYSYOVyLDFZTJFUHSdm6X0VklVksNSNW5tPSn48ma9GTWVUnB2IQfWgYfIfIKxVDKxxuUigpoSsboESZhiI8ys2AdnoFHaS/1EmoqxBUmCuWVCTEvOz+AGcy5VKrgWvPMS4PPfvMCNhctVqse337qPDYWbXQJoo1dNwjl71TP/P3Izga2N+c4dXwTd99+ApuLDlf2BvTuOWYJcT9krIfRqxLHgPf9MGLVZ6z6Ef1o7/eDXbNam3kweHw8O9JKSSz8N9u0f51Df8/U1BqyD2sM6xXGYYmce4z92kyAPBgEH3pLqunX8XeYBfFvXeD+sMZIWD6O0NG69YyDx/BdUA3ev6/vh3h/GAeMg/8bMzLfG7P1WBxM6FizFXuGmSXZewCMYWpYFZYVAlnPADow3QzQbIqG7402T+Ys0KxQN0sMHZmpkJqE1f4eDh/ewevefC8u7a5wzckt/M3/5A04ubHC/nqJpqV/Sg/QXPmrkoWmhILPAEaqTEAKwEgZGVtcHAiAZIK4ju6lpg2+auksS2KVbDkrNjdae4hDElrxzMglhLGsP5TijLC1GUe390yjTyUbZ0knHhOMCOfVi3cMWbsZgKr0l2LAIQ0Zus6m4jslh8CX3O81dRLZBcxVYIyh0YRRzLGSB2A+a/H0uSv4+hOX8LpbD+O5ly7juqt2cNw9/NGohItNyKWYoA24tj20Pcdy1aDrRrzuzlN4+dw+nnnxEq7sD5h3DdrOxjgO6j9tT+yk34QmmfnBngbZq+3QNVhh9AiCMVnOZv+3sznaxSa6xSaabgFX00bQeUBer9wGX7kmz85cFt5DzsbsnkxTUAARAQzVRfjPV9i1mygiWy76E1YKhX31mU4rZftAyNc4AhilMiH5Uwu9UOAyesT8DoEAOXsWZAMdh4gg2BkEY3wfjhjHccBkMIxc0VELBUbb4f0rl3HkyDbe8OZ78MXPPYjrTm/jp//sG/F3/8UX8dwlYGM2s0iEnyhEFDChSNKsFuaN1u0C8LCbWBsOzZUdIwltmE3ODalBkyynoeV3KSGi8w8IzTy1RiwMYkw59fDbcCWScdh6moONNEgJZAKL8dMo0PAfCI1YmOTLgKXxMsyf6qdKwDQLEWoIJsLuKBCh1qdAc/iZA6MDUs9I6k1wUyDZoi8WC3zq6xdx89Vb2Nnq8M3Hz+Itr9/ErGusv59IZT4BRazxCf6+myubGx3mucV6PeLGaw/jutM7eP7MLp578TKu7K0MyvvJwOogbFRPeW0StHEfTQbGpio5VTokB8zWPcZxRGoatPMttLMNs/uhYctTm4/D2h1vgzvGXFOSyek0y7UZwHwAJz7XlgSBoVXJKE4XOROS2Zpbf0SNt0w4IRQP+x7QWRvcQBoNcwL80PNcTCkI1LsSJT/sNE3ONmRCE2/LsxlKmolFViyTcop6i/BXtG2HdZ9x7NRp3POOt+Oh3/kkTp/Ywn/7n7wRf/vnvoBnLwPz+dzW0IWaoGQQci7Tl5u+7kws/COOGAsiVqbZl+WxabgPiLvQTjSyAE2TsLvP3unUhMaIowDQbLZThtmeol5JVu3SgVfUnmeDLh40Kw4VoFSnUXOH5xCGxinpptiIfEqZgZTdzqPfodqjECz8fjC3TJKEwjwAkJNC0EBGOvYy2qbB3tDiww+dwf/5+6/F/mrAtx5/Ga+986oitX1QYf/XsMzLWE0a2/Vdm7CYdwZpO8XtNx7DLdcfxblLS7zw8i7OXtjD3v7ataP3J4yGJN6daNL5B9G5CWLtzMZhQNvNsdg6jNliC6YESx382K8w9CuD8X3vTsDSDAYwzU8Inx0iI1JvzdGY2dkHCIbMY3GoxnbAUEwtANpGoj9FaVlljJiackpxavy8xNQ6I4vXsxiNRJqzNECSV1wvTRtnLoqIw2LxZ4b9VlSCFBoUpz1UyqrY7oWZLPIz4MQNHdpuE1/61AM4dXIHf/e/eCv+b//4czizZ85dKFxBlkrL8vIP/VdDrV7CzP3V0f3VdkEm+q4c23yx1oMZI23m5DhZ1eigUk+mSB1MvJWh0erFqTUup6FB/WCsnRyhrmEDWUU0wIVChdUjnVgBcWKJzsXCnD9ulmmiSXrzgQWO6AI/I5oI9GDCyxJ+BGha5HHAfDbD0+dX+MSXz+AH3nwVzl/cx5PPXMDNNxzFatUHJE0uiYOQSTwUPE7cDHV2nRXWjDmjTcA1pw7hutOHse5HXFn2uHR5hUu7S1zZX6Nfj3GKU86KPg6H8LkJkFJG02Qs1xavn20dgjQzrJd7ltYboT0Lt0kekcSzeLOgX4+GCsYeceoNtT8z/vgvFzTHI7SY/5Gz4sqVPetQE9rNrrXzE6siHgClZTmFCEKghompat2eculfUdqtT8cxZrtnMKyvUxzTprbvwzhizIZEeNCrtUaXmB+AUnhU3yMy7Yz+ulawvxqxOU/4wd93F44cPYx5J3j3b30bF/bcI891QglHF75hdaSvl05pNydzltPxaTw3PU2pmNkoOSD0QwFoyTjF1j/wUvPqihpj0s6gIIgIAafh2IkaDhXko8QqSlxCkNo9Ew42drC+ZUXYRfKRkNIL8xtS8QWQMvEQoq7ByyTM0RmJFlVzi4AWvg+mHRo0OkKkwQjFYjHDp755Gcd2ZnjLa07i2RcvYmPR4epTO3GYiMCr6DjjEESpOFYDHfiDBZH7r07QTZNw7PAmTh3fQduyZsPSfZMfBw6Uo8HtWdwDc5SlJuH8C8/g5aefwDD0GPoBq3WPfr3GajlgPYwYFQASZvMZdg7t4Oixwzh27Ag2Nreg44DlcomRNr+biCxoUSjqnnWR4q2KprWipt3dK1aQk0urbPZM5PHf1kY9xzVjdBHyf8yJyDppuT4MtlbDOAYzjmOOYiweTaYowiZObMrWC4P5F5ZPkU0Y5IKoaoGkTp+a7SevEwFmbYN1P2Bna4Y//ce/C23K2NyY4X/91c/jn73nMWwdOuoq6mBSmwbPRElxdhUrCHOahK0KK4ZLxhTCVn4gzdM8MfpqwiPtAiCaMtTamjeHQXKeXBIYltfS1gZMsig1sEssp2czENj+KQX/ha2nnrVEh04qnntJBSLSeScVVFJnTi5W8kXiWppfwbhYI42Z9rgxf2ikWsD6okgyBCKwar2cjXHbpsGYgfliAx9+6CyuOr7AzdcexhPPnoMk4NTxbQzDGBo+VraClVHBJ3XuQEFVAKKIh+PuhzGyD5tG4zspieX/d63b/ckdgA3a2QYAxbNPP4sXHn/eTzsaPOnI2mX3g/XOJzMYcZmAn8/nOHHyGG699XrcdNNpbG1v4MruLvphCLph9d0UDSAQAVTRtA22d7awWq6wXvf2rNEccsaAIxpNaHJGbhGfc0xxEnNjv7fU9o26f0ORhoxOW2NI78SsWrowc4y1xh5d0GRFCIt+4Pe0CCCnN57xaMJN4rtZvelLY8jp6qOH8H/5k2/H0UMb0Dzif/6Vz+JfvP8xbB/aMWSSapOooNeiYivFURizcCezmV3BEPtmpWjJwZuoQTA5W4ROQGc2t1sC1iu/ULSiQou9nBH2Ghk5ijiCiez7qYY2Ul/ipO0Pi7MGyCT8XGunIdxk8BtVErF+8XEeDjbsMEk2qjGPh1rUcEQkl0B8bNm6CovZ3dmdfUkSxnaO+z72HH7yB1pcf3oLTz5zHlDg9MkdDIPtUtTgh4NTwMNG7WBLm7tEX3fEdQoLc0rTeHZhHW60ezDhQ3NG8iKf+eYONg4dQ9PNsXvmGbz84jl87evP4NzFJXb3e6z7jH5ko9IKKibBrGsw6xIWsxZds8Izz1/A5x/6FrYPbePVr7oB977+Jhw9soUrV/a9F0KKKsFwXmlxSPKMPNWMrusAAOu1mRWWumrRjOwCHew+XAnHJIpRaXJWkQRVjA7h+T6bs6hqaG6OrTD/6AjA6GD0cxvNN8UmK0AcQEJliWI+1PcfvQX55d01ThzdwF/4D9+Oo4c3oeOA/+e/+DR+6f3fxvbOIUQwIZOWyRBk/EphHHglrXw7KFaBwlivnCJlHKCsOkRR4pbBaAq5VT9hBVoWjvYwWQwo0t16sFPto1zpPDupyZMCk8zLyl2Y2jLlZdmAnD/TUe2NJuzGgkDcVBASXXG6JQUmx5GV7CZbDL+u2JS+jAooIXRcr4A03szDHytesiFWXrm7bvHLH3oKf+qHbsQNV+/gmRcvAgCuOX04Ck+SN+CYMLkPMUkT9Q5kcg6iFBWR4ZNXASYrA2an4lmHbrbAbGML860jZu+nFnvnX8CFMy8hJcGxo1vIao7D1ZjR99lPL+bRZQ6Nh4zVesTF3TWSCLouYd41WJ7dxQd/+0v4nc98E2+95zZ893fdjvmsw97+KjQM0RTX1t4rga6cDcF0XRfQvmksAWfEGLQgwvZXRoOFukrDFCoIa85SUJ1V8rLOwzz2jWWHWSQlCbJaBiuZMYWgtkcRdbUwwUQtn1XLuZhix8ENo/V7uLS7wtUnt/Gf/eQ7cPjQBnQc8fd/7lP41Q8/hs3NTQvnNqbAAD9KTjUEXaSrT1STk0k23qHCUFTmqwtNnlfglgRKdI5+KH+ef6eljcaHgB+iuMaYREKHmaDUTDNCFw+tJFJhIiIHajRuKK+w8kU+hBCZEDSEjFKWcVHcH6D1k+zD7D8LH2n8P6RnDakoCJxyFYjkojIXQUEgjWXkQSFZMZ+1uLzO+IX3P4E//cM34a6bjuLM+StQVVx79ZEwA1Jb1etJBQHdvJoiBIawxJnezImmTWia1gqD2hazmR113c430G3sYLaxjW6x7empF7G8fA7rdQ8I7DtNKv0MGoeMaukkZuZYxIdFJWNWrPqMvaU1QdmYN1itR7z/t7+Ch77yJP7wD7wWd9x6FXb3Vg4UxR1nBQSqCwEWCBpNCbpZBxmSJfi4YLB18Ew3yd4wRZESNb4VSmG0MG7DDlUu2HmcGoWGqmKE5bhY1MEEXjJYYWNMzlyq5uvyTUmNCZGRHXxcWYoIcvK3nPkvXF7ixmuP4C/+qe/F1kaLYb3Gz/wvH8O/fuBJbGwsvF1Yoe9wFDMFWQu3vCIM6HwZFX9qqDBTJvp6Z4Za3T9TclrsRQFHWm5boMRyfdLluc5gvrCswLKBFKYwgUXnWgEcUiBCEQ4TLc7Rl4w/oHYkxl1iMeg0pJffd/w7oKWi/cOZEhe5sIKH+MSIE8LkIA3yYY21VsijEYYwG1jKLZBVMOs67K4FP/++x/Hj393je++9Bhd3DT5fc9URzOddgbXebEJSDXOLMGA4Shr7mZK3G/dwWNs2mM06tG2LZrZAN9+0+P5iC91sA5IS+uUVrHbPY7W/j74fDGkk0+Zd23hDzYQuAdKqn+SjpjVF/RBT+45mBRqrZdhbDthfCTYXHc6d38PP/eon8f3vuAO//7vvwqofPRcC4DkSRIFQxv1jp80x1SRLZQbs2aHVioPMFJxAdYyzAwEtzM7KRS8ftxyMhJT4TNf0DDezDBnirc5NQLSNmYwyAtLQ+65RmJYEGGB2f7KNR2oTLlxa4o6bT+E/+4+/F5tbM6z2lvjpf/xR/MbHn8J8voFhNIHaVH4fnyKKw6+8DjI/ezAGf9SA2uF8qZtwtSp07FO5VsrMaaztHP5WFjU25o3fSGEdXZi/7dVMYGjLU4eZj62UA8wgtBt6UWFAQN9SlHcoTbRi5EoihpeS+Lu8Z7Z6ZS+C0D9Xl0mgAY4pNiEkbwmDxkqEzCjMH/dUMmnjzxiRAcy6Fste8Isffgrnr/T4D37gFvSD4sWXLuLkicM4dGgzpHs4/gDAYT0w1f5N0/jPhKa1DK62a9C2MzQzK+Jp55vo5ptW1TffsMai632s9y+j37uM9WplvghVP9asHGgyjiO0kZifKjBUhDjANJyBMxtX4/L2yv6AthVsb3T46Ke+hXPnd/FjP/ImiCT06yEYjRo/GoD4/6iZRARN20KHASlnL9BJAVUt8mKxb7YvzH22HgkZgAvotsnQZMgmS3HiARktEjSZmaNeFm3aV7yhK7wlmLVpz+IRB3rgqV3FzIl+sMKgrk04d3Efd99+Gn/uJ9+Jzc0F1qsVfuoffhD3/85TmM8XGBXRmwH03WSYQBX1Q34Tak3NveAauKwCE8xsCRXg3gSzI9ZYXeny+8Ef9AEI0J6SS2hyjwD+qtja6ADaWcLsKkCyedKLJLKfUYrsRTsl20vdQeXaLTQx+Vgx8ZAfxO3U1FQI0auJaUfFjNCEKt3YpZNynPaliVQNGKMhJEoJc7kkyDSTOX18Uho30BEn2ar72rZB027g/k89jxde3sdf+PFX4dTxLVy8vItxGHD02CHM5jPXiHmCANh4M6XkTT+SdwEyD3+p4Juj6Yz5224ehT0iCcN6ifX+Lvr9y1it9tEPdigmw6tJ6D/I6DpvhDcYtYwKNJSx8N8TYiWaTCQIb4MOXN4bcGhrhocfeQHLf/MZ/PE/dC9SY6ccsWFKhAtRyXOdIrumSZaZOY6wvhtabPWsSE1Bc00joemL/9tPvBXFkIxwZLRPzJ+QkbzKNJiQgkaswApqzryUTKENsFRazX4sqCuIrjXBcP7iEm+4+1r8yf/TW7CYd1gt1/irf+d+vPfTz2K2mFu7+Ma69NC84T2s6FScrivmpd8klONB5VfyB2r+hFZIIngwIx/QmwX9AO3mrDSD5Jez1z1bERWjAgmQtsqwL/BaRvKHemKOa7bg9wy2WrJ03cJidVKHwbbG51rgsErR5gpqX8qCCkqFWYJI5imvQmi2CL7wodorbBIRhoJP4qdJA9BEgTJ6kOyE4dbademYsLG5ic89egnP/tOH8Of+yJ14x5uuw3o94OyZC9je2cThQ9uYbcy9jFMtS8vPDag1fkqCbj63Gv5ubpq+nVkhT9dZSq9X81kBzz7We5fRr/Yx9H3E2UXFS4gNBYxt43HsZN1Jke0E9qasCOF7ShYyGvm+Ex0rbi/trrGzNcOTz5zDr/76Z/GuP3wPmjZh6A0JEPprRHikIkr7pWksZbfrGjsCLWeMeUROJV8giWttVjmKImVBqr3+o/llzEwzk2DMwDAAjfIcAESegHFbMls/awgSVUEDi66MDpmtwtR8JxcuLfHWN92IP/QDr0PbNbhyZR9/7e+9Dx/43HOYLxbu3GxhuSBNnLUhruTIIwfQf+ErUEdVCUxaInaq6un11P7+vpgpRQUrvn/sPEVGEgjarmVHlCpzixpX4U0gi5Q1Zx5HrFVXoArWy/T95Iutyezn3/XlTSVDuFDDH8yA8gUIQCBAHDZS2TmRNOGLxD8kkoReyfzlzwKomITBgzx4bkHWXASQAIrGnKI2YagCG5sbeOnKgL/7L76KH3j4ZfzEH7wTN157BJd2l3jhpbPY2d7E4cM7WGzOA+c1yRx+VrPfop3NTeO3pYy3nS2ieSeh5dhbNd6w2sew3sewXnlDENcMXlXWthYFsPh344ksOZqbDqNvPvv0JfEEIVsizYhCEwrHthXs7q2xsznD8y9exK+//4v4sR9+g0VAKk1vmi0XFMDbuu9JRHDhwhWM4xg+ER6fNmav+mOWoCf1BIoA/OAVRatWL6EtqxyNuddDxv7+Gp00yDmjScA4mhefraBS8ti+813OiKrRZHYDLu+t8PvealEQVcXli7v4S//9+/DZb57DYrHAmK3PAJtvEDUn9iUgqdGpl3VC5prEG/CUfcju1IOvfZBvkK2h2OxCDLCoGsP76qYI/XAiQDvJuQ/iryR0ZctHt1KURgsKGDhQDzcktSabSdiMy5guuXSu0EOBh/5omhrhAU1gzjClnFTjg2txqcYpXBGOL6anKOtbzBA6mVQnC1AWN5BO6Weg5SlFqMDklOQmDrPJnqbZNjPIRoP3fe5lfObhl/FHv/tG/Oj33oKTx7awe2WF5597GVvbmzhyZAdbO1uYdZ633nReu+91++3Mevl5Ew/xNtwAomvNsN5Dv9xFHnoMg3cXGosQoNONB5gmzyVIyW11oQ1MdGO9H4II/BQapmMDJUbepITL+z2ObM/w+FNn8ZGPfx3f9/Y7sLe/9r22FU0B/wV09JmfIGNjMcPjT5/BV7/xHDY3OjDd1uL3BTGm5KaM90ts2oQ2Je9TIUEC1Q5ifzXgxNEtzGctVuuxnIjFWHk2Ey+PJsVFFEkF2c0JAwuKK/s9vu8dd+INr7kRfT9gb2+Fv/w/fBBffOwi5nOD/dIk8DTqgzpPg56YJyGh99yvCKplqfgCcMGg6qjAqJBmpBGl++LCHGCDE+PFrJXQFKClA2yKQ8hKjKsWtapO9KKM7TsjxQV+Fkz2jZaSElrb2YXJCzNSKk289rlCKOJM74wo3iwkzA8XDlXgsGQPovgsDIKVfnd1FRkjD3xOcLpmqyBTrz1wM4GHOsJlrknxBGnKFFSBPAo2Nua43Gf8wgcew3s/9TT+4Nuvxw+/4yZcd/oQ1kPGSy+dQ3fhMg7tbOHQkSPYOrSN+aZV7knTWdFLVQhDdcya9WG9xLheYvCinmHwk29VI7kqCdAwkuDl39Znj/rf1onMkJKYunG8n4T574661DbYG2CjFcHF3TWObM/wxYefxenj27jj1tNYrnovW3YnY+yLk7mPb90PuPvOa/H0s+eszgHu4mPExBlKPObPYqiI3zthF0bzJJ0MrNbmC2nbzpyBMBMhclX9aDY7GLeggDYxvKjYW/Z459vvwKtuvwbL5Qq7u0v8lb//EXz5iUsG+zMs+iBm95NJmfRFJjcW0RJaVyJUTwiDIg4ECWEmpF5TqEDVT6NMnyjdzOKEQvVVLqyvS2upkp7XjZJdxSWkw2CCwr1DK+vbBfDYSWwnRTrQiPfqQZQRTzWuh22kBA/V7SwOlGOpz3Az2VYIiZC+hoOhBWr55gyq1RsUOK/wGSgFie0NT331LY3xB/pQuBfZ5tyIQTy279JsyShpsYEXdwf88/c/ht/4+FP47tedxg++7UbcfftJbC46LPf3cPnyZaT0Aja3NrB95Bi2Dx3GYmsH7WyBdga0aW5CwJ1a2YWUdewZotGGetZbDcPFt6rsh9nb694aiYzuj+ja5MVGcI+7Fd+4hWOprx4mTFCMI1WH4NKVHlsbLT7x4OM4fXIbi8XM7W0ELkQyrZ6EuRWK5WrE1sYcV58+jKeeOYtLV0Z88PMvlY1EmQOFrpAGBGAHp+jMDLPzv/+e0zh+qHX/R4OutXbvAzRs49HSCVE6/wqaRJPAzIff99Y7cO1VR7G/t8TulRX+q//xt/HVpy9jsbFpNRtJIOIdlpnpSUZWQy7q3ZmsNwGmsXqvmac/g6RYyJJ8UdqCRw1J/G7ChUfwEQFpIIMc92zXQ+WdzYQ6Lol8icsX6zYbzjyZlO8D0GI6qqv/lErVFjsPVVtZEITfIyF4r4LiyTYHEq2Q4iKhBHXHXjB8mnI+nSd8R4g+ChKAj8VAD6GZeolxtRuxX1KGKQJtFFBzvLCKKUlGFoFgjLLZ2awFVHB+X3H/p57Fb37qWbzm5kP47jdeg7e97hrceO1R7GzNkHXE7tkXcOHl54I4rKW3ZQAyUYgmmnXE4XNsjZq2webWJhabGzjpDMMMvNHz//t+wO7eCucvXMFLZy7jhTO72N1bo23dYTh6lSjj+EKByUo6uOAzIhnHbKdM5xEPffVZfM+bb8FyHA1R0Hk12n3G6p6qwGrd44Zrj+Nbj72Ew9sdVr3ipUsrQNpqz0ueSHIB4JrI99RzSESRhzX6oRzM2raCMbu/RoBhVE9utVigjHbWXnJfA7Nj33rPrdjZnOHy5V3sr0b89X/0CTz8zBUsNjaQx2wxfqnCfUSilRKjz5FothgoHlXykHs5J8E+ifyI6juo6BNhQ1BpeZhTyv1RCRU6GdtVz57uOYhmuWZPdlR1xc4UysV2yULkIvXDS7KCZfnBYBUkoGP5ImD9zZi9xOQOTogL4fXm0phzxLlOrRNceDuNz6V0TgHC2y9CsVaETRQOCeL8wBxD0+gfSGQUsi58IyFfgXiedzyQBNURGQ0asEzKY9eqgLSYdRlAg3FUfPnxXXz58W/gF979Ldxx/RZeffMxvPq2U7jxmkM4dWIbh7YX2Jh3aFtzEhpS8v524Whq4MeuVARUUolDYEqyfYehg+z7v+4H7F5Z4vyFPTz97Dl8/dGXcOnKChvzzgQG1MuqEPBUfT2Ta3RA0bYJy/WAxdYMjz11FnfcfAJHD2+VMxSJ9KLWSyNys1yO2NmeY3trgb7v8YbbDuFDD53BbNYWB3CiARH42GL7yuCZ15RoxlDki/dRaKJIaEAD9TyDnAUyjMjShFDK5hHFm990C8b1GpcvrbC/zviZ//fn8ciL+1hsLDAM2Y5nq7Q+H1iiTox2lfS3WrFDwhMRpF8+cjhP5hcqreKfozC0fo3me0rBJFoUlrogcEHZLteuNfIQsKNNwV32z72worAa5OAsi6vWIQpxBiT0KLC6tPNiHJlKUmz2pQeAEiEI6deuSa15S8O9aLZbJEYI7SHv5Vc1KA0GTRqLUocNQeHqv3ArwgajkE1+/2DnwmRcrgSbGI+toqwz51VjvotMk8v+1zZA2y4AMVj95SdX+NLjTwO/9SRmXcLxrQYnj27g6OEFDm3OcHhzhuNH5l4anEL4FqhfiaTqF/payDWhnQTY2V7gpqsP48ZrDuPksU0c2p7juquP4OFHXsSjT5wxwdMKBkYBSGQZJhi0lFwo7EyE/bVp3m88+iLefu/N5pCM3A8U/wJK/ohmRUotrjl9GF9/9AVcd2KBmacut4138YmkMbez3TfBUHK08PaID2ecknVXasfkAkcD/o9iMdDRm64Mw4imbfCmu2/AxYu7GPseqz7j7/3il/HkyyvMN+YYBp6slTzMJ9ExqNa6pOUUzGoEVRx+NRL18ToDUUiDu0qfnPcMNzrN0e9ASObMvRDuvdE0S68hgvaiHsEoXSH2qirMR4UcTkBvwOk9ysJ2kQKs7Tw0S2Gtb2QRggI9yGIKiy03kEqOFNhimr28zyQOqDuvEu81BlFPWjWhaH1bVF9MSp/KGIlxhkDxOVbjsTGVkKg9r87CYgallPG7WKCTULUzwsxu0iR6agWaRyQA89kMkM7WHxkv7o54/sIegCu+Yr/XVz1HhSEExTSIV14tgFuvO4Tvv/dq/IG33oijhxe457XX4aqTO/jMF5+0PHwXbpZLD2dYceHl+6oWDu0H65/w4pldXLy8xOZGh3GYjp+Mz/4HrNU/dnQDWQU7mw2uPtbh6XOeKwEgOvVSwNKpm62nhEiie2ZicrImvml4ncN+ycDQmJoSQb/ssbHocPutV+PZ585iHAYs1xn/07/6Op47v7Z2XgP8aLfG7X5xRWH8kEPwFE1NuklAdEkqzE507NcFQ3C3+JlWyHva04JCxzVBoCMqBh0ts5fr3jbDJejYx+Ayymk2xtg+fH9gE5LHY/2qCHPACa6WWODk4mU+BacdeIFTCTupRtWSEX9plwx4co9wUak5ko9Pyhnp9YoHEyDsYlKPUPJVUHIybilefocSiOgCZQkIR+tb6OQe5sl1n4QQhgugLbKOhrJoomQ3iRwlJAi6pgWa4uMwwVzGIH4wjgLFfqRX2ZGSCsxZq0X8MpNBYR68PALffOYSvvnMJdz/iSfxF//Y3XjrG67BNacP4fe95VZ87LOPmTOzsfMK2U+BxGl+ACdWNY27HjLm44jnX7yI228+iTWPQw6blHszxsqN6xGb8xYb8xYpKU4enuOZ8yszZZB8wjzcM0S/CVPfKmsY2gCawlGYPFSYBJbKKGYwUSllFQz7axzaXuCqq47i4W8+h64B9lYZ//O/+RZevrjGbD7HqFbBmKSB1PvP6JZWwBhFy1Mb54oH/ItBM4XNjVYZxz9I01Gn4G1wRNV5m7sRYg+A5zM08MiBY+i0umhHMjv0sniuVANRC/M4o1oCji3YKOKls1KPy5giT6YRE0f1rpLh4RJMFNkzCZmVyxOIag2LqKOmS1IQsD80Nr0txBi5PN/lgWljjXW1pg9lwWKsUmv7yUcm8R01xRO0CMtg6tBU9qXkxGjFPhbHNsJskJoGjTRoUuuZgMkdS8lDQwId/RBIeHpp5uAEmsXNsATRxnLYc7KQal33gARR+5fUtFiTWnSzGWbzOZ49n/E3/tcH8Svv+QYSgENbHe59zbWeLce1NaKXJGiEJyJZYmHDSMJgOQIvnbmM1cqakw794GFKc1pazoK1Mh/9pwA4tG1x9etPLdA1CUk6AE3xdzDcBlYR2t+ChCa17hvRYHwBoodicjTQeihxNmugWXHkyBauvuoYHvzSk9BxwIXLPX72176Jly/26GZz8HCWOEUpovYRdUccXFspw/AHZH5CscPvuZ+N9BZ2Pn+nZrfELGsnSse2Bn0xt4D3If5ltG/SeWq5XJokB0MPlQRiDXclyqqmW6aFXBNSwtae+nAGklFqKErtmgEdq7Rdh/gRmoslErfx3eMPYNJEUQtKUQUbDxX4wdRix1OaGFSUWCxqd4vParVjRZyHGKL2LQMvtUzxyGlYUuA+FCSkEea+FKBprKCokYzMvGrxGgodLcau6utsMDU3Pr8Es6kVKBVvzpS+yQ3K3KKOI1tcvYjkxlSE+zgAwXwmkNTi537zEYzjiD/xg7fj2OEN3HTdETzyxDm0rfkeLDpQ8jGaVHw8AsHoZcB7yzXOX7yCzUWHYcyhJWuTkzYrna6HtjrsXlni2M4MFjixCj8EPXH1yx6J/88guLhn3pCt1Vg0SMkyDXPOyJKgDbBc9jhx4hDmizk+/ulvYWvR4sLegJ/7zcdxfnfArJt5dSTAQ3XNYz/tH1HGBMQpVtDIXKyjTzV9xyuSowoqiA7bVfJc7Ss3erFXRhXqq1AIn1nXxLTtcMWlUg4nYBVldyeK92lzOCzurbVGLpb4kzyNV1AgIJk41VIs+DUsJTDxRplaq0xioN2OgnXhtpu6E4reePizPZ8AWQKxcBRliYAo/Knhf5g8KM+FERE9t/VLp3tWEjakaIPawRM5BIT2gmK+UJZrCz8WyD9v7QRlYShSECWxUUhEQkuV0KlWhWHCWkIJKpvV9kDdb0N0pd7dd2NzG7/4/sdx3clNvOnVJ3HNyW08+8Jl7K+GqLkKkw4l2lKEX7LDMRW4eGmJrm3Q98UPUByRB3IxNGNzc4aUBIe3O5zYTnhxT9H42IOwpYLevn8sPzZU04QfQARxQjCb/zYNsFz1OH36KKTp8OEHvoatRYPzl3v8iw8+iYt7im42M4ddU4p6yrrWzuBS1SeuibIRKwjlVQuirCZL5W6mrCNinx5AQenooYkIWkWDxBU80AaF/tnVyPJZrKcjBGjZ2sqUt6dB1jeNvVHX7p56quV7yePeoTUlaMyn5vAGCnEHYnJ4UpiUcAe+WMw0VE8rFnMuOuObhiH08YlXjycThrkfY2AIiRMDwniGAMKTdM1VwxoCyokABiCq4ffwihfHQeGgKM0myIfqkEVgG2/L27rEzyX/IMaggHdyUzpIRUpS1gHtEugGQPKaflRrIjAhxHwxojbLskxgS6l2voF/ev+38LdOLrC9Occ1p3bwyJNn0bYNRhdWWawoh/MLEZSAfrDY9pX9Hof70Q9RKeOlMKfaMubKmHct2rbBvEvYmAvGyyOa1E2J0xUYFV5xvjGVvNoTTwRqGutErE2D1WqNq04fR58FH/roV7C10eH85TV++UNP4eI+MJu1UGAS6gOc1iSF6ZeCCAQl0ObOaQoLDtiJoziYyfDEiuVVqS3/f8E+kRNDglOFZEbnquItMDW9urdWY1YyVtBHibMaKySv69fp+OhJRfH+RrukSgSUEVYjkqJv45YU0w57LePJ7aQYn5WrJZl8s/Rwc9OkfnKNh+rcanuHTiWFYAQkm3ZIuZKAAA00zWWOttG50mKI7SmypZLkQCWlUEuosq1ik3ORZx52r/ZLYtWBjYed4OcSJkuOd2SWPL/fE4VSAry3AJuFJvHTdVJCatpyfdMZREZT7Nus6FrBixd6fOAzzyLnjEPbM2wuOmMMPhcoWlWYaWjjt1bdFhXYX/VY9zzN2IRBfepxHrM38bSa/1mXMOsabC8SeJwXuwdH6LAiSTqC7SCb8ilbqjWtdVNuuxY5Z1xzzUnsrTM+8FtfxvZGh7OX1viVDz2Fi0vFrGO/h+Tml7iecGUBqi2nKUbRKukXgtiIE+HJVks5rpjO6NgFBPmpSFOawFoxcoX0lK5dLUKfdBc0z7WwX1ObClPkjAjBcMD06DM8yLryLGS2KRyztt5lWAn83JlY1K7xk2Po+S+hCwIIL0iBPbvJJY+ZUYmI2wsXrnLEed7CAVlViMQXN8cKZ9ey7lSpJbNXRLJsgs/mvqmg5DhkzqUggLI4/F3poC/5U0CcUUhPEe9fki0JJ+xdcfs7uSMxVYkoiYdnJhMjrcNCra5LqTFBAtOMzK+3GyQAjR+mYVlzTdvid758Bi+d3UOTEg5tz6GuudnLIEkqQiaZn8Gjtuj9eLLlarCzDfsR6z77Mealc++Qq2PQs/oxVsCpo3PQVyWVBqXXXX1fJ/us/KdRykvmhwDXXnsKL57dxfs/8iXsbM3w0vkl/uWHn8KFpaDrWkeMDVKy8xqQosQn9o9qSJGdLzKNKqMgzYCOodsUVeo915vgB5UiCDoqyIL0LiQg8matZDQhmhv4e3Wb9MwKTQCp9ZNZmEZat2ziIBT0ONrteHy2ZyLHJkTLCSkQfaxYMGBuNcE4O47KT6cSrJQpI57DKIQ603gzM0t7JOOQuSuGVGJ4cOPce5yNg817nqqW1r5ZopCJeJnqnBQ4xl7mhPH6dFCgFgnARCiD7pW3VovQ0mLEEbcUmhDxZBov+XSIGTbmgVCFQL3SVXw/PSEENLxcqNIUcWhu7zfuDxC0XYezl0c8+swlpARsbXRRjdfyqHJHu7VQ4OiH0YRB34/evz97FIBCwJqUFmI1pWPNPwTzrjG/h6/tFG2R03OZD5WYWniPZbJtZ6nUV199Ao8+8TI+/MDXcPzwBp47s4df/e1nnPkb81Ml67/IlOsIUTsV0L6rHWsan9d+iUrhVJrYObjiEFRoMiQCpDIPxK+hSlSniwwTBshudqgU1xmKEOQRbyJAmxIHR21fDVDVyFsKISo0kukEjBoY4STANK9n/XABRnVPtDCm7kRMDS1SnHJencVJUuOW77gDTe0qrbxzXHhxUyfaFPq4IkUg+MOJROjm47bWEgllA2s1HviexzTxfHlMXpwC7+guT3K5T8sGWSdVTqBLBSNK4QeFGp/hhObOptI8sswqvqkoCK5aiThVhkxFx1q21GMbo+CJ53dx710nsJg1mM8JkW2NVcr5dklYN2bjHXNG1zZWNOPjSF7hB3EvvQjGLOEP8O5ydr9kJkBG57khQJYcKeCEun61NfEIs7AcV9a2LU6e2MQXv/oUPvuFb+Pa04fwzScu4d/8zvNYaYO28fZjPFrMsmNin0yOUpinKb04jaRABvZ+3TsCipiUBIywzQ8QrxXFeR8APj4ziYDC3IEh1JywxUeGQHUUPtGbwH/GuQAURGNNwXFnAHmMSahUMEvIHk4woakUyYsrsmt01YxGCjNJuQGYOUfBIxDP8nPtXDs7fIEAWE+00KKujTnuKj2WjE2Txp4s4aAjY9pTzO61cwHFfueicdohvXzlfX4heSt6EA9A0Gyo7X7OWQPelzVhNEV8ZuVVmH+aZFX/IdP35JW/SnWZTi8J5qcwMc1nPQou7vZom4SNjRkWXeO1IxZqiyo3ZzzuNUNWbZuw6u1cweQ5H4nfyR6v992qpyFiR21ZspAi64hy6KeEEFS3y1VJAiVjQdVqFI4dPYTf/sTX8LVvPINrTx3C1759Hv/6E8+hlw5NYqKazZchPupxmokUufUe1pGiKvpelJx/yuiXKR+ErlU36wKphhIoyEA5BqlMXK3WiwlfrpEZhxpZ8ZvVTnz2/Wl5Fr35ADSkJHwRoSZx2BCSVEcoSs3DPOwyQQb4shdp2PXWbIbhO40qJ8JocHFqhOBLqkFQhtpTtgmq5Ej7VDILGVu93ztNi4pY6BgROmoi1EaUIN6ttvgqLMzFXHSfvdSwjILHN8696ZRDQoOem18hC8n1Rh5gUG+RHuFGCmHNEYYyLV7IdfLS7/huLUrsmY7GJnkYFM4iSK1l9klKWMwNKq/7MbIMxZHhyG429TzUmpEM+z0Az+tHRnbfgSWgKjBqQXMelTJfQu2WdkrL8KSzFElXydfATAXQMoAq0HYtfuez38SXH34K15w6hC89ch6//onnkBtjfsD9Jqnxmn6BJg9kKxff739wRbUI0UC0zjTMHAXg6KymM5t3CROS8BOXzWiXcbxaAVfWgyk0hhm56aM9KiMKOYt5CrS9L3DtKCk2a9SvlQw5KZMkxqYAYa81AJNDCDKzJ7ILi2qxuLA5icM6+1721SFsmShBVvsF4wETM0LzpGuNSkS67bswpi9NRmp2iDStMu8kaJhi6U64WtfWEYDyfc7OxiNh/vgmocJt8cDa1OAtyZgazwmQVnY6MtB4r6SMhMgEO4BDm/wt8Rzn9Mm1TB5iZx6IYDZr0GREDQAhu9WjWGWgepPUJLa3TbITjXlkV+68GCwnNClbuNdzHKJDMsTbdTvtsW2cSGSE1m3hBSitvHyNxRXBfN7ha19/Blf2Vjh5bBufe/gM3vOZF4Gm8/MCAPo83JHhzmQtjvvgjamc5x4wSW1iMmp5P1A1t07rq0kf/ixSAiE/Sycj1Crx+CL8UfFW7U9TP0zFuwe5kGktI0urx6PAV0KPiiRrYGkPqDRH9Zkd+VTRkzcRsaQxwktjyOSUppQuQLVgRQyVTeZ4amYr0riG2cXxZS+TQ5TI1GwVyxFmAZ6A49f5otn6EKaVxxbBINXYK3sf2cJ0IWB9zMoFtwYVRCOFx3327inmkeohdFiXWwkSOoQoPnLslu+Oe0mz7xsq1FfKbcvRWOAjEpCznRC0tTFHP2RfU1sLtv1KvmYWHpWYYtclzGedn703huBIfupsVvEsQkMQ5GuW5o5jUKj7mgrNcaG5e+rcRXq21mfA/rLHkZ0FPv3wWXzg8y+haTtXBkQhzvwhk6e0VWk/MN03hLyWnItCRfB8jTCOQ+ECNJem+y2+jlFCjIogfD6BYoNlxHMh6Nr1hwidj07bWaB5CBOtzRkMqAfxxEzVCReENVo0plZ8F+pZoxCFDEPS46CBSqLGUvm9spamodX9iz2tVcjUM55I/CFpKvbR5Ixe22H2MBUBksbimOXvBFQhm3Jrt/EytWJ5XBhCPuCAr5CA7mXNOCFzdoZwAP0G3ECYI0i4LwcBZ6ik+DtI9cDa1r8LtwvGqRrrZgtOpKK5CHXeJUGAccCxnTl2the4eNnOG0juCGOlZhB7RAAU6IFZ12A+a+wg0rEkAlnHHTMPcmb0wP08ITDhJ/xSuXg2HkjktVb1udIkUxauAYe2ZvjUw2fxwQdfRmqaajUFVlvAdS3z59H1JfOyNpNSKAaN2dL55/RAD5Obu/Vx99MIkUd1nPnryIJ4NqE9Uqrsw9FTjKXsl9I5b+MRR+GjWtygrm5NJQxXwhRkVHuyO0HyAfKT+p+AHVWLU8o1CfVODiHtmh8ouc5aGD2X8Bk312q2Q0Y6uq4sQXo2uVBO6kUalwXlAZJRK12RAJmheNrZ0onpFRy/mzb8Hm16J6RKXk3ua7YoN5jvIzaeNmDE79OB9fa14hzLXOt/NArruXFPS+JM9FQR2u0SSTwQpRsl/BuhYfOIO28+ju2dTaz6jNV6mBxo0sR9qd3J5MDO5gxdlzzxx88irMKA694EA0OClgeQw3a9tDtYRx2vt89Kn44W/0uFZsppU0bXm4sWn/yqM3/beBmv2flJ2moe3pGH9vvBRJ3Q5nT7TemNVE1eym7zhoNZEPQczTxLyk7cJI55B6oyfTHLm4IjI5RDEJ0GNdk1JcAVqIIO7dYkKs9mryUHYYwxQwaz4tyJRkeglg03ge0SN5VBlQwlVIMDSntoCacabVk/TNyVSLUwWliNGtWQidfdU1AFc9TEQHDkiThxX79eqMWpocs19CEIxCMlWi0oPAuvrBjRSjXsQE9UAIIiBEU8aVRrUFC0STiGKo1dfAKEilI9rYwRpGX4PavYtUg5Ek6cfgL1+r3E57vuRxzfafCON16Dpulw/tIehjF7U5KChMLd4/Z/kwRDk3DkyAYgCX2fIzvQHLR+8IeIIwDvYy92n9Gbg17ZX9uQ2JMy2YGidQ19wGfQIWtJXFsbM3ziyy/jQ194GU1nJcLuO0QnjfdXLDHH6C7FpfD/FfOtph1SpAvm8IX5/gn3mvvFG1Z+K9T3R5ixpAXuUQHrGnkNpiiZG2EPy56VY+4GcSdoJTC9mWgbWt8fXueQ03miSq1nk4zMPtIkCT94xqSBirr3PbaH4rCC0UWoKDQ6BNGD7+xhi+HCIHjbK9fUWz+FX9bvwe+j4N6y0NU9yToWs5gKBzIeex8UKe+fe+RAsjFSHa4Mj331ZCIIgcb6kSjYvSYCT5T4HDt/OBGyBVaKJxbRXZ5XoSwg5hnfODDAQD8J1iINPJcOWC2X+OF3nMar77wWFy4v8cJLF9G1TfkehQ37D4SJAcy6hJPHtrBeZ/RjxjxZX34VO1actQSSJQ7/SJKgyoNFMi7tjWEzCxCdi4spZcqHMxWxA2nabo73fe5lPPPyFTTtzBgppKJ4B5+xdFomRXDwUb872cmycbWgV0L+NBGkNfWZrySVrwvXyRk4zAJ3mHuEwBjbvpTJk1LuH34yLXtgnznqy4rGEzBYLdgaVCsTLwTGMIaijiEUrV5NjJ51FM98drFV5Fu2MBFMW8dY1TdcKfXgMU7xMla3f6WsTwKgjNGHREal+Kd1/UHuoQ2LpuRG222s5sFCdxJak8KJg479dulSuqwKsmRr+wRxKSwolqZvUjbmiLWW6TrWV3OKZb0LVY3q3mUXHBNedslPdwM9weKeWWqCWqPAj8mC+wE4P0kJeczYmCn+/J/4LmztbOPRx1/CxUv7WMw7O/zDh0thJCiErZqxvTnD8SPb+PqjL1qmH8GJ55ZYU2nvLJQEeaAT2QRd3ysuLXNB9bT7XeCKEqVR/9INZ07Vp15e26EqSqZ3Wip2D4mjosEibGNSWSeLLKnwaxE8vmm1AuP1ofCCk1D9CpCWwuzQMMP8ljFHoo4QAjTvdCjPrgQXlX3OYzw/laOVeUgBBV+1KAFt7MXEngKChDRXvs9JgMKENr0tbgYhGhnMYvu0PQmdbEGL8MngGW31g+qn1y+/E9sn1+ODa78QIAkWdswFQlZwTypxTsEgMT//vggaGqxO0NHQxDVTjlRlMoH/J24z05/hOf3qD1TA4tEHlNCk9kILkXCiNWopbbR8PQhdtVwrXCDa1ABmXYcruxfwf/3J78Jb3/JqrHrF177xjPcDsPswRk8a4nmJScx7f+LoNjY3F3j+5ctQdYfeaOm+rAGgX6Af+Lf5A6QR7K8HXLrSo0lN8RFJ8XrTFHNKrqjCoi+zWWvFT+I1DykBTTNdz9B7GpC5Vowm/QudMe+ACx6n8SgrxWieagguHm5COmJPQiYYZec9IQ25hB4J+TPnKE5P9l74llHQAs1Hy8gsvBLncQrQbi3ayWCLOeVMLwUOcZFTpY3iYVVKU0n8QSweQ3xSMVb1CWoTovZ8s6Y+joH0PWDWWaoYs8C/ek99GfiZFgRAAVNsMv8bcFivzrASc+bL/J7FIUmgHnngE6GjCG9xJa1DePizyKzC+zAEyNHlHHM4ABXinlGYVX1eayQ2Aatr8AljqbU55AQriDnz8hm86wfvwk/9F38UI4CHv/EVvHTmIjY3F9HXzoGN38MBBZ2ZOePWm09huR7x4pldACjnDbDJrFTCB4jj0USsSe3Z3R4XrmSz32NJbU2ZfViIt+6Z3/g1JpQmawRAo0disdepkOrDOuxvX3hmdSpQvNuKV/RqjIiBvuJY9LJnLgTA0LgUGqBgDjoBSpJAQSIitqt0THuNHXgMGLc0KyzJinytQDqy3bmtRRopNtQIlxyEbOG5rj3YZGh+q/KSCrVknWd/UIVReymg3uTI0cPURrac78YnzAQVPlUgde1E9RT7S0Hi1ih6mm5MwBbQAtK483TAEXJyI982iw4XzoXqmy8WNQlq5idDR5kRkUG2Gooczys/abIcFHYh2Mrj/PfKv6MSDrr6XuDe5xGiaqftpIQzL7+AH/+hV+Gf/E9/CRvHrsELL17EZz/3NWxuLQCYIGawIg6gdNhOhtvemuP2W67Ck8+cx5X9HgpgGHIU/IT2z9Y33wpFFcNghNokwdMv7WFgFqV7SokiiWFjxlqEWYSug6Oq9dIQ2xOwa+I63Nbgllqeffk+Tb1XvoqA4V5WsCx+5xaw+CkckBlQL4QqKIRfpdPPcaf4SVzwqFTWOBi0omgXbBphcSKC9ujOHB5tCAIk9yZ1mebJGZCM4rWWgC1TdSRFSHmZooTWrSCzD4gowT42GF5QVRVKlGoRqz2b1P2rAlIafcV4YherZ8FTnMPeD5zsXW40NljShBQi/wgQKNcuCUQFraCgAmYDViGfiB2jzI8wmm5pEnT0lavoc6L+HYXE+hBpkHgD6lGU0ckohaZId87IKbUYsuLSpSvYbJb4mb/8Q/i//7X/GE3b4YVnnsZv/pv3WhlxSlaPn5KPwZ6fFH4ctdnz/XrEa159Pba3N/Glrz8LQDC4A8AOT9GSkAUX7kmQxxJBAIBnz+47LeVYP4V6xwQNetGy0ZZi7hGJVNPthDIKTRVEKighwOJ4C2crTVKnXdd0jhLgQkQLMqwIkDtBiMz0OAuN29xyLSxinlJSgg/KtBBaHtLlngbqlUAFlWaGiKDd2Z5HQkSMswqhBSI0gwU8g00BlJZ8hC8HX5R0xIRFoxZYU6CbKDGCIGzwgKjVpvC+Abe5UBL8YYvhK5NhST8xJ5nckqZPTRAmj6xybb0a3BeqqC5xAVSFCyv5VPsMys8Uz7NxROqRjZ63KPjSnxc4yPdPIDkBGFGkre+D+PMq4cr/B3NoyFC/LdcpA1jh9JEZfvQHbsN/+Rf+EN76vW+DDsAzjz2KX/uVX8Xe3hKLxQx9P5RwH7zWQt0J7ItrXueE77r3VXj8mQt46rnz2NpcxOEgCtubyOQNGW9IYGNuzTr3ViOeO7MCaI76frJsqCgBCsbifCyCM+GgHVeOKq/eg+OyXK2RWhsyHKTxWGv7I6JJUqudA8+s6N4EBr+nqEPCvjRVchl5Q4Pxg0wqyrWTvIopb6ZRiSTlUMr2/LZrU8ClmFWM2TWYqkl5L/cMCSbG3GWRi+QjI3Pt6VHN8KIPPsO1h3mlTWmFU9mZPwSi2OYzLZZjVNCbbVsWoa3smjyVzbTuRbQjC1ZQLd8HgEYaXNnbx5Etwd037Fi/frc5FQiBV36XSjQh7h+ONmC6JhOimDJoXFN9cNDDbz+6EBoH71o7t4pAPXiNawxJWMwaXHVyG29+0x34g9//Brzm9XcD8y1cOX8OX3voQTzw4Y9hGEZj/sEr+TKQPAyaQSRl926S4PLuEq9/7U246qqT+KX7PomsFs5TFGehHhy/UFspFrMW81mDJ1+4gjOXe8y6ha1FqgRs5cOI+5BpYCiAwbDKf1f5OnS6eKqhWChSUioMFA+hfe1vZ2rmav8KHqmFrhQhUdFcRkE2iEcUauHfWt13crHfixEp+2Zyc7yYvLWdrKpos6dV1lln31GXawmshbSONSxSi1p6QvA++RKy0iA+YzxfsIRIOuHe2C1T9RyX0coYPkLgUK2bBM9gMcIkpTh7ACUWjVqgaN2uaXD5yj5uv3aOX/vnP4Xb77wV43pti+dYKvtCh9BwG+6gVpF4z1a9FGIQ0dRzjAlzIwCNRtPlee5tC59A7JG6wMyI0mzfLOVZgQJzJjJFGeYRb7sOW1ubaDc2kQfF+XMX8OzjD+ELn38ITz35HObzOdquxTCYE9HMRuuqqwmQsTBLVrPxF/MOf+AH3oovfu1pPPTVp3B4Z8O6AUtRGqmp7HQUhm2SYGujw3zW4NFnrXEtU465OHWQjeis1hWvpOVKzFYwm1o0vl2H+qo9poOOKMVIjvkG01i9uL1tCkPBCIGFDTUiL4invnKc7GXAytmA+ySd8PMUQTjNbj0g2/x/FCsignbdjyDvqBN2uUkJZ4DCI9JQgciphzFStEAWprpM5VotQKaMYgtXn+fHgUamH2/gxTyJe8BfQE3HWzrjMSIBGh/ZNz3FCUNBCPAz7neXuOWaDu/5pZ/CHW94LZa7V5BaP0sv2bwTGrNzhSjJdyMEmMRkRVofi/eV835yJBgzrZqK6MqG5jyGMCXjhkZRhepo+xBCRj0dVmMY6nkcoZGynRqseUTWEXndY7l3BWdffB6XLu3h5RdfxpNPPI2XXzoDSXaw6Dhm8/gDcfgHm3nwmCk7LMSOAtvb28OP/sjbcfTECfzSP7gPQIpW4E3jQ6Pfw+sHiOzGMePQ9gLbmzOs+wGPPLsLSTPkbGXIpkg82aZiignRaxG+heDLdtt6IiTFVIk5U5Ge3F4PRQLYegbqdHkOjegNmc1+SAinlKnD3b8VAEZeoVTpcxiVJkIp2wkhhBLFqrNYTe+zZ5B9KeccGbp0Prb9MEbsOxjPByFOWCaxyL5kVClMKNPF0lhwiYXkjUtrajrEaKtb26YIXRyUXbHwXEyXyHnCaxUTVWaIa0syUoB3Oul83G0y2H/LNTP85i//FO547V0489QTeOgTH8XYr9G0LURKeEvEClh46iwS++3Z+5LEGnE2jbXOajs0bYu269B0M6Sms4acTQtJDfI4WKXWOGIceuQ8YhwGjEOPcRgw9D2GYcB6bb/3w4g8jpFPbwK8HK1Foc73eSJwzqXxpp0MbAdxrNY9Vssl1kNG27RYbGwAqnFv5vQXDQYXXrYtWa1/3+XdPbzqzuvxg3/we/FPf+E9+MYjL+LUyR30g4eIxbzshhZCZyMxEQiCI9tzbCxafOOJC3jhQo9uvjBGYYEX021p74PwG4hCqwlBTMCSk0iVwVKRW4zo4PV+k5o261ZddWkLkWkkdzn8DkFTJedw/iqOsl3Z5rpK1W/HStoysyKAVIwXc/05Sb1S8sgj6M9o63xyNgOpeKhGQuHNjkczW2q6zBVSqJmYH5NySvHDxJHxu3wNEmsIrp9Uj+Eda4HAjqzB/MWmKAkfMMjcNAlX9vZw6zVzvOeXfwqvev1rcfa5p/E7H3gvzp07h63NhTO2d+WtfzbJO+xK9I1P3oW3bRvkJiE3jWveBOTWfArtgKbtoLmFjqMz/NoFwNqYfhj95JwRfT9gve6N+dcmAMZhtESaMcfJTpkMrxqHUVDi2wnQxqzj6MIgoKNgvlhg5oQyUuOjyuiUEq+WBPPWe8pvmwR7+2vsbG/gT/7pd+FLX3kMv3LfA9g5tIm+H4v2GQ25KfMossaWDEPGsUNzHNmZA6r44iMXEXUeaeqsFmrBylamAy4TAQVXOm2i0tpsHJCA2pcb9SSkOxb9BKooSpIcppoCudU8gzC1eN8ahVQvVUOGOQd9F9kgxdzjdWTyyow05iaN+3mHFIm+3ymF3gNE0CapJzodGMN3CpR2YMFEtpzKbxyQlvWdwuafvlsWORaS8M21t5SkR1uUqURUwMNI/jc9y1ogXSRVxLfo9Cwask3A3t4+brt2E7/5Kz+FO15zN84++zQ++t77ceHcRezsbHrzS7bOTnHAJIgCXMuT+ZN/bv8aNG2Lpk1o287/nlnb7dR4IdYIHXtYc9ah2MVuYoCdfJnN1jRIWaENFZ1B8TErkvsp1EFOqfFQ71toDUNS8sabYAPOghQiYSbMshJVSVKKtiSJ3atr0K8HtAn4M//pT0Klwd/5+78CSYaasmIajdGShciDZFlPcPLoJrY2O3z76Uv41jOX0bVzf67TTCSyVXF80oQfVENtUtXTBc0Un5CvrzqqpXBjsxglkgXMQ59jrY0B6oa2RR9be7OCqqNYiZ4/fya9+vSbGZIpPJEg3ruxUlwUBBU3UY7xGToiOiFZuzXyO+dTVqUtWWL+/ep3vh8OJF80av0pC1eeUmpgxeSKwr6Vw6v6VPz/KaS3VmEthAkRosIpnGVALLUkkVBThXCxFZkwRpsS9vZ3ccd1O3j3L//XuOPVd+HMs0/ho795P86dvYjtnQ3k0WveiV60igRUziupWnEbbUn1r/xNTQYYoeSxD/g/9tb33rS6af8x+89xsN9zLr3zR3p4c7R0q89HsPMOUVWD2c9IPkGhr8mmakVvMddCaAneBk4Ubdui7wdAB/zkn/uTuP7WW/CX/+J/h6deuIhjhzcxDoaw7PxJRPZmQ5Sezek3jBlHduY4emiBJgk++eWXsBwFsxZeR1Iy6wh3izrWYNiauuyTEUEJwZROQhRGAT8r371kgIfeoOScmKPSbyAl9JrqdZ9QdkErTA0PhUiSMnkCVM9JNLV8TJaPQi5B7KsNnWHhGq3FlFCOCyv9CwCglZS8OMDyr3N4QG1yBrl5GopNmuf+cWhC5gxMwM+rv+oVcRwfpwv72geeEJeUSsmrPukq88+JoKAUMmLx/nP1HeiT611CA13XYvfyFbzqhkN4z6/8N7j1VXfgzHPP4LfufzfOn7+I7S2zgRPbRQlPCpKQqE0qTA9/j58FPCvSMORh0doZOg7QcUAeB7Ppq4MvzPmmGP3QDDrjon+jfqd/zuSKysY+INcrpSL1pz7+cDZJSeSKfvz00wjQtR32lyt0bcJP/Kd/Bre8+i78jf/q7+JzX3oCR49sW9RA6LglHLVnDurnCPqjc1Zcf3oHWxsdnnzuEh569CLa2dxRQoo9joawvqBFORFmlKxQuj4n6WEh1TCh1tgeTw6jJlNXRoaCKmqU8mzeljdlS7rJi4xNf3H1HXMU+kEh3CfSTeXh5z7UZkThNMT/peJLaFHaY3UfBdB2jXg5ZD0oBc9J5wJqLFZ5bFJxgeLeVoEtdZXXLdTpLgZDoatVDBYmsSclRfQCMDlQUSqKJOV6lrbgHB2r3TLq0JoPLfwNXWehvrtu3MJv/su/jpvvuB1nnnkSH77/3bhw/hK2tjZsjp4mGY4+YZqrlF7xbCYpB/4llGv8RB/A1juJQMcRqmT83px5zvx5LD/HcXSBYD+jtzttdyeIknFKoaqxNvysLkQJQaAm3FQyEoDROKYqMKn33v7gvPau7OH4yaP4D/7Mf4TDJ07iv/1rfw+//Ymv4NjRHfT9EDZzzhpVu0IOccISEazWGdee2sSJIxsQAT70uRewygldK0AuxSsUnBOBVVQspo4rm4BICu1K+ubroJM6OKqaa9HYxvBZDhxZX10f1oAvffhPKBDUD1E1jWeCIhuds0I0KjFdZzG3M0cRgs2R/rARno9RVYWJeO1D9sPBaAbEtGzsLY9MjvkqSkWif1HBMBLA5EUAXvqawpFj6KCSfMG8xUgJQlLOw6Qt7T+VavXqb1QiWmOfxcMxEqZJWAYeIlKpNs9XrW0TLl9Z4lXXzXH/L/8Ubr7zTpx7/ml8+P534/y5i8b83ue/1uTcUIaryk+Lf0eCkiMCHssVR1OLRBcaBaDZGD/nMaA8gDi9JYQAD21xj38ex4mmL0K7aBUKhsLoldaI7yI2K5AU76PkH2+kUsHa1CSs1z3Gocfr3/Qa/Ogf/zGcPXcBf/Uv/bf40tefwYnjh7Fa92gTE1FqbWev7O21MoC+t6Yit1x7BBuLDl977Cy+8OhFtO0cdopxTaFlzCRUUUGOLFOtyEfiwYXuXDiGnCgEReVrjOVC1duUw2nJrcjQiKYTWHzkyEESGi+6soI1Ch2JtYAgsmpjtJOCIYT/IldhxVhN9VCsp6xTZkA8xR1VI18qB1QhQ6frtmSdFQgZdwqoZNcwn7ows8MJwqVCVRbbrZwdZOT4zTeghn8FDGhsCDe07FUlIA5Iah5VzgmqE4e62YIMdLMWu1f2cce1M7z7l/5r3HrH7Tj3/DP4yG/8Os6fu4jt7Q1L6mhKiStrJXhfuPBReEgwDot0Jhc/oV6KAGHsn5M0m9/CeOqVcTkXrZ4rP8DgvoAC+62clrH/qcUZ2znR8lOHXrWepEYUYcHPakFgjT8F63WP9Wofx08cwff/4Pfh1fe8AZ/86Gfwj/7xr+L8pSWOH9nGaj2gEUH2Jg8lElFoQLjPSbBc9Xjra6/CzvYMy1WPX/vIUxilQQtbN9ZWJEl+MhCKtqwnHLvkiqtKoeaPwuTT7D4FPMvUNTZNOdX4DnNXwuSg+cLErKpFGLs4GznaTbMj4Ag+1tGGmI2NqUGyfhJ+j/oU7DInqabtYcSKj1k+TOSVNaOB54w4ImoPrh89wQUw+M2QHV1zYdwGEg2YrtFdAtFdtrT0krLCNZX5XApqc2lde0vrMr8i28tmwmwo8QXNCVHkyUIOgWI2m2F3dw93XjfHr//CX8Gtd9yKsy8+h99+z/04d+4Ctrc2/HCKos2ZS50at/9dBMEde6ly8NX1/FLV7hOBlDl6NmH20B81utfAUxAUjZ8xDtnf959M7awZSxU1i5N51YmNSKGmIcLa2jMuCXGOAtd7ueoxDCMOH9rC29/+Btz7tntwZX/EP/of/yne9+HPYTZfYGd7gX6wZJPRtRCbt2SPa9Vp0ykJrix73HbdYVxzaguzrsG//vhTeOLsEl23mISYS9qsjyho1K/R8nuJ1BcNeHDOZY3UmZ35BAoeZjj1HRmlUbGgvFXMqKg30YjGcQhClFxlxZWcmNAL/r5ghDOzSDysiAfTdFJVEKorzZKabPRrCNjnlQFtCseoAm15csWXWrOsBuxVqu64RQEIRR6XM3YACgJfdEkQZrLBHXnhuX/lS+NO3qWnggI1quCUi9qyFFX7sq141yRj/uvnePc//6u49bYbce7F5/Db730vzp+7iM1Nc/hZqE/8xFuJcF5KYmE7cfuXa+LjiTPjHfKzqWQIBBHY6bKwfmym8r03m1ZwvyAAQnfG7/OYwzygFjLAZm21akqfyNnqE9Khb0fAseTUnGGFL9Goc91DkuD0qaO469W34q5X34EhK+5/98fw7vd9GmfOXcGRw9vhsLQ+DZ4wlBGOQwrP0fMvGhEs1yOOH1rg9befwMa8xTceP4/3fvYFtN3Ms9ZSEbDc/WA4OvfcRInZ0dNOPikzz6LM0y1rkuzwVPNh+fta8lvCcVR9VhRXrZgQJ4HX3ACuN/eEokls3xRV2nagI2/5FaZrDsFQdtNbwjnQt9oM809YdmgORaT+lRi5t69LCWgn0EktHiwOuRQa0MNaIlPCFukVdq/yGmrJEte1yVn2B+FMSCFkFnSi7qtuK+fSXHIk+NSiknZ9aAaqCpK7AppHNI3gypUlbrt2E//m5/9LXH/9aTz1xJP42Ac+hHPnLmBnexPL/SXa1uP4Aoy++BbzZ8LPiNRYGWzbNFDNVkmpClU7d56n4QIlbGUb0UTcn8esRfJVBZEzYX9vST7DMGDdD/F7+AcqE8BOdc4e/qNDsG7yynh/ESj162DWoIh10Dl6ZIFTp47h+utP49iJ47h0eR/vff8n8Vsf+zKeed4aghw/uo1+sHTlpkkhBARmApjikEkIUAGshoxZm/A9b7waO1sz7O71+IX3PWYKgYom/EHuv3GTgaTs+HSy35FG5xGfXF1Ju4jMxlbhFu6LUxttDUUKhVHQ1/om6i0Q46V/Do5yTOH79535mW9ALcsxQBgRUxfqnGfx7YRY0aJ4LQxYxkHhZ85cNgqlrKr9QKZg2sgYIyFAserpXRaMYqfvJoVlbIVDhstfwnMRE0cTUgvVAoapQD4VX+Cgx1ry+jOEEtSzzypYpL4RcCYzQaWlfwGsCeJqtcSt12zi1/6XP49rTu5g1Y948ekncfT4cVx3w3WACzqm90Zyhv8QFI/+5DqBnR7LBCA3EyiniBR4sOY4jtBhMOg/WFw/tDsz9PIY/hA+s2stgtA2qSAErqULXgrpHMxcmN3QQGlBJpWnvGksuciSlBpsLObY2dnEzvYGZvMO+8sBTzz9Et7zwYfw8Defw7mLe5jPZzhxfCfG2jbJEpDI+AZuwjNt9Zdmmqkiko6+78034MihDXSN4J+9+xG8fHGNpjGdFG25nZcBfaUzECRqfqZgTT3XJohfiEKdrkYNZF/qOILkUCjVKVEweSfaalHBqeERZjWyWYwNwONase5lj2qeOED5FaoJIFshgWL6kY+yjhBNfmK23TvHGpSszzHQpZ8MVDsNAGvXVDS462mxuuvkUrRelRpq2t++GJX3n3Yf8UFZ7UoCugCIbaaHWogpKB1tLQlb1aWE9RNxxwcs0221WuOmqzbxK//wJ3D1yQX295fA2OKue9+G16RUCkxi3FwsO0I5e+gNtYPO4/WqtN2LDa86Ig8DhsGSe8ahx9ivI6lHc+l3F+m7UHcIVXJeMK1wkwRpSoPRynIL6V/7BFTLfAphk5gqiCrl/IGcgXU/4KlnzuDCpT28dOYSXjpzGRcu7aMfFF3X4sSx7ejXb2FRI7LG8/qT2QAwk82YPnkSUtsIhhHoxxF/4C034NpT21jMGvzCe76Frzx5CU3beltwQlUhnAohVjNJeZE7BUCapC2TQqJ7Jwko1XTrwWpqIvdlFayZ42+awqRFL4oMDVuc1u4ILIP364oQmAwdhknonZswf6ADfhJiyOnDBZ8k2ClEvh/ZZhZtEChQ1asXBWgpjS2DzHK7563FtXNE5BEe2+wB5UKAcsDeVONMjTqkiakUThff0KnwOGAC+GTLYsiE8M3r79e4ZE8ekpEkWK3WuOHUHD/3Mz+Cq08ukKXDz//KR/DRB76AQ4e2jCFRkEssrNOJSctij5dRghDGGkUIonsN/QcpUEKFFvxZgW7LqsS9m8TogiMPfi+ZQ1VE0Dbld0liJy6744r3r++t9VP8UWEGuKCxUCO8TZcToVgJ7qGtBYasGPxMP0t7SHEPahrLDjRB3AgJEBgTT+YxX8cPve0GXH/VDhbzFv/qQ9/G+z/3AprGMi0baZ2u6UTl6CulgcLHZiJqaNe4whGstW23MUZDFzAxhn2EeX6ifYfvwlcvYv6BGIy5a2cirfU6h19RhG4JM2olXIrZIfGN8tfv9qrH9grl63O3fAUJdGNIUZGT0TOf1Rb4aQhgpCb1ByltapEqx9CUuwvcyePFF5hsaxCUm6dRDx36zhMHbH2Va2XltlV318kEOSOaHry7+y+aRrBaLnH9yTn+8U99P04cXSCnOf5fP/ch/Mb7P4ejR7Zx5sJeMJgC1fPL2BlLrRUH4DF/zjc58XglWxMCoNoqgZ2YUzH/JD2Yzxe7tzld4U5ImhQedUhAzqXjbhLBkMp9irARKgjQlp6cQVGtJ5O1mgZo22J90tfA8usm0gMRHmhJwJhdaTL+7PtrRUKKJAnDYEL0D373zbj29DZmswa/9uHHcN9Hn0aTGoTjmNEf8jzNvVqLwAU/zTUwEc2cmXEeBLUxGSExNFxmLqBCY7i4bDSRWa60jngYckKGxKfKUF9hDDOl7fyD4lVgdAFFg4N0IBPBV5DPdM/qMueyMHYds/0ic1BQFXyhYiJBC4G3Zy4e6JBQIsGsuYZftZSLwTEeXgZbFwDxfTbF1GC+EjNgyEUAc8zUoyWnHhAJlP7BaI1gtVzhxtML/D/+yvfg2KEZ5tuH8XP/8nfwr+//LE6dPoI8juG8DIux0jqmgaUwvRZBQ6Yqh9ROtXtTaWpui6UAmL+6Oq2qihCULQzGdybmCTm8PqXqemdAC7eW95mxKPydK9mU7xHG+s5N7OU4YQZlDOKmlQBAtmzBRBgtXmlIM64i3NQ02F/1WMxafP9bb8JVxzexmHf43z/4CH7xg4+jcS+1SAM4AyYXBHbripGiKo/+83DbTZnEAUFQF5PFKs07OTBVpjF2Ihn+HrQLY/Up31X5E57pCaJSGKMmqcNzVR8MIYYxOjZl6UfPo0LOgnCCh5nqo2eyG5mWqjUsDalT94j8ygTaxu3gMWLLXEP5DvrXBxRLEiOxhyqlVrlCXDoTotuYpPqqlsVToRwMwRDfqQiUgkk8suBPR5MEq+Uat1w9x9/7z9+G7Q3BoeMn8S9/4yHc/4GHcPLUYQz96IpGY3FH31TNOTQ3Dw6Fb44A0ZKcQoHPNaSE0OQjAPEyWac/sNlJyuW8PGoPrlNwerW+WjFjTXt8K1P7qk7X1b/HZCr2l4/9Uw2hwUeUnv6+C0mMqauyWUVJHpFsCUlsRqlJS2t3uxH2lz2uPrmD77nnBhzenmE+a/FL7/kGfvGDj6FpG8RNlc7VFHNEEpQDOUljZdWhCh4fH12jQIYADhadFQeoTNbK6KvQbCSlKdGHhW0Zdap2h9923eTX+L3YRzPoNTQK+aD8bn9zP1zgHjBNiwnjgukAX8Hn5kPx/TeFHid8EQ2q0UDbtQ0iBMUB1s9VQEcFU4btWi5CpbsrCczKsRg6nSrKWWsQXfgDSDaCSEqxywnxyoJMD+SwMaWUsFotcctVc/x3f/4ezJqME1dfh197/9fw6+/7HI4e3kYec4yrfgVvcMyK/1VQXgAAVq9JREFUysYswIMaWoGADgWE2rzL0EJaTdKj6/Wb2ur+DCo5ZdFgNWAta0P6rMUl17Q2LQDf9Jggy0dr340RHDvP1qrH5LLb82rxe2+1b5Ni0k8SpAzPjlOsB8sLeN2dp/GmV1+FxaLDOCr+8a9+Ce/+5LPeB8EWRtCgJEtJCDr1QzQm9QvAJDtPKkhFJrS1lcIwosVSrfffhTKTjII8fY8c+1Y8qyjBfqonCTM3nu8EEUVyTlARxw/iL3xgw9ZwEpJBq006MHa4xq/eFnPe27T9/uM0w1MxDQO3pPLwHGdOIGPSzroewIQAyzWx/uDGFQ87FzGrFojsG6nVzRkJeIUzUBx2KizjSsvmm+Zf4ebTc/zUf/RaIA+45sZb8Rsf/jre84HP45hXpUFi3SuCQQi+Go5rvbLV+hdPej087niFEgRWq6/l2HEuQs7shuPMmoCWNRlTJeFEgUATBf4jBIJUQ6DwIGWxd4QkRIxYklT7VqZB30HRa9S1CUj2c8zZjnBvYQjAmstgVENgQ1bs7Q/Y2ZrhLa+9BtdffRibGx1ePLePf/gLD+ELT1xE185NI4nd86CjNIy/UCqFYaaif6pspgL7oK4um8l9BxApwSbc+Q3zxhfBWe4x6U/hNxL+4ZLe3RYhvBJNy0opJi+iI/nUma8UAKEFUQuJ2k+R3MNvh9cY/dCXkAOZxt5WvE4h2fa9h6OqXQ8o6PaDhbta09bVglSkEytaazUTKNlJyDKxmPUkkKoJaLW11ZpTJMTnTtR1vXtqElbLHjeenOE//2N3IucR1998M/7Nhx7G+z/yRRw7so11P04YWypKoewJDY7C5FwTmnYxs/r36g0mftB8Kj0SnYkqic84edjj7IojfsS2kLg9oSQIo5y8dHBOoSmrlQu5QEIKB6aUuagTt49rOj8pLOFZc5hY32LKolfsr63rz2tvP4k7bjqGwzsLNE3CRz7zFP7Zu7+Jly/1mM3m6EfTqklSCABTliWhpSazcNABUZtflKIi6kZoDvh82EAmVEswrLhmzqWatJYKBY/aRyJBHyTQXH1e0pQrio3x+bgjvZh7Ztp+IuxRvPYxb/IH9TIraskXlZkQWt6bBBxE4nx6yWZUtJd313a4Y7Xig59wlCtNwrsENK5sYA6ei8sBgESllT0dDTkq7kMVunJqY0Vi2EFaa2fTqSkB69UKN5zo8Gd+9CaM44ibb7oev/Hhr+PDn/gGjh/dsiy1kKgVcctk3YsS982Uigu4oWRmqt1aG8X2U41D2O/S1o3OSqEDlM5VZy4fQOLnPtj6/mA/BxcQTeWEI9PQ1q+rYqtVDqKitg/SLfIX082oTIVM6J3QNubxzjlb/r8IbrnuCG669giOH9nExqzBS+f38L998FF84LMvAJLQdC36frQOQJJsMvR7CMp6kXh9vAxbpWo9yjArO19r7a6Tdal3yWi4EiRkYNJ3JVghYu3wY0UOMLoV4wIHHeBcVHfQRWa6o5nQ8GEKaA0ky+cVESagQsZSfc41LHBf/SDeUpgmIUTq8Ht79tIK4+gHTPiX5x2fYicB5RFIjd18dDtwIqIJg0KrpCqJhVrQPmUZaKAAX5TiE6CNLNPd4J1885omYbVe4aYTHX7iB29Azhm33XoNfuO3HsHHP/c4jh3edMIsxEJ5VoinrB2qTT8Ii2t0ZHtWk2H9+3TPSnjTYb98B0artIcImM8RGm0iwlP9azHLavhcj7tGEdM5VX0SarMHNpZSeVY0kGVAmoDRzLP9FJuLFtddfRinj2/h0PYc81mL5bLHuz/9FO77rSdw5nKP1DaACvIokDjVmYSPoJ0SGrPBE6swUYmIip70qYmsgRLgzE2HH4XnhGzpR6iaSPpTfB9C09Wr6gRy4L0DkDBYIfwXxaxiU1T7uLTzqtFbKYhzWqmIkGFE7hf5omTQ2tqq82TOVsRXUC/9febiby/sWpaas1wpfVWARTjeUMiliRNrKoMOiVj9XTtFai3G30ss1guOyrnP8b45iGmfcTMETZuwWq1w26kWf+L334AkwKtvvwbv+8Rj+PQXnsKxIxtx+kx9y7gPKkKI0RdtWkPFev8nc6j4nqjI5VOFBArR1e/xZmTaulVzbavVtGXptBoPKSksJFu+yriTMBYPqJaMP15T0y1Qko/otwCYPszyYy8g6RIO78xx5NAGjh7exOZGi415i929Hp/68vO47yOP4ZHn9gB4fYCaCZSkQWTlxV5I2No2vMI08JJaMtWopR28OYM8/g9nealCkCBMV0de2Z8pvp4Sf0tQBIXSdKNC/4tBBDoq4/OJ6fUdCAalPiQrFR6FXxHEDI9zjyyZjtEDV5nBYgdSiESB6LGQoTJCpbXvpGqGVDqes9HuLQcMQ47adSglbpFaKsAogEoCybBgzyLJJ7OW8rBYP9pn1RpZ1ZgvolATSmEmSjZxSNMIVqset5/u8K7vuw6qiuuuOYr3/84T+MLXX8DRQxvh8GP4jZReb6tWv2j9RuWTEP+wZkKAdrLNMVXzLZVrElqCRE2nnzElDFW5ZI7OuqDN7+4mKWXVIgplCBHe3VUTUtLw1Ygw7u9oLVdCxcfNs/YkKAI1ycUv1XEkSCLoZgmzrsXmRoftzRm2t+bYXHSYdQ0uXF7hYw8+j/d+6ml84+nLvq8GsrOa40yYOBGSkTSRYrwckDFI8TNoRT8RqXI0MGU5ATT7PkkR5gfi6lSvIignPFe2dozlIBwMpCBg01DumcFrLSXM/Fpobwp5nZjIUxQjJcFJa01/wJ/k86+VmC26t69TLrCV8c87b2Drpp9C0bud3w6jYr0e0LSlBLZNpQsMIJ4jYJvaa/ZmBb4JbEdS7WpdQ1CSL1zysASSe5F9IdjuSMqEuVe2h7bQ69UaN51s8WPfczUu7a2xmLV44MFn8fizF3Hq2Ib3oEshlSE8awDlHIjy0YQwilKvQmhMnonNP6ihS9IOoO5kK9o1Mvik/t0YmRq5FhzJswiZJJScb3gNE4Gm93JmqK4JmhA7alt8woWeC5iMJqY+C2kd7ougaxu0bcK8a7GYN5jPWsy6hL7P+NYT5/DQt87iY194Ac+dX9vzGuvEkDPAtux1BqSGcCMyYYYLBakWAvY1tr4i1c44jbBbkEWWqk3lr3Gb8Ns7XTp9aoVaGZoNge73yZSQGeGHUtPOcX3FrAWpVk1kISW3IDR5LXnD6wM6JchRFOiF2QtSQUVnhvj8fImsQLaSdLGNQPLDXHnxaj1AAbSzRjCO2Y+Dtk1pGieAgJzMUmo8Zh4ylmQPxAIUaWf/8xbLoCQo8LJkBLpHVCgISgoxxwQB+n6FG463+JG3nsa5S2vsr0ak1CNBcddNhwOmxkmooYULOKM2LN5wBEORYVIqxDBJ2RXrfV/+Lr8z99/8W0zVZSafIDWll2DTJLTJzxAQthu3+7RNsvXntX5sG6sQi6gpq65sJZbVOwYrhnGEZtjfvn+agVFZgERa09DyJLLGS6CTAG2b0CSr4Lt4eYUXz1/At5++jK8+cRHffm7XjuyGuOZJXpzpKC7Wrwgk0/jyiow0EpQpDP+FCKCeKyGbM6Wqx1eiUtX3LrRqedEsqhmKcXMViaalodGrYjRSMqMLDGdDpbpvcHQlWEiH9l5p+un8EGXu9pYeWJKa4ZUXEhX6x8VEcaepjhDviZmzYNYJmgT0vSOKnLFaDQCAtmkT+iFjc2MeJ7XMumZiu9omFiwpKPtzcJFtoevkwwIlS4NPjlfiHoQmwZSsofWFH4eMV9+wjR+69xgu7w3oh4yNOfvko1SiUbKj1uPUBiSOoj1jc0MLcyHhqbuVdkxFmKSG2g1hYyVJIUCEjO0ComlSFO00jfi5AiaZ26YUETXsHwgTGtF1OIRhhbZiDzScjI0k9J6skkmwni2Yvekns8dylXARYUgF9vbW2Fv2uLIacf7SGk+/cAXPndvHsy/t48JyLGsqNlaoRsQoOdRP0sRaA4w81MkTxRsPKUog2raTaoI42PwdVY+++nbTzMppYhoVkz23Ti6jFvVHhOAwpOKspwoIj+0uef1UMuLrScRLpmS4kQLJIWMgLzpVXiGI9ZVzqAU/Z1kUWJUoJ2pKNKml0wvQNo01CNXRUq9VceHyErt7g50MtFz1OHl8K240nyW0EAwksCwYR41ikGlShRSk4IOuEygsF7pkbktFuEyPFTeOswJNXTUV97MN3ltnvPtTL2A9aOXdF7KDIQfUizZ9hbMuvoAKCE+AVRFGUha/UmRxFQ6gi+rWqCGalJtVggbVfV/plKvNjpgD/3fg2jpeDBDeOvxVu1vJc5h+h8Srjrz29kZc3B/Qj9k6BNdj8nTdQBHsXaBNCHRSRMlXYJWmcUdoWN8Q04z1BFE0HEqIVAKio6Q6xww41xLCPeikjntVdBCKwhm+1qjEsuIIoVDwdFFY8AMp/hu+X4QN97lCBpUGpdmcNdyTKIlJWmXRVs+1hQieshb/8C5T5LURm4sWSRT9OKJtG4zjiMtXVhgVdjbg7t4ai/kMVhegWHQJs8YOarAaDbYuapGkQc5jDEYmw6kWXov3MQogaM8oJSs8pm2agc3J6wQIwKCrqOKJF/ZiQabPTEEC5SdddnLg+v9fXtQJ36GsbvKc//9/mXe8ifCvqljqbtV6TKjRxHv2V1LNaL0QsRby8L8tlzpMNSXKZHKDRgp1KI2akSEGv72Xfg5kV/uvylxseyqaKPA2IHVB51pZIJ55pxpVnxSYPhAX/kXYHUQffGZN95EgEqTka+qFTsqQbwzKf2q1zqGKzcuRYK14egWgyeoysmKjNZMuj4rZvEPOGfv7ayQRtMtVxoVLS8xmLbquwWo9YHPe4MhOi92zVUFLVkhj0Dez13j1Yq4bvZe1/RRQD3BnjgdovPBGWfQBRKy7sFNRgU1qwSYcgSCC7ycpXTYapk1SGIVCYBw5BoeQxlKejOojkPZJ9LUOEdsYxYjSjrTMn9q37ONED1daD3GvgxrewUYlyqg1JcY3hQf8B9AHQ4eV7UMujFV/V5y4s3nw4b4fWxu/OEnVglGCeeuag4NoqY6dFy1tF7GYqcyxJPQoak+7O5W5xACEraBfIVyq+Wu9xlX+xER91Qiq3gyulzrZVHtZafFaQdtXpyFkMkI8ewJHK9LkEnoFI+9oPseaPl1ouWNSRdE0TfjBbNftrtsLy+LNWbG5Mce6z7i0u7IuU0NWnL2wh7ZJmM9b7F5ZYTFvsZglAD1UWpMmvi0BS8Q33uER4602Xk9TUZPUbpqEo0aqTYXm4jgiJRIacNKcsntfea5f1lzCJa9YUErMatN9o6MPW+wa481SrneblfdWaiJez69n1ziiAHO+MzWjl1+KTKIaIS5jENY9iZ1zrcQ5VYKuEIkpTnMmZRJp1XWyPlQCdhtEGnLNENFbSH0NfVa+p+HxFtbq0yRKiLOrgBBWdcUenVGM9oQWkwDwgQgEgLI9l6h7rTlaE+BmKroQ8PFHmbDHw2k710xX6Myf6cNLzlAs0kFFKyRtCuo4KUt9NmyCUtFTAAzew29QEsaqTFuOhT02K0EUq0rlOWm2oWDKc7yjxdnZ+JmRfR5BR2lO9uxjh+eR2LS5YUeuX7rSGwIAJJ89fyWpmnR4YbyM7SZhZ6MFsEJJObEHWp87KU06SRw+wUIbJbNLBJPzzrJruaSYEhc1pS++5HrCCj2wJI457Ek+FqFELBeVzQWQxLq/WvShMEaSssAiYg1PIJDkmxclfRrrkQBz4iBDiNlgXXV5UGld5PEKG58UAIWiCQddtYSVTHNtyaQhGScOvYMPILOUItkiBFPtjPMWUhSMfGgMDS4Q3FkVxbokXH5FputOvwM7nRkzs9DAHX41WKnmWNvxVAYJTJyxSZvTl5WcGug+nInQyX3NGSomaJGRRq5R5cNBUSZaFd0U8KKxpipenwEFXFFE8aGjAn4jULDfK0euvg0we2g95GROIRBtGhbb14NmbbVGqUkGgnPlSM/GvUcPzaz2JAHbWzNcubLC/moABLltG0nnLuxjuR6wvbWB7KfFHt+ZA7jsxDEiAxhHQde0EzuHUF+TaR/jI3svaQrp6bvjyTm2EsyDt6wWmFRMFKJFE6mgtD2uaaaCSKh+rZYobLPQvdoAXillBOvOJXECJ+OmiJIDwubToa8naGMilgSuiQtxQFFgK4m+eIWCBOOvsIkrjprUs1qFGVG5CcDCvKjvdwAySs1xLoCzrxOJ6RX+HQGhhK1JaPuyCKFM/cYkeo6fwoR2slmCVWjLlQXnUIQsObCMmQKKzzVBUyfIVGsJ+gPKPQQCtrcTRxZR0OPP1kBBGnMIckvOXFoK5sxHYLTKXAeuQ0GznGIJ4YUPpZr+ZNkFE8fgASIqii41yICb574244h5Axza6jCqom0abG3O8dyLl7DuR8y6NiWofGJ3v8fulWU+tLMAYC2kTx6b2dZkd86pORFU1UJ0CoObqvGzQl++6QrCH27zRDoKvG/ZARtK4Wl82SFgdi1QW95iWrbWUqS3ILwp8xfp4E5D9Z+SvHgiEp2DiEQJ8QvhiY9RAi5zI/2Z3JrKKJxsMIm13nDORdlrrdpn/z0850otZwLCCNB9HjFnzss/QxP35ZDVhVUKBhCEuZL9Ap2unjX/mKjt6uVkSqFLRpVqvv4cRbVv9MAHs6ZYxXr36sdQhhbrYirewlR19CGazKHpe0dCybCYPrthkZYnix4C1J+bffyJUaeidXnfEm9xhVJNwsZQzGnzmXnTEeXEnMayOlVqJdwRNAcx/1bXJKA6S0LU+jEc3e6ws9li3Q9YzDtsbS7w0pkreRgzMvQTqevSB/eWPV4+u5sPH7KDGVf9iMNbHVoBRh3dMwnQFk5tW01QAw6lAzYKx2lwuHj34ow1aho10yAIwH0CmbC6cqBYlxU/cJM6zaWosbCA2NDWp/pcKuL1ccBllAQDOvMqSjdVGExOoC1PKQBv1unkG7afjaG0GQ9O8A1j1KJQs80j2bkB9WcqkZUXbOdYUgRAsvMGC+Un78FQnVrs8zeoyme7uVRbOBP16j9TNW7TlxUh16il2vgJ/5R9DdSgZAjfI1cwfgofWPILLe3Pg+6lEg0+pkxhS2FSj98VTEYuR6SrQvNYEIYzrYBHq6fwK3J+pmxCBFRD4p6nWJNiC2nQN0yuhQrjPOg4j2PjVINOwxzWItzgqkkqIQHQOa8VPwhUM04emWMxb9H3GYd2FthYdHjh7OUMETQiH2ylkc3l3ognn72Am647hlnXYbUecGirw5GdFi9fymhTC4Z5cvZYYipOqum+pyhe4LLG5wqUaKqGFi1poD7NRKmaJpoKqlEQw3LacK5VItYIrUoH/o7aqnrVUJzJMXxPyvtSQUTEs23cPNVYpHIKEQTw71ql1zBaTQoxclGK/4162OrZ4KZX67HZqj8oMu9iTpOpcWeMIWIzCuOKa7vonZfoLfdnVI5G3r7OB6GPpCCi6doStdA5bEtcLgzMxYWDTICQrXf8D3QERw6HcTPIkIwYGEqYjouCrERSKsEaGr3Qb5kCGQxlDUEzA+X6+N0VSdAV10qBVHIvpiYjhZuvb+V7qkUOs6FytiPvoMCQRwQiNxsL151cRE3JkcNbGLPiqecuoLMirc2kY94EBI8/cw5NEhzaWWC9HrExS7jq6BxAtpa2JJBsnveUUhB0WbaiRQ4e+cUYvwbRkfBdQziTh82mgHiLIyIEbpLCA1tSFky4WLHGFWHE1nCzKw3rTSnDKUVt5keYGW+OrkVQEU1TplATqNOFVr9nra8rcw6NRYKvtEtIDYh7UEmSKeD/NJGnOPnKc4JcqvWhZHCbPjQ0YKcOmPMrioFclicupk7v7qo6GDEERvWxVO+TuEN0aK7SOMoMooxWNBDjQXRpR9hzboj1rHNIRDNqvEVRA2hYgvYvlfWVCsJL3NZfdSsQTIR4mSs8yOKUFkizTtBx0RF7wFWlYPBoiORAsmXxFTRfRQRt2xYTBhYdshO3FNec3IyuzSePH8LFS/t48cweZl0CFJtJNH8AIvtPPXcx7S97PX50y3PKFdedWNjzPPdD1dofjMhIXVc2C1oxI0NitfOFYRx4F5jC9LzChGSqtKZOmaZmNNT2eaVlA3XQW+13j01GbEgAai2avTyHgzAC5TQ0/mXvpV+EisFQjQdJJYkJ88hgtQPNyQiijpz4Jk2emD8RDx1XmDDkQfEx4UKuuF8f2saWokRwQDu0eFuCUWuEQa0lJOcSYjuYbSgqQQclQy9NuTkEpFT74yvp0aKSVmvabFQmA3lIOBfFAYR+hyb6RmzMNj7ft1zNL5aq0IZqKVoz2uFuUDhFto6lMAciA2QECo3ZdLUcM10EP8fg65ZjMGU3a4XCdYnkpGQHxrDQh2MehhHHtlucPDzHehgxn7U4cXwHz75wQXf310kk7UPyB5KcuvxBESxfPr+fXnjpEk6fPIwmCdbrEded2kSb7BRb2psKxZDHOCyziOYKfk60T/G2hyjlx9kXhx7SSZfTFFqjRhj6HZxTRdjEThUNFnFJmTw6xqnc1ByMWV8nEEtUim8YIQqsP7wlW1VhK2Swf7YCluascE3GTSqPL8FDBLHUSKWUgcZMg8lIkt8R5Uhh7Hq+6gk7IX7Kw4yoEgm8jKcoV0URAn6V6mRN6YSCCymtUlU1YuiuUbwgSHigouRg+nqhLITnJyOrwk8dRdTUV2sQNJLp0KvWG2VNKAwjDTm7iUI/gS/iBFlV+zbRXgJE3gaVRb3mKJdyzaNfhi8zYt5aZGMIPkwEZkHRQNM0to5ZPbPD0uQ1Z1xzYo6drRn6fsShnQ1sb83wyBNnMI6acsay+/rlD6YLTxzeblJaL9cjvvn4GRw7soH5vMWyzzi8NcNVR+cYx8GZ0IZs0QB/uNaxYRIItaBprICZ8BgoqonFapW6cBXacGrZV77LgbbMn2UaPwG0ZTXsavuOQDxBUH3dSSXFTqMGa4JjAVovxly8sHbEHNgTTZjsskqYFFkJpzXO8AvICgoUQmw1Z30QhaJc6lqx0oRAaZAxKTwhEXJbqpEzL4Agt5hedg+CmODByqfhss8zOO3IKanGr/53CFLOw59hJdBlRFxMHpSas1U0ZrXzKM0h7KaYrwf9O1wfry0s1Ck2mMxUW2jF9Vr8BJ6IE0omIUwR03UlKhM6yVGQFY5VfgK1p4cSiDn7uJPa9RSOEcGpIgHJhHPSskdGZM4fFbqlgw8CtLMWo2ZfwzJNYMQtV29DxLo3HT+6g2HIeOSJs2itE/j6wo2Ht9OXnrx4UYF/0qaEbzz+8tA0CaeO72DoM2Zdwo2nN2AVUJVkdGJuuxmkaayqDBVkr6A/nOyEUBhFO4eHWi0aTa98KpSKCKdJIUCpbq8B/ZwgXWNOD5KsWVdtBKnio0S7SSth4U+XKePwmKiJchUSoPsJtFoLpx4JL7eHnPifb1zcMTQU/xWNASGhodiE9ZrzoRWsSJU6IT35jlQVkFpWiILOCVgkglAAJJjfvTXFwQbfm+RhYqZeV0KByhtOAxn0yGc/UozCg/4ejgduSrhioCBwP5T6XMUn6DGQ2Hf7rTAQT+wNv4TAzjQo5BI0Bd/Pspflb9IIxCNatMPjOt4MoQxZsQe/Lh9INiqqUsoDJwlAEnvYti2ABsOo1ezsENqNLuHGqzaxXI8QCK6+6ghePHMZTz1/cZjPEkboP/nSkxcvJgA6jrnpugaPP3MRZ89fwfXXHgXEuobcfNUWGrHmjwyZCIBhGICc0bR+mmt4VFAKGUSCgegMox6uDyExGV6mkHMGNKHkQlcboraZAdOLAwCFyrRkJBJ2ej5BCfeVTVVvIBAakRK9xmIgrC8oJRix2ivx/xeEwzuQ4e0v5y+jBYe3dlS4C4WxhK2s7t1aYhUi8N+lMKfNs5gwJWDmRFYLqZiWEW2uxhaEzCWvap9Yxx93roQdw2h5tH+iPPl4tOfwDELT77G+VA4aORBSBD8KsxDp1ShvEp7z8SsPuSlTLKaJ06C68hCmKioKDVR0GXvJ9eIvOqmwiGvh62/mmzuvVaK1msKP7oJ7IhwRhPhJZS5F0NfKzO5izr8OeRxLAww1RJTHHteemOPwVoe9ZY+tjRmOH9vGI4+9hHFUHNma4dCibYAox5EHoOgv7q6brz92BtecOoytzRmWqxGnj81xdZgBTEowyTXkAbOm8Tr8apjcWK0973ZByDIyq8Dzsl0TCfuxO5kmxkuprfyViuSc7A/Xi7ziconCxxBGSbs0xhCwQ4vAtS6K/Wfe2sAE5nyK5BaNzYZ/18zLjPA2V3hhkkBkCxEhYAgdqJV2CYIlY+bi8PKnIHucW1EQkd8kg9GM0sYl+KBSnbUGKdfXjtzsDiba3lrdqzARMxNZ6k1IHjA+BHa1P9w2D3lF3/vKqUp6AswRzW/VaxkR5STQ6hFF2xsU5yxN7EQNqu21kGSmfpJCLjKhhyQ+bs1Oi0anWTkOxeh+FyauCb/IOXNZKgVL2WfzYkhUA/6nZD078jjE2pf0/IxXXbeFlATr9YDTpw4hCfCtJ87g0FbXLOZNv7ORHgCX/8Y3/tBHMvSCQNKXv/GizmYtrj51GP0wYt4lvPrG7YkaIETJXsTRdV0FXQqxM8QGf5IJEHP6RKi9mrAxUmm0YYxLwqHerBaKC06NFVJIPJXAKMxookITMCFQi/saLIK/uQPrYPgJcO1I/wSleegDH6ki5oO4s19fHmUMyFbATg3hqBO7e/I51EIntF6q5V4hqGDA4AwOyndRXIMShWS1k2Tg9QJEKz6QSIsNpgdY1sqdD2ajPc1JuAC3iAiKAKwEeIApN0Pi5BQAJb2Widfi42DjQ6r5ghKKQlBnvIJSRQSa7LRcXsZ7qNcLEIWUPQ2iC9pjvMHITWNOSBTYU9oT0j8Fesi3wjekqNARCkShAYAmNei6zvgvVzTaAP0w4Oh2h9uv38GVZQ8RwTVXHcWLL13CU89d1PmsTcv1cCFd+/JHACDdcw863HcfVPXnNzdafPvpC8MLZ3Zxy40n0DQJ6z7j5mu2sOiAIWf3rhYNNY4jmqYJqCKC6IJTtAeg2Vw1mVqtwkRK0XuAKbmBsT4KqOSy4E4YFS1VtQLClYt75iBmVFrD3siikyK3HByVUYbsHvTIHUCYPnXeQdjZKYWzuFDAVBCVnxo+EBtXIYw6vhJUIDYA8TnTHUbYmGsbNiSQO0oLacG9Ly5ciovQJ+dErtWzrblHQ42qWjIhi3grXnb/nkgDiOfNkzuJIvx7WWARl6jscRtfEfkAYT9rlfDCrjpwuqOZIoXeXF8XR5kINFbOcytcK6k0sRZQiXMtYpyuABFQ3r6afU84NVVmj6LiBarPogFJtxXVH3i570DtjIS2tfGNY0ZOYUyYIswDbr16A1sbLfaXA3a2FjhxdAsPP/ICruz1Q9cljJCfB4C/cA+6BAD3AaOqXkgpjZf2enz+K8/g6lOHcfzoFvZXA47tzHDndVvQsQ/6ozN1GEaoAvMZ8wLIHN9pIqRpqworMVkSMhfT7agcCU/VsqSQyoU4i52myjR2xrQLUcIJIiDswSFWAiuUXcWl0YufQidV6ICaLiQQm1RUjlOSgPB+vrlOIBQufB7npmoCis5Pkg2fnWLYdMgVhqXziRQpdDqSKLWUpVYZP/5t+xwkeH9y/F3lh6C6QgC39SpGN9d+XGjLxaQXjTUJoVDtjflviu9mGpqrBuBMKdVP+72ghUBmWYEsZS1ttRB2OahZPRkNhb7s4uJ8jPWicOE7iUukpTV3dY1WC5h0KuYjkyUUi/FLSg2atsEw9hFRU9j65lHRJsHdNx5CP2QMg+L6a4+iH0Z8+VsvWov2MY8Y9cJ999lupAcfxAAAbdafH4Y8zrqm/fxXn9e9/RVuu+kUxpwxZsUbbj2MrkF0XlEgbI5hHACx1sPqIZ1q+2K6Rhw8c1BDyyqKd9db7AJetntA+YTW48YddNAExHQqU188MjDUCIpRgGk4EAFb47Noo62FcFGF0zKZxMckRYDR2I6GkVTedlBfoXdFcRo6cdVjAyoNUws7H6hdlv2eStdKmX/8Hvq4wFphFKZag5gNh801LkZY0WVc+6KdbY4HRIbYIS2sKeFFRCws44bvF8V2gHatTbSQsRGKLHUhhRhCyEfkwueTWOQeq4PqWzFPBaMots7Z7y0VHZbvVOFw0rsa3WgItFqAxizK3k721/V6KDZTmt1sBkAwDqPdJSMiX6Nr/9PH5riyHLCx0eLmG07gsafO4rmXdnU+S+3eWsdVm34eAP7JgxgSAH3Xu9Csj145r4pPL2aNvHBmP3/h4edxyw3HcXhnA1f2B1x9fAN3XLOBPHhHnkxoJhjyCNURXddN7LmiTcvGabWJST1gQ61G6BovD84Kzyik1KVN55ssByWwv1fURAgtye59pulYfQ+VlKZZEuZOoI3KExHjJmWRWKfPpPmWWbcQ0LdMU9U2U0WROV94FpwTGG3d7GZJHS+2HgZGMLXW469k5JRToASabS5zEB59T1oqetErIjkM/pNKYPhnWeBq74A6FPfn2Mr58Mg+hSnElYGNtyDCyLoim3EwUrIAeBYg9yPy7rRo8OzO0NKApjhAxdNnBVKEaAXdhSRSKZi4vxZHK4VpXOf3p3IqXFDELpOWCn1U9xZ7r2tbJNPifo+yxhkjGsl4022HoQqs1yNuuPootjdn+PxXnoUqsqZOzuftT59bX3f+Xe9CiQIAwIMPooekv6mqa0nA7zz0NFQzbrvpRCRq3HvnUXRNdhtNgaRIavH3YbDqqm42t0XVsr1M1jlIEbXNW3QS30soGS32nHKfIkRQPaN4fsV9FR7fD0cfotuw8jscUjxXi+yI+9Gpx1g04n6RiOTf1+zhRqDYqTDGYAQAApbXHxCYlQBxZicLxjFXAW0VxTGrCK8qtXlFn5Yp5kKI0ZPKuRaPDC3qfo1K+0j2rsQCRBceAFGW7AVLFM5BwiIFGDi6Kw5fChFKc9/K8ClYum/R0+7wdY05JmBMAkFBYCEruXYVagmhF5vL75Ywo1aMrVBPKOLegdIltgiAFU4JdbZHFygQeW+fh/oaTBzLSi1eKRcXgCK2zXT86TigHwcrPAv6GjEOPW6+agPXnlxgbzliY97hjltP4+nnLuDRp85hNuvQj7o+3Zz7mw8++GDPR5sP4D4TXLvdNZ8ZBr20mLXNt5+9pF98+HncfvMpHNqaY39lKOCuazcxDn148KN7iwuBtmnQNI3ZK7FUqCpiuKC220w/HX3DmpoSglps9VMu0JAeVqG3+oCpmmEmBkM67oG0TRWJ0CUAaIOqMKQBJydqhJal0hI1ozphOE9F1IpQVFG8+SZ8bB5BTE6xLAYiFDGZwnx8f88fnBIPIvEBq8NULX7jEoKElzoTRSm/EiiEEBzCLL3pZ+rMjbJcKAk5PoeSjgiOOtGo9++Fa0FdyHsSGO8pTvUFLLrlTU0MIBqdZ1vjBI/2hDa376ZgVl+icEi7nPTx1iaR0SJiTTmeQBkS8ZWyK6QvLT6pOrwdfkSum9Mu199uLeGDKaXOGuvJ2c/ncwgE48CMmWyOa6if1wm86bYjEBH0/Ygbrj2CY0c28dkvPYtlr9o12iRdX5rtXvgMAHGeLzlj73wnmrsffniURn5WBKMqxgc+/xSaJLjtllPoh4xRFfe+6ijmjWCsStw4mSFn9OOI2XyGpmnB9kS2WNMJlZdtRCIiCHJgchA5JXl7KdNMmcetarkLF5tCKTkSUGicqqtBnFWFK8TDKRQsPu6JqvetrwhJBeWocifegP0cEacbKhHh8KoiV8H8nC9teYhAk8Xzxb9ssoyeckxbUfO5FXSt9TttjXDEu/1RMj2rgXoiksSYvZot19qtQFE6WkWKBib0yOGd1xhzIDt1JEGlQMSmvGuOPXSRhDAVcnaHbc3MvjTiGrfyOYSX2C/LdFZONirHvFOoaynIxgUEHXf1SVfgfvI6KfOi6resUBc6kyyrkougrlzHbPyUUsJ6WPuJD/YfT0XM44C7rt/CTddsmPbfaPGq267C8y9dwtceexlbszQOaMYszc/ibozvfGd0ri1m0gMPYLwPGDXpzw5DHhezpnnsmYv64FefxZ23nMaRQwvs7fc4cXiGe+/YQR77SciLYG0cemhWzOczl2gHFoAyTg7QPNSZFbHYKFfHwrIKis1FIWR4D7lxBXlbkWBKdbiuTsuhCbQK3YDxXmogKY1Baq8cSTElZJXqNGR+WDVRqaYYit+vmdjrLlXo1Q0toE7wkPBPlNx/KXOv2IDjY2uzyWdaxklrMgRbWXSE5nZiVMK+siBeDIUgS/JXABom6sT9i4NUJ6vhwqPaD+r15IkObLbqLpwwIfh0X+4Q7GVCCEqXHBgyBHTk53Nd/LAZwDS/euFXCOagXWVOY4yA20haKEqg0laT33IIAQO7AlrmFvLr0M1mGIYBeczG9n59UhMgG63ira8+hpytlf9N1x7HscOb+NQXn8Zq1euYZs1qwNhr+7P33YfxgQdKLlUIAMCcgVfS5csAPt0kQUop//Znn0S/HnD3nddgzBnLPuMNtx3Gie3G0oFJClK0at+vIQLM5nM3ZX071cNUr0AClYZC0SRk/mDM2n4DwheRQmQW6GfSMcfd7Re7PvKv4zMtDTBoYwt9goZPXG/GGEvSldse4XxzfVLBOomFljIv1bClixT1OL3AOg1ZJ4cytzJ1I/RMGEktVAlF/5n9AnZEKoMDRNhgBZGRhuoHC2LoXmCABqg89q7yAzlUjkH6ObjHfDTvjeTMFQzjK+VoLQ55qVUq6QPFHJvyu0YBWPGQFL8NyxTKWvp+OlMXVFZrqDK/UCbCPCUbfKZgEFTCDSG8Y/uljJvmVykisgGQPrqmwcZ8gbE3u18SkDIirCuwTMC3vOoIThyZYbnqsbM5w2tedTWefO48vvLNlzCfd7mVEb12n37+ypHLdP5xvWoBAAB4+GGsVZqfzqrSdUmffP4yPvb5J3DrjSdw1clD2NvvMe8avOPuo0gUJFqkIEQwQrFe9UgpYTabhTIrOqZCAb4JWm0yF7GuxFMBePwxpAgccaYpIyBBa4xHVKMARLmdws1BMARDSUVhGWNnL1NODpUhhIYerpMQVYX4Ky1bPOKVkHKNnY0bKP7BUF4G2D8iEE0J11Hg2O+1CVA7Hs3+t3HWuQ9k6rJuNQu541ToVXdiEwlhLhSSvlD0brOmorw0GHIarnVzSV2wSqENhULYkkvKe7XXLElBG3yNGIs/Cig59b4QwjGSaiYCz2mtkHBsVwn/SgUvSAfuz5EikMJsrMamnEv1Xv0MqqKcqQiBlBrMFwuoKoa+D7axE4pst4dxwDVHZ3jjHUex7jPGUXHXHVdhc2OG3/7041gPGa1ARyTZbvZ/+uGHH17jwGsiAO67D+O73oXmc49c+NiY9YEkaLu2GT76uafx/IsX8fq7rkXbJuwuB9xy7TZef/MOxmFlDDqWpAbj34xxHNB2jccuXatXC1F0o0wGpS5iJSfwpJTiNKvXVwphS/mYne80NoS7ypCLU5zQSVe4VXkYafzzDbHY0dQ+Vfptncm4l1LPx56doYAfSDqB8Hw0n6ViHvdczZORAymhNIFXJoYrhM8vGYFRo+uEHMNyRk7RQlp4k2BohSJniRgz1ak5RWuTAuHriUKk4MwESCrrKW5yZIn7JUnx/dp5V2toif/741xE6mTM7jDMxaY2pitcbfTACFURypJKpELrffe/ax9D7XBk3D92pHIGVguK+qXxHHWlV2cxlss3NjYAAVbrdQiQ2veTNaOTEb//TSfQtQn7ywGnTuzgrtuuwkNfexaPPHUem4t2kCa151azB977ubMfe9e73tUwAYivVyAArl0H/elx1N22TXJxd63v/dijOHZ4gbtuP42hz1j1GW+96yhOH24xDH0QNicJAcahR9+vMZt1mHWzkP5lNWpiqSW26wNqLL5bxaYnXl3XSCp1CKviRRfekov2DX+r6qTaDV7wAmolrbV6iRFHN1gKJjJ3JQTruVATC0oX3iB0v65uL17gJHhXvw+MKZVap2gy4xcbUJk7EZJr1az1UwqJUrNrQWPC+/tAaAcftOvNUSkhZ5m2SuapHToFMfmDK3hI/UdaomnOS0tTVnsmj1C3/6wJa45F8zFTGcDNNuHecj6g3jLHMdFmrAGJx8OiyvcKXZYkpprZp7/Xsf1XJsqV91WAjQ3rzr1ar823lDhGdwwjI49rvO3VR3D18Q3sLwd0bcIb774OFy7u4bc//Ti6xuIjwyi7mpuf1hpCVa9XCID77sN4zz1oP/nI7seHjH+QgLQxb4eHvvEyHvzac3jtHadx1altrFYDZl3C73/TcbQyYrTa1bBRMgRICeOQMfQ9ZvMZOk8Xjq6lQTD1P984cejoqtw2uoTGKIcD1ilgffwquRtIw2U1q+6AsM01jNsA0RMNznRj5e9SMVciMyISaSbhvVqw+PcZM2QnWxWG/cSbgTiaCWLzIVE7+d8E7lkI7YstSYuVJ/YyFKlAmaukWEVbR4EmFmnlWGnAnFEBmjKQ0AAs2vKMKuFx38E8tofG/xprSv9KxPcotLmoqTDnNNGKpkBdMuzvM8JD1BMsbzeJbBdfV6KVQm9SBD5RUa2LhLfimItioclI1FA+r/wkQU5TurL3PSLjAmhzYxNtatCv+0DVZnnYGicBxmGNm04ucO+dR7G/HrHqR7zq9qtw+sQOPvzJR3Fxd41uloY2SRrG8R989iuPf/zee9Ded999E+3PlXrF68EHMfwtILUz/Gw/5n0I2pQkv/djj+Ps+Su45zXXYj5vsbcccOrIAt9z91Fo7mE17d6Z1MMz0iT0Y8aq79HO5ph1czvgI9fn+Goh7gC4gjE2331hKEU4sQuKIHwjR42NAVDq651AjCxSMFAknbh0Da98/aImDW3gY8gcr/2MFGR/W8moUrRZVvMc1zZxduHBE2MKNfolJn3AlFm7whlZEceWh8OUX1dQBYdgQaxBsI/9XXJuy9r6w6Wyp43wM3LV9iwcdtTateRCCQXbmHLsUdwv9tRuwOxOqY7OBgDW/gtHnrObI9w/Cg51wVcVbaHUTHAsGUXIUtNbcU1ZF1b8cQWKXwSOBHkNZxrTmJJQCDEJh3NQjtoZnFtbW+iahOVqZR1+KU81hzQcxwFHtxr80JtPAxAsVwNOn9jB3bdfhS987Rl86ZsvYzFvs2ZtV/24j9n6Z/G3Ssr/wdfvZgLozwDy6YcvncsZP6FZpW2SvnxhH/d/9Ns4cmiB173qKmRV7K8zXnvrYdx9wyZyNsefTzlq00WAdT+iX7k5sJj7U4qEIxHUB140wWSkzarOQGkHltXWQt2TDSS1RU86zeFQU69KLKaC39eZwLcMdYeY2GVohKQUBoNzxewVR5TnM3asU+cbeVWyeMu7IiCD4FE84+HEdA5ixRq/QaVrDCC+zurCphQEUWgpBJpz+FsYYSjj09B2oZlBGGQ/K3TutvaIcheSfDF/AKD2G3LJIhc+Gl0WKVHuYuOOswQAiKQQpoBUfRPKenE/uC3sBBXJT6U5ha9foa0ovak+r7V6jPHA0V8le7REiqIcOFtjz82tLSAJriz3MXjvDVMO1BxA1hFNHvDDbz6FnU2r9tucd3jz66/HuQtX8MFPPoamSchqR4ZmwU988NOXzuFnCgA8+PrdBAAAcwh+/tuX3z2O+oAomo1FN3z5kTP4rU8/iTtvPombrz+K1XpAP2S84+5juOZIh37s43gtFfGmmEZp/dhj1a8wa1tsbGzYmfGZ2uw7MNcBFjDk6CSQjFCpuFjZRoYkVXETs2fE1Xesn0LtSVgo2QlQeOyUbXrJ50Yggdq5VldvkXFLgR0jEWWu4bR25GFe8xq2a9y75hQloZGY6/lWzVUFhVALUuINAxS4xiweeak+pAYtjjAfL5mHui+XhBj2/Le4fnW01RTcgBBY4MR+gJ+SSHQXe8V42YhGfT5Vnz8zZWImHhFBSUeGlsNoKFZcMlmFCoUEx157ZV0rV4iFc+CqFnKerjn9HwKBjoqua7G1tQkosNxfIo/ZsmGrzFYb3wgde3zP647h2hMbWK5NuL7pNddie6PDex94BBd3e3RJhjah6cf8wAc+f/bdHvZ7BfSP9f3dPqivGZP+dNY8aFbMulY/8Mkn8bVHX8J3ve46HD+yib3lgKZJ+MF7T+L4TkI/9LHxk41rEtbDgOVqhdS22NzaRONHGiH2Psc3jLm4SaE/QoPwvYPEUZywGsTLmD7c0TKprPN/TBoLgvL/W0lSAkJbaYwhSdCNEwE1YiFmG3eJjiSdMmNKBYlM6eVAbkS8Xyas/uBECqxuQa0dc6mFla+TlU6r38uEUPRH9Iw/ChDlM5XhOgR0VmTrEcA9cU0u0hwQPAemQG0PhhYJW+zziK/HclIIsXCMNrvtocA2W7SKYKBGQ4jICQCUWgFKGXJ4seEpaCOvRAF67yXo1W8Ra3nwVaFIR7LzxQKbW5sYx4z95RLZw9yGMOo84oxx7PGWOw/jjbcfwXI9Yt2PuPuOq3HLDcfwkU8/hm8+eQGbi1ZX2mI9pgEYf/pv/R74+996wX33YXwXIA89svvxUfHjImhFMEKAX/vQt3D2/D7ecc+NWMxb7K9GbCxa/PC9J3FkUzAMfd0X0rR1ViRpkLNiub+PnEdsLDbRzmYVUg4ZD4Nxxcl2MBRYjF2AXtoEhEPKnHY14/gTFKXbMJw5PcxHhwzge0Cqd+854S2HySpFiAbs5+lHEYLioyIZp0QxKOgobkyTFiI3bWX3CcamMAPzGg4qztKimujglTw4HZtZUuLfRnzG3vWRLQkEk9LWpynAmgmGHAsyKeOMxhi5RBsOzkFikyg0bfaJ9/arJvRQawEilmrONLiUmp6+lMpxKtWacphFoPvKiHgWaj1YzrWszXd6pWT9+yUlbG1uYLGxwHrdY7W/hOTsqCMSnyPcmcc17r3tEN726mNY9Rn7qwE333Acr3/V1Xjwq8/iU196HhuLDjqO4xpd+8zuoR//wEMXPv7wuyAHw36vGNO/7UPAmoW8851oP//o5fvHMd/fJGnbRsbzl9f43977dczahN/35pvQJMFyNeLQVocf+a5TOL4tGIbBDxWyFbH0TQ2tsVqtMY4D5os5Njc3rNpMUZJNJLajbDwZMhiCSSUVMTr1lRBS9CEOjRjIgk4nDlD1gNfaNlVRCCrSjio3r/g847CHA9lrBv0ts6c+dYeXWEcwifmRCVSzf4vMUNYi4C7Bg3KlauRQXrZ+ubJNbVJklrhvLX8ohKhdFROhSk3Pda4FE7mazFRzjbBVNsB0RWc8z+ALlc2vcdWSMYafKBQCTu0+ytqPqBD02JGHiyLEy7TwOk+gWrBaeEhZvAk64Z9RaVaJsvL1Qmc8xmt7awtd12G5v8R6tQaI71zyqLcME2f+19+4jXe85rgx/36P6646jLe98UY8+uTLeO/HH0PXJgh0bNrUyri6/2vffPT+d74T7f8R88e0fg8v8QIC7D2781ttI9+jkGFvObSvu+0Y/tQffQ2ee2kXD3z2cSiAxazB7t6A9372JZzdVe9DHjl6aFKVvZcVbdNiPp8BIlgtl1it1wVOo2gRI9SixV09Vgs3Zdwqgl9NmN5/2pxFYhcCR/VtCYVBR1Lixh9QA6EjK6YAhUXRn3G9jcWLWYQjnkAc/3ZC0nIIJu9YfkPcg81WAsJyrMTRAOxcPX7P3v9O4KpB8GbkPoeiraeiFCD8XQDvwFyvD9QyHxthslWltquOzerSTHS6FhRRZGb1e5bYvd9NiFgKjIdyJcVMU4aXyxeKY5UQPCRXvX4SyAeTfeXfE6MLgNFZIw0WmwssZjMM/Yj91b5BftA04CyZ55cxjGvcc+shvO3VRzEqsL/scdXJHfyB77kTZ89fwS/+xpexXI9omzQ0SdpxyB9/y6Gz3/9RWG1PNbDf9fV78QHETB54AEPO+tfHrOM45rS5aPQrj57F//7+b+DqU9t4xz03QgAs1yO2N1v86FtO4eSOmQMiCOcKJaKoSeJ+HM0GGkZsLBbY3tpEkxoLFdbNSElsOhkWCP+nA642H2TI4oCjV7YmezYjKQkv/jww9FMji+J1l3LDIA6X+4E5DqpE+inYLIXto2t6Kv6OHBqtwqbT8zqTVM87UIdKQUlNPYEFJeZOQQr/O/vPusU2OY++kOoJRb5xbxVhp/NanrwTsCUy83wfPI+EORRs9oEQkIpqK0otfuyLCxdGR9i4xvM1otBIyzjpyIOWg1ZoqoSoLeCskvv05dTZrGVNSLobiwUOHz6EWddhub+PveU+dCTTZ6A62MMahhrz33v7Ibz9Ncec+QecPL6N73vbbbi8u8S/et/DuLI/oGuTAkiqOiKlv/4zD0S47/+Q+WPffq+vd70LzX33Ybznlp0fTQm/LgIkSc3+qpe3v/5q/PgP3IGnn7+ETzz4JLIaEliuB3zo82fw7PkeTTvzRaysWrFlTu4Bb9oGs9kMrTRYDz1WyyXGTHOAsrXypEfFCedbdBmhbcFXlZqoILJU3ynwTSeXmgBIpj0r+c6sPqNlATA6fyZkyRC0EbmYklT1/AkzcezJimVy5bHSaqRJiyxwZ4vGh5Ge8m+hgvK8kl1XbqIVoU9q/6tx12saBplIqWGYaMfy3eLc9O+LMXpyzac+A3FtbclBFI6uIaVaCyl311wEQTxViwKXYGYKe0rRhBrmZCn3LjUENF9rofTKNaXzupvNsbnYQNM26Jdr7C+XUB0RDr5MSx8gYhuh0HGFt991BPfecQT9qFiuRpw4uonf/47b0Q8DfvndX8ULZ69gY94qFGNKwKj4sQ88eOY3yaO/264ffP07CQAAuOcedA8+iP7e23b+cJvk3Vm1b1Lq9lcD3vra0/hjf+BOMwc+9wTGIWMxb9CPGZ99+By++vQSqekQZ6mTWJ0LsrulJQm6rsV8NoMAWPc9+nWPfhicXiQ0Fw1BDUxaNkMU1tElPL31xIsQqWU3NxjIDmVJAb7hAQ1rceJ/hzmhRTv5x64YAwQYscLhrEwuEGr3krdc7nGAoQh3BSVOfdCMQEX49Xft41zQgaJA5BC4Pq5qkcp95BXrGutI776WdeJ0FN7/gYuTFMis13Uk41+iOaAROamFSjUoEUcNRQBUIsDvYc/N9bdjgBL3UV//0tDmlYqjrEl5iro50s06LJzx8zBif7mPoR8RbebLtthrHKHJknxaGfHO1x7Dq28+hHWvWK57XH3yEL73LbdguR7wq+/9Gp57+Qo2Fx3ymPumlW4Yhz/yoS9cuJ+8+R225Hd9/TsLAKAIgXtu3X73vE1/eBi1b5rU7S0HvPnuU/jjP3gnzl7YxwOfeRz7qxGLeYO2EXz1sUv41NcvYtAWTcuWCE54AbEa0P+ZRDBrW8xnc0hKWPdrrNc9hmFd4Dc7AkmUznE7qike0IMKMHsrFiEzUFyWJXwBE81KH/9BV5sUQg1WLdolNE09qgkvu0DiWlBaqEDFxmayQl2A6pSIDryC4QnH+VAythbSFs1g7waeYVcZXuFcrGQRKn9/rC89/1EkIwrN5vALwOYXJqgLQNfyFJ6SwKPZp9QpESKTWJ+CPybr6r+wW9AYUZAS7bHBaJmXC3iKlxrnTHcNRRm4gDNaTVgsZlgsNtA2DYZhxHK5j/UwICpTUW4ec/ZM1TGvcWSrxfe+9hiuPbmB/XVG34+46dojeOdbbsHFy0v86vsexkvn9rC5aDH02s9mTbdcD/d/5Evn/si/D/NXM/p3foVT8Moz278+65ofHQbtm0a6veWA19x2DD/xI6/GctXjY597Emcv7GExazHrEp47s8QnvnoOZ3dHQwNcE9eCmpjFxi0wyDfrZui8M0oeh0AF1iDRrowaA4rY7yS5gYlGK3Fs/kUI7No4VJdiiiOqMFSggxiKE6GGsBFvRxaoAgqpOHPqBCxkqK6J8mSnKk0CuNCpGWaKArhCqV4O/urzY9ttifEfQE0V5K5Fny8fLwk0YkUORcpMir58qBmWAmttbshUBe4oMnNtEcFJtX1mow4zHSNeW88MNDFLubRGbkDtNOQeHnyvsG2NFxH+AkOqHbr5HIvZDEkEfT9gtVqh7y2bL4tEanI4wgVe623ZfZoH3HpqA9/9uuPYmDfYXw0Yxoy7bz+Ft7/pRjz74iX8fz7wdZy7tMbGvEEec9+1qdtdp9984Mt3/dg73/nA79npd/D17ysA+F15FyBP3Lb9G13b/Ogw5rFJqdlbDrj52h38hz9yF7Y2ZvjUF5/Ck89eREoJi1nC3nLE5795Hl9/dh+QFk1KDi1tIxsuvqTS1DMD0gjaxsqLZ10LUcE4juj7dQiDuo3YFDJK9a9oD1SS396z38rfFSMJk1X4ZQoPDc1KYRYwFihhKmrlCt+Kayl1G1CIHBTfAcoiRleluIBe/FDdoU3JnfqK+/Bmta0fyIha1tentqmL2esCOsCPBnHXcyXyqZFCPatgrEqK0MTjW3WMwhCLelRGygD4GVxY6sEn+d5yXdU+sXnas9j3T8ouHIBpRpNd22I2azFfLKwVfs5Yr3ssl2sM44hquVA376SzEtmE/zCOWLSKt9x5GHffcgjDCOzt92gawVtefz1ed9fV+NLXn8evf+RbGEbFfNZgHMdxkI1md0i/+dde9cwf/RP3BYH/OzN/Ncx/71cCgHe+E2nvue1/3Uj6w6M1UpXlepRT/9/mruTnsuK6/07VvfeN39Tf1xN00yMNZpDBDSY0OGRhgqWEKLFEso6UZBMvElnKLkIou0hWsnA2SaT8AZZiK2QRAo6EjMCWBzAG09BNN91ND9/c3/SmW1Uni6pTVe91x4ppGlyLb3jv3lvDrfM7vzrn1KnZJv7ka/fgyIE5/Pz9a3j79DUY4ztSFgofXNrCD09voDdiKFVAjDt+oAWpEwYLmjP5gKJGo0RVlNBa+11S1qKuDWpjYKyFNSZqs6juJNlmNHipJEDIppIItkwgcRUB8V7KBBcItC5OwyBMTsAhH3SKMRHAuOahcF8eFhvbJpSZJt91qE+EjQTXMkoSJqLMFEUMzrSqsJ6owQWscqGVPQXx2DAXv5d7ouZk73TLmVB4SILjCFK+njje4bOxeyeAJ9ZLElSVuT1FwOO4MuJuJ0rhypFcMJIXIRo8vTIirb3AlwWKokBZllDkc2JaazAa+WUpuxRrAhAUMSwL6/JLQwmJttaAYXBoVwOPP7AL8zMN7+Mf1JidbuK3HzuKA3un8T9vnMNLr59HUWgUhWbLxA0FdW3QefGtXx76OvA7DnhBuvKJyq0CQOox4B45PvWsIvw7QEorcsa6oiwUnjl1CKceuhPXVrbx419cxvJaD1VZoFlpbOyM8NbZDbx/uQ+G8kAQhE1i9yUYJYojcUzHJKmTikKjKAuUhWcUHmidZwXOwtQWztqQwy5Ymm0wduXcN3ZJdiGF4KRIImVmhetJhUxB4xMz3AqJ7xfXX5rLSth3+EDCQEP9HARdouGIQaygoBBdglFLit6SNgkVV9FuIOv7JOBSAtAIUCKMexYZGRsdmY3EZ7i4tk4vKD4sQUPoaMa7INZ8xxLUlI76TtmcMu0vryRnVXGZCGQVIi7r4q2i+YNQI30HJp9+jQikfaSmDvNJKeWPvQuGZGssRsbCGONPxHKedVv4bNYECll94A3AYUesC/YpdoBzNWbawMNHZ3DiYAdKKQyGFtY5HL1rF5585AgUAd995T389N1FjIopTOmhISK1wy03U/S+/vKbqy8+D6gXbkHzS/k0AAAA8BygvwPvIiwK+g/yK0DjGIUxFl+6dze+9sRhdNoV3vzlIt47twRrgXargFaES4t9nP54G+cXBwA0tPLpuYU6poMcOGz0EH+3HwMfPaagCNCKUCgNrRW0LkBKRfuAn1QORDpqzJjQIU4I+PU5VPJY6GDaIm/wkbiCuPRXygekMIf6/MST5KV+Q1C6ByB/HUICSgoZfihbYnjJSHWEMfDP9AIzZsoMfUyUVz4PQiD1YlKpyifBthBBhaPf3I8FwbFNUBNYit8Xk7Yyu+hXd2AO+YXiGYuc7gXCUfAeQGVtHc815OTj9zEhDOYAgJnvXkAk7Xb0/Y05E+FPVE7rHXkWwTNC2bUYYhLYbx4z1sAaC+ccalP7JgXkUBkwySrLBVAjWe8TALbheRaVYtx9ZwsPHZvBdLfEsHYYDg26nQqPPHgA95/Yh0tX1vG9V97HhatbaLVK9I0yThVF31RuWOs/OH3m3K/t6vtV5VMDACBzER7pfLUo1d8QqaetY6cUqf7Q5w74va8cwQMn9uDq8jZ+8s4VLK5sQ2uFdlODGbhwrYdffLSFa9drADocg0xeEJ0DK46CkAtL2pMNALLmDu+cdMwJCO3juYvwmRxMIQCgwpLAC2rIopNlE5Yz3hTENRUGUnLns+d9/hxBPzFVFPxx4Y4UWflVp8TgRxEN4CGJM4Vmk1ZxMovsRiAgn/ORZPubozQ+LGMnrAJjMQAxsQi8YDBsWNZoqSTmQGASSpu8F16AXLZstshzPcplEW44fcZgyLmFToA0CJuTZK5jmZsQmRWHFy00Xnagir3F2exGSssgtmJvsXBW9m8w2DpYEqBCjCPwtwc2Fdrt4EAs716CtdK4eNeew7H9Ldx/eAoLMw0YxxgMDQjA0UO7cOrhQ+h2Gnj9Zxfw/R9+hMHIoV0p9Cy5VgG1XjdfXh9Uf3/mzPlXTp48WeYHe9xq+VQBAEhMAIB+9Fj3u4VWzxrHTpFfEjADj9y/G7976ghmp1t498wS3vlgERvbQ1RVgValYa3DxaU+3ru4g6vrIzhWQcOqKHCiSSONhgpC5SDCligkwoUKDn6SadFiSILkFXF6bjQyBeGLihHi6vKTQbR7nPccNDN5LaBAPg+e1EiEEJXi93mT34mooqU4CCmNL0pinIHsL87Y8ZidmhG9CpLB20UAEUqc3ISx5P5CSoxbBQHIzBKhGrGDhP8iBQ/jLoAXDYmIghv7Ev7PQ5gB+RVAVIYqLF+IEG0rEXiiTQfeM8D5ac/JC+CFluGYsjfoxynP5eddmGnMfDdkbkm7xYXp2yOLM89qLCoNHNnTxBcOd7FnrglmoD+0sNZi964OvvTAnTh+1zwuXFnHf/3gQ5y9tIF2s0ChYLZNpSwVqkO9F7//87U/Qtie/2lpfimfOgAAMWKQAbhHj0/9Poi+pwDN7Fegw5GhhdkGnn78ML784H5s92q8ffoazl5cR39k0Cg1WpWGsYzl6wOcubyDj5YGGNQEQEFpnQxvAY0VeSKnBKmRYspUnHxi8BMCnV0bqHN+1DUQlCj7ODUvd2LNFS+D14+y7nSy3kYGGsj1Ose4FyZAx3V1EmiRfBKGkqxZkCPCHLFPmBK/kZ7kvYpkA3IseC6kXtA5YAp5rcfpO9GwirQXUjFahu22cnR69sC8MRMjnL6QyML8TeSuRc7amR4atDOCjSIu35DYi4AiAu1HcqNGrc/e9SixATE8OANIieeALEUyb0MC2Rxs2RsBg01gV0fj4O4mjt3Rxu7ZJhyA4dDCWodup8J9x/fgwXv2wRiHV3/8EV5/8zIGhtFtFuwAVBq0MmzZLdP8w9Onz/7n84D6/+zs+yTltgCAlOefh3rhBbiHjnSebhTqmwCeAQAiVdfWFdZauufwHJ7+rUM4enAOaxsDvHtmEecuraM3MKgqjWapoRSw0zP4eKWPD6/0sbxRY+QAQMfjtJWcuRYzCHH8CYSgEIWY3sEHHhEUHMAKTvmrFamQBtyvs1WmFSlolbiBjMmnPiNZH3sAkKSYMnFksmvRiEDQUL59WsnnYqwL18BrpeTlztkJYtw6JPyVKFn0pd9I2jRuuEH4kJCYCoTqJi0s/fXejLC7TmQsM8h5Deyptwet9PzMEhf7TVFzSlspBuKkLlkoqBiS61gCe/z7cEiZgF2MXIoWo4kGyvIn0PrQHr/9VgCYs/wHspzkSPlF4P0rDQIPGReLZkG4Y76BgwtNHNjTQqdVwDpgEHz6s1MN3HN0N+6/ey9ajRJvnb6KV14/jysrPZRVxVqTGVhdDmyFXY3RS009+NZ/v7X5ssjQzSXs1sttBQBgbEmAR45PPauJ/42Umg+Bd7Y/srpVKXzxxAKeeOgADu6fwfpmH++dXca5S+vY6o+gSKHTLNBs+Air1c0RLi4OsLQxxNL1GgOTWcOVjjTR2/FS1Jz0OApZJgTR2yTCkM1f+cznm6Q0iSEBNEk7iNYXnSfPBFI2oRSXHnzWwZqvKB1zmXIPhGYH8IgbkQLt1UCauNI2CaoSlhy1sxzBlo0BkqZWnBiBTI38v4BRSStCPojSHf8kEbqsz3J/BIm8kTfR+pmpLWxMimIJSTiKsISQWPpE9DPbRABrzr6JtQSBluAz8dsLJ/Eg4fwEtqKALRQBzYKwZ66BfbMNHNzdxMxUCSLCMCTqBDNmp5v4wrE9uO/4XjRbBU5/uIJXf3wB73+0hqFRYK0sMfRODTim1ZHRf3plcfVFIO29wW0stx0AQtEITuNH75iapzZ/g0F/qzVpnx+Uua6tajUKevD4PJ54+AAOH5jFdm+EcxfXce7SGlY3eqiNQ6PUaJQauiAY47C1U2OjZ3B5ZYCNHYO1jRq92sHGdyw7tSjR67zzlF44EYI7SgWBTBMuJ/TMiBtwVCSbE2tqcZWl2pPcRMn2SwuPXTLdxIBEQK6NpW5QNOjJmQZRMAMoKN/AKLxC8aVMsnaBKtHcBHhmJfRYWLCgQCZQEfYCgibAAjiwqxQ8HUh2tKwhsg8EViAeEmEOUcPHhnNWf2hQAFDvUeF0NFiGKDG2gBmg4J7L3md8S/G9SPFp4rVizLZLzHQLTDU19i80MdMpMdUuoLXCqHYYDA2sdagqjT27urj36G4cPzwPEPDOB0t47WeXcPbidVgGW9JuZ0Q0cqQqcnZk8XcbO/ztra2tVQboj5+Dut3CL73+LEvMT3bySOdpXahvAvSMImDkGaGpjdXNUtG9R+bw2IP7cfeRBVSlxvLaDs5fWsPH1zaxsTXAsPYpqKpKoyr8MVrGOPQGFjtDg41tg62ewWBkMagd+iOgP3Qwzm+9lChTBsdM0ylehTKtJe65bHIDkVQI042CEDSaEw9BnIOcTfa0D5tFxoWxQEAi3cbZd0EskhU6qkdpR65VRUDijWPCT0gbiPJLI+6EDuTJTZzUEbsVdCqFgFwXnk5pV18CvtSfvDex7+yXIMnNmPorLWeksYCAruhriV1AiOqTkGthO7FjHuyVQvadggah0IROi9AoFBqlQqelsWu6Qruh0W4WaFQKCv4MvtowhrWBcz64bWGujbvumMXxu+YxP9fBxlYfb7+/iB+9fQXnr2zCOTAVha00ivUhoV8TNOOl2rlvXV3afHlSRj6L8lkDAADQyZMoZOPCo8emn1GK/8oCp0qlpgHAOuZhbV2hSN25t0NfPLEH9x1fwL6FKTjnsHq9h4+vXsflxS2sXu9jODLesq8VtCaUhQqHRgT66BjW+aAEyRTrJDZfJt6YNkgmqTG2i6i0krZLkTzxgjESLdeGT+RZAgD53hQEGhqvpkSjRRjk+SlaLqsr3hnqkuuk3RO/Y/Nu0seb/RevizfTeHuyi8TFR2G5kX4mAHHCrbJ+yhjJe5hsa16vgB7f0IesFkpCPpawlcSZEuYJ+UQ1REBZpENHgBAT4BjGONTGwVgHrQitRomFXW0c2DeDQ3fOYfd8B9YyLl65jp+8ewXvnFnG0vqAaybXrbTaGBH1aoVKu022eL026h8/Xl5/CQBOAuVPAXPD8N/m8nkAgJTcOIunTnQX+g5/CdA3oGih1H5f+cg4Y4zlbqss7to/Rfcemcexg7PYO99BWWps9UZYWt3B0uo2Vtd72NgaoDfwmYpdOEgh0nVN0crvXzoggsI3GYrJuQ7gV76esTV3PkFzWpzhRQSIvM7JenjC3oag8DN5y2/IWLKsCsa2yoyREiTtOv6ZNDb/ZkIL522cIAR5W0XbS1zEeJtvLEm2k/ZOFJ9ugnT5YIwDWX65gHA0YnLWG05j4JjhLEcAAnl2WRUKnXaFmW4TC/Md7FuYwsJcG912hcHQ4PLSFk5/uIL3zq3g4uI2j2pnqlLRwBbFliXAAMbyilL49nVq/dP21asr2egRbiGc91bK5wkAAKKRMAaVf/k4ppnbj2ut/1operzUalprwrB2GNUOznHdahS0d76lD98xg6MHZ+nAvmlMdRogItS1xU5/hM3tITa3h9je8YAwHBoMax9yaS3HXYQuJBvJvDoTGihJ65hHCDcTwjCNJiZrrjk5uy8ZrcZpdS6OYkxjSBqz2Jyo+XwdSTjzFYA8VTRg8ttnZUKNjoFY/v0NtyTBTKAXDJoiuHnPRAuPgSBN9PfG8bih5P2KnUvPzIWbcsBH9i4CK1DBR6yVgtYKZaHRqDTarRJT3Qa67Qamuk3MdCu0mhWKQmFUW6yu9XDh6jrOXVrn85c3sbzWsxt9x0SqnG75uJXVHcLI8iYIb3BN/9C09MbZtbXNrOkKnyHdv1n53AEgK/TUU9CvppRGePKh7m4eqT8jpmkQ/Xmhab4qlM8qXFtY46AUodsszdxsE3vm29i3q6Pm59pqbrqJTrtCo1GgLPTYS09GnzDVcsMgyY/4CSCCEz/jqDiIfaRaTDkW9hlIWHB8qFDl8SdHN+aYhuWM+mYUO07gaEBIv3gchbKmexHUWsXPwAn4xvual+TpiOtquSej10AuVNLdTM2GixgcIyJjCDHz2NinJRAi6Ek9af8/jY1H3t1oGCUJ6Q1D7zidIRDev7RH/o9gEEDMOcaotuj1R9jaHmJlvYfFlR13dWXTXVvawdL1AYYjWxgLFIWPTdmuSwxqB8Ctwrp/sUybDWr+69lr15azgS2AT7Z193aU3yQAkELPAeo7E8j41H27u47sqabGYzVzSYS/UIoqZswqAvnjkZ1PHwagKjWazcIbb1ol2s0SrUaBqtSoSoWi0NBKQYW9x2N59ScBARm9R5rSok0V+eWFGOZEq8jEiksQyt863VT2co0uk1hyFeaaMTKNmwowRzenP9TEGyVjzkNMLG+yv8eosQBmbBiNXUz5mOVjk10TT9EB3SjwSEKd/svbwbGeMYCLJVPr+aei9cMPeXcugJKcosThiDpj/XKxNg6j2mKnX3vB79XY6o3QH1jUxsI4xshplFqh0P7RmnB9ra9GRO6fh3VZK3I/2jH69eXl5e2JxkZP2E068rmV30QAyAudPImi2wXnzAAAvnpybqbQxL0eP9ko6SsS7s0OTyqFJ43156q63PAXaK7MGXH9jVWYq7b8r4zCa+WFvNAKWvk1oiZgqApUbEEEjKDRgo3ak8AY6hIlWyjnA43i8VucxTEEFLHshcc6b4Sy1kX6H9enSEKnFUFrigau1EcPblu9GsPaxbCIsROK/k8gySqQseFkk8hBY/L2nJFPAkIyTAYaBSBzwUy8D8p6mr2RfD02uUSZ7EpOjqRhoTqWqjO2JKCtFcE4Qs8WrlOy6lv1Wu3wmgtBR4rxg4UWvXbGMa2fW9/Iq3wKKLYB+jwMe79O+V/MNQGv/IvcnQAAAABJRU5ErkJggg==";
    const img = nativeImage.createFromBuffer(Buffer.from(b64, "base64"));
    if (!img.isEmpty()) return img;
  } catch (e) {}
  return nativeImage.createEmpty();
}

const YH_LICENSE_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAUa9JJyjnPMZdJOkbIq0avvV3e2zFv4cIBqlrluoHWBo=
-----END PUBLIC KEY-----`;
// Clé du nouveau « Générateur de codes » (même programme pour Strider Pro et Strider DTS).
const YH_LICENSE_GEN_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEApDB2XLMNf10FfjFFGaIwnK89bIF5QEIn32wUQWRM00Q=
-----END PUBLIC KEY-----`;
const YH_LICENSE_PRODUCT = "YhCoachPro";

function getLicenseInstallId() {
  ensureDataDir();
  const file = path.join(dataDir, "installation-id.txt");
  if (fs.existsSync(file)) return fs.readFileSync(file, "utf8").trim();
  const id = crypto.randomBytes(16).toString("hex").toUpperCase();
  fs.writeFileSync(file, id, { encoding: "utf8", mode: 0o600 });
  return id;
}
function fromBase64Url(value) {
  const normalized = String(value || "")
    .replace(/-/g, "+")
    .replace(/_/g, "/");
  return Buffer.from(normalized + "=".repeat((4 - (normalized.length % 4)) % 4), "base64");
}
function verifySignedLicense(key) {
  try {
    const raw = String(key || "").trim();
    if (raw.length > 4096) return { ok: false, reason: "Licence trop longue" };
    const parts = raw.split(".");
    if (parts.length !== 3 || parts[0] !== "YH2")
      return { ok: false, reason: "Format de licence invalide" };
    const payloadPart = parts[1];
    const signature = fromBase64Url(parts[2]);
    const valid = [YH_LICENSE_PUBLIC_KEY, YH_LICENSE_GEN_PUBLIC_KEY].some((k) => {
      try { return crypto.verify(null, Buffer.from(payloadPart, "utf8"), k, signature); } catch (_) { return false; }
    });
    if (!valid) return { ok: false, reason: "Signature de licence invalide" };
    const payload = JSON.parse(fromBase64Url(payloadPart).toString("utf8"));
    if (payload.v !== 2 || payload.product !== YH_LICENSE_PRODUCT)
      return { ok: false, reason: "Licence destinée à un autre produit" };
    const device = getLicenseInstallId();
    if (!payload.device || payload.device !== device)
      return { ok: false, reason: "Cette licence appartient à une autre installation" };

    // Clé de blocage d'abonnement (envoyée par Strider Admin)
    if (payload.status === "blocked") {
      return {
        ok: false,
        blocked: true,
        reason: "Abonnement bloqué par l'administrateur",
        licenseId: String(payload.licenseId || ""),
        customer: String(payload.customer || ""),
        blockReason: String(payload.reason || "Abonnement suspendu"),
        device,
      };
    }
    if (payload.status && payload.status !== "active")
      return { ok: false, reason: "Cette licence n'est pas active" };

    const expiry = new Date(String(payload.exp || "") + "T23:59:59.999Z");
    if (!Number.isFinite(expiry.getTime()))
      return { ok: false, reason: "Date de licence invalide" };
    if (Date.now() > expiry.getTime()) return { ok: false, reason: "Licence expirée" };
    return {
      ok: true,
      licenseId: String(payload.licenseId || ""),
      customer: String(payload.customer || ""),
      expiresAt: payload.exp,
      expiresLabel: expiry.toLocaleDateString("fr-FR"),
      device,
    };
  } catch (err) {
    console.error("license verify", err);
    return { ok: false, reason: "Licence illisible" };
  }
}
ipcMain.handle("yh-license-device-id", () => getLicenseInstallId());
ipcMain.handle("yh-license-verify", (_event, key) => verifySignedLicense(key));
ipcMain.handle("yh-clipboard-read", () => String(clipboard.readText() || "").slice(0, 8192));

// Reprendre le clavier seulement dans la fenêtre déjà au premier plan.
function restoreRendererInputFocus(win) {
  if (!win || win.isDestroyed() || !win.isFocused() || win.webContents.isDestroyed()) return false;
  win.webContents.focus();
  return true;
}
ipcMain.handle("yh-input-focus", (event) => {
  const owner = BrowserWindow.fromWebContents(event.sender);
  if (!owner || owner.webContents !== event.sender) return false;
  return restoreRendererInputFocus(owner);
});

function createWindow() {
  const icon = getAppIcon();
  const win = new BrowserWindow({
    width: 1100,
    height: 800,
    minWidth: 360,
    minHeight: 500,
    title: "Strider Pro",
    icon: icon.isEmpty() ? undefined : icon,
    backgroundColor: "#0a0a12",
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
    },
  });

  // L'application reste dans sa fenêtre. Les liens web éventuels s'ouvrent
  // dans le navigateur par défaut au lieu de charger du contenu distant ici.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url).catch(() => {});
    return { action: "deny" };
  });
  win.webContents.on("will-navigate", (event, url) => {
    if (url !== win.webContents.getURL()) {
      event.preventDefault();
      if (/^https?:\/\//i.test(url)) shell.openExternal(url).catch(() => {});
    }
  });

  if (!icon.isEmpty()) {
    try {
      win.setIcon(icon);
    } catch (e) {}
  } else {
    console.warn("YhCoachPro: icone vide");
  }
  win.once("ready-to-show", () => win.show());
  win.loadFile(path.join(__dirname, "index.html"));

  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      {
        label: "Fichier",
        submenu: [
          { role: "reload", label: "Recharger" },
          { type: "separator" },
          { role: "quit", label: "Quitter" },
        ],
      },
      {
        label: "Édition",
        submenu: [
          { role: "undo", label: "Annuler" },
          { role: "redo", label: "Rétablir" },
          { type: "separator" },
          { role: "cut", label: "Couper" },
          { role: "copy", label: "Copier" },
          { role: "paste", label: "Coller" },
          { role: "selectAll", label: "Tout sélectionner" },
          { type: "separator" },
          {
            label: "Rétablir la saisie",
            accelerator: "F6",
            click: () => {
              if (restoreRendererInputFocus(win)) win.webContents.send("yh-restore-input-focus");
            },
          },
        ],
      },
      {
        label: "Affichage",
        submenu: [
          { role: "togglefullscreen", label: "Plein ecran" },
          { role: "zoomIn", label: "Zoom +" },
          { role: "zoomOut", label: "Zoom -" },
          { role: "resetZoom", label: "Zoom normal" },
        ],
      },
    ]),
  );
}

app.setAppUserModelId("com.yassinehakmi.yhcoachpro");

// Une seule fenêtre Strider à la fois : deux fenêtres ouvertes en même temps
// pourraient enregistrer des versions différentes des mêmes données.
if (!app.requestSingleInstanceLock()) {
  app.exit(0);
}
app.on("second-instance", () => {
  const win = BrowserWindow.getAllWindows().find((w) => !w.isDestroyed() && (w.isVisible() || w.isMinimized()));
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
});

app.whenReady().then(() => {
  ensureDataDir();
  protocol.registerFileProtocol("yhmedia", (request, callback) => {
    try {
      const file = mediaFileFromRef(request.url);
      if (file) callback({ path: file });
      else callback({ error: -6 });
    } catch (err) {
      callback({ error: -2 });
    }
  });
  createWindow();
  setTimeout(() => scheduleAutomaticBackup("startup"), 8000);
});

app.on("before-quit", () => {
  try {
    if (autoBackupTimer) clearTimeout(autoBackupTimer);
    createAutomaticBackup("app-close", false);
  } catch (e) {}
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
