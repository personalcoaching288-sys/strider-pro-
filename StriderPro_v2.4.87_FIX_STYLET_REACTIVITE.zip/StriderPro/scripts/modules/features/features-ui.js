/** Filtres programmes, timer repos, actions UI récentes */
// ========== NOUVELLES FEATURES ==========
let progFilter = "all";
let restTimerInterval = null;
let restTimerSeconds = 0;
let restTimerPaused = false;

function setProgFilter(f, btn) {
  progFilter = f || "all";
  document.querySelectorAll(".filter-chip").forEach((c) => c.classList.remove("active"));
  if (btn) btn.classList.add("active");
  renderProgramList();
}

function moveExercise(dayId, exId, dir) {
  if (!guardEdit()) return;
  const day = program.days.find((d) => d.id === dayId);
  if (!day || !day.exercises) return;
  const idx = day.exercises.findIndex((e) => e.id === exId);
  if (idx < 0) return;
  const j = idx + dir;
  if (j < 0 || j >= day.exercises.length) return;
  const t = day.exercises[idx];
  day.exercises[idx] = day.exercises[j];
  day.exercises[j] = t;
  save();
  render();
}

function parseRecupToSeconds(recup) {
  if (recup == null) return 90;
  const s = String(recup).toLowerCase().trim();
  if (!s) return 90;
  const min = s.match(/(\d+)\s*min/);
  const sec = s.match(/(\d+)\s*s/);
  if (min && sec) return +min[1] * 60 + +sec[1];
  if (min) return +min[1] * 60;
  if (sec) return +sec[1];
  const range = s.match(/(\d+)\s*[-–]\s*(\d+)/);
  if (range)
    return Math.round(
      ((+range[1] + +range[2]) / 2) * (s.includes("min") || +range[2] < 30 ? 60 : 1),
    );
  const n = parseFloat(s);
  if (!isNaN(n)) return n <= 15 ? Math.round(n * 60) : Math.round(n);
  return 90;
}

function startRestTimerFromEx(dayId, exId) {
  const day = program.days.find((d) => d.id === dayId);
  const ex = day?.exercises?.find((e) => e.id === exId);
  const sec = parseRecupToSeconds(ex?.recup);
  startRestTimer(sec);
}

let _timerAudioCtx = null;

function getTimerAudioCtx() {
  const Ctx = window.AudioContext || window.webkitAudioContext;
  if (!Ctx) return null;
  if (!_timerAudioCtx || _timerAudioCtx.state === "closed") {
    _timerAudioCtx = new Ctx();
  }
  return _timerAudioCtx;
}

/** Débloque l'audio (à appeler au clic utilisateur) */
function unlockTimerAudio() {
  try {
    const ctx = getTimerAudioCtx();
    if (ctx && ctx.state === "suspended") ctx.resume();
  } catch (e) {}
}

function playTimerEndSound() {
  const run = async () => {
    try {
      const ctx = getTimerAudioCtx();
      if (!ctx) return;
      if (ctx.state === "suspended") {
        await ctx.resume();
      }

      const beep = (type, freq, when, dur, vol) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = type;
        o.frequency.value = freq;
        const t0 = when;
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(Math.max(0.01, vol), t0 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(t0);
        o.stop(t0 + dur + 0.05);
      };

      const t = ctx.currentTime + 0.05;
      // Alarme forte et claire, plusieurs répétitions
      for (let i = 0; i < 6; i++) {
        const base = t + i * 0.4;
        beep("square", 880, base, 0.22, 0.85);
        beep("square", 1175, base + 0.12, 0.22, 0.9);
      }
      beep("square", 1320, t + 2.5, 0.45, 0.95);

      // Fallback HTML Audio si besoin (2e couche)
      try {
        // bip simple WAV 880Hz généré à la volée trop lourd — on double avec vibration
        if (navigator.vibrate) navigator.vibrate([300, 120, 300, 120, 500]);
      } catch (e) {}
    } catch (e) {
      console.warn("Son minuteur:", e);
      // Dernier recours : bip système via data URI très court
      try {
        const a = new Audio(
          "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdH2Onp2QgHVpbXqDkp+akYiAdnFteISWoJ6Vhn50b3B+jZmhmI+Ce3Nvcn+Nl6GYjYF6dG9yf46XoJiPgnxzcHF/jZegmI6Be3Rvcn+Ol6CYj4J8c3Bxf42XoJiOgXt0b3J/jpegmI+CfHNwcX+Nl6CYjoF7dG9yf46XoJiPgnxzcHF/jZegmI6Be3Rvcn+Ol6CYj4J8c3Bxf42XoJiOgXt0b3J/jpegmI+CfHNwcX+Nl6CYjoF7dG9yf46XoJiPgnxzcHF/",
        );
        a.volume = 1;
        a.play().catch(() => {});
      } catch (e2) {}
    }
  };
  run();
}

function startRestTimer(sec) {
  unlockTimerAudio();
  if (typeof sec !== "number") {
    const v = prompt("Durée du repos (secondes) :", "90");
    if (v == null) return;
    sec = parseInt(v, 10) || 90;
  }
  restTimerSeconds = Math.max(1, sec);
  restTimerPaused = false;
  const fab = document.getElementById("timerFab");
  if (fab) fab.classList.add("show", "running");
  updateTimerFab();
  if (restTimerInterval) clearInterval(restTimerInterval);
  restTimerInterval = setInterval(() => {
    if (restTimerPaused) return;
    restTimerSeconds--;
    updateTimerFab();
    if (restTimerSeconds <= 0) {
      clearInterval(restTimerInterval);
      restTimerInterval = null;
      fab?.classList.remove("running");
      try {
        if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 200]);
      } catch (e) {}
      playTimerEndSound();
      showToast("Récup terminé !");
      setTimeout(() => fab?.classList.remove("show"), 2500);
    }
  }, 1000);
  showToast("Minuteur " + sec + "s");
}

function updateTimerFab() {
  const el = document.getElementById("timerFabText");
  if (!el) return;
  const m = Math.floor(Math.max(0, restTimerSeconds) / 60);
  const s = Math.max(0, restTimerSeconds) % 60;
  el.textContent = m + ":" + String(s).padStart(2, "0");
}

function toggleRestTimerPause() {
  if (!restTimerInterval && restTimerSeconds <= 0) {
    startRestTimer(90);
    return;
  }
  restTimerPaused = !restTimerPaused;
  showToast(restTimerPaused ? "Minuteur en pause" : "Minuteur repris");
}

function toggleCompactMode() {
  document.body.classList.toggle("compact-mode");
  const on = document.body.classList.contains("compact-mode");
  try {
    localStorage.setItem("yhcoachpro_compact", on ? "1" : "0");
  } catch (e) {}
  showToast(on ? "Mode compact" : "Mode normal");
}

function toggleSessionDone() {
  if (!guardEdit()) return;
  program.completed = !program.completed;
  program.completedAt = program.completed ? new Date().toISOString().slice(0, 10) : null;
  // marquer jours ouverts aussi
  (program.days || []).forEach((d) => {
    if (d.open !== false) {
      d.done = program.completed;
      d.doneAt = program.completedAt;
    }
  });
  save();
  render();
  showToast(program.completed ? "Séance marquée comme faite" : "Séance non faite");
}

function updateSessionDoneBadge() {
  const badge = document.getElementById("sessionDoneBadge");
  const text = document.getElementById("sessionDoneText");
  if (!badge) return;
  if (program.completed) {
    badge.style.display = "inline-flex";
    if (text)
      text.textContent = "Séance faite" + (program.completedAt ? " · " + program.completedAt : "");
  } else {
    badge.style.display = "none";
  }
}

function duplicateWeek() {
  if (!guardEdit()) return;
  if (!(program.days || []).length) {
    showToast("Aucun jour à dupliquer");
    return;
  }
  if (!confirm("Dupliquer tous les jours de ce programme (semaine) ?")) return;
  const copies = program.days.map((day) => {
    const c = JSON.parse(JSON.stringify(day));
    c.id = uid();
    c.exercises = (c.exercises || []).map((ex) => {
      const e = JSON.parse(JSON.stringify(ex));
      e.id = uid();
      return e;
    });
    return c;
  });
  program.days = program.days.concat(copies);
  save();
  render();
  showToast("Semaine dupliquée");
}

function calcSessionStats(prog) {
  let volume = 0,
    sets = 0,
    exercises = 0,
    chargeSum = 0,
    chargeN = 0;
  (prog.days || []).forEach((d) => {
    (d.exercises || []).forEach((ex) => {
      exercises++;
      const ser = +ex.series || 0;
      const rep = +ex.reps || 0;
      const kg = ex.chargeKg != null && ex.chargeKg !== "" ? +ex.chargeKg : 0;
      sets += ser;
      volume += ser * rep * kg;
      if (ex.charge != null) {
        chargeSum += +ex.charge;
        chargeN++;
      }
      if (ex.compName) {
        exercises++;
        const cs = +ex.compSeries || 0,
          cr = +ex.compReps || 0;
        const ckg = ex.compChargeKg != null && ex.compChargeKg !== "" ? +ex.compChargeKg : 0;
        sets += cs;
        volume += cs * cr * ckg;
      }
    });
  });
  return {
    athlete: prog.athlete || "—",
    theme: prog.theme || "—",
    date: prog.date || "—",
    days: (prog.days || []).length,
    exercises,
    sets,
    volume: Math.round(volume),
    avgCharge: chargeN ? Math.round(chargeSum / chargeN) : 0,
  };
}

function openCompareModal() {
  loadProgramsIndex();
  const a = document.getElementById("compareA");
  const b = document.getElementById("compareB");
  if (!a || !b) return;
  const opts = programsIndex
    .map(
      (p) =>
        `<option value="${p.id}">${escapeHtml(p.athlete || "?")} · ${escapeHtml(p.theme || "")} · ${p.date || ""}</option>`,
    )
    .join("");
  a.innerHTML = opts;
  b.innerHTML = opts;
  if (program.id) a.value = program.id;
  if (programsIndex.length > 1) {
    const other = programsIndex.find((p) => p.id !== a.value);
    if (other) b.value = other.id;
  }
  openModal("compareModal");
  runCompare();
}

function runCompare() {
  const idA = document.getElementById("compareA")?.value;
  const idB = document.getElementById("compareB")?.value;
  const box = document.getElementById("compareResult");
  if (!box) return;
  const pA = idA === program.id ? program : loadProgramFromStorage(idA);
  const pB = idB === program.id ? program : loadProgramFromStorage(idB);
  if (!pA || !pB) {
    box.innerHTML = "<p>Sélectionne 2 programmes</p>";
    return;
  }
  const sA = calcSessionStats(pA);
  const sB = calcSessionStats(pB);
  const row = (label, va, vb, unit) => {
    const diff = va - vb;
    const diffStr = diff > 0 ? "+" + diff : String(diff);
    const col = diff > 0 ? "#10b981" : diff < 0 ? "#f43f5e" : "#94a3b8";
    return `<div class="compare-metric"><span>${label}</span><span><strong>${va}${unit || ""}</strong> vs <strong>${vb}${unit || ""}</strong> <span style="color:${col}">(${diffStr})</span></span></div>`;
  };
  box.innerHTML = `<div class="compare-grid">
        <div class="compare-card"><h4>${escapeHtml(sA.athlete)}</h4>
          <div style="font-size:0.8rem;color:#94a3b8;margin-bottom:8px">${escapeHtml(sA.theme)} · ${sA.date}</div>
          ${row("Volume (kg)", sA.volume, sB.volume, "")}
          ${row("Séries", sA.sets, sB.sets, "")}
          ${row("Exercices", sA.exercises, sB.exercises, "")}
          ${row("Charge moy. %", sA.avgCharge, sB.avgCharge, "%")}
          ${row("Jours", sA.days, sB.days, "")}
        </div>
        <div class="compare-card"><h4>${escapeHtml(sB.athlete)}</h4>
          <div style="font-size:0.8rem;color:#94a3b8;margin-bottom:8px">${escapeHtml(sB.theme)} · ${sB.date}</div>
          ${row("Volume (kg)", sB.volume, sA.volume, "")}
          ${row("Séries", sB.sets, sA.sets, "")}
          ${row("Exercices", sB.exercises, sA.exercises, "")}
          ${row("Charge moy. %", sB.avgCharge, sA.avgCharge, "%")}
          ${row("Jours", sB.days, sA.days, "")}
        </div>
      </div>`;
}

function exportChargesExcel() {
  const store = loadHistoryStore();
  let csv = "Athlete;Exercice;Date;Seance;Charge_kg\n";
  let n = 0;
  Object.keys(store).forEach((athlete) => {
    Object.keys(store[athlete] || {}).forEach((ex) => {
      (store[athlete][ex] || []).forEach((e) => {
        csv += `"${(athlete || "").replace(/"/g, '""')}";"${(ex || "").replace(/"/g, '""')}";${e.date || ""};${e.session || ""};${e.kg}\n`;
        n++;
      });
    });
  });
  // aussi charges du programme ouvert
  if (program && program.days) {
    (program.days || []).forEach((d) => {
      (d.exercises || []).forEach((ex) => {
        if (ex.chargeKg != null && ex.chargeKg !== "") {
          csv += `"${(program.athlete || "").replace(/"/g, '""')}";"${(ex.name || "").replace(/"/g, '""')}";${program.date || ""};${program.sessionNum || ""};${ex.chargeKg}\n`;
          n++;
        }
      });
    });
  }
  if (!n) {
    showToast("Aucune charge (kg) à exporter");
    return;
  }
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "StriderPro_charges.csv";
  a.click();
  showToast("Export Excel (CSV) téléchargé");
}

// profiles.js chargé séparément.
