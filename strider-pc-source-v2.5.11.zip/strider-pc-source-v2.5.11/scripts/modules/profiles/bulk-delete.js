/* Suppressions groupées, après sélection et confirmation explicite. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id),
    esc = (v) =>
      String(v ?? "").replace(
        /[&<>"']/g,
        (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
      );
  const normalize = (v) =>
    String(v || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  let groupMode = false,
    selected = new Set(),
    busy = false;
  function people() {
    const group = $("pbdGroup").value,
      query = normalize($("pbdSearch").value);
    return athleteProfiles
      .filter(
        (p) =>
          (!group || profileGroupIds(p).includes(group)) &&
          (!query || normalize(p.nom + " " + p.prenom).includes(query)),
      )
      .slice()
      .sort(compareAthleteProfiles);
  }
  function targets() {
    if (groupMode) {
      const gid = $("pbdGroup").value;
      return gid ? athleteProfiles.filter((p) => profileGroupIds(p).includes(gid)) : [];
    }
    return athleteProfiles.filter((p) => selected.has(p.id));
  }
  function redraw() {
    const visible = people(),
      chosen = targets(),
      gid = $("pbdGroup").value;
    $("pbdList").innerHTML = visible.length
      ? visible
          .map(
            (p) =>
              '<label><input type="checkbox" data-profile-id="' +
              esc(p.id) +
              '" ' +
              (groupMode || selected.has(p.id) ? "checked " : "") +
              (groupMode ? "disabled " : "") +
              "/><span>" +
              profileColorDot(p.code_couleur) +
              esc([p.nom, p.prenom].filter(Boolean).join(" ")) +
              "</span></label>",
          )
          .join("")
      : "<p>Aucun profil dans cette sélection.</p>";
    $("pbdCount").textContent =
      chosen.length +
      (groupMode ? " profils du groupe seront supprimés." : " profils sélectionnés au total.");
    const shared = chosen.filter((p) => profileGroupIds(p).length > 1).length;
    $("pbdWarning").textContent =
      (groupMode
        ? "Le groupe et son historique d’assiduité seront supprimés. "
        : "Les fiches sélectionnées seront supprimées. ") +
      (shared
        ? shared +
          " profils sont aussi affiliés à d’autres groupes : leur fiche sera supprimée partout. "
        : "") +
      "Les autres profils et programmes ne seront pas supprimés. Faites une sauvegarde avant de continuer.";
    $("pbdConfirm").disabled = busy || (groupMode ? !gid : !chosen.length);
    $("pbdAll").disabled = groupMode || !visible.length;
    $("pbdAll").checked = visible.length > 0 && visible.every((p) => selected.has(p.id));
  }
  async function remove() {
    if (busy || !guardEdit()) return;
    flushProfileAutosave();
    loadAthleteProfiles();
    asLoad();
    const gid = groupMode ? $("pbdGroup").value : null,
      g = gid ? asStore.groups.find((g) => g.id === gid) : null;
    if (groupMode && !g) {
      $("pbdError").textContent = "Ce groupe n’existe plus.";
      return;
    }
    const doomed = targets(),
      ids = new Set(doomed.map((p) => p.id));
    if (!groupMode && !ids.size) return;
    const shared = doomed.filter((p) => profileGroupIds(p).length > 1).length;
    const question =
      (groupMode
        ? "Supprimer le groupe « " +
          g.title +
          " », son historique d’assiduité et ses " +
          ids.size +
          " profils ?"
        : "Supprimer définitivement les " + ids.size + " profils sélectionnés ?") +
      (shared
        ? "\n" +
          shared +
          " profils appartiennent aussi à d’autres groupes : ils seront supprimés partout."
        : "") +
      "\nLes autres profils et programmes seront conservés.\nCette action est définitive. Confirmer ?";
    if (!confirm(question)) return;
    busy = true;
    $("pbdConfirm").disabled = true;
    $("pbdClose").disabled = true;
    $("pbdCancel").disabled = true;
    const previousProfiles = JSON.parse(JSON.stringify(athleteProfiles)),
      previousAttendance = JSON.parse(JSON.stringify(asStore)),
      previousCurrent = currentProfileId,
      previousFilter = profileGroupFilterId;
    try {
      clearTimeout(_profileAutosaveTimer);
      _profileAutosaveTimer = null;
      const next = JSON.parse(JSON.stringify(asStore));
      if (gid) next.groups = next.groups.filter((x) => x.id !== gid);
      for (const group of next.groups) {
        const removedPlayers = new Set(
          (group.players || []).filter((p) => ids.has(p.profileId)).map((p) => p.id),
        );
        group.players = (group.players || []).filter((p) => !ids.has(p.profileId));
        for (const session of group.sessions || [])
          if (session.attendance) for (const pid of removedPlayers) delete session.attendance[pid];
      }
      if (!next.groups.length) next.groups = [asDefaultGroup("Nouveau groupe")];
      if (!next.groups.some((g) => g.id === next.currentGroupId))
        next.currentGroupId = next.groups[0].id;
      athleteProfiles = athleteProfiles.filter((p) => !ids.has(p.id));
      if (!saveAthleteProfilesStore())
        throw Error("Suppression non enregistrée : vérifiez le stockage.");
      if (!storeSet(AS_KEY, JSON.stringify(next)))
        throw Error("Impossible d’enregistrer les groupes.");
      asStore = next;
      if (ids.has(currentProfileId)) currentProfileId = null;
      if (gid && profileGroupFilterId === gid) profileSetGroupFilter("");
      loadAthleteProfiles();
      refreshProfileGroupControls();
      refreshProfileSelect();
      const current = athleteProfiles.find((p) => p.id === currentProfileId),
        visible = profileVisibleProfiles().slice().sort(compareAthleteProfiles);
      if (current) fillProfileForm(current);
      else if (visible.length) selectAthleteProfile(visible[0].id);
      else newAthleteProfile();
      if (typeof asRenderAll === "function") asRenderAll();
      $("pbdModal").classList.remove("show");
      selected.clear();
      window.dispatchEvent(new CustomEvent("yh-profile-import-complete"));
      showToast(
        groupMode
          ? "Groupe et " + ids.size + " profils supprimés."
          : ids.size + " profils supprimés.",
      );
    } catch (e) {
      athleteProfiles = previousProfiles;
      asStore = previousAttendance;
      currentProfileId = previousCurrent;
      profileSetGroupFilter(previousFilter);
      const restored =
        saveAthleteProfilesStore() && storeSet(AS_KEY, JSON.stringify(previousAttendance));
      $("pbdError").textContent =
        e.message +
        (restored
          ? " Les données précédentes ont été rétablies."
          : " Vérifiez votre sauvegarde : la restauration n’a pas pu être confirmée.");
    } finally {
      busy = false;
      $("pbdClose").disabled = false;
      $("pbdCancel").disabled = false;
      if ($("pbdModal").classList.contains("show")) redraw();
    }
  }
  function ensure() {
    if ($("pbdModal")) return;
    const modal = document.createElement("div");
    modal.id = "pbdModal";
    modal.className = "modal-overlay";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-label", "Suppression groupée des profils");
    modal.innerHTML =
      '<div class="modal pbd-modal"><div class="modal-header"><h2 id="pbdTitle"></h2><button type="button" id="pbdClose" class="modal-close" aria-label="Fermer">×</button></div><div class="modal-body"><div class="pbd-filters"><label>Groupe<select id="pbdGroup"></select></label><label id="pbdSearchWrap">Rechercher un nom<input type="search" id="pbdSearch" placeholder="Nom ou prénom"/></label></div><label id="pbdAllWrap" class="pbd-check"><input type="checkbox" id="pbdAll"/> Tout sélectionner dans la liste affichée</label><div id="pbdList"></div><p id="pbdCount" role="status"></p><p id="pbdWarning"></p><p id="pbdError" role="alert"></p></div><div class="modal-footer"><button type="button" id="pbdCancel" class="btn-cancel">Annuler</button><button type="button" id="pbdConfirm" class="pbd-danger"></button></div></div>';
    document.body.appendChild(modal);
    $("pbdGroup").onchange = redraw;
    $("pbdSearch").oninput = redraw;
    $("pbdAll").onchange = () => {
      for (const p of people()) $("pbdAll").checked ? selected.add(p.id) : selected.delete(p.id);
      redraw();
    };
    $("pbdList").onchange = (e) => {
      const id = e.target.dataset.profileId;
      if (!id || groupMode) return;
      e.target.checked ? selected.add(id) : selected.delete(id);
      redraw();
    };
    const close = () => {
      if (!busy) modal.classList.remove("show");
    };
    $("pbdCancel").onclick = close;
    $("pbdClose").onclick = close;
    $("pbdConfirm").onclick = remove;
    modal.addEventListener("click", (e) => {
      if (e.target === modal) close();
    });
  }
  window.openProfileBulkDelete = function (deleteGroup) {
    if (!guardEdit()) return;
    flushProfileAutosave();
    loadAthleteProfiles();
    asLoad();
    closeProfileMoreMenu();
    ensure();
    groupMode = Boolean(deleteGroup);
    selected.clear();
    $("pbdSearch").value = "";
    $("pbdError").textContent = "";
    $("pbdTitle").textContent = groupMode
      ? "Supprimer un groupe et ses profils"
      : "Supprimer plusieurs profils";
    $("pbdConfirm").textContent = groupMode
      ? "Supprimer le groupe et ses profils"
      : "Supprimer la sélection";
    $("pbdGroup").innerHTML =
      '<option value="">' +
      (groupMode ? "Choisir le groupe à supprimer" : "Tous les groupes") +
      "</option>" +
      asStore.groups
        .map((g) => '<option value="' + esc(g.id) + '">' + esc(profileGroupLabel(g)) + "</option>")
        .join("");
    $("pbdGroup").value = asStore.groups.some((g) => g.id === profileGroupFilterId)
      ? profileGroupFilterId
      : "";
    $("pbdSearchWrap").hidden = groupMode;
    $("pbdAllWrap").hidden = groupMode;
    $("pbdModal").classList.add("show");
    redraw();
  };
})();
