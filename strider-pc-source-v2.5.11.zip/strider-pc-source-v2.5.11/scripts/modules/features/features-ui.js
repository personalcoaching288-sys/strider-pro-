/** Filtres programmes, timer repos, actions UI récentes */
// ========== NOUVELLES FEATURES ==========
let progFilter = "all";
let restTimerInterval = null;
let restTimerSeconds = 0;
let restTimerPaused = false;

function setProgFilter(f, btn) {
  progFilter = f || "all";
  document.querySelectorAll(".filter-chip").forEach((c) => c.classList.remove("active"));
  if (btn) btn.classList.add("active");
  renderProgramList();
}

function moveExercise(dayId, exId, dir) {
  if (!guardEdit()) return;
  const day = program.days.find((d) => d.id === dayId);
  if (!day || !day.exercises) return;
  const idx = day.exercises.findIndex((e) => e.id === exId);
  if (idx < 0) return;
  const j = idx + dir;
  if (j < 0 || j >= day.exercises.length) return;
  const t = day.exercises[idx];
  day.exercises[idx] = day.exercises[j];
  day.exercises[j] = t;
  save();
  render();
}

function parseRecupToSeconds(recup) {
  if (recup == null) return 90;
  const s = String(recup).toLowerCase().trim();
  if (!s) return 90;
  const min = s.match(/(\d+)\s*min/);
  const sec = s.match(/(\d+)\s*s/);
  if (min && sec) return +min[1] * 60 + +sec[1];
  if (min) return +min[1] * 60;
  if (sec) return +sec[1];
  const range = s.match(/(\d+)\s*[-–]\s*(\d+)/);
  if (range)
    return Math.round(
      ((+range[1] + +range[2]) / 2) * (s.includes("min") || +range[2] < 30 ? 60 : 1),
    );
  const n = parseFloat(s);
  if (!isNaN(n)) return n <= 15 ? Math.round(n * 60) : Math.round(n);
  return 90;
}

function startRestTimerFromEx(dayId, exId) {
  const day = program.days.find((d) => d.id === dayId);
  const ex = day?.exercises?.find((e) => e.id === exId);
  const sec = parseRecupToSeconds(ex?.recup);
  startRestTimer(sec);
}

let _timerAudioCtx = null;
let _timerAlarmEl = null;
let _timerAlarmEl2 = null;
let _timerTickEl = null;

function getTimerAudioCtx() {
  const Ctx = window.AudioContext || window.webkitAudioContext;
  if (!Ctx) return null;
  if (!_timerAudioCtx || _timerAudioCtx.state === "closed") _timerAudioCtx = new Ctx();
  return _timerAudioCtx;
}

/** Génère un WAV fort (onde carrée adoucie, pleine amplitude) à partir d'un motif [fréq, durée] */
function buildTimerWav(pattern) {
  const rate = 22050;
  let total = 0;
  pattern.forEach(([, d]) => (total += Math.round(d * rate)));
  const buf = new ArrayBuffer(44 + total * 2);
  const v = new DataView(buf);
  const w = (o, str) => { for (let i = 0; i < str.length; i++) v.setUint8(o + i, str.charCodeAt(i)); };
  w(0, "RIFF"); v.setUint32(4, 36 + total * 2, true); w(8, "WAVE"); w(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  w(36, "data"); v.setUint32(40, total * 2, true);
  let off = 44;
  pattern.forEach(([f, d]) => {
    const n = Math.round(d * rate);
    for (let i = 0; i < n; i++) {
      let s = 0;
      if (f > 0) {
        const ph = (2 * Math.PI * f * i) / rate;
        // sinus saturé = très fort et perçant sur haut-parleur de téléphone
        s = Math.max(-1, Math.min(1, Math.sin(ph) * 3 + Math.sin(ph * 2) * 0.6));
        const edge = Math.min(1, i / 60, (n - i) / 60);
        s *= edge;
      }
      v.setInt16(off, s * 32767, true);
      off += 2;
    }
  });
  return URL.createObjectURL(new Blob([buf], { type: "audio/wav" }));
}

/** Cloche de boxe : deux cloches superposées, coups rapides qui se chevauchent comme sur un ring */
function buildBellWav(strikes, strikeEvery, ringDur) {
  const rate = 22050;
  const total = Math.round(((strikes - 1) * strikeEvery + ringDur) * rate);
  const buf = new ArrayBuffer(44 + total * 2);
  const v = new DataView(buf);
  const w = (o, str) => { for (let i = 0; i < str.length; i++) v.setUint8(o + i, str.charCodeAt(i)); };
  w(0, "RIFF"); v.setUint32(4, 36 + total * 2, true); w(8, "WAVE"); w(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  w(36, "data"); v.setUint32(40, total * 2, true);
  // Partiels d'une cloche en laiton ; chaque coup est doublé par une 2e cloche légèrement désaccordée
  const partials = [
    [1175, 1.0, 1.6],    // fondamentale (corps du son)
    [1568, 0.7, 2.4],    // tierce haute
    [2350, 0.5, 3.0],    // octave
    [3520, 0.3, 4.2],    // partiel métallique
    [4700, 0.18, 5.5],   // éclat
    [6260, 0.1, 7.0],    // brillance
  ];
  const layers = [1, 1.007]; // deux cloches désaccordées = son « doublé » plus large
  let seed = 12345;
  const noise = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x40000000 - 1; };
  // Pré-calcul des bruits de maillet par coup (reproductible)
  const malletLen = Math.round(0.012 * rate);
  const mallets = [];
  for (let s = 0; s < strikes; s++) {
    const m = new Float64Array(malletLen);
    for (let i = 0; i < malletLen; i++) m[i] = noise() * 0.9 * Math.exp(-(i / rate) * 380);
    mallets.push(m);
  }
  const samples = new Float64Array(total);
  for (let s = 0; s < strikes; s++) {
    const start = Math.round(s * strikeEvery * rate);
    const n = Math.min(Math.round(ringDur * rate), total - start);
    for (let i = 0; i < n; i++) {
      const t = i / rate;
      let x = 0;
      for (const detune of layers) {
        for (const [f, amp, decay] of partials) {
          x += amp * Math.sin(2 * Math.PI * f * detune * t) * Math.exp(-t * decay);
        }
      }
      if (i < malletLen) x += mallets[s][i] * 2;
      samples[start + i] += x * Math.min(1, i / 18);
    }
  }
  // Normalisation puis compression : toute la sonnerie reste près du volume maximal
  let peak = 0;
  for (let i = 0; i < total; i++) { const a = Math.abs(samples[i]); if (a > peak) peak = a; }
  const norm = peak > 0 ? 1 / peak : 1;
  const drive = 2.6; // saturation douce = son perçu beaucoup plus fort
  let off = 44;
  for (let i = 0; i < total; i++) {
    const s = Math.tanh(samples[i] * norm * drive) / Math.tanh(drive);
    v.setInt16(off, s * 0.98 * 32767, true);
    off += 2;
  }
  return URL.createObjectURL(new Blob([buf], { type: "audio/wav" }));
}

function getTimerAlarmEls() {
  if (!_timerAlarmEl) {
    // Cloche de boxe : 5 coups rapides qui se chevauchent, deux cloches superposées
    const bellUrl = buildBellWav(5, 0.5, 1.8);
    _timerAlarmEl = new Audio(bellUrl);
    _timerAlarmEl.preload = "auto";
    _timerAlarmEl.volume = 1;
    // Deuxième lecteur identique joué en même temps = puissance doublée
    _timerAlarmEl2 = new Audio(bellUrl);
    _timerAlarmEl2.preload = "auto";
    _timerAlarmEl2.volume = 1;
    _timerTickEl = new Audio(buildTimerWav([[2400, 0.12]]));
    _timerTickEl.preload = "auto";
    _timerTickEl.volume = 1;
  }
  return { alarm: _timerAlarmEl, tick: _timerTickEl };
}

/** Débloque l'audio (à appeler au clic utilisateur) */
function unlockTimerAudio() {
  try {
    const ctx = getTimerAudioCtx();
    if (ctx && ctx.state === "suspended") ctx.resume();
  } catch (e) {}
  try {
    const { alarm, tick } = getTimerAlarmEls();
    [alarm, _timerAlarmEl2, tick].filter(Boolean).forEach((el) => {
      el.muted = true;
      const pr = el.play();
      const done = () => { el.pause(); el.currentTime = 0; el.muted = false; };
      if (pr && pr.then) pr.then(done).catch(() => { el.muted = false; });
      else done();
    });
  } catch (e) {}
}

function playTimerEl(el) {
  try {
    el.muted = false;
    el.volume = 1;
    el.currentTime = 0;
    const pr = el.play();
    if (pr && pr.catch) pr.catch(() => {});
  } catch (e) {}
}

/** Bip court pour les 3 dernières secondes */
function playTimerTick() {
  playTimerEl(getTimerAlarmEls().tick);
}

function playTimerEndSound() {
  playTimerEl(getTimerAlarmEls().alarm);
  if (_timerAlarmEl2) playTimerEl(_timerAlarmEl2);
  try {
    if (navigator.vibrate) navigator.vibrate([400, 150, 400, 150, 400, 150, 800]);
  } catch (e) {}
}

function startRestTimer(sec) {
  unlockTimerAudio();
  if (typeof sec !== "number") {
    const v = prompt("Durée du repos (secondes) :", "90");
    if (v == null) return;
    sec = parseInt(v, 10) || 90;
  }
  restTimerSeconds = Math.max(1, sec);
  restTimerPaused = false;
  const fab = document.getElementById("timerFab");
  if (fab) fab.classList.add("show", "running");
  updateTimerFab();
  if (restTimerInterval) clearInterval(restTimerInterval);
  restTimerInterval = setInterval(() => {
    if (restTimerPaused) return;
    restTimerSeconds--;
    updateTimerFab();
    if (restTimerSeconds > 0 && restTimerSeconds <= 3) playTimerTick();
    if (restTimerSeconds <= 0) {
      clearInterval(restTimerInterval);
      restTimerInterval = null;
      fab?.classList.remove("running");
      try {
        if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 200]);
      } catch (e) {}
      playTimerEndSound();
      showToast("Récup terminé !");
      setTimeout(() => fab?.classList.remove("show"), 2500);
    }
  }, 1000);
  showToast("Minuteur " + sec + "s");
}

function updateTimerFab() {
  const el = document.getElementById("timerFabText");
  if (!el) return;
  const m = Math.floor(Math.max(0, restTimerSeconds) / 60);
  const s = Math.max(0, restTimerSeconds) % 60;
  el.textContent = m + ":" + String(s).padStart(2, "0");
}

function toggleRestTimerPause() {
  if (!restTimerInterval && restTimerSeconds <= 0) {
    startRestTimer(90);
    return;
  }
  restTimerPaused = !restTimerPaused;
  showToast(restTimerPaused ? "Minuteur en pause" : "Minuteur repris");
}

function toggleCompactMode() {
  document.body.classList.toggle("compact-mode");
  const on = document.body.classList.contains("compact-mode");
  try {
    localStorage.setItem("yhcoachpro_compact", on ? "1" : "0");
  } catch (e) {}
  showToast(on ? "Mode compact" : "Mode normal");
}

function toggleSessionDone() {
  if (!guardEdit()) return;
  program.completed = !program.completed;
  program.completedAt = program.completed ? new Date().toISOString().slice(0, 10) : null;
  // marquer jours ouverts aussi
  (program.days || []).forEach((d) => {
    if (d.open !== false) {
      d.done = program.completed;
      d.doneAt = program.completedAt;
    }
  });
  save();
  render();
  showToast(program.completed ? "Séance marquée comme faite" : "Séance non faite");
}

function updateSessionDoneBadge() {
  const badge = document.getElementById("sessionDoneBadge");
  const text = document.getElementById("sessionDoneText");
  if (!badge) return;
  if (program.completed) {
    badge.style.display = "inline-flex";
    if (text)
      text.textContent = "Séance faite" + (program.completedAt ? " · " + program.completedAt : "");
  } else {
    badge.style.display = "none";
  }
}

function duplicateWeek() {
  if (!guardEdit()) return;
  if (!(program.days || []).length) {
    showToast("Aucun jour à dupliquer");
    return;
  }
  if (!confirm("Dupliquer tous les jours de ce programme (semaine) ?")) return;
  const copies = program.days.map((day) => {
    const c = JSON.parse(JSON.stringify(day));
    c.id = uid();
    c.exercises = (c.exercises || []).map((ex) => {
      const e = JSON.parse(JSON.stringify(ex));
      e.id = uid();
      return e;
    });
    return c;
  });
  program.days = program.days.concat(copies);
  save();
  render();
  showToast("Semaine dupliquée");
}

function calcSessionStats(prog) {
  let volume = 0,
    sets = 0,
    exercises = 0,
    chargeSum = 0,
    chargeN = 0;
  (prog.days || []).forEach((d) => {
    (d.exercises || []).forEach((ex) => {
      exercises++;
      const ser = +ex.series || 0;
      const rep = +ex.reps || 0;
      const kg = ex.chargeKg != null && ex.chargeKg !== "" ? +ex.chargeKg : 0;
      sets += ser;
      volume += ser * rep * kg;
      if (ex.charge != null) {
        chargeSum += +ex.charge;
        chargeN++;
      }
      if (ex.compName) {
        exercises++;
        const cs = +ex.compSeries || 0,
          cr = +ex.compReps || 0;
        const ckg = ex.compChargeKg != null && ex.compChargeKg !== "" ? +ex.compChargeKg : 0;
        sets += cs;
        volume += cs * cr * ckg;
      }
    });
  });
  return {
    athlete: prog.athlete || "—",
    theme: prog.theme || "—",
    date: prog.date || "—",
    days: (prog.days || []).length,
    exercises,
    sets,
    volume: Math.round(volume),
    avgCharge: chargeN ? Math.round(chargeSum / chargeN) : 0,
  };
}

function openCompareModal() {
  loadProgramsIndex();
  const a = document.getElementById("compareA");
  const b = document.getElementById("compareB");
  if (!a || !b) return;
  const opts = programsIndex
    .map(
      (p) =>
        `<option value="${p.id}">${escapeHtml(p.athlete || "?")} · ${escapeHtml(p.theme || "")} · ${p.date || ""}</option>`,
    )
    .join("");
  a.innerHTML = opts;
  b.innerHTML = opts;
  if (program.id) a.value = program.id;
  if (programsIndex.length > 1) {
    const other = programsIndex.find((p) => p.id !== a.value);
    if (other) b.value = other.id;
  }
  openModal("compareModal");
  runCompare();
}

function runCompare() {
  const idA = document.getElementById("compareA")?.value;
  const idB = document.getElementById("compareB")?.value;
  const box = document.getElementById("compareResult");
  if (!box) return;
  const pA = idA === program.id ? program : loadProgramFromStorage(idA);
  const pB = idB === program.id ? program : loadProgramFromStorage(idB);
  if (!pA || !pB) {
    box.innerHTML = "<p>Sélectionne 2 programmes</p>";
    return;
  }
  const sA = calcSessionStats(pA);
  const sB = calcSessionStats(pB);
  const row = (label, va, vb, unit) => {
    const diff = va - vb;
    const diffStr = diff > 0 ? "+" + diff : String(diff);
    const col = diff > 0 ? "#10b981" : diff < 0 ? "#f43f5e" : "#94a3b8";
    return `<div class="compare-metric"><span>${label}</span><span><strong>${va}${unit || ""}</strong> vs <strong>${vb}${unit || ""}</strong> <span style="color:${col}">(${diffStr})</span></span></div>`;
  };
  box.innerHTML = `<div class="compare-grid">
        <div class="compare-card"><h4>${escapeHtml(sA.athlete)}</h4>
          <div style="font-size:0.8rem;color:#94a3b8;margin-bottom:8px">${escapeHtml(sA.theme)} · ${sA.date}</div>
          ${row("Volume (kg)", sA.volume, sB.volume, "")}
          ${row("Séries", sA.sets, sB.sets, "")}
          ${row("Exercices", sA.exercises, sB.exercises, "")}
          ${row("Charge moy. %", sA.avgCharge, sB.avgCharge, "%")}
          ${row("Jours", sA.days, sB.days, "")}
        </div>
        <div class="compare-card"><h4>${escapeHtml(sB.athlete)}</h4>
          <div style="font-size:0.8rem;color:#94a3b8;margin-bottom:8px">${escapeHtml(sB.theme)} · ${sB.date}</div>
          ${row("Volume (kg)", sB.volume, sA.volume, "")}
          ${row("Séries", sB.sets, sA.sets, "")}
          ${row("Exercices", sB.exercises, sA.exercises, "")}
          ${row("Charge moy. %", sB.avgCharge, sA.avgCharge, "%")}
          ${row("Jours", sB.days, sA.days, "")}
        </div>
      </div>`;
}

function exportChargesExcel() {
  const store = loadHistoryStore();
  let csv = "Athlete;Exercice;Date;Seance;Charge_kg\n";
  let n = 0;
  Object.keys(store).forEach((athlete) => {
    Object.keys(store[athlete] || {}).forEach((ex) => {
      (store[athlete][ex] || []).forEach((e) => {
        csv += `"${(athlete || "").replace(/"/g, '""')}";"${(ex || "").replace(/"/g, '""')}";${e.date || ""};${e.session || ""};${e.kg}\n`;
        n++;
      });
    });
  });
  // aussi charges du programme ouvert
  if (program && program.days) {
    (program.days || []).forEach((d) => {
      (d.exercises || []).forEach((ex) => {
        if (ex.chargeKg != null && ex.chargeKg !== "") {
          csv += `"${(program.athlete || "").replace(/"/g, '""')}";"${(ex.name || "").replace(/"/g, '""')}";${program.date || ""};${program.sessionNum || ""};${ex.chargeKg}\n`;
          n++;
        }
      });
    });
  }
  if (!n) {
    showToast("Aucune charge (kg) à exporter");
    return;
  }
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
  window.yhSaveFile("StriderPro_charges.csv", blob);
  showToast("Export Excel (CSV) téléchargé");
}

// profiles.js chargé séparément.
