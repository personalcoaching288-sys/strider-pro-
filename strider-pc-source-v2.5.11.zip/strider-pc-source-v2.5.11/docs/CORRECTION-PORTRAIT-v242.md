# Correction 2.4.2 — Menu latéral

Les sous-menus ne sont plus inaccessibles sous 1000 pixels. Un clic sur Athlètes, Entraînement, Suivi ou Gestion ouvre le menu avec ses libellés. Le bouton de réduction permet de l’ouvrir et de le fermer. Échap ou un clic à l’extérieur ferme le panneau. Le passage portrait/paysage conserve la préférence desktop sans bloquer la navigation.

Cette livraison contient le projet et les scripts de lancement/construction, pas un installateur Windows déjà compilé. Faire une sauvegarde avant de changer de version.
