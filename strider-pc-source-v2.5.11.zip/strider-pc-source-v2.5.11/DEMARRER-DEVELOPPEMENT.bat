@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js doit etre installe.& pause & exit /b 1)
if not exist node_modules call npm install || exit /b 1
call npm run check || exit /b 1
call npm start
