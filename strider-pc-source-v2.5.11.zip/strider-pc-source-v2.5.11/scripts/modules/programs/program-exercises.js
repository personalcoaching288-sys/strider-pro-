/** Exercices dans un jour (CRUD, ordre, médias) */
// ========== EXERCISES ==========
function setMediaPreview(elId, src) {
  const el = document.getElementById(elId);
  if (!el) return;
  if (src && isVideoMedia(src)) {
    el.innerHTML = `<video class="img-preview" src="${toPlayableUrl(src)}" muted playsinline preload="metadata"></video>`;
  } else if (src) {
    el.innerHTML = `<img class="img-preview" src="${src}" />`;
  } else {
    el.innerHTML = `<div class="img-preview-placeholder"><i class="fas fa-dumbbell"></i></div>`;
  }
}

function fillLibraryPickSelect() {
  const list = typeof loadExerciseLibrary === "function" ? loadExerciseLibrary() : [];
  const opts =
    '<option value="">— Liste des exercices enregistrés —</option>' +
    list
      .slice()
      .sort((a, b) => (a.name || "").localeCompare(b.name || "", "fr"))
      .map((item) => {
        const label = (item.name || "Sans nom").replace(/</g, "");
        const media = item.image ? (isVideoMedia(item.image) ? "🎬 " : "🖼 ") : "";
        return `<option value="${item.id}">${media}${label}</option>`;
      })
      .join("");
  ["libPickSelect", "libPickSelectComp"].forEach((id) => {
    const sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = opts;
    sel.value = "";
  });
}

function applyLibraryPick(libId, target) {
  if (!libId) return;
  const item = (loadExerciseLibrary() || []).find((x) => x.id === libId);
  if (!item) return;
  const set = (id, v) => {
    const el = document.getElementById(id);
    if (el && v != null && v !== undefined) el.value = v;
  };
  const which = target === "comp" ? "comp" : "main";

  if (which === "main") {
    set("inputExName", item.name || "");
    set("inputSeries", item.series ?? 3);
    set("inputReps", item.reps ?? 10);
    set("inputCharge", item.charge ?? 70);
    set("inputChargeKg", item.chargeKg ?? "");
    set("inputRecup", item.recup ?? "90s");
    set("inputRpe", item.rpe ?? "");
    set("inputExNotes", item.notes ?? "");
    exImageData = item.image || null;
    setMediaPreview("exImgPreview", exImageData);
  } else {
    set("inputCompName", item.name || "");
    set("inputCompSeries", item.series ?? 3);
    set("inputCompReps", item.reps ?? 12);
    set("inputCompCharge", item.charge ?? 50);
    set("inputCompChargeKg", item.chargeKg ?? "");
    set("inputCompRecup", item.recup ?? "60s");
    set("inputCompRpe", item.rpe ?? "");
    set("inputCompNotes", item.notes ?? "");
    exCompImageData = item.image || null;
    setMediaPreview("exCompImgPreview", exCompImageData);
  }
  showToast((which === "main" ? "Principal" : "Complémentaire") + " : " + (item.name || ""));
}

function openExerciseModal(dayId, exId = null) {
  if (!guardEdit()) return;
  currentDayId = dayId;
  currentExId = exId;
  try {
    fillLibraryPickSelect();
  } catch (e) {}
  exImageData = null;
  exCompImageData = null;

  const title = document.getElementById("exModalTitle");
  const clearFile = (id) => {
    const f = document.getElementById(id);
    if (f) f.value = "";
  };

  if (exId) {
    title.textContent = "Modifier l'exercice";
    const day = program.days.find((d) => d.id === dayId);
    const ex = day?.exercises.find((e) => e.id === exId);
    if (ex) {
      document.getElementById("inputExName").value = ex.name || "";
      document.getElementById("inputSeries").value = ex.series ?? 4;
      document.getElementById("inputReps").value = ex.reps ?? 12;
      document.getElementById("inputCharge").value = ex.charge ?? 70;
      document.getElementById("inputChargeKg").value =
        ex.chargeKg !== null && ex.chargeKg !== undefined ? ex.chargeKg : "";
      document.getElementById("inputRecup").value = ex.recup ?? "2";
      document.getElementById("inputExNotes").value = ex.notes || "";
      if (document.getElementById("inputRpe"))
        document.getElementById("inputRpe").value =
          ex.rpe !== null && ex.rpe !== undefined ? ex.rpe : "";
      document.getElementById("colBorder").value = ex.colBorder || "#10b981";
      document.getElementById("colSeries").value = ex.colSeries || "#6366f1";
      document.getElementById("colReps").value = ex.colReps || "#0d9488";
      document.getElementById("colCharge").value = ex.colCharge || "#e11d48";
      document.getElementById("colRecup").value = ex.colRecup || "#7c3aed";
      document.getElementById("colCard").value = ex.cardColor || "#1f2937";
      document.getElementById("colorWhole").checked = ex.colorWhole !== false;
      exImageData = ex.image || null;
      setMediaPreview("exImgPreview", ex.image);

      document.getElementById("inputCompName").value = ex.compName || "";
      document.getElementById("inputCompSeries").value = ex.compSeries ?? 3;
      document.getElementById("inputCompReps").value = ex.compReps ?? 12;
      document.getElementById("inputCompCharge").value = ex.compCharge ?? 50;
      document.getElementById("inputCompChargeKg").value =
        ex.compChargeKg !== null && ex.compChargeKg !== undefined ? ex.compChargeKg : "";
      document.getElementById("inputCompRecup").value = ex.compRecup ?? "1";
      document.getElementById("inputCompNotes").value = ex.compNotes || "";
      if (document.getElementById("inputCompRpe"))
        document.getElementById("inputCompRpe").value =
          ex.compRpe !== null && ex.compRpe !== undefined ? ex.compRpe : "";
      document.getElementById("compColSeries").value = ex.compColSeries || "#6366f1";
      document.getElementById("compColReps").value = ex.compColReps || "#0d9488";
      document.getElementById("compColCharge").value = ex.compColCharge || "#e11d48";
      document.getElementById("compColRecup").value = ex.compColRecup || "#7c3aed";
      exCompImageData = ex.compImage || null;
      setMediaPreview("exCompImgPreview", ex.compImage);
      updateHexes();
      updateCardColorVisibility();
    }
  } else {
    title.textContent = "Ajouter un exercice";
    document.getElementById("inputExName").value = "";
    document.getElementById("inputSeries").value = 4;
    document.getElementById("inputReps").value = 12;
    document.getElementById("inputCharge").value = 70;
    document.getElementById("inputChargeKg").value = "";
    document.getElementById("inputRecup").value = "2";
    document.getElementById("inputExNotes").value = "";
    if (document.getElementById("inputRpe")) document.getElementById("inputRpe").value = "";
    document.getElementById("colBorder").value = "#10b981";
    document.getElementById("colSeries").value = "#6366f1";
    document.getElementById("colReps").value = "#0d9488";
    document.getElementById("colCharge").value = "#e11d48";
    document.getElementById("colRecup").value = "#7c3aed";
    document.getElementById("colCard").value = "#1f2937";
    document.getElementById("colorWhole").checked = true;
    setMediaPreview("exImgPreview", null);
    clearFile("inputExImage");

    document.getElementById("inputCompName").value = "";
    document.getElementById("inputCompSeries").value = 3;
    document.getElementById("inputCompReps").value = 12;
    document.getElementById("inputCompCharge").value = 50;
    document.getElementById("inputCompChargeKg").value = "";
    document.getElementById("inputCompRecup").value = "1";
    document.getElementById("inputCompNotes").value = "";
    if (document.getElementById("inputCompRpe")) document.getElementById("inputCompRpe").value = "";
    document.getElementById("compColSeries").value = "#6366f1";
    document.getElementById("compColReps").value = "#0d9488";
    document.getElementById("compColCharge").value = "#e11d48";
    document.getElementById("compColRecup").value = "#7c3aed";
    setMediaPreview("exCompImgPreview", null);
    clearFile("inputCompExImage");
    updateHexes();
    updateCardColorVisibility();
  }
  openModal("exerciseModal");
}

async function previewMedia(input, which) {
  const file = input.files[0];
  if (!file) return;
  const isVideo = file.type.startsWith("video/");
  const maxBytes = isVideo ? 2.5 * 1024 * 1024 : 6 * 1024 * 1024;
  if (file.size > maxBytes) {
    showToast(
      isVideo
        ? "Vidéo trop lourde (max 2,5 Mo). Compresse-la ou prends une plus courte."
        : "Image trop lourde (max 6 Mo).",
    );
    input.value = "";
    return;
  }
  const previewId = which === "comp" ? "exCompImgPreview" : "exImgPreview";
  try {
    if (isVideo) {
      const reader = new FileReader();
      const dataUrl = await new Promise((res, rej) => {
        reader.onload = (e) => res(e.target.result);
        reader.onerror = () => rej(new Error("read fail"));
        reader.readAsDataURL(file);
      });
      if (which === "comp") exCompImageData = dataUrl;
      else exImageData = dataUrl;
      const blobUrl = URL.createObjectURL(file);
      document.getElementById(previewId).innerHTML =
        `<video class="img-preview" src="${blobUrl}" muted playsinline preload="metadata"></video>`;
    } else {
      const maxSide = which === "comp" ? 220 : 280;
      const compressed = await compressImageFile(file, maxSide, 0.5);
      if (which === "comp") exCompImageData = compressed;
      else exImageData = compressed;
      document.getElementById(previewId).innerHTML =
        `<img class="img-preview" src="${compressed}" />`;
    }
  } catch (err) {
    console.error(err);
    showToast("Impossible de lire le fichier");
    input.value = "";
  }
}

function removeExMedia(which) {
  if (which === "comp") {
    exCompImageData = null;
    setMediaPreview("exCompImgPreview", null);
    const f = document.getElementById("inputCompExImage");
    if (f) f.value = "";
  } else {
    exImageData = null;
    setMediaPreview("exImgPreview", null);
    const f = document.getElementById("inputExImage");
    if (f) f.value = "";
  }
}

async function saveExercise() {
  try {
    if (!guardEdit()) return;
    if (!program) {
      showToast("Aucun programme");
      return;
    }
    if (!program.id) program.id = uid();
    if (!program.createdAt) program.createdAt = Date.now();
    if (!program.days) program.days = [];

    const nameEl = document.getElementById("inputExName");
    const name = (nameEl && nameEl.value ? nameEl.value : "").trim();
    if (!name) {
      showToast("Nom de l'exercice obligatoire");
      return;
    }

    const day = program.days.find((d) => d.id === currentDayId);
    if (!day) {
      showToast("Jour introuvable — rouvre l'exercice");
      return;
    }
    if (!day.exercises) day.exercises = [];

    const val = (id, def) => {
      const el = document.getElementById(id);
      if (!el) return def;
      return el.value;
    };
    const num = (id, def) => {
      const v = val(id, "");
      if (v === "" || v == null) return def;
      const n = +v;
      return isNaN(n) ? def : n;
    };
    const kgVal = (id) => {
      const v = val(id, "");
      return v === "" || v == null ? null : +v;
    };

    let image = exImageData;
    let compImage = exCompImageData;
    try {
      image = await persistMediaIfNeeded(
        exImageData,
        !!(exImageData && String(exImageData).startsWith("data:video")),
      );
    } catch (e) {
      console.warn(e);
    }
    try {
      compImage = await persistMediaIfNeeded(
        exCompImageData,
        !!(exCompImageData && String(exCompImageData).startsWith("data:video")),
      );
    } catch (e) {
      console.warn(e);
    }

    const data = {
      name,
      series: num("inputSeries", 0),
      reps: num("inputReps", 0),
      charge: num("inputCharge", 0),
      chargeKg: kgVal("inputChargeKg"),
      recup: val("inputRecup", "0") || "0",
      notes: (val("inputExNotes", "") || "").trim(),
      rpe: (() => {
        const v = val("inputRpe", "");
        return v === "" || v == null ? null : +v;
      })(),
      colBorder: val("colBorder", "#10b981"),
      colSeries: val("colSeries", "#6366f1"),
      colReps: val("colReps", "#0d9488"),
      colCharge: val("colCharge", "#e11d48"),
      colRecup: val("colRecup", "#7c3aed"),
      cardColor: val("colCard", "#1f2937"),
      colorWhole: !!(
        document.getElementById("colorWhole") && document.getElementById("colorWhole").checked
      ),
      image: image,
      compName: (val("inputCompName", "") || "").trim(),
      compSeries: num("inputCompSeries", 0),
      compReps: num("inputCompReps", 0),
      compCharge: num("inputCompCharge", 0),
      compChargeKg: kgVal("inputCompChargeKg"),
      compRecup: val("inputCompRecup", "0") || "0",
      compNotes: (val("inputCompNotes", "") || "").trim(),
      compRpe: (() => {
        const v = val("inputCompRpe", "");
        return v === "" || v == null ? null : +v;
      })(),
      compColSeries: val("compColSeries", "#6366f1"),
      compColReps: val("compColReps", "#0d9488"),
      compColCharge: val("compColCharge", "#e11d48"),
      compColRecup: val("compColRecup", "#7c3aed"),
      compImage: compImage,
    };

    const previousExercises = day.exercises.map((e) => ({ ...e }));

    if (currentExId) {
      const idx = day.exercises.findIndex((e) => e.id === currentExId);
      if (idx >= 0) day.exercises[idx] = { ...day.exercises[idx], ...data };
      else day.exercises.push({ id: currentExId, ...data });
    } else {
      day.exercises.push({ id: uid(), ...data });
    }

    program.updatedAt = Date.now();
    const ok = saveProgramToStorage(program);
    if (!ok) {
      day.exercises = previousExercises;
      showToast("Échec sauvegarde — réessaie ou allège le stockage");
      return;
    }
    try {
      if (typeof markDirty === "function") markDirty();
    } catch (e) {}
    programDirty = false;
    // Auto-bibliothèque : principal + complémentaire
    try {
      if (data.name)
        upsertLibraryExercise({
          name: data.name,
          image: data.image,
          series: data.series,
          reps: data.reps,
          charge: data.charge,
          chargeKg: data.chargeKg,
          recup: data.recup,
          rpe: data.rpe,
          notes: data.notes,
        });
      if (data.compName)
        upsertLibraryExercise({
          name: data.compName,
          image: data.compImage,
          series: data.compSeries,
          reps: data.compReps,
          charge: data.compCharge,
          chargeKg: data.compChargeKg,
          recup: data.compRecup,
          rpe: data.compRpe,
          notes: data.compNotes,
        });
    } catch (e) {
      console.warn(e);
    }
    try {
      render();
    } catch (e) {
      console.error(e);
    }
    try {
      closeModal("exerciseModal");
    } catch (e) {}
    showToast("Exercice enregistré (+ bibliothèque)");
  } catch (err) {
    console.error(err);
    showToast("Erreur exercice: " + (err && err.message ? err.message : String(err)));
  }
}

function deleteExercise(dayId, exId) {
  if (!guardEdit()) return;
  if (!confirm("Supprimer cet exercice ?")) return;
  const day = program.days.find((d) => d.id === dayId);
  if (day) {
    day.exercises = day.exercises.filter((e) => e.id !== exId);
    save();
    render();
    showToast("Exercice supprimé");
  }
}
