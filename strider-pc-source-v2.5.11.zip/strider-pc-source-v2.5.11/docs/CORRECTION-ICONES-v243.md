# Version 2.4.3

Correction du jeu d’icônes incomplet de la 2.4.1/2.4.2. 93 icônes SVG locales : options des programmes, outils des exercices et menus. Pas de téléchargement ni de police externe. Icône d’application aux coins arrondis, logo inchangé au centre. Correction portrait conservée.

Projet source avec scripts de lancement et de construction Windows. Sauvegarder les données avant mise à jour et conserver l’ancienne version. Tests navigateur uniquement : validation Windows à effectuer sur votre PC.
