# Correction des fiches de séance — 2.4.76

- Correction du schéma qui restait affiché après le chargement d’une autre fiche ou le changement de partie.
- Le rendu du terrain n’est plus annulé par l’état temporaire de saisie d’un champ.
- Les données de la fiche et les schémas enregistrés ne sont pas modifiés par cette correction.

## Vérification conseillée
1. Ouvrir l’application et ouvrir une fiche enregistrée.
2. Vérifier que le schéma correspond à la première partie.
3. Cliquer sur une autre partie et vérifier que le schéma change.
4. Modifier le titre et les consignes pour confirmer que la saisie fonctionne.
5. Ouvrir une deuxième fiche et vérifier que son schéma remplace celui de la première.
