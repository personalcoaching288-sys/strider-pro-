# Version 2.4.15 — Visibilité des profils

Cas confirmé dans le navigateur : un groupe sélectionné au tableau de bord pouvait filtrer automatiquement la liste des profils et masquer des fiches déjà enregistrées. Un nouveau profil sans affectation pouvait aussi être absent de la liste après sa sauvegarde sous ce filtre. Cela ne prouve pas que tous les cas signalés ont cette cause, mais ces deux comportements sont corrigés.

À chaque ouverture des profils, la liste affiche désormais tous les athlètes. Le choix du groupe au tableau de bord n’impose plus de filtre caché. Les filtres de groupes restent disponibles volontairement et le compteur indique « Filtre actif : X sur Y athlètes ». Le bouton « Afficher tous les profils » retire le filtre et relit les données enregistrées, sans fermer l’application et sans remplacer les champs du formulaire en cours d’édition.

Si une sauvegarde ou une ouverture explicite vise un profil hors du filtre, le filtre est retiré pour que ce profil figure dans la liste. Les modifications en attente sont enregistrées avant un changement de filtre. Aucun fichier de données n’est supprimé, aucune migration et aucune fusion des athlètes. Le classement par nom de famille reste inchangé.

Les protections de saisie et le raccourci F6 de la 2.4.14 sont conservés, ainsi que les fonds, l’import JSON et les exports A4. Tests sur des profils de démonstration dans le navigateur ; vos données et Windows n’ont pas été directement inspectés. Sauvegarder avant mise à jour et tester le projet source dans un nouveau dossier via DEMARRER-DEVELOPPEMENT.bat.
