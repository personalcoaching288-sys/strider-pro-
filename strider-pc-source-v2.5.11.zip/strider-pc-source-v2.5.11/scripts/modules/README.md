# Modules YhCoachPro

| Fichier | Rôle |
|---------|------|
| store.js | Stockage unifié + clés |
| programs.js | Programmes (cœur) |
| modern-programs.js | UI / logique programmes récente |
| profiles.js | Fiches athlètes & groupes |
| attendance.js | Assiduité |
| planning.js | Planning |
| charges.js | Charges / progression |
| dashboard.js | Tableau de bord |
| session-sheet.js | Fiche de séance |
| exports.js | Exports |
| sharing.js | Partage |
| backup-sharing.js | Sauvegarde / partage |
| licenses.js | Licences YH2 |

Ne pas remettre les anciens noms `*-v230.js` etc.

| optional-assets.js | Chargement PDF/image à la demande |
| sport-templates.js | Templates séances par sport |
| load-history.js | Historique des charges |
| theme-dark.js | Dark mode / thème |

| navigation.js | Changement d'écrans |
| render-core.js | Rendu éditeur programme |
| bootstrap.js | Démarrage (à charger en dernier) |

| program-days.js | Jours du programme |
| program-exercises.js | Exercices |
| program-core.js | Save / load programme |
