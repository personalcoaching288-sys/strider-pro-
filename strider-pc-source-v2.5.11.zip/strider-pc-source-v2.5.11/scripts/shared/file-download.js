// Enregistrement d'un fichier partagé (JSON, HTML, CSV, PDF, image, vidéo).
//
// Pourquoi ce fichier : chaque export avait son petit bout de code « créer un
// lien, cliquer dessus ». Sur téléphone (surtout iPhone/iPad) ce réflexe ne
// suffit pas : le lien doit être dans la page, et le navigateur propose mieux
// avec la fenêtre « Partager » (Enregistrer dans Fichiers, Drive, WhatsApp…).
// Tous les exports passent maintenant par ici.

(function () {
  "use strict";

  function toBlob(data, type) {
    if (data instanceof Blob) return data;
    return new Blob([data], { type: type || "application/octet-stream" });
  }

  function canShareFile(blob, name) {
    try {
      if (!navigator.canShare || !window.File) return false;
      return navigator.canShare({ files: [new File([blob], name, { type: blob.type })] });
    } catch (_) {
      return false;
    }
  }

  async function shareFile(blob, name) {
    const file = new File([blob], name, { type: blob.type });
    await navigator.share({ files: [file], title: name });
    return true;
  }

  function anchorDownload(blob, name) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    link.rel = "noopener";
    // Sans cette ligne, Safari (iPhone/iPad/Mac) ignore complètement le clic.
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    // L'URL doit survivre le temps que le navigateur lance le téléchargement.
    setTimeout(() => {
      URL.revokeObjectURL(url);
      link.remove();
    }, 30000);
    return true;
  }

  function isTouch() {
    try {
      return window.matchMedia && matchMedia("(pointer: coarse)").matches;
    } catch (_) {
      return "ontouchstart" in window;
    }
  }

  /**
   * Enregistre un fichier. data = texte ou Blob.
   * Renvoie true si le fichier a été remis à l'utilisateur.
   * Ne l'appelle qu'à partir d'un clic (sinon le navigateur refuse le partage).
   */
  window.yhSaveFile = async function (name, data, type) {
    const blob = toBlob(data, type);
    if (isTouch() && canShareFile(blob, name)) {
      try {
        return await shareFile(blob, name);
      } catch (e) {
        // Partage annulé par l'utilisateur : on ne relance pas un téléchargement.
        if (e && e.name === "AbortError") return false;
        // Le partage n'est pas possible ici : on tente le téléchargement.
      }
    }
    return anchorDownload(blob, name);
  };
})();
