const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("yhDisk", {
  enabled: true,
  restoreInputFocus: () => ipcRenderer.invoke("yh-input-focus"),
  onRestoreInputFocus: (callback) => {
    if (typeof callback !== "function") return;
    const listener = () => callback();
    ipcRenderer.on("yh-restore-input-focus", listener);
    return () => ipcRenderer.removeListener("yh-restore-input-focus", listener);
  },
  read: (key) => ipcRenderer.sendSync("yh-disk-read", key),
  write: (key, value) => ipcRenderer.sendSync("yh-disk-write", key, value),
  remove: (key) => ipcRenderer.sendSync("yh-disk-remove", key),
  listPrograms: () => ipcRenderer.sendSync("yh-disk-list-programs"),
  getDataPath: () => ipcRenderer.sendSync("yh-disk-path"),
  saveMedia: (id, base64) => ipcRenderer.sendSync("yh-media-save", id, base64),
  mediaPath: (id) => ipcRenderer.sendSync("yh-media-path", id),
  deleteMedia: (id) => ipcRenderer.sendSync("yh-media-delete", id),
  mediaAsBase64: (id) => ipcRenderer.sendSync("yh-media-as-base64", id),
  exportFile: (filename, content) => ipcRenderer.invoke("yh-export-file", filename, content),
  exportVideos: (files) => ipcRenderer.invoke("yh-export-videos", files),
  exportBinary: (filename, bytes) => ipcRenderer.invoke("yh-export-binary", filename, bytes),
  exportProfileList: (filename, html, landscape, mode, pageRanges) =>
    ipcRenderer.invoke("yh-profile-list-export", filename, html, landscape, mode, pageRanges),
  exportSessionSummary: (filename, html, mode) =>
    ipcRenderer.invoke("yh-session-summary-export", filename, html, mode),
  exportPdf: (filename, options) => ipcRenderer.invoke("yh-export-pdf", filename, options || {}),
  getLicenseDeviceId: () => ipcRenderer.invoke("yh-license-device-id"),
  verifyLicense: (key) => ipcRenderer.invoke("yh-license-verify", key),
  readClipboardText: () => ipcRenderer.invoke("yh-clipboard-read"),
  createAutomaticBackup: () => ipcRenderer.invoke("yh-auto-backup-now"),
  automaticBackupStatus: () => ipcRenderer.invoke("yh-auto-backup-status"),
  restoreAutomaticBackup: (content) => ipcRenderer.invoke("yh-auto-backup-restore", content),
});
