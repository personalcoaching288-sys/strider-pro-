$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ico = Join-Path $root "icon.ico"
$candidates = @(
  (Join-Path $env:LOCALAPPDATA "Programs\Strider Pro\Strider Pro.exe"),
  (Join-Path $root "dist\win-unpacked\Strider Pro.exe"),
  (Join-Path $root "dist\StriderPro-Portable.exe"),
  (Join-Path $env:LOCALAPPDATA "Programs\YhCoachPro\YhCoachPro.exe"),
  (Join-Path $env:LOCALAPPDATA "Programs\yhcoachpro\YhCoachPro.exe"),
  (Join-Path $root "dist\win-unpacked\YhCoachPro.exe"),
  (Join-Path $root "dist\YhCoachPro-Portable.exe")
)
$exe = $null
foreach ($p in $candidates) {
  if (Test-Path $p) { $exe = $p; break }
}
if (-not $exe) {
  Write-Host "Aucun exe trouve pour le raccourci"
  exit 0
}
$desk = [Environment]::GetFolderPath("Desktop")
$lnkPath = Join-Path $desk "Strider Pro.lnk"
$w = New-Object -ComObject WScript.Shell
$s = $w.CreateShortcut($lnkPath)
$s.TargetPath = $exe
$s.WorkingDirectory = Split-Path $exe
if (Test-Path $ico) { $s.IconLocation = "$ico,0" }
$s.Description = "Strider Pro — Coaching & Performance"
$s.Save()
Write-Host "Raccourci: $lnkPath"
Write-Host "Cible: $exe"
