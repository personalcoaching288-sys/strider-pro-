# Version 2.4.11 — Fond des fiches de séance

Photo fournie (ballon jaune/bleu et bras du joueur) en fond de la page Fiches de séance. Image légère en WebP, recadrage automatique sans déformation, voile sombre pour conserver la lisibilité, logo et panneaux translucides inchangés.

Les fonds du tableau de bord et du menu latéral de la 2.4.10 restent en place. Les données des fiches et leur fonctionnement ne changent pas. Le PDF, le HTML de partage et l’impression gardent le résumé A4 clair validé, sans photo de fond.

Tests navigateur ; installation Windows à vérifier sur votre ordinateur. Faire une sauvegarde et conserver la version précédente avant mise à jour. Projet source avec scripts de lancement, pas un installateur compilé.
