/** Templates de séances par sport */
// ========== TEMPLATES PAR SPORT ==========
// Structure: SPORT -> types de seance (force, hypertrophie, etc.)
const SPORT_TEMPLATES = {
  volley: {
    label: "Volleyball",
    desc: "Prep physique haut niveau",
    icon: "fa-volleyball-ball",
    sessions: {
      force_max: {
        label: "Force max",
        desc: "Charges lourdes, force utile",
        theme: "volley force",
        objective: "Volley HL — force maximale (jambes, tirage, gainage)",
        days: [
          {
            name: "FORCE MAX VOLLEY",
            color: "#4f46e5",
            exercises: [
              {
                name: "Squat arrière",
                series: 5,
                reps: 3,
                charge: 85,
                recup: "3-4 min",
                rpe: 8,
                notes: "Zone 85-90% 1RM",
              },
              {
                name: "Soulevé de terre roumain",
                series: 4,
                reps: 5,
                charge: 75,
                recup: "2-3 min",
                rpe: 8,
              },
              { name: "Tractions lestées", series: 4, reps: 5, charge: 70, recup: "2 min", rpe: 8 },
              {
                name: "Développé militaire haltères",
                series: 4,
                reps: 5,
                charge: 70,
                recup: "2 min",
                rpe: 7,
              },
              { name: "Hip thrust barre", series: 4, reps: 6, charge: 80, recup: "2 min", rpe: 7 },
              { name: "Rowing barre", series: 3, reps: 6, charge: 75, recup: "90s", rpe: 7 },
              { name: "Mollets mono-jambe", series: 3, reps: 8, charge: 50, recup: "60s", rpe: 7 },
              { name: "Pallof press", series: 3, reps: 10, charge: 40, recup: "60s", rpe: 6 },
            ],
          },
        ],
      },
      hypertrophie: {
        label: "Hypertrophie",
        desc: "Volume musculaire spécifique",
        theme: "volley hypertrophie",
        objective: "Volley HL — hypertrophie utile (chaîne postérieure + épaules)",
        days: [
          {
            name: "HYPERTROPHIE VOLLEY",
            color: "#0d9488",
            exercises: [
              { name: "Squat gobelet", series: 4, reps: 10, charge: 65, recup: "90s", rpe: 8 },
              {
                name: "Fentes arrière",
                series: 3,
                reps: 10,
                charge: 55,
                recup: "75s",
                rpe: 7,
                notes: "Par jambe",
              },
              {
                name: "Développé incliné haltères",
                series: 4,
                reps: 10,
                charge: 65,
                recup: "90s",
                rpe: 7,
              },
              {
                name: "Tirage vertical / tractions",
                series: 4,
                reps: 10,
                charge: 60,
                recup: "90s",
                rpe: 8,
              },
              { name: "Face pull", series: 4, reps: 15, charge: 40, recup: "60s", rpe: 7 },
              {
                name: "Élévations latérales",
                series: 3,
                reps: 12,
                charge: 45,
                recup: "45s",
                rpe: 7,
              },
              { name: "Leg curl", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 7 },
              { name: "Curl biceps", series: 3, reps: 12, charge: 55, recup: "45s", rpe: 7 },
            ],
          },
        ],
      },
      puissance: {
        label: "Puissance / saut",
        desc: "Appel, détente, explosivité",
        theme: "volley puissance",
        objective: "Volley HL — puissance d'appel et vitesse de contraction",
        days: [
          {
            name: "PUISSANCE VOLLEY",
            color: "#e11d48",
            exercises: [
              {
                name: "Box jump",
                series: 5,
                reps: 5,
                charge: 0,
                recup: "2 min",
                rpe: 7,
                notes: "Réception stable",
              },
              { name: "Squat jump léger", series: 5, reps: 5, charge: 30, recup: "2 min", rpe: 7 },
              {
                name: "Hang clean technique",
                series: 4,
                reps: 3,
                charge: 65,
                recup: "2-3 min",
                rpe: 7,
              },
              {
                name: "Fentes sautées",
                series: 3,
                reps: 6,
                charge: 0,
                recup: "90s",
                rpe: 8,
                notes: "Par jambe",
              },
              { name: "Med ball slam", series: 4, reps: 8, charge: 0, recup: "75s", rpe: 7 },
              {
                name: "Hip thrust explosif",
                series: 4,
                reps: 5,
                charge: 65,
                recup: "2 min",
                rpe: 7,
              },
              { name: "Mollets rebond", series: 3, reps: 10, charge: 0, recup: "60s", rpe: 6 },
            ],
          },
        ],
      },
      endurance_force: {
        label: "Endurance de force",
        desc: "Résistance match / blocs",
        theme: "volley endurance",
        objective: "Volley HL — endurance de force et tolérance au volume",
        days: [
          {
            name: "ENDURANCE FORCE VOLLEY",
            color: "#f59e0b",
            exercises: [
              { name: "Goblet squat", series: 4, reps: 15, charge: 50, recup: "60s", rpe: 7 },
              { name: "Pompes tempo", series: 4, reps: 12, charge: 0, recup: "60s", rpe: 7 },
              {
                name: "Rowing élastique / TRX",
                series: 3,
                reps: 15,
                charge: 40,
                recup: "45s",
                rpe: 7,
              },
              { name: "Fentes marchées", series: 3, reps: 12, charge: 45, recup: "60s", rpe: 7 },
              { name: "Mountain climbers", series: 3, reps: 20, charge: 0, recup: "45s", rpe: 7 },
              {
                name: "Planche",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 6,
                notes: "45-60s",
              },
            ],
          },
        ],
      },
      prevention: {
        label: "Prévention",
        desc: "Épaules, genoux, chevilles",
        theme: "volley prévention",
        objective: "Volley HL — prévention blessures (épaule, genou, cheville)",
        days: [
          {
            name: "PRÉVENTION VOLLEY",
            color: "#0369a1",
            exercises: [
              {
                name: "External rotation épaule",
                series: 3,
                reps: 15,
                charge: 30,
                recup: "45s",
                rpe: 5,
              },
              { name: "Face pull", series: 3, reps: 15, charge: 35, recup: "45s", rpe: 6 },
              {
                name: "Nordic curl assisté",
                series: 3,
                reps: 5,
                charge: 0,
                recup: "2 min",
                rpe: 8,
              },
              {
                name: "Copenhagen adductor",
                series: 3,
                reps: 6,
                charge: 0,
                recup: "90s",
                rpe: 7,
                notes: "Par côté",
              },
              { name: "Single leg RDL", series: 3, reps: 8, charge: 40, recup: "75s", rpe: 6 },
              {
                name: "Proprioception monopedale",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "30s",
                rpe: 4,
                notes: "30s / jambe",
              },
              {
                name: "Mobilité hanche 90/90",
                series: 2,
                reps: 8,
                charge: 0,
                recup: "30s",
                rpe: 3,
              },
            ],
          },
        ],
      },
      gainage: {
        label: "Gainage / core",
        desc: "Stabilité tronc et transfert",
        theme: "volley gainage",
        objective: "Volley HL — core anti-rotation et stabilité",
        days: [
          {
            name: "GAINAGE VOLLEY",
            color: "#7c3aed",
            exercises: [
              {
                name: "Planche frontale",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 6,
                notes: "40-50s",
              },
              {
                name: "Planche latérale",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 6,
                notes: "30s / côté",
              },
              { name: "Dead bug", series: 3, reps: 10, charge: 0, recup: "45s", rpe: 5 },
              { name: "Pallof press", series: 3, reps: 12, charge: 40, recup: "45s", rpe: 6 },
              {
                name: "Hollow hold",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 7,
                notes: "25-35s",
              },
              { name: "Bird dog", series: 3, reps: 10, charge: 0, recup: "30s", rpe: 4 },
            ],
          },
        ],
      },
    },
  },
  handball: {
    label: "Handball",
    desc: "Prep physique contact & tir",
    icon: "fa-hand-paper",
    sessions: {
      force_max: {
        label: "Force max",
        desc: "Force utile et contact",
        theme: "hand force",
        objective: "Hand HL — force max (squat, développé, tirage)",
        days: [
          {
            name: "FORCE MAX HAND",
            color: "#b91c1c",
            exercises: [
              { name: "Squat arrière", series: 5, reps: 3, charge: 85, recup: "3-4 min", rpe: 8 },
              { name: "Développé couché", series: 5, reps: 3, charge: 85, recup: "3 min", rpe: 8 },
              { name: "Soulevé de terre", series: 4, reps: 3, charge: 80, recup: "3 min", rpe: 8 },
              { name: "Rowing barre", series: 4, reps: 5, charge: 75, recup: "2 min", rpe: 7 },
              { name: "Fentes chargées", series: 3, reps: 6, charge: 65, recup: "90s", rpe: 7 },
              {
                name: "Farmer walk",
                series: 4,
                reps: 1,
                charge: 60,
                recup: "90s",
                rpe: 7,
                notes: "20-30 m",
              },
              {
                name: "Gainage anti-rotation",
                series: 3,
                reps: 10,
                charge: 40,
                recup: "60s",
                rpe: 6,
              },
            ],
          },
        ],
      },
      hypertrophie: {
        label: "Hypertrophie",
        desc: "Masse utile performance",
        theme: "hand hypertrophie",
        objective: "Hand HL — hypertrophie orientée performance",
        days: [
          {
            name: "HYPERTROPHIE HAND",
            color: "#0d9488",
            exercises: [
              { name: "Squat", series: 4, reps: 8, charge: 72, recup: "2 min", rpe: 8 },
              { name: "Développé incliné", series: 4, reps: 10, charge: 65, recup: "90s", rpe: 7 },
              { name: "Tractions", series: 4, reps: 8, charge: 0, recup: "90s", rpe: 8 },
              { name: "Rowing haltère", series: 3, reps: 10, charge: 70, recup: "75s", rpe: 7 },
              { name: "Développé militaire", series: 3, reps: 8, charge: 65, recup: "90s", rpe: 7 },
              { name: "Leg curl", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 7 },
              {
                name: "Curl + extensions bras",
                series: 3,
                reps: 12,
                charge: 55,
                recup: "45s",
                rpe: 7,
              },
            ],
          },
        ],
      },
      puissance: {
        label: "Puissance",
        desc: "Vitesse, courses, tir",
        theme: "hand puissance",
        objective: "Hand HL — puissance et transferts de tir",
        days: [
          {
            name: "PUISSANCE HAND",
            color: "#ea580c",
            exercises: [
              { name: "Sprint 20 m", series: 6, reps: 1, charge: 0, recup: "90s", rpe: 9 },
              { name: "Broad jump", series: 5, reps: 3, charge: 0, recup: "90s", rpe: 7 },
              { name: "Hang clean", series: 4, reps: 3, charge: 65, recup: "2 min", rpe: 7 },
              {
                name: "Med ball rotational throw",
                series: 4,
                reps: 6,
                charge: 0,
                recup: "75s",
                rpe: 7,
                notes: "Par côté",
              },
              { name: "Step-up explosif", series: 3, reps: 6, charge: 40, recup: "90s", rpe: 7 },
              {
                name: "Pompes plyo contrôlées",
                series: 3,
                reps: 6,
                charge: 0,
                recup: "90s",
                rpe: 8,
              },
              { name: "Landmine rotation", series: 3, reps: 6, charge: 45, recup: "75s", rpe: 7 },
            ],
          },
        ],
      },
      endurance_force: {
        label: "Endurance de force",
        desc: "Répétitions match",
        theme: "hand endurance",
        objective: "Hand HL — endurance de force",
        days: [
          {
            name: "ENDURANCE FORCE HAND",
            color: "#f59e0b",
            exercises: [
              { name: "Goblet squat", series: 4, reps: 15, charge: 50, recup: "60s", rpe: 7 },
              { name: "Pompes", series: 4, reps: 15, charge: 0, recup: "60s", rpe: 7 },
              { name: "Fentes marchées", series: 3, reps: 12, charge: 50, recup: "60s", rpe: 7 },
              { name: "Rowing TRX", series: 3, reps: 15, charge: 40, recup: "45s", rpe: 7 },
              { name: "Burpees contrôlés", series: 3, reps: 10, charge: 0, recup: "60s", rpe: 8 },
              {
                name: "Planche",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 6,
                notes: "45s",
              },
            ],
          },
        ],
      },
      prevention: {
        label: "Prévention",
        desc: "Épaule, ischios, adducteurs",
        theme: "hand prévention",
        objective: "Hand HL — prévention épaule / ischios / adducteurs",
        days: [
          {
            name: "PRÉVENTION HAND",
            color: "#0369a1",
            exercises: [
              { name: "External rotation", series: 3, reps: 15, charge: 30, recup: "45s", rpe: 5 },
              { name: "Face pull", series: 4, reps: 15, charge: 40, recup: "60s", rpe: 6 },
              { name: "Nordic curl", series: 3, reps: 4, charge: 0, recup: "2 min", rpe: 8 },
              {
                name: "Copenhagen plank",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "60s",
                rpe: 7,
                notes: "25-35s / côté",
              },
              { name: "Single leg RDL", series: 3, reps: 8, charge: 45, recup: "75s", rpe: 6 },
              { name: "Y-T-W scapulaire", series: 3, reps: 12, charge: 25, recup: "45s", rpe: 5 },
            ],
          },
        ],
      },
      gainage: {
        label: "Gainage / core",
        desc: "Stabilité et duels",
        theme: "hand gainage",
        objective: "Hand HL — core robuste",
        days: [
          {
            name: "GAINAGE HAND",
            color: "#7c3aed",
            exercises: [
              {
                name: "Planche",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 6,
                notes: "45s",
              },
              {
                name: "Planche latérale",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 6,
                notes: "30s / côté",
              },
              { name: "Pallof press", series: 3, reps: 12, charge: 45, recup: "45s", rpe: 6 },
              { name: "Hollow rock", series: 3, reps: 15, charge: 0, recup: "45s", rpe: 7 },
              { name: "Dead bug", series: 3, reps: 10, charge: 0, recup: "30s", rpe: 5 },
            ],
          },
        ],
      },
    },
  },
  bodybuilding: {
    label: "Bodybuilding",
    desc: "Musculation esthétique / force",
    icon: "fa-dumbbell",
    sessions: {
      force_max: {
        label: "Force max",
        desc: "1-5 reps, basiques",
        theme: "bodybuilding force",
        objective: "Musculation — force max sur les mouvements de base",
        days: [
          {
            name: "FORCE MAX BB",
            color: "#4f46e5",
            exercises: [
              { name: "Squat", series: 5, reps: 3, charge: 87, recup: "3-4 min", rpe: 9 },
              { name: "Développé couché", series: 5, reps: 3, charge: 85, recup: "3 min", rpe: 9 },
              {
                name: "Soulevé de terre",
                series: 4,
                reps: 3,
                charge: 85,
                recup: "3-4 min",
                rpe: 9,
              },
              { name: "Rowing barre", series: 4, reps: 5, charge: 75, recup: "2 min", rpe: 8 },
              {
                name: "Développé militaire",
                series: 4,
                reps: 5,
                charge: 75,
                recup: "2 min",
                rpe: 8,
              },
              { name: "Tractions lestées", series: 4, reps: 5, charge: 70, recup: "2 min", rpe: 8 },
            ],
          },
        ],
      },
      hypertrophie: {
        label: "Hypertrophie",
        desc: "8-12 reps volume",
        theme: "bodybuilding hypertrophie",
        objective: "Musculation — hypertrophie globale",
        days: [
          {
            name: "HYPERTROPHIE BB",
            color: "#0d9488",
            exercises: [
              { name: "Développé couché", series: 4, reps: 10, charge: 70, recup: "90s", rpe: 8 },
              { name: "Squat / presse", series: 4, reps: 10, charge: 70, recup: "2 min", rpe: 8 },
              { name: "Tractions / tirage", series: 4, reps: 10, charge: 65, recup: "90s", rpe: 8 },
              {
                name: "Élévations latérales",
                series: 4,
                reps: 12,
                charge: 50,
                recup: "60s",
                rpe: 8,
              },
              { name: "Curl biceps", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 8 },
              { name: "Extensions triceps", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 8 },
              { name: "Leg curl", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 7 },
              { name: "Mollets", series: 4, reps: 15, charge: 60, recup: "45s", rpe: 8 },
            ],
          },
        ],
      },
      ppl_push: {
        label: "PPL — Push",
        desc: "Poussée poitrine / épaules / triceps",
        theme: "bodybuilding push",
        objective: "Split PPL — jour Push",
        days: [
          {
            name: "PUSH",
            color: "#e11d48",
            exercises: [
              { name: "Développé couché", series: 4, reps: 8, charge: 75, recup: "2 min", rpe: 8 },
              {
                name: "Développé incliné haltères",
                series: 4,
                reps: 10,
                charge: 65,
                recup: "90s",
                rpe: 8,
              },
              { name: "Développé militaire", series: 4, reps: 8, charge: 70, recup: "90s", rpe: 8 },
              {
                name: "Élévations latérales",
                series: 4,
                reps: 15,
                charge: 50,
                recup: "60s",
                rpe: 8,
              },
              { name: "Écarté poulie", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 7 },
              { name: "Barre au front", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 7 },
              { name: "Extension corde", series: 3, reps: 15, charge: 50, recup: "45s", rpe: 8 },
            ],
          },
        ],
      },
      ppl_pull: {
        label: "PPL — Pull",
        desc: "Tirage dos / biceps",
        theme: "bodybuilding pull",
        objective: "Split PPL — jour Pull",
        days: [
          {
            name: "PULL",
            color: "#6366f1",
            exercises: [
              {
                name: "Soulevé de terre roumain",
                series: 4,
                reps: 8,
                charge: 75,
                recup: "2 min",
                rpe: 8,
              },
              { name: "Tractions", series: 4, reps: 8, charge: 0, recup: "2 min", rpe: 8 },
              { name: "Rowing barre", series: 4, reps: 8, charge: 72, recup: "90s", rpe: 8 },
              { name: "Tirage horizontal", series: 3, reps: 12, charge: 65, recup: "75s", rpe: 7 },
              { name: "Face pull", series: 3, reps: 15, charge: 45, recup: "60s", rpe: 7 },
              { name: "Curl pupitre", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 8 },
              { name: "Curl marteau", series: 3, reps: 12, charge: 55, recup: "60s", rpe: 7 },
            ],
          },
        ],
      },
      ppl_legs: {
        label: "PPL — Legs",
        desc: "Jambes complètes",
        theme: "bodybuilding legs",
        objective: "Split PPL — jour Legs",
        days: [
          {
            name: "LEGS",
            color: "#0d9488",
            exercises: [
              { name: "Squat", series: 4, reps: 8, charge: 75, recup: "2-3 min", rpe: 8 },
              { name: "Presse à cuisses", series: 4, reps: 12, charge: 70, recup: "2 min", rpe: 8 },
              { name: "Fentes", series: 3, reps: 10, charge: 55, recup: "90s", rpe: 8 },
              { name: "Leg curl", series: 4, reps: 12, charge: 60, recup: "75s", rpe: 8 },
              { name: "Leg extension", series: 3, reps: 15, charge: 55, recup: "60s", rpe: 8 },
              { name: "Hip thrust", series: 4, reps: 10, charge: 70, recup: "90s", rpe: 8 },
              { name: "Mollets", series: 4, reps: 15, charge: 60, recup: "45s", rpe: 8 },
            ],
          },
        ],
      },
      endurance_force: {
        label: "Endurance de force",
        desc: "15+ reps, densite",
        theme: "bodybuilding endurance",
        objective: "Musculation — endurance de force",
        days: [
          {
            name: "ENDURANCE BB",
            color: "#f59e0b",
            exercises: [
              { name: "Goblet squat", series: 3, reps: 20, charge: 45, recup: "45s", rpe: 7 },
              { name: "Pompes", series: 3, reps: 20, charge: 0, recup: "45s", rpe: 7 },
              { name: "Rowing élastique", series: 3, reps: 20, charge: 40, recup: "45s", rpe: 7 },
              { name: "Fentes", series: 3, reps: 15, charge: 40, recup: "45s", rpe: 7 },
              {
                name: "Planche",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "30s",
                rpe: 6,
                notes: "45s",
              },
            ],
          },
        ],
      },
      prevention: {
        label: "Prévention / mobilité",
        desc: "Épaules, hanches, ischios",
        theme: "bodybuilding prévention",
        objective: "Musculation — prévention et mobilité",
        days: [
          {
            name: "PRÉVENTION BB",
            color: "#0369a1",
            exercises: [
              { name: "Face pull", series: 3, reps: 15, charge: 35, recup: "45s", rpe: 5 },
              { name: "External rotation", series: 3, reps: 15, charge: 25, recup: "45s", rpe: 5 },
              { name: "Nordic curl assisté", series: 3, reps: 5, charge: 0, recup: "90s", rpe: 7 },
              { name: "Mobilité hanche", series: 2, reps: 10, charge: 0, recup: "30s", rpe: 3 },
              {
                name: "Cat-cow + thoracic open",
                series: 2,
                reps: 10,
                charge: 0,
                recup: "30s",
                rpe: 2,
              },
            ],
          },
        ],
      },
      gainage: {
        label: "Gainage",
        desc: "Core esthétique et stable",
        theme: "bodybuilding gainage",
        objective: "Musculation — gainage",
        days: [
          {
            name: "GAINAGE BB",
            color: "#7c3aed",
            exercises: [
              {
                name: "Planche",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 6,
                notes: "45-60s",
              },
              { name: "Crunch contrôlé", series: 3, reps: 15, charge: 0, recup: "30s", rpe: 6 },
              { name: "Relevé de jambes", series: 3, reps: 12, charge: 0, recup: "45s", rpe: 7 },
              {
                name: "Planche latérale",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "30s",
                rpe: 6,
                notes: "30s / côté",
              },
              { name: "Dead bug", series: 3, reps: 10, charge: 0, recup: "30s", rpe: 5 },
            ],
          },
        ],
      },
    },
  },
  combat_debutant: {
    label: "Sports de combat (débutant)",
    desc: "Base force, cardio, prévention",
    icon: "fa-fist-raised",
    sessions: {
      force_max: {
        label: "Force de base",
        desc: "Apprentissage charges modérées",
        theme: "combat force",
        objective: "Combat débutant — force de base sécurisée",
        days: [
          {
            name: "FORCE BASE COMBAT",
            color: "#4f46e5",
            exercises: [
              {
                name: "Goblet squat",
                series: 4,
                reps: 8,
                charge: 50,
                recup: "2 min",
                rpe: 6,
                notes: "Technique prioritaire",
              },
              {
                name: "Développé haltères sol",
                series: 3,
                reps: 8,
                charge: 50,
                recup: "90s",
                rpe: 6,
              },
              { name: "Rowing haltère", series: 3, reps: 10, charge: 50, recup: "90s", rpe: 6 },
              {
                name: "Hip hinge / RDL léger",
                series: 3,
                reps: 8,
                charge: 45,
                recup: "90s",
                rpe: 6,
              },
              {
                name: "Pompes genoux ou classiques",
                series: 3,
                reps: 10,
                charge: 0,
                recup: "60s",
                rpe: 6,
              },
              {
                name: "Planche",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "45s",
                rpe: 5,
                notes: "20-30s",
              },
            ],
          },
        ],
      },
      hypertrophie: {
        label: "Hypertrophie légère",
        desc: "Volume progressif",
        theme: "combat hypertrophie",
        objective: "Combat débutant — construction musculaire progressive",
        days: [
          {
            name: "VOLUME COMBAT",
            color: "#0d9488",
            exercises: [
              { name: "Squat gobelet", series: 3, reps: 12, charge: 45, recup: "75s", rpe: 7 },
              { name: "Développé haltères", series: 3, reps: 12, charge: 45, recup: "75s", rpe: 6 },
              { name: "Tirage horizontal", series: 3, reps: 12, charge: 45, recup: "75s", rpe: 6 },
              { name: "Fentes assistées", series: 3, reps: 10, charge: 0, recup: "60s", rpe: 6 },
              {
                name: "Élévations latérales légères",
                series: 3,
                reps: 12,
                charge: 30,
                recup: "45s",
                rpe: 6,
              },
              {
                name: "Curl + triceps léger",
                series: 2,
                reps: 12,
                charge: 35,
                recup: "45s",
                rpe: 6,
              },
            ],
          },
        ],
      },
      puissance: {
        label: "Puissance débutant",
        desc: "Sauts et médicine ball",
        theme: "combat puissance",
        objective: "Combat débutant — initiation puissance",
        days: [
          {
            name: "PUISSANCE COMBAT",
            color: "#e11d48",
            exercises: [
              {
                name: "Squat jump sans charge",
                series: 4,
                reps: 5,
                charge: 0,
                recup: "90s",
                rpe: 6,
              },
              { name: "Med ball chest pass", series: 4, reps: 6, charge: 0, recup: "75s", rpe: 6 },
              { name: "Step-up rapide", series: 3, reps: 6, charge: 0, recup: "75s", rpe: 6 },
              {
                name: "Pompes explosives faciles",
                series: 3,
                reps: 5,
                charge: 0,
                recup: "90s",
                rpe: 6,
              },
              { name: "Sprint sur place 10s", series: 5, reps: 1, charge: 0, recup: "60s", rpe: 7 },
            ],
          },
        ],
      },
      endurance_force: {
        label: "Endurance de force",
        desc: "Circuits simples",
        theme: "combat endurance",
        objective: "Combat débutant — endurance de force",
        days: [
          {
            name: "ENDURANCE COMBAT",
            color: "#f59e0b",
            exercises: [
              {
                name: "Squat au poids de corps",
                series: 3,
                reps: 20,
                charge: 0,
                recup: "45s",
                rpe: 6,
              },
              { name: "Pompes", series: 3, reps: 12, charge: 0, recup: "45s", rpe: 6 },
              { name: "Rowing élastique", series: 3, reps: 15, charge: 0, recup: "45s", rpe: 5 },
              { name: "Mountain climbers", series: 3, reps: 20, charge: 0, recup: "45s", rpe: 7 },
              {
                name: "Planche",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "30s",
                rpe: 5,
                notes: "30s",
              },
            ],
          },
        ],
      },
      prevention: {
        label: "Prévention",
        desc: "Épaules, poignets, hanches",
        theme: "combat prévention",
        objective: "Combat débutant — prévention articulaire",
        days: [
          {
            name: "PRÉVENTION COMBAT",
            color: "#0369a1",
            exercises: [
              {
                name: "Rotations d'épaules élastique",
                series: 3,
                reps: 15,
                charge: 0,
                recup: "30s",
                rpe: 3,
              },
              { name: "Face pull léger", series: 3, reps: 15, charge: 25, recup: "45s", rpe: 4 },
              { name: "Pont fessier", series: 3, reps: 12, charge: 0, recup: "45s", rpe: 4 },
              { name: "Mobilité hanche", series: 2, reps: 8, charge: 0, recup: "30s", rpe: 2 },
              {
                name: "Gainage simple",
                series: 2,
                reps: 1,
                charge: 0,
                recup: "30s",
                rpe: 4,
                notes: "20s",
              },
            ],
          },
        ],
      },
      gainage: {
        label: "Gainage",
        desc: "Core débutant",
        theme: "combat gainage",
        objective: "Combat débutant — gainage de base",
        days: [
          {
            name: "GAINAGE COMBAT",
            color: "#7c3aed",
            exercises: [
              {
                name: "Planche genoux ou classique",
                series: 3,
                reps: 1,
                charge: 0,
                recup: "30s",
                rpe: 4,
                notes: "15-25s",
              },
              { name: "Dead bug", series: 3, reps: 8, charge: 0, recup: "30s", rpe: 4 },
              { name: "Bird dog", series: 3, reps: 8, charge: 0, recup: "30s", rpe: 3 },
              {
                name: "Planche latérale genou",
                series: 2,
                reps: 1,
                charge: 0,
                recup: "30s",
                rpe: 4,
                notes: "15s / côté",
              },
            ],
          },
        ],
      },
    },
  },
};

// Compat: ancien nom
const SESSION_TEMPLATES = {};

let templateSportKey = null;

function openTemplateModal() {
  templateSportKey = null;
  const title = document.querySelector("#templateModal .modal-header h2");
  const sub = document.querySelector("#templateModal .modal-header p");
  if (title) title.textContent = "Modèles par sport";
  if (sub) sub.textContent = "Choisis un sport, puis un type de séance";
  const grid = document.getElementById("templateGrid");
  grid.innerHTML = Object.keys(SPORT_TEMPLATES)
    .map((key) => {
      const s = SPORT_TEMPLATES[key];
      const icon = s.icon || "fa-dumbbell";
      return `<button type="button" onclick="openSportSessions('${key}')">
          <strong><i class="fas ${icon}" style="margin-right:8px"></i>${s.label}</strong>
          <span>${s.desc}</span>
        </button>`;
    })
    .join("");
  openModal("templateModal");
}

function openSportSessions(sportKey) {
  const sport = SPORT_TEMPLATES[sportKey];
  if (!sport) return;
  templateSportKey = sportKey;
  const title = document.querySelector("#templateModal .modal-header h2");
  const sub = document.querySelector("#templateModal .modal-header p");
  if (title) title.textContent = sport.label;
  if (sub) sub.textContent = "Choisis le type de séance";
  const grid = document.getElementById("templateGrid");
  let htmlBtn = `<button type="button" onclick="openTemplateModal()" style="border-style:dashed">
        <strong><i class="fas fa-arrow-left"></i> Retour sports</strong>
        <span>Changer de sport</span>
      </button>`;
  htmlBtn += Object.keys(sport.sessions)
    .map((sk) => {
      const t = sport.sessions[sk];
      return `<button type="button" onclick="applySportTemplate('${sportKey}', '${sk}')">
          <strong>${t.label}</strong>
          <span>${t.desc}</span>
        </button>`;
    })
    .join("");
  grid.innerHTML = htmlBtn;
}

function findBuiltinExerciseImage(name) {
  if (!name) return null;
  if (!window.__yhImgCache) window.__yhImgCache = {};
  const cacheKey = String(name).toLowerCase().trim();
  if (cacheKey in window.__yhImgCache) return window.__yhImgCache[cacheKey];
  const norm = (s) =>
    String(s || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  const n = norm(name);
  const ALIASES = {
    "squat": "squat arriere",
    "squat gobelet": "goblet squat",
    "squat jump leger": "squat jump",
    "fentes": "fentes arriere",
    "fentes chargees": "fentes arriere",
    "rowing haltere": "rowing haltere unilateral",
    "tirage vertical": "tirage vertical poulie",
    "tirage vertical tractions": "tirage vertical poulie",
    "tirage horizontal": "tirage horizontal",
    "epaule": "epaule",
    "epauler": "epaule",
    "epaule jete": "epaule jete",
    "arrache": "arrache",
    "pull over": "pull over",
    "pullover": "pull over",
    "curl pupitre": "curl pupitre",
    "1 2 squat": "1 2 squat",
    "demi squat": "1 2 squat",
    "half squat": "1 2 squat",
    "dips": "dips paralleles",
    "curl biceps": "curl biceps barre",
    "curl extensions bras": "curl biceps barre",
    "mollets": "mollets debout",
    "mollets rebond": "mollets debout",
    "mollets mono jambe": "mollets debout",
    "pompes tempo": "pompes",
    "pompes plyo controlees": "pompes explosives",
    "hip thrust barre": "hip thrust",
    "hip thrust explosif": "hip thrust",
    "external rotation": "external rotation epaule",
    "planche frontale": "planche",
    "rowing elastique trx": "rowing trx elastique",
    "rowing elastique": "rowing trx elastique",
    "hang clean technique": "hang clean",
    "developpe incline": "developpe incline halteres",
    "gainage anti rotation": "pallof press",
    "mobilite hanche": "mobilite hanche 90 90",
    "burpees": "burpees controles",
    "crunch": "crunch controle",
    "shrug": "shrug halteres",
  };

  const target = ALIASES[n] || n;
  let hit = null;
  if (typeof YH_BUILTIN_EXERCISES !== "undefined" && YH_BUILTIN_EXERCISES.length) {
    hit = YH_BUILTIN_EXERCISES.find((e) => norm(e.name) === target);
    if (!hit) {
      hit = YH_BUILTIN_EXERCISES.find((e) => {
        const en = norm(e.name);
        return en && (en.includes(target) || target.includes(en));
      });
    }
  }
  const img = hit && hit.image ? hit.image : null;
  window.__yhImgCache[cacheKey] = img;
  return img;
}

const YH_GEN_POOLS = {
  upper: [
    "Développé couché",
    "Développé incliné haltères",
    "Développé militaire",
    "Rowing barre",
    "Rowing haltère unilatéral",
    "Tirage vertical poulie",
    "Tirage horizontal",
    "Tractions",
    "Dips parallèles",
    "Écarté haltères",
    "Élévations latérales",
    "Curl biceps barre",
    "Curl pupitre",
    "Extension triceps poulie",
    "Face pull",
    "Pompes",
    "Pompes explosives",
    "Shrug haltères",
    "Pull-over",
    "Épaulé",
    "Épaulé-jeté",
    "Arraché",
  ],
  lower: [
    "Squat arrière",
    "Squat avant",
    "1/2 squat",
    "Goblet squat",
    "Presse à cuisses",
    "Fentes arrière",
    "Fentes marchées",
    "Soulevé de terre",
    "Soulevé de terre roumain",
    "Hip thrust",
    "Pont fessier",
    "Leg curl",
    "Leg extension",
    "Mollets debout",
    "Squat jump",
    "Fentes sautées",
    "Épaulé",
    "Arraché",
    "Épaulé-jeté",
  ],
  core: [
    "Planche",
    "Planche latérale",
    "Dead bug",
    "Bird dog",
    "Pallof press",
    "Crunch contrôlé",
    "Mountain climbers",
    "Gainage",
  ],
};
function yhGenParamsForTheme(themeRaw) {
  const t = String(themeRaw || "force").toLowerCase();
  // series, reps, charge%, recup, rpe, color
  if (t.includes("hyper") || t.includes("volume") || t.includes("masse")) {
    return {
      series: 4,
      reps: 10,
      charge: 70,
      recup: "90s",
      rpe: 7,
      color: "#7c3aed",
      label: "Hypertrophie",
    };
  }
  if (t.includes("endur")) {
    return {
      series: 3,
      reps: 15,
      charge: 50,
      recup: "45s",
      rpe: 6,
      color: "#f59e0b",
      label: "Endurance de force",
    };
  }
  if (t.includes("puiss") || t.includes("explos") || t.includes("vitesse")) {
    return {
      series: 5,
      reps: 3,
      charge: 60,
      recup: "2-3 min",
      rpe: 8,
      color: "#ef4444",
      label: "Puissance",
    };
  }
  if (t.includes("prev") || t.includes("mobil") || t.includes("rehab")) {
    return {
      series: 3,
      reps: 12,
      charge: 30,
      recup: "45s",
      rpe: 4,
      color: "#0369a1",
      label: "Prévention",
    };
  }
  if (t.includes("gain") || t.includes("core") || t.includes("abdo")) {
    return {
      series: 3,
      reps: 1,
      charge: 0,
      recup: "30s",
      rpe: 5,
      color: "#8b5cf6",
      label: "Gainage",
    };
  }
  // force par défaut
  return {
    series: 5,
    reps: 5,
    charge: 80,
    recup: "2-3 min",
    rpe: 8,
    color: "#4f46e5",
    label: "Force",
  };
}
function yhPickExercises(pool, n) {
  const list = (pool || []).slice();
  // shuffle
  for (let i = list.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = list[i];
    list[i] = list[j];
    list[j] = tmp;
  }
  const out = [];
  for (let i = 0; i < n; i++) {
    if (list.length) out.push(list[i % list.length]);
    else break;
  }
  // unique as much as possible
  return out.slice(0, n);
}
function generateSmartProgram() {
  const free = (
    (document.getElementById("genThemeFree") && document.getElementById("genThemeFree").value) ||
    ""
  ).trim();
  const sel =
    (document.getElementById("genTheme") && document.getElementById("genTheme").value) || "force";
  const themeText = free || sel;
  const nUpper = Math.max(
    0,
    Math.min(12, parseInt(document.getElementById("genUpper")?.value, 10) || 0),
  );
  const nLower = Math.max(
    0,
    Math.min(12, parseInt(document.getElementById("genLower")?.value, 10) || 0),
  );
  if (nUpper + nLower < 1) {
    showToast("Indique au moins 1 exercice (haut ou bas)");
    return;
  }
  const params = yhGenParamsForTheme(themeText);
  let upperNames = yhPickExercises(YH_GEN_POOLS.upper, nUpper);
  let lowerNames = yhPickExercises(YH_GEN_POOLS.lower, nLower);
  // gainage theme → favor core
  if (/gain|core|abdo/i.test(themeText)) {
    upperNames = yhPickExercises(YH_GEN_POOLS.core.concat(YH_GEN_POOLS.upper), nUpper);
    lowerNames = yhPickExercises(YH_GEN_POOLS.core.concat(YH_GEN_POOLS.lower), nLower);
  }
  const makeEx = (name) => ({
    id: uid(),
    name: name,
    series: params.series,
    reps: params.reps,
    charge: params.charge,
    chargeKg: null,
    recup: params.recup,
    rpe: params.rpe,
    notes: "",
    colBorder: "#10b981",
    colSeries: "#6366f1",
    colReps: "#0d9488",
    colCharge: "#e11d48",
    colRecup: "#7c3aed",
    cardColor: "#1f2937",
    colorWhole: true,
    image: typeof findBuiltinExerciseImage === "function" ? findBuiltinExerciseImage(name) : null,
    compName: "",
    compSeries: 0,
    compReps: 0,
    compCharge: 0,
    compChargeKg: null,
    compRecup: "",
    compNotes: "",
    compImage: null,
  });
  const exercises = lowerNames.map(makeEx).concat(upperNames.map(makeEx));
  program = defaultProgram();
  program.theme = params.label + (free ? " — " + free : "");
  program.objective =
    "Séance générée · " + params.label + " · " + nLower + " bas + " + nUpper + " haut";
  program.athlete = program.athlete || "Nouvel athlète";
  program.days = [
    {
      id: uid(),
      name: (params.label || "Séance").toUpperCase(),
      color: params.color,
      open: true,
      exercises: exercises,
    },
  ];
  closeModal("templateModal");
  showEditor();
  render();
  showToast("Programme généré : " + exercises.length + " exercices");
}

function applySportTemplate(sportKey, sessionKey) {
  // Images depuis la mémoire (builtin-exercises.js) — rapide
  const sport = SPORT_TEMPLATES[sportKey];
  const t = sport && sport.sessions && sport.sessions[sessionKey];
  if (!t) return;
  program = defaultProgram();
  program.theme = t.theme || sport.label;
  program.objective = t.objective || "";
  program.athlete = program.athlete || "Nouvel athlète";
  program.days = (t.days || []).map((d) => ({
    id: uid(),
    name: d.name,
    color: d.color,
    open: true,
    exercises: (d.exercises || []).map((ex) => ({
      id: uid(),
      name: ex.name,
      series: ex.series || 0,
      reps: ex.reps || 0,
      charge: ex.charge || 0,
      chargeKg: ex.chargeKg ?? null,
      recup: ex.recup || "2",
      rpe: ex.rpe ?? null,
      notes: ex.notes || "",
      colBorder: "#10b981",
      colSeries: "#6366f1",
      colReps: "#0d9488",
      colCharge: "#e11d48",
      colRecup: "#7c3aed",
      cardColor: "#1f2937",
      colorWhole: true,
      image: ex.image || findBuiltinExerciseImage(ex.name) || null,
      compName: "",
      compSeries: 0,
      compReps: 0,
      compCharge: 0,
      compChargeKg: null,
      compRecup: "",
      compNotes: "",
      compImage: null,
    })),
  }));
  closeModal("templateModal");
  showEditor();
  render();
  showToast(sport.label + " → " + t.label);
}

function applyTemplate(key) {
  // compat anciens appels
  if (key && key.includes("|")) {
    const [s, se] = key.split("|");
    return applySportTemplate(s, se);
  }
  showToast("Choisis un sport puis une séance");
  openTemplateModal();
}
