// Ouverture directe d'un fichier Strider depuis Windows ou Android.
// Le contenu reste des données : il est seulement confié à l'import existant correspondant.
function striderExternalFileTarget(name, text) {
  if (/\.(xlsx|docx|csv)$/i.test(name)) return "importProfilesInput";
  if (!/\.json$/i.test(name)) return null;
  var d;
  try { d = JSON.parse(String(text || "").replace(/^\uFEFF/, "")); } catch (_) { return null; }
  if (!d || typeof d !== "object") return null;
  function looksProfile(p) {
    return !!p && typeof p === "object" && !Array.isArray(p) && !p.days &&
      (p.nom != null || p.prenom != null);
  }
  if (d.yhcoachproFullBackup === true || d.yhcoachproAutoBackup === true) return "fullBackupInput";
  if (d.yhcoachproAttendanceReport === true) return "asAttendanceImportInput";
  if (d.yhcoachproProfiles === true) return "importProfilesInput";
  if (Array.isArray(d)) {
    if (d.length && d.every(looksProfile)) return "importProfilesInput";
    return d.length ? "importFileInput" : null;
  }
  if (d.yhcoachproBackup === true || Array.isArray(d.programs) || (d.program && typeof d.program === "object"))
    return "importFileInput";
  if (Array.isArray(d.profiles)) return "importProfilesInput";
  if (looksProfile(d)) return "importProfilesInput";
  if (d.days || d.athlete != null) return "importFileInput";
  return null;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { striderExternalFileTarget: striderExternalFileTarget };
}

(function () {
  if (typeof window === "undefined") return;
  var A = window.StriderInbox;
  var D = window.yhDisk && typeof window.yhDisk.externalFilePending === "function" ? window.yhDisk : null;
  if (!A && !D) return;
  var B = A || {
    pending: function () { return D.externalFilePending(); },
    read: function (offset, length) { return D.externalFileRead(offset, length); },
    done: function () { D.externalFileDone(); },
    waiting: function () {}
  };
  var busy = false;
  var started = Date.now();

  function licenceOk() {
    try { return !!(window.YHLicense && window.YHLicense.isActive()); } catch (_) { return false; }
  }

  function readAll(size) {
    var CH = 768 * 1024, parts = [];
    for (var off = 0; off < size; off += CH) {
      var b64 = B.read(off, CH);
      if (b64 === null || b64 === undefined) throw new Error("read");
      var bin = atob(b64), arr = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      parts.push(arr);
    }
    return parts;
  }

  function concat(parts) {
    var n = 0, i;
    for (i = 0; i < parts.length; i++) n += parts[i].length;
    var out = new Uint8Array(n), pos = 0;
    for (i = 0; i < parts.length; i++) { out.set(parts[i], pos); pos += parts[i].length; }
    return out;
  }

  function mimeOf(name) {
    if (/\.json$/i.test(name)) return "application/json";
    if (/\.csv$/i.test(name)) return "text/csv";
    if (/\.xlsx$/i.test(name)) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    if (/\.docx$/i.test(name)) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    return "application/octet-stream";
  }

  function translated(key, name) {
    var lang = "fr", saved = "";
    try { saved = localStorage.getItem("strider_lang") || ""; } catch (_) {}
    if (!saved && D) { try { saved = D.read("strider_lang") || ""; } catch (_) {} }
    try { lang = String(saved || "fr").replace(/["']/g, "").slice(0, 2); } catch (_) {}
    var messages = {
      open: {
        fr: 'Ouvrir "' + name + '" dans Strider ?',
        en: 'Open "' + name + '" in Strider?',
        ar: 'هل تريد فتح "' + name + '" في Strider؟'
      },
      notStrider: {
        fr: "Ce fichier JSON n'est pas un programme, des profils, une assiduité ou une sauvegarde Strider. Rien n'a été modifié.",
        en: "This JSON file is not a Strider program, profiles, attendance or backup file. Nothing was changed.",
        ar: "هذا الملف ليس برنامجاً أو ملفات رياضيين أو حضوراً أو نسخة احتياطية من Strider. لم يتم تغيير أي شيء."
      },
      readFail: {
        fr: "Lecture du fichier impossible. Rien n'a été modifié.",
        en: "Could not read the file. Nothing was changed.",
        ar: "تعذّرت قراءة الملف. لم يتم تغيير أي شيء."
      }
    };
    return (messages[key] && (messages[key][lang] || messages[key].fr)) || "";
  }

  function check() {
    if (busy) return;
    var info = "";
    try { info = B.pending(); } catch (_) { return; }
    if (!info) return;
    if (document.readyState !== "complete" || Date.now() - started < 1500) return;
    if (!licenceOk()) { try { B.waiting(); } catch (_) {} return; }
    busy = true;
    try {
      var meta = JSON.parse(info);
      if (!A && !window.confirm(translated("open", meta.name))) { B.done("cancel"); return; }
      var parts = readAll(meta.size);
      var id = striderExternalFileTarget(meta.name, /\.json$/i.test(meta.name) ? new TextDecoder("utf-8").decode(concat(parts)) : "");
      var input = id && document.getElementById(id);
      if (!input) {
        B.done(A && /\.(xlsx|docx|csv)$/i.test(meta.name) ? "manual" : "unknown");
        if (!A) window.alert(translated("notStrider", meta.name));
        return;
      }
      var file = new File(parts, meta.name, { type: mimeOf(meta.name) });
      try { if (typeof closeHomeMenus === "function") closeHomeMenus(); } catch (_) {}
      var dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      B.done("ok");
    } catch (e) {
      console.error(e);
      try { B.done("fail"); } catch (_) {}
      if (!A) window.alert(translated("readFail", ""));
    } finally {
      busy = false;
    }
  }

  setInterval(check, 1000);
})();
