/** Rendu éditeur de programme (header, jours, exercices) */
// ========== RENDER ==========
function render() {
  // Ensure headerColors exists (for old saved data)
  if (!program.headerColors) {
    program.headerColors = {
      cardBg: "#000000",
      name: "#ffffff",
      theme: "#6366f1",
      themeText: "#ffffff",
      date: "#374151",
      dateBg: "#e5e7eb",
      charge: "#ffffff",
      chargeBg: "#6366f1",
      border: "#e5e7eb",
      session: "#ffffff",
      sessionBg: "#1f2937",
    };
  }
  const hc = program.headerColors;

  // Page background
  const pageBg = program.pageBg || "#f4f6f9";
  /* ne pas écraser le fond global avec pageBg */
  /* pageBg appliqué au contenu, pas au body (fond global conservé) */
  if (document.documentElement)
    document.documentElement.style.setProperty("--page-bg-user", pageBg);

  // Apply header colors
  const athleteCard = document.querySelector(".athlete-card");
  if (athleteCard) {
    athleteCard.style.background = hc.cardBg || "#000000";
    athleteCard.style.border = `2px solid ${hc.border || "#e5e7eb"}`;
  }

  const nameEl = document.getElementById("athleteName");
  nameEl.textContent = program.athlete || "Nouvel athlète";
  nameEl.style.color = hc.name || "#ffffff";
  nameEl.style.fontFamily = program.titleFont || "'Segoe UI', system-ui, sans-serif";
  nameEl.style.fontSize = (program.titleSize || 24) + "px";

  // Poste
  const posteBadge = document.getElementById("posteBadge");
  if (posteBadge) {
    if (program.poste) {
      posteBadge.style.display = "";
      posteBadge.textContent = program.poste;
    } else {
      posteBadge.style.display = "none";
    }
  }

  const themeBadge = document.getElementById("themeBadge");
  themeBadge.textContent = program.theme || "—";
  themeBadge.style.background = hc.theme || program.themeColor || "#6366f1";
  themeBadge.style.color = hc.themeText || "#ffffff";
  program.themeColor = hc.theme || program.themeColor;

  const dateBadge = document.querySelector(".badge-date");
  if (dateBadge) {
    dateBadge.style.background = hc.dateBg || "#e5e7eb";
    dateBadge.style.color = hc.date || "#374151";
  }
  (function () {
    const el = document.getElementById("progDate");
    if (!el) return;
    const iso = program.date || "";
    if (!iso) {
      el.textContent = "—";
      return;
    }
    const d = new Date(iso + "T12:00:00");
    if (Number.isNaN(d.getTime())) {
      el.textContent = iso;
      return;
    }
    const jours = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
    const jour = jours[d.getDay()];
    const fr = d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
    el.textContent = jour + " " + fr;
  })();
  if (typeof applyReadOnlyUI === "function") applyReadOnlyUI();
  if (typeof updateSessionDoneBadge === "function") updateSessionDoneBadge();
  const rpeIn = document.getElementById("sessionRpeInput");
  if (rpeIn) rpeIn.value = program.sessionRpe != null ? program.sessionRpe : "";
  if (typeof updateSessionStatsBar === "function") updateSessionStatsBar();

  const sessionBadge = document.getElementById("sessionBadge");
  if (sessionBadge) {
    sessionBadge.style.display = "";
    const num = program.sessionNum || 1;
    let label = "Séance n°" + num;
    if (program.date) {
      const d = new Date(program.date + "T12:00:00");
      if (!Number.isNaN(d.getTime())) {
        const jours = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
        const fr = d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
        label = "Séance n°" + num + " · " + jours[d.getDay()] + " " + fr;
      }
    }
    sessionBadge.textContent = label;
    sessionBadge.style.background = hc.sessionBg || "#1f2937";
    sessionBadge.style.color = hc.session || "#ffffff";
  }

  // Athlete photo (logo app par défaut)
  const photoWrap = document.getElementById("athletePhotoWrap");
  if (photoWrap) {
    if (program.athletePhoto) {
      photoWrap.innerHTML = `<img loading="lazy" decoding="async" class="athlete-photo" src="${program.athletePhoto}" alt="Photo athlète" style="background:transparent;border:none;" />`;
    } else {
      const logo = getAppPlaceholderDataUrl();
      photoWrap.innerHTML = logo
        ? `<img loading="lazy" decoding="async" class="athlete-photo" src="${logo}" alt="Strider Pro" style="background:#000;border:none;object-fit:cover;" />`
        : `<div class="athlete-photo-placeholder"><i class="fas fa-user"></i></div>`;
    }
  }

  // Club logo (logo app par défaut)
  const logoWrap = document.getElementById("clubLogoWrap");
  if (logoWrap) {
    if (program.clubLogo) {
      logoWrap.innerHTML = `<img loading="lazy" decoding="async" class="club-logo" src="${program.clubLogo}" alt="Logo club" style="background:transparent;border:none;" />`;
    } else {
      const logo = getAppPlaceholderDataUrl();
      logoWrap.innerHTML = logo
        ? `<img loading="lazy" decoding="async" class="club-logo" src="${logo}" alt="Strider Pro" style="background:#000;border:none;object-fit:cover;" />`
        : `<div class="club-logo-placeholder"><i class="fas fa-shield-alt"></i></div>`;
    }
  }

  // Charge % : manual if set, otherwise auto-average (principal + complémentaire)
  let total = 0,
    count = 0;
  program.days.forEach((d) =>
    d.exercises.forEach((e) => {
      if (e.charge > 0) {
        total += e.charge;
        count++;
      }
      if (e.compName && e.compCharge > 0) {
        total += e.compCharge;
        count++;
      }
    }),
  );
  const autoAvg = count ? Math.round(total / count) : 0;
  const displayCharge =
    program.chargePct !== null && program.chargePct !== undefined && program.chargePct !== ""
      ? program.chargePct
      : autoAvg;
  const chargeEl = document.getElementById("avgCharge");
  chargeEl.textContent = `% Charge : ${displayCharge}%`;
  chargeEl.style.background = hc.chargeBg || "#6366f1";
  chargeEl.style.color = hc.charge || "#ffffff";

  const objEl = document.getElementById("sessionObjective");
  if (objEl) {
    if (program.objective && String(program.objective).trim()) {
      objEl.style.display = "";
      objEl.innerHTML =
        "<strong>Objectif :</strong> " + escapeHtml(String(program.objective).trim());
    } else {
      objEl.style.display = "none";
      objEl.innerHTML = "";
    }
  }

  const container = document.getElementById("daysContainer");
  container.innerHTML = "";

  if (program.days.length === 0) {
    container.innerHTML = `
          <div class="empty-state">
            <i class="fas fa-calendar-plus"></i>
            <p>Aucun jour ajouté.<br>Clique sur « Ajouter un jour » pour commencer.</p>
          </div>`;
    return;
  }

  program.days.forEach((day) => {
    const isOpen = day.open !== false;
    const section = document.createElement("div");
    section.className = "day-section" + (isOpen ? " open" : "");
    section.innerHTML = `
          <div class="day-header" style="background:${day.color || "#4f46e5"}" onclick="toggleDay('${day.id}')">
            <div class="left">
              <i class="fas fa-chevron-down chevron"></i>
              <span>${escapeHtml(day.name)}</span>
              ${day.done ? `<span class="done-badge" style="margin-left:8px"><i class="fas fa-check"></i> Fait${day.doneAt ? " · " + day.doneAt : ""}</span>` : ""}
            </div>

            <div class="day-actions" onclick="event.stopPropagation()">
              <button aria-label="Dupliquer" title="Dupliquer" onclick="duplicateDay('${day.id}')"><i class="fas fa-copy" aria-hidden="true"></i></button>
              <button aria-label="Modifier" title="Modifier" onclick="editDay('${day.id}')"><i class="fas fa-pen" aria-hidden="true"></i></button>
              <button aria-label="Supprimer" title="Supprimer" onclick="deleteDay('${day.id}')"><i class="fas fa-trash" aria-hidden="true"></i></button>
            </div>
          </div>
          <div class="day-body">
            ${day.exercises.map((ex) => renderExercise(ex, day.id)).join("")}
            <button class="add-exercise-btn" onclick="openExerciseModal('${day.id}')">
              <i class="fas fa-plus"></i> Ajouter un exercice
            </button>
          </div>
        `;
    container.appendChild(section);
  });
  setTimeout(kickExerciseVideos, 80);
  setTimeout(kickExerciseVideos, 500);
}

function isVideoMedia(src) {
  if (!src || typeof src !== "string") return false;
  if (src.startsWith("data:video") || src.startsWith("blob:")) return true;
  if (/\.(mp4|webm|mov|m4v|ogg)(\?|$)/i.test(src)) return true;
  if (src.startsWith("yhmedia:") || src.startsWith("yhmedia://")) {
    if (/\.(mp4|webm|mov|m4v|ogg)(\?|$)/i.test(src)) return true;
    // default: treat unknown yhmedia without image ext as possible video
    if (/\.(png|jpe?g|gif|webp|svg)(\?|$)/i.test(src)) return false;
    return true; // prefer video tag; browser will fail soft if image
  }
  if (src.startsWith("file:") && /\.(mp4|webm|mov|m4v)(\?|$)/i.test(src)) return true;
  return false;
}

// Convert data: URL → Blob URL (beaucoup plus fiable pour <video>)
const blobUrlCache = new Map();
function toPlayableUrl(dataUrl) {
  if (!dataUrl) return null;
  if (isYhMediaRef(dataUrl)) {
    return resolveMediaSrc(dataUrl) || null;
  }
  if (dataUrl.startsWith("blob:") || dataUrl.startsWith("file:")) return dataUrl;
  if (!dataUrl.startsWith("data:")) return dataUrl;
  if (blobUrlCache.has(dataUrl)) return blobUrlCache.get(dataUrl);
  try {
    const [header, base64] = dataUrl.split(",");
    const mime = (header.match(/data:([^;]+)/) || [])[1] || "video/mp4";
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const blob = new Blob([bytes], { type: mime });
    const url = URL.createObjectURL(blob);
    blobUrlCache.set(dataUrl, url);
    return url;
  } catch (e) {
    console.warn("toPlayableUrl failed", e);
    return dataUrl;
  }
}

function mediaBlock(src, exId, dayId, which) {
  if (src && isVideoMedia(src)) {
    const playUrl = toPlayableUrl(src) || "";
    const safeUrl = String(playUrl).replace(/"/g, "&quot;");
    return `
          <div class="ex-media-video-wrap" onclick="playExerciseVideo('${exId}', '${dayId}', '${which}'); event.stopPropagation();" title="Agrandir la vidéo">
            <video class="ex-img" src="${safeUrl}" autoplay muted loop playsinline preload="auto"></video>
          </div>`;
  }
  if (src) {
    const imgSrc = resolveMediaSrc(src) || src;
    const safeImg = String(imgSrc).replace(/"/g, "&quot;");
    return `<img loading="lazy" decoding="async" class="ex-img" src="${safeImg}" alt="" style="object-fit:cover;width:120px;height:120px;" />`;
  }
  return `<div class="ex-img-placeholder"><i class="fas fa-dumbbell"></i></div>`;
}

function kickExerciseVideos() {
  try {
    document.querySelectorAll("video.ex-img").forEach((v) => {
      v.muted = true;
      v.defaultMuted = true;
      v.playsInline = true;
      v.setAttribute("playsinline", "");
      v.setAttribute("muted", "");
      const p = v.play();
      if (p && p.catch) p.catch(() => {});
    });
  } catch (e) {}
}

function renderExercise(ex, dayId) {
  const bg = ex.colorWhole ? ex.cardColor || "#1f2937" : "#1f2937";
  const hasComp = !!(ex.compName && ex.compName.trim());
  const mainMedia = mediaBlock(ex.image, ex.id, dayId, "main");
  const compMedia = mediaBlock(ex.compImage, ex.id, dayId, "comp");
  const compHalf = hasComp
    ? `
          <div class="ex-divider"></div>
          <div class="ex-half ex-comp">
            ${compMedia}
            <div class="ex-info">
              <div class="ex-label">Complémentaire</div>
              <div class="ex-name">${escapeHtml(ex.compName)}</div>
              <div class="ex-badges">
                <span class="ex-badge" style="background:${ex.compColSeries || "#6366f1"}">Séries ${ex.compSeries ?? 0}</span>
                <span class="ex-badge" style="background:${ex.compColReps || "#0d9488"}">Reps ${ex.compReps ?? 0}</span>
                <span class="ex-badge" style="background:${ex.compColCharge || "#e11d48"}">Charge ${ex.compCharge ?? 0}%</span>
                ${ex.compChargeKg !== null && ex.compChargeKg !== undefined && ex.compChargeKg !== "" ? `<span class="ex-badge" style="background:#f59e0b">${ex.compChargeKg} kg</span>` : ""}
                <span class="ex-badge" style="background:${ex.compColRecup || "#7c3aed"}">Récup ${ex.compRecup ?? "0"}</span>
                ${ex.compRpe !== null && ex.compRpe !== undefined && ex.compRpe !== "" ? `<span class="ex-badge" style="background:#64748b">RPE ${ex.compRpe}</span>` : ""}
              </div>
              ${ex.compNotes && String(ex.compNotes).trim() ? `<div class="ex-note"><i class="fas fa-sticky-note"></i> ${escapeHtml(String(ex.compNotes).trim())}</div>` : ""}
            </div>
          </div>`
    : "";
  return `
        <div class="exercise-card" style="background:${bg}; border-left: 5px solid ${ex.colBorder || "#10b981"}">
          <div class="ex-half ex-main">
            ${mainMedia}
            <div class="ex-info">
              <div class="ex-label">Principal</div>
              <div class="ex-name">${escapeHtml(ex.name)}</div>
              <div class="ex-badges">
                <span class="ex-badge" style="background:${ex.colSeries || "#6366f1"}">Séries ${ex.series}</span>
                <span class="ex-badge" style="background:${ex.colReps || "#0d9488"}">Reps ${ex.reps}</span>
                <span class="ex-badge" style="background:${ex.colCharge || "#e11d48"}">Charge ${ex.charge}%</span>
                ${ex.chargeKg !== null && ex.chargeKg !== undefined && ex.chargeKg !== "" ? `<span class="ex-badge" style="background:#f59e0b">${ex.chargeKg} kg</span>` : ""}
                <span class="ex-badge" style="background:${ex.colRecup || "#7c3aed"}">Récup ${ex.recup}</span>
                ${ex.rpe !== null && ex.rpe !== undefined && ex.rpe !== "" ? `<span class="ex-badge" style="background:#64748b">RPE ${ex.rpe}</span>` : ""}
              </div>
              ${ex.notes && String(ex.notes).trim() ? `<div class="ex-note"><i class="fas fa-sticky-note"></i> ${escapeHtml(String(ex.notes).trim())}</div>` : ""}
            </div>
          </div>
          ${compHalf}
          <div class="ex-actions">
            <button title="Monter" onclick="moveExercise('${dayId}', '${ex.id}', -1)"><i class="fas fa-arrow-up"></i></button>
            <button title="Descendre" onclick="moveExercise('${dayId}', '${ex.id}', 1)"><i class="fas fa-arrow-down"></i></button>
            <button title="Minuteur récup" onclick="startRestTimerFromEx('${dayId}', '${ex.id}')"><i class="fas fa-clock"></i></button>
            <button title="Ajouter à la biblio" onclick="addExerciseToLibrary('${dayId}', '${ex.id}')"><i class="fas fa-book"></i></button>
            <button aria-label="Dupliquer" title="Dupliquer" onclick="duplicateExercise('${dayId}', '${ex.id}')"><i class="fas fa-copy" aria-hidden="true"></i></button>
            <button aria-label="Modifier" title="Modifier" onclick="openExerciseModal('${dayId}', '${ex.id}')"><i class="fas fa-pen" aria-hidden="true"></i></button>
            <button aria-label="Supprimer" title="Supprimer" onclick="deleteExercise('${dayId}', '${ex.id}')"><i class="fas fa-trash" aria-hidden="true"></i></button>
          </div>
        </div>
      `;
}

function playExerciseVideo(exId, dayId, which) {
  const day = program.days.find((d) => d.id === dayId);
  const ex = day?.exercises.find((e) => e.id === exId);
  if (!ex) return;
  const src = which === "comp" ? ex.compImage : ex.image;
  const title = which === "comp" ? ex.compName || "Complémentaire" : ex.name;
  if (!src || !isVideoMedia(src)) return;
  const url = toPlayableUrl(src) || resolveMediaSrc(src);
  if (!url) {
    showToast("Vidéo introuvable sur le disque");
    return;
  }
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay show";
  overlay.style.zIndex = "2000";
  overlay.innerHTML = `
        <div class="modal" style="max-width:640px;background:#0f172a;padding:0;overflow:hidden">
          <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;color:#fff">
            <strong style="font-size:1rem">${escapeHtml(title)}</strong>
            <button class="modal-close" style="color:#fff" onclick="this.closest('.modal-overlay').remove()">&times;</button>
          </div>
          <video src="${url}" controls autoplay playsinline style="width:100%;max-height:70vh;display:block;background:#000"></video>
        </div>`;
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) overlay.remove();
  });
  document.body.appendChild(overlay);
}
