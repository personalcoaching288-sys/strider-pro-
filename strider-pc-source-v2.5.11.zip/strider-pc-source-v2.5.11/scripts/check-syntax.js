"use strict";
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");
const root = path.resolve(__dirname, "..");
const files = ["main.js", "preload.js", "builtin-exercises.js"];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.isFile() && entry.name.endsWith(".js")) files.push(path.relative(root, full));
  }
}
walk(path.join(root, "scripts"));
const unique = [...new Set(files)].sort();
let failed = 0;
for (const file of unique) {
  const run = spawnSync(process.execPath, ["--check", path.join(root, file)], { encoding: "utf8" });
  if (run.status !== 0) {
    failed++;
    console.error("\n✗ " + file + "\n" + (run.stderr || run.stdout));
  } else console.log("✓ " + file);
}
console.log(`\n${unique.length} fichiers JavaScript vérifiés.`);
if (failed) {
  console.error(`${failed} fichier(s) en erreur.`);
  process.exit(1);
}
console.log("Aucune erreur de syntaxe.");
