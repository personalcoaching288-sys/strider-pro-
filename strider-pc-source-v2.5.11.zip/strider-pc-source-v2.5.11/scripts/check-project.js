"use strict";
// Vérifications locales, sans accès réseau et sans lecture des données utilisateur.
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
let checked = 0;
const failures = [];
function verifyResource(reference, owner) {
  if (/^(?:data:|https?:|\/\/|#)/i.test(reference)) return;
  const target = path.resolve(path.dirname(owner), reference.split(/[?#]/)[0]);
  checked++;
  if (!fs.existsSync(target)) failures.push(path.relative(root, owner) + " → " + reference);
}
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
for (const match of html.matchAll(/<(?:script|link)\b[^>]*(?:src|href)=["']([^"']+)["']/g)) {
  verifyResource(match[1], path.join(root, "index.html"));
}
function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(file);
    else if (file.endsWith(".css")) {
      const text = fs.readFileSync(file, "utf8");
      for (const match of text.matchAll(/url\(\s*["']?([^\)"']+)/g)) {
        verifyResource(match[1].trim(), file);
      }
    }
  }
}
walk(path.join(root, "styles"));
walk(path.join(root, "assets", "vendor"));
const manifest = JSON.parse(fs.readFileSync(path.join(root, "manifest.webmanifest"), "utf8"));
for (const icon of manifest.icons || []) verifyResource(icon.src, path.join(root, "manifest.webmanifest"));
const scripts = [...html.matchAll(/<script\b[^>]*src=["']([^"']+)["']/g)].map(m => m[1]);
const sharedIndex = scripts.indexOf("./scripts/shared/embedded-images.js");
if (sharedIndex < 0 || sharedIndex >= scripts.findIndex(s => s.includes("modules/"))) failures.push("Images embarquées : ordre de chargement incorrect");
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
if (pkg.name !== "yhcoachpro" || pkg.build.appId !== "com.yassinehakmi.yhcoachpro") failures.push("Identifiants de compatibilité modifiés");
const images = require("./shared/embedded-images.js");
if (!Object.isFrozen(images) || !Object.values(images).every(v => v.startsWith("data:image/"))) failures.push("Banque d’images invalide");
if (failures.length) {
  console.error(failures.join("\n"));
  process.exit(1);
}
console.log(`${checked} références locales vérifiées; ordre de chargement, images et compatibilité préservés.`);
