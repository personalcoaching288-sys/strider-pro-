# Version 2.4.4 — Barre supérieure translucide

La barre supérieure du tableau de bord reprend le fond sombre translucide et le flou léger (7 px) de la carte Activité de la semaine. Fine bordure dorée. Aucun bouton déplacé, aucune modification du stockage, des programmes ou des sauvegardes. Corrections portrait et icônes de la 2.4.3 conservées.

Archive du projet, pas un installateur Windows compilé. Faire une sauvegarde avant mise à jour ; conserver l’ancienne version.
