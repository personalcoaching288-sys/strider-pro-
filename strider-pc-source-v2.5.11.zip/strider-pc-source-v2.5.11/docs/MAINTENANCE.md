# YhCoachPro — Maniabilité du code (v2.3.20)

## Objectif
Rendre le code plus simple à modifier sans tout casser.

## Changements déjà faits (2.3.20)
1. **`scripts/modules/store.js`** — stockage unique (SSD / localStorage) + liste des clés
2. **Modules renommés** (plus de suffixes v230 / v233 / v235 / v2315) :
   - `planning.js`
   - `modern-programs.js`
   - `charges.js`
   - `dashboard.js`
3. **`index.html`** charge `store.js` en premier parmi les modules

## Où modifier quoi

| Besoin | Fichier |
|--------|---------|
| Structure écrans / HTML | `index.html` |
| Styles | `styles/app.css` (+ css dashboard si besoin) |
| Cœur navigation, timer, UI générale | `scripts/app.js` |
| Stockage (clés, get/set) | `scripts/modules/store.js` |
| Fiches athlètes | `scripts/modules/profiles.js` |
| Programmes (base) | `scripts/modules/programs.js` |
| Programmes modernes | `scripts/modules/modern-programs.js` |
| Assiduité | `scripts/modules/attendance.js` |
| Licences | `scripts/modules/licenses.js` |
| Planning annuel | `scripts/modules/planning.js` |
| Charges | `scripts/modules/charges.js` |
| Tableau de bord | `scripts/modules/dashboard.js` |
| Fiche de séance | `scripts/modules/session-sheet.js` |
| Export PDF / image | `scripts/modules/exports.js` |
| Electron fenêtre / disque | `main.js`, `preload.js` |

## Ordre de chargement des scripts
1. builtin-exercises.js
2. store.js
3. programs → profiles → attendance → exports → sharing → backup-sharing → licenses
4. app.js
5. planning → modern-programs → charges → session-sheet → dashboard

## Prochaines étapes recommandées
1. Découper `app.js` par domaines (home, editor, timer, dashboard glue)
2. Variables CSS communes (couleurs, radii) en tête de `app.css`
3. Un seul script de build documenté
4. Tests manuels checklist avant chaque EXE

## Avant chaque build
```bat
npm run check
npm start
```
Puis tester : créer 2 athlètes, 1 programme, assiduité, export.


## Changements 2.3.21 — découpage de app.js
Fichiers extraits (même comportement, fonctions globales inchangées) :
- `scripts/modules/optional-assets.js` — html2canvas / jspdf à la demande
- `scripts/modules/sport-templates.js` — templates par sport
- `scripts/modules/load-history.js` — historique des kg
- `scripts/modules/theme-dark.js` — thème sombre

`scripts/app.js` ne garde que le cœur (data, nav, render, days, exercises, program, import/export, init).

Prochaine étape possible : extraire navigation + render dans des modules dédiés.


## 2.3.22 — navigation, render, bootstrap
- `scripts/modules/navigation.js` — showHome, showEditor, carousel, dashboard links
- `scripts/modules/render-core.js` — function render() éditeur
- `scripts/modules/bootstrap.js` — load() + showHome() au démarrage (**dernier script**)
- `scripts/app.js` allégé encore (data, features, days, exercises, program, import)


## 2.3.23 — days / exercises / program
- `program-days.js` — gestion des jours
- `program-exercises.js` — exercices d'un jour
- `program-core.js` — sauvegarde / index / ouverture programme


## 2.3.24 — features, autosave, library, UI, file-io, reminders
- features-ui.js
- autosave-tools.js
- exercise-library.js
- ui-helpers.js
- file-io.js
- reminders.js
app.js ≈ data + stockage + load/uid uniquement.
