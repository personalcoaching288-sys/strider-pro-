# Version 2.4.8 — Ouverture complète des fiches

Problème reproduit dans la 2.4.7 : sélectionner une fiche dans Mes fiches modifiait seulement le choix affiché dans la liste, sans charger la séance ; il fallait encore cliquer Ouvrir. Désormais, sélectionner la fiche charge tous ses champs, ses parties et leurs schémas. Le bouton Ouvrir reste disponible.

Enregistrer relit explicitement les champs et consignes de la fiche avant de sauvegarder tout le modèle. Une relecture du stockage vérifie le résultat avant d’annoncer le succès. Une fiche enregistrée dépourvue de parties est signalée comme incomplète, sans générer des schémas par défaut et sans l’écraser. Les anciennes fiches complètes restent compatibles. Le nom du club, le pied épuré et l’enregistrement à la fermeture sont conservés.

Important : cette correction ne peut pas reconstituer des informations qui n’auraient jamais été enregistrées. Conserver l’ancienne version et exporter une sauvegarde complète avant mise à jour. Ne supprimer aucune fiche en cas de doute.

Tests : deux fiches distinctes avec textes, clubs, durées, joueurs et schémas différents ; alternance par la liste sans bouton Ouvrir ; réouverture après rechargement ; saisies relues même sans événement de saisie ; copie indépendante ; fermeture et récupération des dernières modifications. Tests navigateur et stockage simulé, pas une installation Windows.

Archive du projet avec les scripts de lancement/construction Windows, pas un installateur déjà compilé.
