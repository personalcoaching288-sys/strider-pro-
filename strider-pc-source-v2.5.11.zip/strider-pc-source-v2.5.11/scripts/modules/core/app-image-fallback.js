/* Visual fixes only: never replace stored media data. Existing sizes remain unchanged. */
(function () {
  "use strict";
  const fallback = YHEmbeddedAssets["striderDefaultPhoto"],
    brandFallback = YHEmbeddedAssets["2940a12e33b47f20"],
    brandScope = ".logo-icon,.v233-coach-logo img",
    legacy = new Set([
      YHEmbeddedAssets["a2f0dd07a5e1de3e"],
      YHEmbeddedAssets["80de3f70dbd7d3ae"],
      YHEmbeddedAssets["ae7d1949a6ac804e"],
      YHEmbeddedAssets["4e4f1049ec868722"],
    ]);
  window.getAppPlaceholderDataUrl = () => fallback;
  // Same default photo as a short in-memory address, for lists that repeat it
  // on every card (copying the full image into each card made pages slow).
  let fallbackDisplayUrl = fallback;
  try {
    const m = /^data:([^;,]+);base64,(.*)$/.exec(fallback || "");
    if (m && window.URL && URL.createObjectURL) {
      const bin = atob(m[2]);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      fallbackDisplayUrl = URL.createObjectURL(new Blob([bytes], { type: m[1] }));
    }
  } catch (e) {
    fallbackDisplayUrl = fallback;
  }
  window.getAppPlaceholderDisplayUrl = () => fallbackDisplayUrl;
  const scope =
    ".logo-icon,.v233-coach-logo img,.v233-avatar img,#athleteImgPreview img,#clubLogoPreview img,img.athlete-photo,img.club-logo,#profilePhotoBox img,#profileClubLogoBox img,#asGroupLogoBox img";
  function replace(img) {
    const expected = img.matches(brandScope) ? brandFallback : fallback;
    const cur = img.getAttribute("src");
    if (img.dataset.striderFallback === "1" && (cur === expected || (expected === fallback && cur === fallbackDisplayUrl))) return;
    img.dataset.striderFallback = "1";
    img.classList.add("strider-image-default");
    img.alt = "Logo Strider Pro par défaut";
    img.src = expected;
  }
  function prepare(img) {
    const expected = img.matches(brandScope) ? brandFallback : fallback;
    if (!img.matches(scope)) return;
    const src = img.getAttribute("src") || "";
    if (
      !src ||
      legacy.has(src) ||
      src === getAppLogoDataUrl() ||
      /^(?:\.\/)?styles\/dashboard-logo(?:-transparent)?\.png$/.test(src)
    )
      replace(img);
    else if (img.complete && !img.naturalWidth) replace(img);
    else if (src === expected || (expected === fallback && src === fallbackDisplayUrl)) {
      img.classList.add("strider-image-default");
      img.dataset.striderFallback = "1";
    }
  }
  function scan(node) {
    if (node.nodeType !== 1) return;
    if (node.tagName === "IMG") prepare(node);
    node.querySelectorAll?.(scope).forEach(prepare);
  }
  document.addEventListener(
    "error",
    (event) => {
      const img = event.target;
      if (img?.tagName !== "IMG" || !img.matches(scope)) return;
      if (img.getAttribute("src") === (img.matches(brandScope) ? brandFallback : fallback)) {
        img.dataset.striderFallbackFailed = "1";
        return;
      }
      replace(img);
    },
    true,
  );
  // Newly rendered program/profile cards and image replacements, without a full-page rescan.
  const observer = new MutationObserver((records) => {
    for (const record of records) {
      if (record.type === "attributes") prepare(record.target);
      else record.addedNodes.forEach(scan);
    }
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["src"],
  });
  document.querySelectorAll(scope).forEach(prepare);
  window.StriderImageFallback = { scan, legacyCount: legacy.size };
})();
