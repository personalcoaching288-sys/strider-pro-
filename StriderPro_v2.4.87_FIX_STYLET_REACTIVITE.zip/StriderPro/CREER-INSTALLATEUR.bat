@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js doit etre installe.& pause & exit /b 1)
call npm install || goto :erreur
call npm run check || goto :erreur
call npm run dist || goto :erreur
echo.
echo Installateur cree dans le dossier dist.
pause
exit /b 0
:erreur
echo.
echo La creation a echoue. Consultez le message ci-dessus.
pause
exit /b 1
