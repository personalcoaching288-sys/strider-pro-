// ========== APP.JS (cœur) — data, storage, init helpers ==========

// ========== APP.JS (cœur) — days/exercises/program en modules ==========

// ========== APP.JS (cœur) — nav/render/bootstrap extraits en modules ==========

// ========== APP.JS (cœur) — modules extraits: optional-assets, sport-templates, load-history, theme-dark ==========

// ========== DATA ==========
function defaultProgram() {
  return {
    id: null,
    athlete: "Nouvel athlète",
    athletePhoto: null,
    clubLogo: null,
    poste: "",
    theme: "force",
    objective: "",
    themeColor: "#6366f1",
    sessionNum: 1,
    date: new Date().toISOString().slice(0, 10),
    chargePct: null,
    titleFont: "'Segoe UI', system-ui, sans-serif",
    titleSize: 24,
    pageBg: "#f4f6f9",
    headerColors: {
      cardBg: "#000000",
      name: "#ffffff",
      theme: "#6366f1",
      themeText: "#ffffff",
      date: "#374151",
      dateBg: "#e5e7eb",
      charge: "#ffffff",
      chargeBg: "#6366f1",
      border: "#e5e7eb",
      session: "#ffffff",
      sessionBg: "#1f2937",
    },
    days: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

let program = defaultProgram();
let programsIndex = []; // { id, athlete, date, updatedAt, poste, theme, hasPhoto }

let currentDayId = null;
let currentExId = null;
let editingDayId = null;
let exImageData = null;
let exCompImageData = null;
let athleteImageData = null;
let clubLogoData = null;

/** Compresse une image (max side px, qualité JPEG) — optimisé stockage */
function compressImageFile(file, maxSide, quality, preserveAlpha) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type || !file.type.startsWith("image/")) {
      resolve(null);
      return;
    }
    maxSide = maxSide || 320;
    quality = quality != null ? quality : 0.55;
    const keepAlpha = !!preserveAlpha;

    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let w = img.width,
        h = img.height;
      if (w > maxSide || h > maxSide) {
        if (w >= h) {
          h = Math.round((h * maxSide) / w);
          w = maxSide;
        } else {
          w = Math.round((w * maxSide) / h);
          h = maxSide;
        }
      }
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d", { alpha: !!keepAlpha });
      if (keepAlpha) {
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        // PNG seulement si petit, sinon JPEG (beaucoup plus léger)
        let png = canvas.toDataURL("image/png");
        if (png.length > 180000) {
          // fond transparent perdu mais stockage prioritaire
          resolve(canvas.toDataURL("image/jpeg", quality));
        } else {
          resolve(png);
        }
      } else {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", quality));
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("image load failed"));
    };
    img.src = url;
  });
}

/** Réduit une dataURL image déjà stockée */
function recompressDataUrl(dataUrl, maxSide, quality) {
  return new Promise((resolve) => {
    if (!dataUrl || typeof dataUrl !== "string" || !dataUrl.startsWith("data:image")) {
      resolve(dataUrl);
      return;
    }
    // vidéos : supprimer pour alléger
    if (dataUrl.startsWith("data:video")) {
      resolve(null);
      return;
    }
    // déjà petite
    if (dataUrl.length < 40000) {
      resolve(dataUrl);
      return;
    }
    const img = new Image();
    img.onload = () => {
      let w = img.width,
        h = img.height;
      maxSide = maxSide || 280;
      quality = quality != null ? quality : 0.5;
      if (w > maxSide || h > maxSide) {
        if (w >= h) {
          h = Math.round((h * maxSide) / w);
          w = maxSide;
        } else {
          w = Math.round((w * maxSide) / h);
          h = maxSide;
        }
      }
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#111";
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL("image/jpeg", quality));
    };
    img.onerror = () => resolve(null);
    img.src = dataUrl;
  });
}

async function lightenProgram(prog, aggressive) {
  if (!prog) return prog;
  const side = aggressive ? 200 : 280;
  const q = aggressive ? 0.42 : 0.52;
  if (prog.athletePhoto)
    prog.athletePhoto = await recompressDataUrl(prog.athletePhoto, aggressive ? 160 : 220, q);
  if (prog.clubLogo)
    prog.clubLogo = await recompressDataUrl(prog.clubLogo, aggressive ? 120 : 180, q);
  for (const day of prog.days || []) {
    for (const ex of day.exercises || []) {
      if (ex.image) {
        if (String(ex.image).startsWith("data:video")) ex.image = null;
        else ex.image = await recompressDataUrl(ex.image, side, q);
      }
      if (ex.compImage) {
        if (String(ex.compImage).startsWith("data:video")) ex.compImage = null;
        else ex.compImage = await recompressDataUrl(ex.compImage, Math.round(side * 0.85), q);
      }
    }
  }
  return prog;
}

function clearShareCache() {
  try {
    localStorage.removeItem("yhcoachpro_shares");
  } catch (e) {}
}

function trimLoadHistory() {
  try {
    const store = JSON.parse(localStorage.getItem("yhcoachpro_load_history") || "{}");
    Object.keys(store).forEach((athlete) => {
      Object.keys(store[athlete] || {}).forEach((ex) => {
        const arr = store[athlete][ex] || [];
        if (arr.length > 12) store[athlete][ex] = arr.slice(-12);
      });
    });
    localStorage.setItem("yhcoachpro_load_history", JSON.stringify(store));
  } catch (e) {}
}

function getStorageUsage() {
  let total = 0;
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      const v = localStorage.getItem(k) || "";
      total += (k.length + v.length) * 2;
    }
  } catch (e) {}
  return total;
}

async function lightenAllStorage() {
  showToast("Allègement du stockage...");
  clearShareCache();
  trimLoadHistory();
  loadProgramsIndex();
  let ok = 0,
    fail = 0;
  for (const entry of programsIndex) {
    try {
      let prog = loadProgramFromStorage(entry.id);
      if (!prog) continue;
      prog = await lightenProgram(prog, true);
      prog.updatedAt = Date.now();
      const json = JSON.stringify(prog);
      localStorage.setItem("yhcoachpro_prog_" + prog.id, json);
      ok++;
    } catch (e) {
      fail++;
      console.error(e);
    }
  }
  // alléger programme ouvert
  if (program && program.id) {
    await lightenProgram(program, true);
    athleteImageData = program.athletePhoto || null;
    clubLogoData = program.clubLogo || null;
    try {
      saveProgramToStorage(program);
    } catch (e) {}
    render();
  }
  const mb = (getStorageUsage() / (1024 * 1024)).toFixed(2);
  showToast("Allégé : " + ok + " programme(s). Stockage ~" + mb + " Mo");
}

// ========== STOCKAGE (source unique : scripts/modules/store.js) ==========
const USE_DISK = !!(window.yhDisk && window.yhDisk.enabled);
if (
  !window.YHStore ||
  typeof storeGet !== "function" ||
  typeof storeSet !== "function" ||
  typeof storeRemove !== "function"
) {
  throw new Error("Module de stockage YhCoachPro indisponible");
}

function isYhMediaRef(src) {
  return typeof src === "string" && (src.startsWith("yhmedia:") || src.startsWith("yhmedia://"));
}

function resolveMediaSrc(src) {
  if (!src) return "";
  try {
    if (isYhMediaRef(src)) {
      if (USE_DISK && window.yhDisk && window.yhDisk.mediaPath) {
        const p = window.yhDisk.mediaPath(src);
        if (p) return p; // file:///...
      }
      // fallback protocole custom
      const name = src
        .replace(/^yhmedia:\/\//, "")
        .replace(/^yhmedia:/, "")
        .replace(/^\/+/, "");
      return "yhmedia://" + name;
    }
  } catch (e) {
    console.warn("resolveMediaSrc", e);
  }
  return src;
}

async function persistMediaIfNeeded(dataUrl, preferDisk) {
  try {
    if (!dataUrl || typeof dataUrl !== "string") return dataUrl;
    // déjà une ref disque
    if (dataUrl.startsWith("yhmedia:") || dataUrl.startsWith("file:")) return dataUrl;
    if (!USE_DISK || !window.yhDisk || !window.yhDisk.saveMedia) return dataUrl;
    const isVid = dataUrl.startsWith("data:video");
    const isBig = dataUrl.length > 150000;
    if (!preferDisk && !isVid && !isBig) return dataUrl;
    const id = "m_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 7);
    const ref = window.yhDisk.saveMedia(id, dataUrl);
    return ref || dataUrl;
  } catch (e) {
    console.warn("persistMediaIfNeeded", e);
    return dataUrl;
  }
}

function storageModeLabel() {
  if (USE_DISK) {
    let p = "";
    try {
      p = window.yhDisk.getDataPath() || "";
    } catch (e) {}
    return "SSD / disque" + (p ? " (" + p + ")" : "");
  }
  return "Navigateur (localStorage limité)";
}

// ========== STORAGE ==========
function loadProgramsIndex() {
  try {
    const raw = storeGet("yhcoachpro_programs_index");
    programsIndex = raw ? JSON.parse(raw) : [];
  } catch (e) {
    programsIndex = [];
  }
}

function saveProgramsIndex() {
  try {
    storeSet("yhcoachpro_programs_index", JSON.stringify(programsIndex));
  } catch (e) {
    showToast("Impossible de mettre à jour la liste des programmes");
  }
}

function saveProgramToStorage(prog) {
  const write = (p) => {
    const json = JSON.stringify(p);
    if (!storeSet("prog_" + p.id, json)) throw new Error("write fail");
    const entry = {
      id: p.id,
      athlete: p.athlete || "Sans nom",
      date: p.date || "",
      updatedAt: p.updatedAt || Date.now(),
      createdAt: p.createdAt || Date.now(),
      poste: p.poste || "",
      theme: p.theme || "",
      hasPhoto: !!p.athletePhoto,
      photoThumb: null,
    };
    const idx = programsIndex.findIndex((x) => x.id === p.id);
    if (idx >= 0) programsIndex[idx] = entry;
    else programsIndex.push(entry);
    saveProgramsIndex();
    return true;
  };
  try {
    clearShareCache();
    return write(prog);
  } catch (e) {
    console.error(e);
    if (e.name === "QuotaExceededError" || e.code === 22) {
      showToast("Stockage plein — allègement auto...");
      clearShareCache();
      trimLoadHistory();
      // retry after stripping videos sync
      try {
        const p = JSON.parse(JSON.stringify(prog));
        if (p.athletePhoto && p.athletePhoto.length > 120000) p.athletePhoto = null;
        if (p.clubLogo && p.clubLogo.length > 80000) p.clubLogo = null;
        (p.days || []).forEach((d) =>
          (d.exercises || []).forEach((ex) => {
            if (
              ex.image &&
              !String(ex.image).startsWith("yhmedia") &&
              (String(ex.image).startsWith("data:video") || ex.image.length > 100000)
            )
              ex.image = null;
            if (
              ex.compImage &&
              !String(ex.compImage).startsWith("yhmedia") &&
              (String(ex.compImage).startsWith("data:video") || ex.compImage.length > 80000)
            )
              ex.compImage = null;
          }),
        );
        write(p);
        Object.assign(prog, p);
        showToast("Sauvé après allègement (certains médias retirés)");
        return true;
      } catch (e2) {
        showToast("Stockage plein. Clique « Alléger stockage » ou supprime des programmes.");
        return false;
      }
    }
    showToast("Erreur de sauvegarde: " + (e && e.message ? e.message : "inconnue"));
    return false;
  }
}

function loadProgramFromStorage(id) {
  try {
    const raw = storeGet("prog_" + id);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

function deleteProgramFromStorage(id) {
  storeRemove("prog_" + id);
  programsIndex = programsIndex.filter((p) => p.id !== id);
  saveProgramsIndex();
}

// Compat: old single-program key
function migrateOldData() {
  const old = localStorage.getItem("yhcoachpro_program");
  if (!old) return;
  try {
    const p = JSON.parse(old);
    if (!p.id) p.id = uid();
    p.createdAt = p.createdAt || Date.now();
    p.updatedAt = Date.now();
    if (saveProgramToStorage(p)) {
      localStorage.removeItem("yhcoachpro_program");
    }
  } catch (e) {}
}

function save() {
  if (!program) return false;
  if (!program.id) program.id = uid();
  if (!program.createdAt) program.createdAt = Date.now();
  program.updatedAt = Date.now();
  return saveProgramToStorage(program);
}

// ========== INIT ==========
function load() {
  try {
    document.getElementById("licenseLock")?.classList.remove("show");
    document.getElementById("licenseLock")?.classList.remove("force-show");
    document.body.classList.remove("athlete-mode");
  } catch (e) {}
  try {
    applyLicenseLockUI();
  } catch (e) {}
  // bibliothèque plus tard pour ne pas bloquer l'UI
  setTimeout(function () {
    try {
      ensureBuiltinExerciseLibrary(false);
    } catch (e) {}
  }, 1500);
  try {
    loadProgramsIndex();
  } catch (e) {}
  try {
    migrateOldData();
  } catch (e) {}
  try {
    loadProgramsIndex();
  } catch (e) {}
  try {
    initDarkMode();
  } catch (e) {}
  try {
    checkTodayReminders();
    requestNotificationPermission();
  } catch (e) {}
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
