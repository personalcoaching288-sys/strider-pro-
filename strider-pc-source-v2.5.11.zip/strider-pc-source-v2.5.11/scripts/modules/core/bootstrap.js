/** Démarrage app — charger EN DERNIER */
// Init
try {
  load();
  showHome();
} catch (err) {
  console.error(err);
  alert("Erreur de demarrage YhCoachPro: " + (err && err.message ? err.message : err));
}
try {
  // Logos par défaut visibles dès l'ouverture
  const logo = getAppPlaceholderDataUrl();
  if (logo) {
    document
      .querySelectorAll(
        ".athlete-photo-placeholder, .club-logo-placeholder, .img-preview-placeholder",
      )
      .forEach((el) => {
        if (el.querySelector("i.fa-dumbbell")) return; // ne pas remplacer images exercice
        const img = document.createElement("img");
        img.src = logo;
        img.alt = "Strider Pro";
        img.style.cssText =
          "width:100%;height:100%;object-fit:cover;border-radius:inherit;background:#000";
        el.innerHTML = "";
        el.appendChild(img);
        el.classList.add("has-default-logo");
      });
  }
} catch (e) {}

// PWA – Service Worker
// Service worker uniquement en http(s) — jamais en file:// (casse souvent le mobile)
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  });
}

// Diagnostic mobile si erreur JS
window.addEventListener("error", function (e) {
  try {
    console.error(e.message);
  } catch (err) {}
});
