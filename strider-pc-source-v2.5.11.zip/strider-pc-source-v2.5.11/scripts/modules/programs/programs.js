"use strict";

// ========== PROGRAMMES ==========
function createNewProgram() {
  unlockCoachMode();
  if (!guardEdit()) return;
  program = defaultProgram();
  athleteImageData = null;
  clubLogoData = null;
  showEditor();
  showToast("Nouveau programme");
}

function openProgram(id) {
  unlockCoachMode();
  const p = loadProgramFromStorage(id);
  if (!p) {
    showToast("Programme introuvable");
    deleteProgramFromStorage(id);
    renderProgramList();
    return;
  }
  program = p;
  // Ensure new fields exist
  if (!program.poste) program.poste = "";
  if (!program.clubLogo) program.clubLogo = null;
  if (!program.titleFont) program.titleFont = "'Segoe UI', system-ui, sans-serif";
  if (!program.titleSize) program.titleSize = 24;
  athleteImageData = program.athletePhoto || null;
  clubLogoData = program.clubLogo || null;
  showEditor();
}

function saveCurrentProgram() {
  try {
    if (!guardEdit()) return;
    if (!program) {
      showToast("Aucun programme ouvert");
      return;
    }
    if (!program.id) program.id = uid();
    if (!program.createdAt) program.createdAt = Date.now();
    program.updatedAt = Date.now();
    program.athletePhoto = athleteImageData;
    program.clubLogo = clubLogoData;
    if (!program.athlete) program.athlete = "Nouvel athlète";
    const ok = saveProgramToStorage(program);
    if (ok) {
      programDirty = false;
      try {
        recordLoadHistory(program);
      } catch (e) {
        console.warn(e);
      }
      showToast("Programme enregistré !");
      try {
        renderProgramList();
      } catch (e) {}
      try {
        checkTodayReminders();
      } catch (e) {}
    } else {
      showToast("Échec enregistrement — stockage ou fichier inaccessible");
    }
  } catch (e) {
    console.error(e);
    showToast("Erreur: " + (e && e.message ? e.message : e));
  }
}

function confirmDeleteProgram(id, ev) {
  if (ev) ev.stopPropagation();
  if (!confirm("Supprimer ce programme définitivement ?")) return;
  deleteProgramFromStorage(id);
  showToast("Programme supprimé");
  renderProgramList();
}

function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

// Une copie conserve tous les champs; seuls les identifiants techniques changent.
function cloneProgramExerciseExact(ex) {
  const copy = deepClone(ex);
  copy.id = uid();
  return copy;
}
function cloneProgramDayExact(day) {
  const copy = deepClone(day);
  copy.id = uid();
  copy.exercises = (copy.exercises || []).map(cloneProgramExerciseExact);
  return copy;
}
function duplicateProgram(id, ev) {
  if (ev) ev.stopPropagation();
  const src = loadProgramFromStorage(id);
  if (!src) {
    showToast("Programme introuvable");
    return;
  }
  const copy = deepClone(src);
  copy.id = uid();
  copy.athlete = (copy.athlete || "Sans nom") + " (copie)";
  copy.createdAt = Date.now();
  copy.updatedAt = Date.now();
  // new ids for days & exercises
  (copy.days || []).forEach((day) => {
    day.id = uid();
    (day.exercises || []).forEach((ex) => {
      ex.id = uid();
    });
  });
  if (saveProgramToStorage(copy)) {
    showToast("Programme dupliqué");
    renderProgramList();
  }
}

function duplicateDay(dayId) {
  if (!guardEdit()) return;
  const day = program.days.find((d) => d.id === dayId);
  if (!day) return;
  const copy = cloneProgramDayExact(day);
  const idx = program.days.findIndex((d) => d.id === dayId);
  program.days.splice(idx + 1, 0, copy);
  save();
  render();
  showToast("Jour dupliqué");
}

function duplicateExercise(dayId, exId) {
  if (!guardEdit()) return;
  const day = program.days.find((d) => d.id === dayId);
  if (!day) return;
  const ex = day.exercises.find((e) => e.id === exId);
  if (!ex) return;
  const copy = cloneProgramExerciseExact(ex);
  const idx = day.exercises.findIndex((e) => e.id === exId);
  day.exercises.splice(idx + 1, 0, copy);
  save();
  render();
  showToast("Exercice dupliqué");
}

function closeHomeMenus() {
  document.getElementById("programsPanel")?.classList.remove("show");
  document.getElementById("homeScreen")?.classList.remove("programs-view");
  document.getElementById("homeMenuDropdown")?.classList.remove("show");
  const ts = document.getElementById("themesSubmenu");
  if (ts) {
    ts.classList.remove("show");
    ts.style.display = "none";
  }
}
function toggleHomePrograms() {
  const panel = document.getElementById("programsPanel");
  const open = panel && !panel.classList.contains("show");
  closeHomeMenus();
  if (open && panel) {
    panel.classList.add("show");
    document.getElementById("homeScreen")?.classList.add("programs-view");
    renderProgramList();
  }
}
function toggleHomeMenu() {
  const drop = document.getElementById("homeMenuDropdown");
  const open = drop && !drop.classList.contains("show");
  closeHomeMenus();
  if (open && drop) drop.classList.add("show");
}
function showProgramsPanel() {
  toggleHomePrograms();
}
function hideProgramsPanel() {
  closeHomeMenus();
}

function renderProgramList() {
  const list = document.getElementById("programList");
  if (!list) return;
  const q = (document.getElementById("progSearch")?.value || "").trim().toLowerCase();
  const themeF = document.getElementById("progThemeFilter")?.value || "";
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  // thèmes pour select
  const themeSel = document.getElementById("progThemeFilter");
  if (themeSel && themeSel.options.length <= 1) {
    const themes = [...new Set(programsIndex.map((p) => p.theme).filter(Boolean))].sort();
    themes.forEach((t) => {
      const o = document.createElement("option");
      o.value = t;
      o.textContent = t;
      themeSel.appendChild(o);
    });
  }

  let sorted = [...programsIndex].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  sorted = sorted.filter((p) => {
    if (q) {
      const hay = ((p.athlete || "") + " " + (p.theme || "") + " " + (p.poste || "")).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    if (themeF && p.theme !== themeF) return false;
    if (progFilter === "week" || progFilter === "month") {
      const d = p.date
        ? new Date(p.date + "T12:00:00")
        : p.updatedAt
          ? new Date(p.updatedAt)
          : null;
      if (!d || isNaN(d)) return false;
      if (progFilter === "week" && d < startOfWeek) return false;
      if (progFilter === "month" && d < startOfMonth) return false;
    }
    return true;
  });

  if (!programsIndex.length) {
    list.innerHTML = `<div class="empty-state"><i class="fas fa-inbox"></i><p>Aucun programme enregistré.</p></div>`;
    return;
  }
  if (!sorted.length) {
    list.innerHTML = `<div class="empty-state"><i class="fas fa-search"></i><p>Aucun résultat pour ces filtres.</p></div>`;
    return;
  }
  list.innerHTML = sorted
    .map((p) => {
      const dateStr =
        p.date || (p.updatedAt ? new Date(p.updatedAt).toLocaleDateString("fr-FR") : "—");
      let photoHtml = "";
      {
        const logo = typeof getAppLogoDataUrl === "function" ? getAppLogoDataUrl() : null;
        photoHtml = logo
          ? `<div class="program-item-photo"><img src="${logo}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;background:#000" /></div>`
          : `<div class="program-item-photo placeholder"><i class="fas fa-user"></i></div>`;
      }
      let doneHtml = "";
      try {
        const full = loadProgramFromStorage(p.id);
        if (full && full.athletePhoto) {
          photoHtml = `<div class="program-item-photo"><img src="${full.athletePhoto}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;background:transparent" /></div>`;
        }
        if (full && full.completed) {
          doneHtml = `<div class="done-badge"><i class="fas fa-check"></i> Fait${full.completedAt ? " · " + full.completedAt : ""}</div>`;
        }
      } catch (e) {}
      return `
          <div class="program-item" onclick="openProgram('${p.id}')">
            ${photoHtml}
            <div class="program-item-info">
              <h3>${escapeHtml(p.athlete || "Sans nom")}</h3>
              <p>${escapeHtml(p.theme || "")}${p.poste ? " · " + escapeHtml(p.poste) : ""} · ${dateStr}</p>
              ${doneHtml}
            </div>
            <div class="program-item-actions" onclick="event.stopPropagation()">
              <button class="open-btn" aria-label="Ouvrir" title="Ouvrir" onclick="openProgram('${p.id}')"><span class="action-symbol" aria-hidden="true">▣</span></button>
              <button class="dup-btn" aria-label="Dupliquer" title="Dupliquer" onclick="duplicateProgram('${p.id}', event)"><span class="action-symbol copy-symbol" aria-hidden="true"></span></button>
              <button aria-label="Supprimer" title="Supprimer" onclick="confirmDeleteProgram('${p.id}', event)"><span class="action-symbol" aria-hidden="true">×</span></button>
            </div>
          </div>`;
    })
    .join("");
}
