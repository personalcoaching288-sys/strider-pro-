"use strict";

// ========== DOWNLOAD MENU ==========
function toggleDownloadMenu(e) {
  e.stopPropagation();
  document.getElementById("downloadMenu").classList.toggle("show");
}
function closeDownloadMenu() {
  document.getElementById("downloadMenu").classList.remove("show");
}
document.addEventListener("click", () => closeDownloadMenu());

function toggleEditorOptions(e) {
  if (e) e.stopPropagation();
  const bar = document.getElementById("editorToolbar");
  const btn = document.getElementById("optionsToggleBtn");
  if (!bar) return;
  const open =
    bar.style.display === "none" || !bar.style.display || getComputedStyle(bar).display === "none";
  bar.style.display = open ? "flex" : "none";
  if (btn) btn.classList.toggle("open", open);
}

function getExportBackground() {
  return "#0a0a12";
}

async function videoSrcToPoster(src) {
  try {
    const url = toPlayableUrl(src) || resolveMediaSrc(src) || src;
    if (!url) return null;
    return await new Promise((resolve) => {
      const v = document.createElement("video");
      v.muted = true;
      v.playsInline = true;
      v.preload = "auto";
      v.crossOrigin = "anonymous";
      let done = false;
      const finish = (val) => {
        if (!done) {
          done = true;
          resolve(val);
        }
      };
      const snap = () => {
        try {
          const w = v.videoWidth || 320;
          const h = v.videoHeight || 320;
          if (!w || !h) {
            finish(null);
            return;
          }
          const c = document.createElement("canvas");
          c.width = w;
          c.height = h;
          c.getContext("2d").drawImage(v, 0, 0, w, h);
          finish(c.toDataURL("image/jpeg", 0.88));
        } catch (e) {
          finish(null);
        }
      };
      v.addEventListener("loadeddata", () => {
        try {
          const t = Math.min(0.35, Math.max(0.05, (v.duration || 1) * 0.08));
          if (v.seekable && v.seekable.length) v.currentTime = t;
          else snap();
        } catch (e) {
          snap();
        }
      });
      v.addEventListener("seeked", snap);
      v.onerror = () => finish(null);
      setTimeout(() => finish(null), 4000);
      v.src = url;
      try {
        v.load();
      } catch (e) {}
    });
  } catch (e) {
    return null;
  }
}

async function replaceVideosWithPosters(root) {
  const vids = Array.from((root || document).querySelectorAll("video"));
  const backups = [];
  for (const v of vids) {
    const src = v.currentSrc || v.src || "";
    const poster = await videoSrcToPoster(src);
    const img = document.createElement("img");
    img.className = (v.className || "ex-img") + " ex-pdf-poster";
    img.alt = "exercice";
    if (poster) {
      img.src = poster;
    } else {
      const c = document.createElement("canvas");
      c.width = 240;
      c.height = 240;
      const ctx = c.getContext("2d");
      ctx.fillStyle = "#111";
      ctx.fillRect(0, 0, 240, 240);
      ctx.fillStyle = "#e8d0af";
      ctx.font = "bold 26px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("VIDEO", 120, 125);
      img.src = c.toDataURL("image/png");
    }
    // Remplir exactement le cadre parent
    img.style.cssText =
      "position:absolute;inset:0;width:100%!important;height:100%!important;object-fit:cover!important;object-position:center!important;margin:0;padding:0;border-radius:0;display:block;background:#000;";
    const parent = v.parentNode;
    if (parent) {
      if (parent.classList && parent.classList.contains("ex-media-video-wrap")) {
        parent.style.position = "relative";
        parent.style.overflow = "hidden";
      }
      backups.push({ parent, v, img });
      parent.replaceChild(img, v);
    }
  }
  // Aussi forcer les images statiques a remplir le cadre
  (root || document).querySelectorAll("img.ex-img").forEach((img) => {
    if (!img.classList.contains("ex-pdf-poster")) {
      img.style.objectFit = "cover";
      img.style.width = "120px";
      img.style.height = "120px";
    }
  });
  return backups;
}

function restoreVideoPosters(backups) {
  (backups || []).forEach(({ parent, v, img }) => {
    try {
      if (img && img.parentNode === parent) parent.replaceChild(v, img);
    } catch (e) {}
  });
}

async function saveBlobDownload(filename, blob) {
  try {
    if (USE_DISK && window.yhDisk && window.yhDisk.exportFile) {
      const buf = await blob.arrayBuffer();
      const bytes = new Uint8Array(buf);
      let binary = "";
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
      }
      const b64 = btoa(binary);
      const dataUrl = "data:application/octet-stream;base64," + b64;
      // For large files use special binary export if available
      if (window.yhDisk.exportBinary) {
        const res = await window.yhDisk.exportBinary(filename, Array.from(bytes));
        if (res && res.ok) {
          showToast("Fichier enregistré");
          return true;
        }
        if (res && res.canceled) {
          showToast("Annulé");
          return false;
        }
      }
    }
    await window.yhSaveFile(filename, blob);
    showToast("Téléchargement lancé");
    return true;
  } catch (e) {
    console.error(e);
    showToast("Échec téléchargement");
    return false;
  }
}

/**
 * ÉTAPE 1 — Jours ouverts uniquement pour export HTML/PDF.
 * Source de vérité = ce qui est visible à l'écran (.day-section.open).
 */
function getCurrentlyOpenProgramDays() {
  const days = (program && Array.isArray(program.days) ? program.days : []).slice();
  if (!days.length) return [];

  // A) Lire l'écran : section ouverte = class "open"
  try {
    const sections = Array.from(document.querySelectorAll(".day-section"));
    if (sections.length) {
      const open = [];
      sections.forEach((sec) => {
        if (!sec.classList.contains("open")) return;
        // id via bouton d'action
        const btn = sec.querySelector("button[onclick]");
        const on = (btn && btn.getAttribute("onclick")) || "";
        const m = on.match(/['"]([a-zA-Z0-9_\-]+)['"]/);
        let day = m ? days.find((d) => d.id === m[1]) : null;
        // repli : même ordre DOM / program.days
        if (!day) {
          const idx = sections.indexOf(sec);
          if (idx >= 0 && idx < days.length) day = days[idx];
        }
        if (day && !open.some((x) => x.id === day.id)) open.push(day);
      });
      if (open.length) {
        // synchroniser le flag pour la suite
        days.forEach((d) => {
          d.open = open.some((x) => x.id === d.id);
        });
        return open;
      }
    }
  } catch (e) {
    console.warn("open days DOM", e);
  }

  // B) Flags mémoire : open === false = fermé
  const byFlag = days.filter((d) => d.open !== false);
  return byFlag.length ? byFlag : days.slice(0, 1);
}

async function buildProgramShareHtml() {
  if (!program) {
    showToast("Aucun programme");
    return null;
  }
  const openOnly = getCurrentlyOpenProgramDays();
  if (!openOnly.length) {
    showToast("Ouvre au moins un jour (clic sur le titre du jour) avant l'export");
    return null;
  }
  try {

    // Synchroniser les images de l'éditeur (parfois pas encore dans program.*)
    try {
      if (typeof athleteImageData !== "undefined" && athleteImageData)
        program.athletePhoto = athleteImageData;
      if (typeof clubLogoData !== "undefined" && clubLogoData)
        program.clubLogo = clubLogoData;
    } catch (e) {}

    function toEmbedImage(ref) {
      if (ref == null || ref === "") return "";
      let s = typeof ref === "string" ? ref : String(ref);
      s = s.trim();
      if (!s) return "";
      if (s.startsWith("data:image")) return s;
      if (s.startsWith("data:")) return s;
      // yhmedia / id fichier → base64
      try {
        if (window.yhDisk && typeof window.yhDisk.mediaAsBase64 === "function") {
          const tries = [s];
          if (s.startsWith("yhmedia://")) tries.push(s.replace("yhmedia://", "yhmedia:"));
          else if (s.startsWith("yhmedia:")) tries.push(s.replace("yhmedia:", "yhmedia://"));
          else {
            tries.push("yhmedia:" + s);
            tries.push("yhmedia://" + s);
          }
          for (const id of tries) {
            try {
              const b64 = window.yhDisk.mediaAsBase64(id);
              if (b64 && String(b64).indexOf("data:") === 0) return String(b64);
            } catch (e) {}
          }
        }
      } catch (e) {}
      return "";
    }

    function fromDom(selectors) {
      for (let i = 0; i < selectors.length; i++) {
        try {
          const img = document.querySelector(selectors[i]);
          if (!img) continue;
          const attr = img.getAttribute("src") || "";
          const src = img.currentSrc || img.src || attr;
          let out = toEmbedImage(attr) || toEmbedImage(src);
          if (out) return out;
          if (src && src.indexOf("data:image") === 0) return src;
          if (img.complete && img.naturalWidth > 0) {
            try {
              const c = document.createElement("canvas");
              c.width = img.naturalWidth;
              c.height = img.naturalHeight;
              c.getContext("2d").drawImage(img, 0, 0);
              out = c.toDataURL("image/png");
              if (out && out.indexOf("data:image") === 0) return out;
            } catch (e) {}
          }
        } catch (e) {}
      }
      return "";
    }

    // 1) clone + embed médias exercices
    const packed = embedMediaInProgram(JSON.parse(JSON.stringify(program)));
    const openIds = {};
    openOnly.forEach((d) => {
      if (d && d.id) openIds[d.id] = true;
    });
    packed.days = (packed.days || []).filter((d) => d && openIds[d.id]);
    if (!packed.days.length) {
      packed.days = JSON.parse(JSON.stringify(openOnly));
      // re-embed exercices des jours ouverts
      const tmp = embedMediaInProgram({ days: packed.days });
      packed.days = tmp.days || packed.days;
    }

    // 2) PHOTO + LOGO — sources multiples, on ne les efface JAMAIS si trouvées
    let photo =
      toEmbedImage(typeof athleteImageData !== "undefined" ? athleteImageData : "") ||
      toEmbedImage(program.athletePhoto) ||
      toEmbedImage(packed.athletePhoto) ||
      fromDom([
        "#athletePhotoWrap img",
        "#athleteImgPreview img",
        "img.athlete-photo",
      ]);

    let logo =
      toEmbedImage(typeof clubLogoData !== "undefined" ? clubLogoData : "") ||
      toEmbedImage(program.clubLogo) ||
      toEmbedImage(packed.clubLogo) ||
      fromDom([
        "#clubLogoWrap img",
        "#clubLogoPreview img",
        "img.club-logo",
      ]);

    // Si encore yhmedia brut après embedMedia, retenter
    if (!photo && packed.athletePhoto) photo = toEmbedImage(packed.athletePhoto);
    if (!logo && packed.clubLogo) logo = toEmbedImage(packed.clubLogo);

    packed.athletePhoto = photo || "";
    packed.clubLogo = logo || "";

    showToast(
      "HTML : " +
        packed.days.length +
        " jour(s) | photo " +
        (packed.athletePhoto ? "OK" : "ABSENTE") +
        " | logo " +
        (packed.clubLogo ? "OK" : "ABSENT"),
    );

    function esc(s) {
      return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    }
    function mediaTag(src, label) {
      if (!src) return '<div class="ph">🏋️</div>';
      const embedded = toEmbedImage(src) || src;
      if (String(embedded).indexOf("data:video") === 0 || /\.(mp4|webm|mov)/i.test(String(src))) {
        return '<video src="' + embedded + '" autoplay muted loop playsinline></video>';
      }
      return '<img src="' + embedded + '" alt="' + esc(label) + '"/>';
    }

    let body = "";
    body += '<header class="head">';
    body += '<div class="who">';
    // Toujours réserver la place photo / logo pour debug visuel
    if (packed.athletePhoto) {
      body +=
        '<img class="avatar" src="' +
        packed.athletePhoto +
        '" alt="Photo athlète"/>';
    } else {
      body +=
        '<div class="avatar avatar-empty" title="Photo absente">?</div>';
    }
    body += "<div><h1>" + esc(packed.athlete || "Athlète") + "</h1>";
    body +=
      "<p>" +
      esc(packed.theme || "") +
      " · Séance " +
      (packed.sessionNum || 1) +
      " · " +
      esc(packed.date || "") +
      "</p></div>";
    if (packed.clubLogo) {
      body +=
        '<img class="club-logo" src="' + packed.clubLogo + '" alt="Logo club"/>';
    } else {
      body += '<div class="club-logo club-logo-empty" title="Logo absent">?</div>';
    }
    body += "</div>";
    if (packed.objective)
      body +=
        '<p class="obj"><strong>Objectif :</strong> ' + esc(packed.objective) + "</p>";
    body += "</header>";

    (packed.days || []).forEach((day) => {
      body +=
        '<section class="day"><h2 style="background:' +
        esc(day.color || "#4f46e5") +
        '">' +
        esc(day.name || "Jour") +
        "</h2>";
      (day.exercises || []).forEach((ex) => {
        body += '<article class="ex">';
        body += '<div class="media">' + mediaTag(ex.image, ex.name) + "</div>";
        body +=
          '<div class="info"><div class="lbl">Principal</div><h3>' +
          esc(ex.name) +
          "</h3>";
        body += '<div class="badges">';
        body +=
          "<span>Séries " +
          (ex.series ?? 0) +
          "</span><span>Reps " +
          (ex.reps ?? 0) +
          "</span>";
        body += "<span>Charge " + (ex.charge ?? 0) + "%</span>";
        if (ex.chargeKg !== "" && ex.chargeKg != null)
          body += "<span>" + ex.chargeKg + " kg</span>";
        body += "<span>Récup " + esc(ex.recup || "") + "</span>";
        if (ex.rpe != null && ex.rpe !== "") body += "<span>RPE " + ex.rpe + "</span>";
        body += "</div>";
        if (ex.notes && String(ex.notes).trim())
          body += '<p class="note">' + esc(ex.notes) + "</p>";
        body += "</div>";
        if (ex.compName) {
          body += '<div class="media">' + mediaTag(ex.compImage, ex.compName) + "</div>";
          body +=
            '<div class="info"><div class="lbl">Complémentaire</div><h3>' +
            esc(ex.compName) +
            "</h3>";
          body += '<div class="badges">';
          body +=
            "<span>Séries " +
            (ex.compSeries ?? 0) +
            "</span><span>Reps " +
            (ex.compReps ?? 0) +
            "</span>";
          body += "<span>Charge " + (ex.compCharge ?? 0) + "%</span>";
          if (ex.compChargeKg !== "" && ex.compChargeKg != null)
            body += "<span>" + ex.compChargeKg + " kg</span>";
          body += "<span>Récup " + esc(ex.compRecup || "") + "</span>";
          body += "</div>";
          if (ex.compNotes && String(ex.compNotes).trim())
            body += '<p class="note">' + esc(ex.compNotes) + "</p>";
          body += "</div>";
        }
        body += "</article>";
      });
      body += "</section>";
    });

    const doc = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Strider Pro – ${esc(packed.athlete || "Programme")}</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:system-ui,sans-serif;background:#0a0a12;color:#f1f5f9}
.head{padding:20px 16px;background:linear-gradient(165deg,#050508,#1a1030,#0a0a12);border-bottom:1px solid rgba(232,208,175,.25)}
.who{display:flex;gap:14px;align-items:center;flex-wrap:wrap}
.avatar{width:72px;height:72px;border-radius:50%;object-fit:cover;border:2px solid #e8d0af;background:#111}
.avatar-empty{display:flex;align-items:center;justify-content:center;color:#64748b;font-size:1.2rem}
.club-logo{width:56px;height:56px;border-radius:10px;object-fit:contain;border:1px solid rgba(232,208,175,.45);background:rgba(0,0,0,.25);margin-left:auto}
.club-logo-empty{display:flex;align-items:center;justify-content:center;color:#64748b;font-size:1rem}
h1{margin:0;font-size:1.4rem}p{margin:4px 0 0;color:#94a3b8;font-size:.9rem}
.obj{margin-top:12px;color:#e2e8f0}.day{margin:16px}.day h2{margin:0 0 10px;padding:12px 16px;border-radius:12px;font-size:1rem;color:#fff}
.ex{display:flex;flex-wrap:wrap;gap:12px;align-items:center;background:#1f2937;border-radius:14px;padding:12px;margin-bottom:10px;border-left:4px solid #10b981}
.media{width:110px;height:110px;border-radius:12px;overflow:hidden;background:#000;flex-shrink:0;border:2px solid rgba(232,208,175,.45)}
.media img,.media video{width:100%;height:100%;object-fit:cover;display:block}
.ph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:2rem;background:#111}
.info{flex:1;min-width:160px}.lbl{font-size:.7rem;color:#94a3b8;text-transform:uppercase}
h3{margin:2px 0 8px;font-size:1.05rem}.badges{display:flex;flex-wrap:wrap;gap:6px}
.badges span{background:#334155;padding:4px 8px;border-radius:8px;font-size:.78rem}
.note{font-size:.85rem;color:#cbd5e1;margin:8px 0 0;white-space:pre-wrap;overflow-wrap:anywhere}
footer{text-align:center;padding:24px;color:#64748b;font-size:.8rem}
</style></head><body>
${body}
<footer>Strider Pro<br>Lecture seule — non modifiable · Vidéos en mouvement</footer>
<script>document.querySelectorAll('video').forEach(v=>{v.muted=true;v.play().catch(()=>{});});<\/script>
</body></html>`;

    return { html: doc, athlete: packed.athlete || "programme", photo: !!packed.athletePhoto, logo: !!packed.clubLogo };
  } catch (e) {
    console.error(e);
    showToast("Erreur préparation export: " + (e && e.message ? e.message : e));
    return null;
  }
}

async function exportHTMLProgram() {
  const built = await buildProgramShareHtml();
  if (!built) return;
  try {
    const name =
      "StriderPro_" + String(built.athlete || "programme").replace(/\s+/g, "_") + "_interactif.html";
    await downloadTextFile(name, built.html);
    showToast(
      "HTML enregistré — photo: " +
        (built.photo ? "oui" : "non") +
        " — logo: " +
        (built.logo ? "oui" : "non"),
    );
  } catch (e) {
    console.error(e);
    showToast("Erreur export HTML: " + (e && e.message ? e.message : e));
  }
}

// ========== IMAGE ==========
async function exportImage() {
  showToast("Génération de l'image...");
  const previousOpenState = program.days.map((d) => d.open);
  program.days.forEach((d) => (d.open = true));
  render();
  await new Promise((r) => setTimeout(r, 200));

  const toHide = document.querySelectorAll(
    ".btn-edit, .btn-save-program, .btn-download, .download-wrap, .add-day-btn, .add-exercise-btn, .day-actions, .ex-actions, .back-btn, .topbar, .toolbar-options-wrap, #editorToolbar, #sessionStatsBar",
  );
  toHide.forEach((el) => (el.style.display = "none"));
  const container = document.querySelector(".container");
  const pageBg = getExportBackground();
  container.style.background = pageBg;
  let posters = [];
  try {
    await ensureExportTools({ image: true });
    posters = await replaceVideosWithPosters(container);
    await new Promise((r) => setTimeout(r, 150));
    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: pageBg,
      logging: false,
    });
    const blob = await new Promise((res) => canvas.toBlob(res, "image/png"));
    await saveBlobDownload(
      `StriderPro_${(program.athlete || "programme").replace(/\s+/g, "_")}.png`,
      blob || new Blob([]),
    );
  } catch (err) {
    console.error(err);
    showToast("Erreur lors de la génération de l'image");
  } finally {
    restoreVideoPosters(posters);
    program.days.forEach((d, i) => (d.open = previousOpenState[i]));
    toHide.forEach((el) => (el.style.display = ""));
    container.style.background = "";
    render();
  }
}

// ========== VIDEO (format téléphone 9:16) ==========
async function exportVideo() {
  showToast("Génération vidéo en cours (peut prendre 1-2 min)...");

  // Collect all exercises with day info
  const slides = [];
  // Intro slide
  slides.push({ type: "intro" });
  program.days.forEach((day) => {
    day.exercises.forEach((ex) => {
      slides.push({ type: "exercise", day: day.name, dayColor: day.color || "#4f46e5", ex });
    });
  });
  if (slides.length === 1) {
    showToast("Ajoute des exercices avant d'exporter une vidéo");
    return;
  }
  // Outro
  slides.push({ type: "outro" });

  const W = 1080; // phone vertical width
  const H = 1920; // phone vertical height
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");

  const imgCache = {};
  const videoCache = {};
  async function loadImg(src) {
    if (!src) return null;
    if (imgCache[src]) return imgCache[src];
    if (isVideoMedia(src) || isYhMediaRef(src)) return null;
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        imgCache[src] = img;
        resolve(img);
      };
      img.onerror = () => resolve(null);
      img.src = resolveMediaSrc(src) || src;
    });
  }
  async function loadVideoEl(src) {
    if (!src) return null;
    if (!(isVideoMedia(src) || isYhMediaRef(src))) return null;
    if (videoCache[src]) return videoCache[src];
    const url = toPlayableUrl(src) || resolveMediaSrc(src);
    if (!url) return null;
    return await new Promise((resolve) => {
      const v = document.createElement("video");
      v.muted = true;
      v.defaultMuted = true;
      v.playsInline = true;
      v.loop = true;
      v.preload = "auto";
      // pas de crossOrigin sur fichiers locaux (sinon frame noire)
      const done = () => {
        videoCache[src] = v;
        resolve(v);
      };
      v.addEventListener("loadeddata", done, { once: true });
      v.addEventListener("canplay", done, { once: true });
      v.onerror = () => resolve(null);
      setTimeout(() => resolve(videoCache[src] || null), 8000);
      v.src = url;
      try {
        v.load();
      } catch (e) {
        resolve(null);
      }
    });
  }
  try {
    if (program.athletePhoto) await loadImg(program.athletePhoto);
    for (const s of slides) {
      if (s.ex?.image) {
        if (isVideoMedia(s.ex.image) || isYhMediaRef(s.ex.image)) await loadVideoEl(s.ex.image);
        else await loadImg(s.ex.image);
      }
      if (s.ex?.compImage) {
        if (isVideoMedia(s.ex.compImage) || isYhMediaRef(s.ex.compImage))
          await loadVideoEl(s.ex.compImage);
        else await loadImg(s.ex.compImage);
      }
    }

    if (typeof MediaRecorder === "undefined") {
      showToast("Export vidéo non supporté sur cet appareil");
      return;
    }
    const stream = canvas.captureStream(30);
    const recordedChunks = [];
    let mimeType = "video/webm;codecs=vp9";
    if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = "video/webm";
    if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = "";
    const recorder = mimeType
      ? new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 5000000 })
      : new MediaRecorder(stream, { videoBitsPerSecond: 5000000 });
    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) recordedChunks.push(e.data);
    };

    const done = new Promise((resolve) => {
      recorder.onstop = async () => {
        try {
          const blob = new Blob(recordedChunks, { type: recorder.mimeType || "video/webm" });
          if (!blob.size) {
            showToast("Vidéo vide — réessaie");
            resolve();
            return;
          }
          const fname = `StriderPro_${(program.athlete || "programme").replace(/\s+/g, "_")}_phone.webm`;
          await saveBlobDownload(fname, blob);
          showToast("Vidéo exportée !");
        } catch (e) {
          console.error(e);
          showToast("Erreur sauvegarde vidéo");
        }
        resolve();
      };
    });

    recorder.start(200);

    const SLIDE_MS = 4000;
    const FPS = 25;
    const framesPerSlide = Math.round((SLIDE_MS / 1000) * FPS);

    function drawRoundedRect(x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + w, y, x + w, y + h, r);
      ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r);
      ctx.arcTo(x, y, x + w, y, r);
      ctx.closePath();
    }

    function drawSlide(slide) {
      // Background
      ctx.fillStyle = "#0f172a";
      ctx.fillRect(0, 0, W, H);

      if (slide.type === "intro") {
        // Athlete photo
        if (program.athletePhoto && imgCache[program.athletePhoto]) {
          const img = imgCache[program.athletePhoto];
          const size = 280;
          ctx.save();
          ctx.beginPath();
          ctx.arc(W / 2, 520, size / 2, 0, Math.PI * 2);
          ctx.closePath();
          ctx.clip();
          ctx.drawImage(img, W / 2 - size / 2, 520 - size / 2, size, size);
          ctx.restore();
        } else {
          ctx.fillStyle = "#1e293b";
          ctx.beginPath();
          ctx.arc(W / 2, 520, 140, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#64748b";
          ctx.font = "80px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("👤", W / 2, 545);
        }

        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 64px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(program.athlete || "Athlète", W / 2, 740);

        // Theme badge
        const theme = program.theme || "force";
        ctx.font = "bold 36px sans-serif";
        const tw = ctx.measureText(theme).width + 48;
        const themeBg = (program.headerColors && program.headerColors.theme) || "#6366f1";
        ctx.fillStyle = themeBg;
        drawRoundedRect(W / 2 - tw / 2, 780, tw, 56, 28);
        ctx.fill();
        ctx.fillStyle = (program.headerColors && program.headerColors.themeText) || "#fff";
        ctx.fillText(theme, W / 2, 818);

        ctx.fillStyle = "#94a3b8";
        ctx.font = "32px sans-serif";
        ctx.fillText(`Séance n°${program.sessionNum || 1}  •  ${program.date || ""}`, W / 2, 900);

        const chargeText = document.getElementById("avgCharge")?.textContent || "";
        ctx.fillStyle = "#6366f1";
        ctx.font = "bold 34px sans-serif";
        ctx.fillText(chargeText, W / 2, 970);

        ctx.fillStyle = "#475569";
        ctx.font = "28px sans-serif";
        ctx.fillText("Strider Pro", W / 2, H - 120);
      } else if (slide.type === "exercise") {
        const ex = slide.ex;
        // Day label
        ctx.fillStyle = slide.dayColor;
        drawRoundedRect(80, 120, W - 160, 70, 16);
        ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.font = "bold 36px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(slide.day, W / 2, 168);

        // Exercise media — image OU frame video en mouvement
        const size = 420;
        const ix = W / 2 - size / 2;
        const iy = 280;
        const vEl = ex.image && videoCache[ex.image];
        if (vEl && vEl.videoWidth) {
          ctx.save();
          drawRoundedRect(ix, iy, size, size, 24);
          ctx.clip();
          ctx.drawImage(vEl, ix, iy, size, size);
          ctx.restore();
        } else if (ex.image && imgCache[ex.image]) {
          const img = imgCache[ex.image];
          ctx.save();
          drawRoundedRect(ix, iy, size, size, 24);
          ctx.clip();
          ctx.drawImage(img, ix, iy, size, size);
          ctx.restore();
        } else {
          ctx.fillStyle = "#1e293b";
          drawRoundedRect(ix, iy, size, size, 24);
          ctx.fill();
          ctx.fillStyle = "#64748b";
          ctx.font = "100px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("🏋️", W / 2, 520);
        }

        // Name
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 52px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(ex.name, W / 2, 780);

        // Badges
        const badges = [
          { label: `Séries ${ex.series}`, color: ex.colSeries || "#6366f1" },
          { label: `Reps ${ex.reps}`, color: ex.colReps || "#0d9488" },
          { label: `Charge ${ex.charge}%`, color: ex.colCharge || "#e11d48" },
          { label: `Récup ${ex.recup}`, color: ex.colRecup || "#7c3aed" },
        ];
        const badgeH = 56;
        const gap = 16;
        ctx.font = "bold 28px sans-serif";
        let totalW = 0;
        const widths = badges.map((b) => {
          const w = ctx.measureText(b.label).width + 40;
          totalW += w;
          return w;
        });
        totalW += gap * (badges.length - 1);
        let bx = W / 2 - totalW / 2;
        const by = 840;
        badges.forEach((b, i) => {
          ctx.fillStyle = b.color;
          drawRoundedRect(bx, by, widths[i], badgeH, 14);
          ctx.fill();
          ctx.fillStyle = "#fff";
          ctx.fillText(b.label, bx + widths[i] / 2, by + 38);
          bx += widths[i] + gap;
        });

        ctx.fillStyle = "#475569";
        ctx.font = "26px sans-serif";
        ctx.fillText("Strider Pro", W / 2, H - 100);
      } else if (slide.type === "outro") {
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 56px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("Bon entraînement !", W / 2, H / 2 - 40);
        ctx.fillStyle = "#94a3b8";
        ctx.font = "36px sans-serif";
        ctx.fillText(program.athlete || "", W / 2, H / 2 + 30);
        ctx.fillStyle = "#6366f1";
        ctx.font = "bold 32px sans-serif";
        ctx.fillText("Strider Pro", W / 2, H / 2 + 120);
      }
    }

    // Render all frames (temps réel pour capturer le mouvement vidéo)
    const frameDelay = Math.round(1000 / FPS);
    for (let s = 0; s < slides.length; s++) {
      const slide = slides[s];
      // démarrer la video de l'exercice si présente
      showToast("Vidéo: slide " + (s + 1) + "/" + slides.length + "...");
      if (slide.type === "exercise" && slide.ex && slide.ex.image && videoCache[slide.ex.image]) {
        const vv = videoCache[slide.ex.image];
        try {
          vv.currentTime = 0;
          await vv.play();
        } catch (e) {}
      }
      for (let f = 0; f < framesPerSlide; f++) {
        drawSlide(slide);
        // small progress bar
        ctx.fillStyle = "rgba(255,255,255,0.15)";
        ctx.fillRect(0, H - 8, W, 8);
        ctx.fillStyle = "#6366f1";
        const progress = (s + f / framesPerSlide) / slides.length;
        ctx.fillRect(0, H - 8, W * progress, 8);
        await new Promise((r) => setTimeout(r, frameDelay));
      }
    }

    recorder.stop();
    await done;
  } catch (err) {
    console.error(err);
    showToast("Erreur export vidéo: " + (err && err.message ? err.message : err));
  }
}

function hideClosedProgramDaysForExport() {
  const changed = [];
  document.querySelectorAll(".day-section").forEach((section) => {
    if (!section.classList.contains("open")) {
      changed.push({ el: section, display: section.style.display });
      section.style.display = "none";
    }
  });
  document.querySelectorAll(".planning-week-title").forEach((title) => {
    let next = title.nextElementSibling,
      hasVisibleDay = false;
    while (next && !next.classList.contains("planning-week-title")) {
      if (next.classList.contains("day-section") && next.style.display !== "none")
        hasVisibleDay = true;
      next = next.nextElementSibling;
    }
    if (!hasVisibleDay) {
      changed.push({ el: title, display: title.style.display });
      title.style.display = "none";
    }
  });
  return changed;
}
function restoreProgramDaysAfterExport(changed) {
  (changed || []).forEach((item) => {
    item.el.style.display = item.display || "";
  });
}

// ========== PDF ==========
async function exportPDF() {
  const built = await buildProgramShareHtml();
  if (!built || !built.html) return;

  showToast("Génération du PDF (même mise en page que le HTML)...");

  try {
    await ensureExportTools({ image: true, pdf: true });
  } catch (err) {
    console.error(err);
    showToast("Outils PDF indisponibles — relance l'installation");
    return;
  }

  const iframe = document.createElement("iframe");
  iframe.setAttribute("aria-hidden", "true");
  iframe.style.cssText =
    "position:fixed;left:-12000px;top:0;width:820px;height:1400px;border:0;opacity:0;pointer-events:none;";
  document.body.appendChild(iframe);

  try {
    const idoc = iframe.contentDocument;
    idoc.open();
    idoc.write(built.html);
    idoc.close();

    // attendre images
    await new Promise((r) => setTimeout(r, 500));
    try {
      const imgs = Array.from(idoc.images || []);
      await Promise.all(
        imgs.map((img) =>
          img.complete
            ? Promise.resolve()
            : new Promise((res) => {
                img.onload = img.onerror = () => res();
                setTimeout(res, 1500);
              }),
        ),
      );
    } catch (e) {}

    const target = idoc.body;
    const canvas = await html2canvas(target, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: "#0a0a12",
      logging: false,
      windowWidth: 820,
      windowHeight: Math.max(target.scrollHeight, target.offsetHeight, 800),
    });

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const pageW = 210;
    const pageH = 297;
    const margin = 8;
    const contentW = pageW - margin * 2;
    const contentH = pageH - margin * 2;
    const pxPerPage = Math.floor((contentH * canvas.width) / contentW);

    let y = 0;
    let page = 0;
    while (y < canvas.height - 1) {
      if (page > 0) pdf.addPage();
      // fond
      pdf.setFillColor(10, 10, 18);
      pdf.rect(0, 0, pageW, pageH, "F");

      const sliceH = Math.min(pxPerPage, canvas.height - y);
      const pageCanvas = document.createElement("canvas");
      pageCanvas.width = canvas.width;
      pageCanvas.height = sliceH;
      const ctx = pageCanvas.getContext("2d");
      ctx.fillStyle = "#0a0a12";
      ctx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
      ctx.drawImage(canvas, 0, y, canvas.width, sliceH, 0, 0, canvas.width, sliceH);
      const hMm = (sliceH * contentW) / canvas.width;
      const imgData = pageCanvas.toDataURL("image/jpeg", 0.93);
      pdf.addImage(imgData, "JPEG", margin, margin, contentW, hMm);
      y += sliceH;
      page++;
      if (page > 40) break;
    }

    const filename =
      "StriderPro_" + String(built.athlete || "programme").replace(/\s+/g, "_") + ".pdf";
    pdf.save(filename);
    showToast(
      "PDF enregistré — même mise en page que le HTML (photo: " +
        (built.photo ? "oui" : "non") +
        ", logo: " +
        (built.logo ? "oui" : "non") +
        ")",
    );
  } catch (err) {
    console.error(err);
    showToast("Erreur lors de la génération du PDF");
  } finally {
    try {
      iframe.remove();
    } catch (e) {}
  }
}



function hexToRgb(hex) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return [r, g, b];
}
