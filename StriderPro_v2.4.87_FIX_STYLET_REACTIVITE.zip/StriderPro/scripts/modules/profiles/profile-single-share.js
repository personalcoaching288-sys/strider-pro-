/* Fiche individuelle : capture isolée, aucun autre profil dans le fichier. */
(function () {
  "use strict";
  const esc = (v) =>
    String(v ?? "").replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[c],
    );
  async function snapshot() {
    flushProfileAutosave();
    loadAthleteProfiles();
    const source = athleteProfiles.find((p) => p.id === currentProfileId);
    if (!source) throw Error("Choisis une fiche enregistrée.");
    const p = JSON.parse(JSON.stringify(source));
    for (const key of ["photo", "clubLogo"])
      if (p[key]) {
        const embedded = yhEmbeddedMedia(p[key]);
        if (!embedded || /^yhmedia:/i.test(embedded))
          throw Error("La photo ou le logo ne peut pas être inclus.");
        p[key] = embedded;
      }
    return p;
  }
  async function embeddedImage(img) {
    const raw = img.getAttribute("src") || img.getAttribute("href") || img.getAttribute("xlink:href") || "";
    if (raw.startsWith("data:image/")) return raw;
    const media = typeof yhEmbeddedMedia === "function" ? yhEmbeddedMedia(raw) : null;
    if (media && media.startsWith("data:image/")) return media;
    try {
      await img.decode();
    } catch (e) {}
    if (!img.complete || !img.naturalWidth)
      throw Error("Une image de la fiche ne peut pas être chargée.");
    const c = document.createElement("canvas");
    c.width = img.naturalWidth;
    c.height = img.naturalHeight;
    c.getContext("2d").drawImage(img, 0, 0);
    return c.toDataURL("image/png");
  }
  async function fetchAssetDataUrl(relPath) {
    try {
      const url = new URL(relPath, document.baseURI).href;
      const res = await fetch(url);
      if (!res.ok) return "";
      const blob = await res.blob();
      return await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(String(r.result || ""));
        r.onerror = () => reject(r.error || new Error("lecture image"));
        r.readAsDataURL(blob);
      });
    } catch (_) {
      return "";
    }
  }
  async function resolveAnthroAvatarDataUrl() {
    // Ancien sélecteur (si présent)
    const legacy = document.querySelector(".avatar-body-img");
    if (legacy) {
      try {
        return await embeddedImage(legacy);
      } catch (_) {}
    }
    // SVG <image href="./assets/branding/anthro-avatar.png">
    const svgImg = document.querySelector("#suppliedAvatar image, .sp-anthro-avatar image");
    if (svgImg) {
      const href =
        svgImg.getAttribute("href") ||
        svgImg.getAttribute("xlink:href") ||
        svgImg.getAttribute("src") ||
        "";
      if (href.startsWith("data:image/")) return href;
      if (href) {
        const fromHref = await fetchAssetDataUrl(href);
        if (fromHref) return fromHref;
      }
    }
    return await fetchAssetDataUrl("./assets/branding/anthro-avatar.png");
  }
  async function readonlyHTML(p) {
    const field=(key)=>{const el=document.getElementById('pf_'+key),label=el?.parentElement?.querySelector('label')?.textContent?.trim()||key;const value=el?.tagName==='SELECT'?el.selectedOptions[0]?.textContent:el?.value;return '<div class="value"><small>'+esc(label)+'</small><b>'+esc(value||'—')+'</b></div>'};
    const fields=(keys)=>'<div class="fields">'+keys.map(field).join('')+'</div>';
    const name=[String(p.nom||'').toLocaleUpperCase('fr-FR'),p.prenom].filter(Boolean).join(' ')||'Athlète';
    const photo=document.getElementById('profilePhotoBox')?.querySelector('img'),clubLogo=document.getElementById('profileClubLogoBox')?.querySelector('img');
    const photoURI=photo?await embeddedImage(photo):getAppLogoDataUrl(),clubURI=clubLogo?await embeddedImage(clubLogo):'',avatarURI=await resolveAnthroAvatarDataUrl();
    const heading=(title)=>'<header><img src="'+esc(getAppLogoDataUrl())+'" alt="Strider Pro"><div><h1>'+esc(name)+'</h1><p>'+esc(title)+'</p></div></header>';
    const page=(title,body)=>'<section class="pdf-page">'+heading(title)+body+'</section>';
    let content=page('Informations de l’athlète','<div class="identity"><img class="photo" src="'+esc(photoURI)+'" alt="Photo de l’athlète"><div><h2>'+esc(p.club||'Club non renseigné')+'</h2><p>'+esc(p.poste||'')+'</p>'+fields(['saison','maillot','taille_maillot','numero_licence'])+'</div>'+(clubURI?'<img class="club-logo" src="'+esc(clubURI)+'" alt="Logo du club">':'')+'</div><h2>Identité & contact</h2>'+fields(['nom','prenom','naissance','tel','blood_group','club'])+'<p class="colour">Repère couleur '+profileColorDot(p.code_couleur)+'</p>');
    content+=page('Mesures & morphologie','<h2>Morphologie</h2>'+fields(['taille','poids','imc_display','env1','env2'])+'<h2>Mesures anthropométriques — cm</h2><div class="anthro"><div>'+fields(['m_cou','m_poitrine','m_abdo','m_biceps_g','m_cuisse_g','m_mollet_g'])+'</div><img class="avatar" src="'+esc(avatarURI)+'" alt="Silhouette de référence"><div>'+fields(['m_epaule','m_tour','m_hanche','m_biceps_d','m_cuisse_d','m_mollet_d'])+'</div></div><p>Ratio taille / hanche : '+esc(document.getElementById('pf_whr_num')?.textContent||'—')+'</p>');
    content+=page('Tests physiques & force','<h2>Tests physiques</h2>'+fields(['saut_elan','saut_sans','vma','vitesse_9m','vitesse_18m'])+'<h2>Tests 1RM — kg</h2>'+fields(['1rm_dc','1rm_tirage','1rm_pullover','1rm_squat','1rm_sdt']));
    content+=page('Santé & observations','<h2>Blessures actuelles</h2><div class="notes">'+esc(p.blessures_actuelles||'—')+'</div><h2>Blessures anciennes</h2><div class="notes">'+esc(p.blessures_anciennes||'—')+'</div><h2>Notes générales</h2><div class="notes">'+esc(p.notes||'—')+'</div>');
    const numeric=PROFILE_FIELDS.filter(k=>!['nom','prenom','naissance','tel','maillot','taille_maillot','numero_licence','code_couleur','poste','saison','blood_group','club','notes','blessures_actuelles','blessures_anciennes'].includes(k));
    const keys=numeric.filter(k=>(p.tests||[]).some(t=>t[k]!==''&&t[k]!=null));let history='';
    for(let i=0;i<keys.length;i+=5){const cols=keys.slice(i,i+5);history+='<h2>Historique complet — partie '+(i/5+1)+'</h2><table><thead><tr><th>Date</th>'+cols.map(k=>'<th>'+esc(document.getElementById('pf_'+k)?.parentElement?.querySelector('label')?.textContent||k)+'</th>').join('')+'</tr></thead><tbody>'+(p.tests||[]).map(t=>'<tr><td>'+esc(t.date||'')+'</td>'+cols.map(k=>'<td>'+esc(t[k]??'—')+'</td>').join('')+'</tr>').join('')+'</tbody></table>'}
    const canvas=document.getElementById('profileEvolutionCanvas');let chart='';if(canvas&&keys.length)chart='<img class="chart" src="'+canvas.toDataURL('image/png')+'" alt="Courbe de progression">';
    content+=page('Évolution & historique',chart+(history||'<p>Aucune mesure historique enregistrée.</p>'));
    return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\';img-src data:;style-src \'unsafe-inline\';"><title>'+esc(name)+' — Fiche individuelle</title><style>@page{size:A4 portrait;margin:12mm}*{box-sizing:border-box}body{margin:0;font:12px/1.4 Arial,sans-serif;background:#eef0f3;color:#1a2737}.pdf-page{width:186mm;background:white;margin:15px auto;padding:6mm;break-before:page}.pdf-page:first-child{break-before:auto}header{display:flex;gap:12px;align-items:center;border-bottom:1px solid #bfa66a;padding:0 0 13px;margin-bottom:20px}header img{width:38px;height:38px;object-fit:contain}h1{font-size:22px;margin:0;color:#6c5935}header p{margin:4px 0 0;color:#647387}h2{font-size:14px;color:#76603a;margin:20px 0 12px;break-after:avoid}.identity{display:flex;gap:17px;align-items:center}.identity>div{flex:1}.photo{width:100px;height:130px;object-fit:cover;border-radius:10px}.club-logo{width:50px;height:50px;object-fit:contain}.fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px}.value{padding:9px;border:1px solid #e0dacd;border-radius:7px;break-inside:avoid}.value small{display:block;color:#637187;font-size:9px}.value b{font-weight:400;display:block;margin-top:4px;white-space:pre-wrap;overflow-wrap:anywhere}.anthro{display:grid;grid-template-columns:1fr 120px 1fr;gap:15px;align-items:center}.anthro .fields{grid-template-columns:1fr;gap:8px}.avatar{width:120px;height:270px;object-fit:contain}.notes{padding:15px;border:1px solid #ded7ca;border-radius:7px;white-space:pre-wrap;overflow-wrap:anywhere}.chart{width:100%;height:auto;max-height:210px;object-fit:contain}table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:9px}th,td{padding:6px;border:1px solid #ccc;overflow-wrap:anywhere}th{background:#f4f0e5}thead{display:table-header-group}tr{break-inside:avoid}@media print{body{background:white}.pdf-page{width:auto;margin:0;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style></head><body>'+content+'</body></html>';
  }

  async function download(name, text, type) {
    if (window.yhDisk?.exportFile) {
      const result = await window.yhDisk.exportFile(name, text);
      if (result?.ok) return true;
      if (result?.canceled) return false;
      throw Error(result?.error || "Enregistrement impossible");
    }
    const a = document.createElement("a"),
      url = URL.createObjectURL(new Blob([text], { type }));
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    return true;
  }
  window.YHCurrentProfileShare = {
    snapshot,
    readonlyHTML,
    export: async function (mode) {
      const p = await snapshot();
      const name =
        "StriderPro_Fiche_" +
        yhSafeFileName([p.nom, p.prenom].filter(Boolean).join(" "), "Athlete");
      let ok = false;
      if (mode === "json")
        ok = await download(
          name + ".json",
          JSON.stringify(
            {
              yhcoachproProfiles: true,
              version: 1,
              exportedAt: new Date().toISOString(),
              profiles: [p],
            },
            null,
            2,
          ),
          "application/json",
        );
      else {
        const content = await readonlyHTML(p);
        if (mode === "html")
          ok = await download(name + ".html", content, "text/html;charset=utf-8");
        else if (mode === "pdf") {
          if (!window.yhDisk?.exportProfileList) {
            showToast(
              "PDF disponible dans l’application de bureau ; exporte le HTML pour l’imprimer depuis ton navigateur.",
            );
            return false;
          }
          const pageRanges = await window.SPProfilePdf.select(name + ".pdf", content);
          if (!pageRanges) return false;
          const result = await window.yhDisk.exportProfileList(name + ".pdf", content, false, "pdf", pageRanges);
          if (result?.ok) ok = true;
          else if (!result?.canceled) throw Error(result?.error || "Export PDF impossible");
        } else throw Error("Format inconnu.");
      }
      if (ok) showToast("Fiche de cet athlète prête à partager.");
      return ok;
    },
  };
})();
