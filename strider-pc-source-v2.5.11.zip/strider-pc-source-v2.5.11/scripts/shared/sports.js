(function(){"use strict";
const sourceVolley="<svg class=\"court-bg\" viewBox=\"0 0 900 600\" preserveAspectRatio=\"none\" aria-hidden=\"true\"><rect width=\"900\" height=\"600\" fill=\"#146979\"/><rect x=\"90\" y=\"110\" width=\"720\" height=\"360\" fill=\"#db907b\"/><rect x=\"330\" y=\"110\" width=\"240\" height=\"360\" fill=\"#e5a28a\"/><rect x=\"90\" y=\"110\" width=\"720\" height=\"360\" fill=\"none\" stroke=\"#fff7e9\" stroke-width=\"6\"/><path d=\"M330 75V505 M570 75V505\" stroke=\"#fff7e9\" stroke-width=\"3\" stroke-dasharray=\"10 12\"/><path d=\"M330 110V470 M570 110V470\" stroke=\"#fff7e9\" stroke-width=\"5\"/><path d=\"M450 80V500\" stroke=\"#fff\" stroke-width=\"4\"/><circle cx=\"450\" cy=\"77\" r=\"10\" fill=\"#d5d8db\" stroke=\"#374a55\" stroke-width=\"5\"/><circle cx=\"450\" cy=\"503\" r=\"10\" fill=\"#d5d8db\" stroke=\"#374a55\" stroke-width=\"5\"/><text x=\"90\" y=\"54\" fill=\"#d6eef0\" font-family=\"Arial\" font-size=\"16\" letter-spacing=\"3\">VOLLEYBALL \u00b7 VUE DU DESSUS</text><text x=\"450\" y=\"559\" fill=\"#d6eef0\" font-family=\"Arial\" text-anchor=\"middle\" font-size=\"15\">18 m \u00d7 9 m \u00b7 Ligne d\u2019attaque \u00e0 3 m</text></svg>";
const data={volley:{name:"Volley"},handball:{name:"Handball"},basket:{name:"Basket"},football:{name:"Football"}};
function sportCourt(s){
 if(s==='volley')return sourceVolley;
 let lines='',bg='#195967',field='#408ba2',caption='40 m × 20 m · Zones à 6 m et 9 m';
 const center='<path d="M450 110V470"/><circle cx="450" cy="290" r="48"/>';
 if(s==='handball'){
  const half='<path d="M90 155 A108 108 0 0 1 198 263 V317 A108 108 0 0 1 90 425" fill="#236579"/><path d="M90 101 A162 162 0 0 1 252 263 V317 A162 162 0 0 1 90 479" stroke-dasharray="11 8" clip-path="url(#pitch)"/><path d="M216 281V299 M162 281V299"/><rect x="66" y="263" width="24" height="54" fill="#143947"/>';
  lines='<path d="M450 110V470"/>'+half+'<g transform="translate(900 0) scale(-1 1)">'+half+'</g>';
 }else if(s==='basket'){
  bg='#3e3026';field='#b78558';caption='28 m × 15 m · Raquettes et lignes à trois points';
  const half='<rect x="90" y="228" width="149" height="124" fill="#845a40"/><circle cx="239" cy="290" r="46"/><path d="M90 125 H130 A165 165 0 0 1 130 455 H90"/><path d="M119 269V311" stroke-width="5"/><circle cx="130" cy="290" r="10" fill="none" stroke="#f8d392"/><path d="M110 247 A43 43 0 0 1 110 333"/>';
  lines=center+half+'<g transform="translate(900 0) scale(-1 1)">'+half+'</g>';
 }else{
  bg='#153e2c';field='#397a4d';caption='Terrain de football · Surfaces, buts et cercle central';
  const half='<rect x="90" y="183" width="114" height="214"/><rect x="90" y="242" width="38" height="96"/><circle cx="166" cy="290" r="3" fill="#fff7e9" stroke="none"/><path d="M204 254 A63 63 0 0 1 204 326"/><rect x="67" y="265" width="23" height="50" fill="#143428"/><path d="M90 125 A15 15 0 0 0 105 110 M90 455 A15 15 0 0 1 105 470"/>';
  lines=center+half+'<g transform="translate(900 0) scale(-1 1)">'+half+'</g>';
 }
 if(s==='football'){
 const half='<rect x="118" y="162.5" width="104.3" height="255"/><rect x="118" y="232" width="34.8" height="116"/><circle cx="187.6" cy="290" r="3" fill="#fff7e9" stroke="none"/><path d="M222.3 243.5 A58 58 0 0 1 222.3 336.5"/><rect x="95" y="266.9" width="23" height="46.2" fill="#143428"/><path d="M118 81.3 A6.3 6.3 0 0 0 124.3 75 M118 498.7 A6.3 6.3 0 0 1 124.3 505"/>';
 lines='<path d="M450 75V505"/><circle cx="450" cy="290" r="58"/>'+half+'<g transform="translate(900 0) scale(-1 1)">'+half+'</g>';
 caption='105 m × 68 m · Surfaces, buts et cercle central';
}
const px=s==='football'?118:90,py=s==='football'?75:s==='basket'?97:110,pw=s==='football'?664:720,ph=s==='football'?430:s==='basket'?386:360;
const stripes=s==='football'?Array.from({length:8},(_,i)=>`<rect x="${px+i*83}" y="${py}" width="83" height="${ph}" fill="${i%2?'#357148':'#408354'}"/>`).join(''):'';
 return `<svg class="court-bg" viewBox="0 0 900 600" preserveAspectRatio="none" aria-hidden="true"><defs><clipPath id="pitch"><rect x="90" y="110" width="720" height="360"/></clipPath></defs><rect width="900" height="600" fill="${bg}"/><rect x="${px}" y="${py}" width="${pw}" height="${ph}" fill="${field}"/>${stripes}<g fill="none" stroke="#fff7e9" stroke-width="3.5"><rect x="${px}" y="${py}" width="${pw}" height="${ph}"/>${lines}</g><text x="90" y="55" fill="#e8ecdf" font-family="Arial" font-size="16" letter-spacing="3">${data[s].name.toUpperCase()} · VUE DU DESSUS</text><text x="450" y="558" fill="#e8ecdf" font-family="Arial" text-anchor="middle" font-size="15">${caption}</text></svg>`;
}

window.StriderSports={court:sportCourt,labels:data,backgrounds:{"handball": "./assets/page-backgrounds/seance-handball.webp", "basket": "./assets/page-backgrounds/seance-basket.webp", "football": "./assets/page-backgrounds/seance-football.webp", "volley": "./assets/page-backgrounds/seance-volley.webp"}};})();