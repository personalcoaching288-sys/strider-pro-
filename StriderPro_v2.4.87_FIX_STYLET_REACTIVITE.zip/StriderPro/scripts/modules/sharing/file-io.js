/** Import / export fichiers programmes */
// ========== FILE IMPORT / EXPORT ==========
function embedMediaInProgram(prog) {
  if (!prog || !prog.days) return prog;
  const out = JSON.parse(JSON.stringify(prog));
  const embed = (ref) => {
    if (!ref || typeof ref !== "string") return ref;
    if (ref.startsWith("data:")) return ref;
    if (!isYhMediaRef(ref)) return ref;
    try {
      if (USE_DISK && window.yhDisk && window.yhDisk.mediaAsBase64) {
        const b64 = window.yhDisk.mediaAsBase64(ref);
        if (b64) return b64;
      }
    } catch (e) {
      console.warn(e);
    }
    return ref;
  };
  (out.days || []).forEach((d) => {
    (d.exercises || []).forEach((ex) => {
      if (ex.image) ex.image = embed(ex.image);
      if (ex.compImage) ex.compImage = embed(ex.compImage);
    });
  });
  if (out.athletePhoto && isYhMediaRef(out.athletePhoto))
    out.athletePhoto = embed(out.athletePhoto);
  if (out.clubLogo && isYhMediaRef(out.clubLogo)) out.clubLogo = embed(out.clubLogo);
  return out;
}

async function downloadTextFile(filename, text) {
  try {
    if (USE_DISK && window.yhDisk && window.yhDisk.exportFile) {
      showToast("Fenêtre d'enregistrement...");
      const res = await window.yhDisk.exportFile(filename, text);
      if (res && res.ok) {
        showToast("Enregistré : " + (res.path || filename));
        return true;
      }
      if (res && res.canceled) {
        showToast("Annulé");
        return false;
      }
      showToast("Échec enregistrement — réessaie");
      return false;
    }
    const blob = new Blob([text], { type: "text/html;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(a.href);
      a.remove();
    }, 2000);
    showToast("Fichier téléchargé : " + filename);
    return true;
  } catch (e) {
    console.error(e);
    showToast("Erreur export: " + (e.message || e));
    return false;
  }
}

async function exportProgramVideos() {
  if (!program || !program.days) {
    showToast("Aucun programme ouvert");
    return;
  }
  if (!USE_DISK || !window.yhDisk || !window.yhDisk.exportVideos) {
    showToast("Export vidéos disponible uniquement dans l'application exe");
    return;
  }
  const files = [];
  let idx = 0;
  (program.days || []).forEach((d, di) => {
    (d.exercises || []).forEach((ex, ei) => {
      const base = ((d.name || "J" + (di + 1)) + "_" + (ex.name || "ex" + (ei + 1))).replace(
        /\s+/g,
        "_",
      );
      if (ex.image && (isVideoMedia(ex.image) || isYhMediaRef(ex.image))) {
        idx++;
        const item = { name: String(idx).padStart(2, "0") + "_" + base };
        if (isYhMediaRef(ex.image)) item.ref = ex.image;
        else if (String(ex.image).startsWith("data:")) item.base64 = ex.image;
        files.push(item);
      }
      if (ex.compImage && (isVideoMedia(ex.compImage) || isYhMediaRef(ex.compImage))) {
        idx++;
        const item = { name: String(idx).padStart(2, "0") + "_" + base + "_comp" };
        if (isYhMediaRef(ex.compImage)) item.ref = ex.compImage;
        else if (String(ex.compImage).startsWith("data:")) item.base64 = ex.compImage;
        files.push(item);
      }
    });
  });
  if (!files.length) {
    showToast("Aucune vidéo dans ce programme");
    return;
  }
  showToast("Choisis le dossier de destination...");
  try {
    const res = await window.yhDisk.exportVideos(files);
    if (res && res.canceled) {
      showToast("Export annulé");
      return;
    }
    if (res && res.ok) {
      showToast(res.count + " vidéo(s) exportée(s)");
    } else {
      showToast("Échec export vidéos");
    }
  } catch (e) {
    console.error(e);
    showToast("Erreur export vidéos");
  }
}

async function exportProgramFile() {
  if (!program || !program.id) {
    showToast("Aucun programme ouvert à exporter");
    return;
  }
  try {
    showToast("Préparation de l'export (vidéos incluses)...");
    const packed = embedMediaInProgram(program);
    const name = "StriderPro_" + (program.athlete || "programme").replace(/\s+/g, "_") + ".json";
    const data = JSON.stringify(packed, null, 2);
    await downloadTextFile(name, data);
  } catch (e) {
    console.error(e);
    showToast("Export impossible (fichier trop lourd ?)");
  }
}

async function exportAllPrograms() {
  loadProgramsIndex();
  const list = [];
  for (const entry of programsIndex) {
    try {
      const p = loadProgramFromStorage(entry.id);
      if (p) list.push(embedMediaInProgram(p));
    } catch (e) {}
  }
  if (!list.length) {
    showToast("Aucun programme à exporter");
    return;
  }
  const payload = {
    yhcoachproBackup: true,
    version: 2,
    exportedAt: new Date().toISOString(),
    programs: list,
  };
  showToast("Export de " + list.length + " programme(s)...");
  await downloadTextFile("StriderPro_TOUS_les_programmes.json", JSON.stringify(payload, null, 2));
}

async function rehydrateProgramMedia(prog) {
  if (!prog || !prog.days) return prog;
  const fix = async (ref) => {
    if (!ref || typeof ref !== "string") return ref;
    if (ref.startsWith("data:video") || (ref.startsWith("data:") && ref.length > 150000)) {
      return await persistMediaIfNeeded(ref, true);
    }
    return ref;
  };
  for (const d of prog.days || []) {
    for (const ex of d.exercises || []) {
      if (ex.image) ex.image = await fix(ex.image);
      if (ex.compImage) ex.compImage = await fix(ex.compImage);
    }
  }
  return prog;
}

function importProgramFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const data = JSON.parse(reader.result);
      let programs = [];

      if (Array.isArray(data)) {
        programs = data;
      } else if (data && Array.isArray(data.programs)) {
        programs = data.programs;
      } else if (data && data.program && typeof data.program === "object") {
        programs = [data.program];
      } else if (
        data &&
        typeof data === "object" &&
        (data.athlete != null || data.days || data.id)
      ) {
        programs = [data];
      } else {
        throw new Error("format");
      }

      let ok = 0,
        lastId = null;
      showToast("Import en cours...");
      for (let prog of programs) {
        if (!prog || typeof prog !== "object") continue;
        if (!prog.id) prog.id = uid();
        prog.updatedAt = Date.now();
        prog.createdAt = prog.createdAt || Date.now();
        prog = await rehydrateProgramMedia(prog);
        if (saveProgramToStorage(prog)) {
          ok++;
          lastId = prog.id;
        }
      }
      loadProgramsIndex();
      renderProgramList();
      if (ok === 0) {
        showToast("Import échoué (stockage plein ou fichier invalide)");
      } else if (ok === 1 && lastId) {
        showToast("Programme importé (médias inclus)");
        openProgram(lastId);
      } else {
        showToast(ok + " programmes importés");
        showHome();
        showProgramsPanel();
      }
    } catch (e) {
      console.error(e);
      showToast("Fichier invalide — exporte un JSON depuis YhCoachPro");
    }
    input.value = "";
  };
  reader.onerror = () => {
    showToast("Impossible de lire le fichier");
    input.value = "";
  };
  reader.readAsText(file);
}
