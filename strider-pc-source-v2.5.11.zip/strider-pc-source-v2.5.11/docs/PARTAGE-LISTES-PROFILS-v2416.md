# Version 2.4.16 — Listes de profils personnalisées

Dans Profils → Partage, choisir tous les profils ou un groupe précis. La sélection de groupe du partage est indépendante du filtre d’affichage ; elle est visible et l’aperçu indique le nombre d’athlètes. Un athlète appartenant à plusieurs groupes apparaît une seule fois dans la liste de chacun des groupes auxquels il appartient. Un groupe vide n’exporte pas les autres athlètes ; un groupe supprimé rend l’export impossible jusqu’à un nouveau choix.

Nom et prénom restent obligatoires. Tous les autres champs sont à cocher ou décocher : naissance, taille, poids, maillot, poste, club, saison, téléphone, groupe sanguin, mesures, tests et notes. Les envergures 1 main et 2 mains sont distinctes. Seules les valeurs actuellement enregistrées sont utilisées, pas l’historique des tests. Par défaut, seuls les noms et prénoms sont cochés.

Raccourcis : Nom + prénom seuls ; Naissance + taille ; Maillot + envergure 2 mains. La case Envergure 1 main peut être ajoutée ou remplacer celle des 2 mains. L’aperçu se met à jour avant l’export. PDF, impression, HTML de lecture seule et JSON de liste n’incluent que la population et les colonnes choisies, sans ajouter d’autres champs en données cachées, ni photos, identifiants de profils, listes d’appartenance ou historiques.

Listes triées par nom de famille. PDF A4 portrait jusqu’à quatre colonnes, paysage au-delà. Les grandes listes s’étendent sur plusieurs pages avec en-têtes de colonnes répétés. Au-delà de six colonnes facultatives, le document est découpé en parties avec nom et prénom répétés, pour garder la lisibilité. Aucune réduction forcée à une page.

Les exports existants de fiche complète et la sauvegarde globale JSON restent accessibles dans le volet replié « Autres exports : fiche complète ou sauvegarde ». Ces exports sont expressément distincts de la liste personnalisée et ne suivent pas ses cases à cocher. Le JSON de liste n’est pas une sauvegarde complète. Le menu général conserve la sauvegarde des profils.

Les exports créent un fichier local ; aucun envoi automatique à une personne ou à un service. Faites attention aux informations de santé, téléphone et naissance avant de partager le fichier. Fonds, logos, protections de saisie F6, liste complète des profils et fiches de séance conservés.

Tests avec des données fictives dans Chromium et vérification des PDF générés. Les dialogues natifs d’enregistrement et d’impression Windows restent à valider sur votre ordinateur. Sauvegarder avant mise à jour, décompresser dans un dossier séparé et lancer DEMARRER-DEVELOPPEMENT.bat. Archive source, pas installateur compilé.
