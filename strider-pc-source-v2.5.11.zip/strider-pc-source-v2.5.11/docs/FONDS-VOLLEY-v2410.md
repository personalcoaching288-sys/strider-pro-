# Version 2.4.10 — Fonds volley

Première photo (ballon et filet) sur le tableau de bord. La bande sombre vide à droite a été retirée du fichier fourni. Le fond remplit l’écran sans déformation avec recadrage selon ses proportions. Deuxième photo (joueur au service) dans le menu latéral, débarrassée de ses grandes marges vides.

Images converties en WebP léger. Logo, voile sombre, transparence, mise en page, autres fonds, séances enregistrées et partage A4 restent inchangés.

Conserver la version précédente et faire une sauvegarde avant mise à jour. Tests navigateur paysage / portrait ; installation Windows à vérifier sur votre ordinateur. Projet source avec scripts de lancement, pas un installateur compilé.
